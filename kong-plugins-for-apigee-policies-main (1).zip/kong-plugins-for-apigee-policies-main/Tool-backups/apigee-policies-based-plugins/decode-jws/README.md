## Kong Plugin: decode-jws

This is a placeholder README for the decode-jws plugin. Please document usage, configuration, and lifecycle here.