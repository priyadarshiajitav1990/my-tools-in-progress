# Kong Plugin: external_callout

Calls an external HTTP service with configurable method, headers, and body source.

## Features
- Configurable HTTP callout
- Flexible request body source
- Error handling options
