Test helpers for Kong-EE (integration) tests
============================================

See `spec/README.md` on how to render the test documentation.
