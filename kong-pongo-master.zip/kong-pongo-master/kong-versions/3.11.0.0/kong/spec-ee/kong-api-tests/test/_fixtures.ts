export async function mochaGlobalSetup() {
  // global setup goes here
}

export function mochaGlobalTeardown() {
  // global teardown goes here
}
