import axios from 'axios';
import {
  expect,
  Environment,
  getBasePath,
  postNegative,
  createGatewayService,
  deleteGatewayService,
  createRouteForService,
  deleteGatewayRoute,
  randomString,
  logResponse,
  getHttpLogServerLogs,
  getSplunkServerHttpLogs,
  eventually,
  waitForConfigRebuild,
  deleteHttpLogServerLogs,
  deleteSplunkServerHttpLogs,
  isGateway,
  checkForArm64
} from '@support';

describe('@oss: Gateway Plugins: http-log', function () {
  const path = `/${randomString()}`;

  let serviceId: string;
  let routeId: string;
  let pluginId: string;
  let basePayload: any;
  let httpLogServerUrl: string;
  let serverLogs: any;

  const url = `${getBasePath({
    environment: isGateway() ? Environment.gateway.admin : undefined,
  })}/plugins`;
  const proxyUrl = `${getBasePath({
    app: 'gateway',
    environment: Environment.gateway.proxy,
  })}`;

  const forbiddenHeaders = ['Host', 'Content-Length', 'Content-Type'];
  const pluginConfigHeaders = ['PUT', 'PATCH'];
  const customHeaderName = 'X-Custom-Myheader';
  const splunkServerInfo = {
    url: 'https://splunk:8088/services/collector/raw',
    headers: {  
      "Authorization": "Splunk 819F80D7BFB0"
    }
  };

  before(async function () {
    const service = await createGatewayService(randomString());
    serviceId = service.id;
    const route = await createRouteForService(serviceId, [path]);
    routeId = route.id;

    await deleteHttpLogServerLogs();
    if (!checkForArm64()) {
      await eventually(async () => {//Need wait the splunk server is ready
        await deleteSplunkServerHttpLogs(); //Note: Run the step only on non-ARM architecture, as the Splunk server is only supported on this architecture.
        })
    }
    
    httpLogServerUrl = 'http://http-log-server:9300/logs';

    basePayload = {
      name: 'http-log',
      service: {
        id: serviceId,
      },
      route: {
        id: routeId,
      },
    };
  });

  context('http-log with http log serveer', function () {
  it('should not create http-log plugin without config.http_endpoint', async function () {
    const resp = await postNegative(url, basePayload);
    logResponse(resp);

    expect(resp.status, 'Status should be 400').to.equal(400);
    expect(resp.data.message, 'Should have correct error message').to.contain(
      `schema violation (config.http_endpoint: required field missing)`
    );
  });

  it('should not create http-log plugin with both Authorization header and userinfo in URL', async function () {
    const pluginPayload = {
      ...basePayload,
      config: {
        http_endpoint: 'http://hi:there@myservice.com/path',
        // must also validate casing
        headers: { AuthoRIZATion: 'test' },
      },
    };
    const resp = await postNegative(url, pluginPayload);
    logResponse(resp);

    expect(resp.status, 'Status should be 400').to.equal(400);
    expect(resp.data.message, 'Should have correct error message').to.contain(
      `specifying both an 'Authorization' header and user info in 'http_endpoint' is not allowed`
    );
  });

  forbiddenHeaders.forEach((header) => {
    it(`should not create http-log plugin with ${header} header`, async function () {
      const pluginPayload = {
        ...basePayload,
        config: {
          http_endpoint: httpLogServerUrl,
          headers: { [header]: 'test' },
        },
      };
      const resp = await postNegative(url, pluginPayload);
      logResponse(resp);

      expect(resp.status, 'Status should be 400').to.equal(400);
      expect(resp.data.message, 'Should have correct error message').to.contain(
        `schema violation (config.headers: cannot contain '${header}' header)`
      );
    });
  });

  it('should create http-log plugin with http-log endpoint', async function () {
    const pluginPayload = {
      ...basePayload,
      config: {
        http_endpoint: httpLogServerUrl,
      },
    };

    const resp = await axios({ method: 'post', url, data: pluginPayload });
    logResponse(resp);

    expect(resp.status, 'Status should be 201').to.equal(201);
    expect(
      resp.data.config.http_endpoint,
      'Should have correct http_endpoint'
    ).to.eq(httpLogServerUrl);

    pluginId = resp.data.id;
    await waitForConfigRebuild()
  });

  it('should send http request logs to http_endpoint', async function () {
    const resp = await axios(`${proxyUrl}${path}`);
    logResponse(resp);

    expect(resp.status, 'Status should be 200').to.equal(200);

    
    await eventually(async () => {
      serverLogs = await getHttpLogServerLogs()
      expect(
        serverLogs[0]?.reqMethod,
        'Should use POST method to log request data'
      ).to.eq('POST');
    });
  });

  it('should send http request random header details to http_endpoint', async function () {
    const resp = await axios({
      url: `${proxyUrl}${path}`,
      headers: { test: 'test' },
    });
    logResponse(resp);

    expect(resp.status, 'Status should be 200').to.equal(200);

    await eventually(async () => {
      serverLogs = await getHttpLogServerLogs();
      // always take the last item of http-log server entries as it represents the last request logs
      const requestDetails = serverLogs?.pop()?.reqBody

      expect(
        requestDetails?.request.method,
        'Should see correct kong request method in logs'
      ).to.eq('GET');
      expect(
        requestDetails?.request.headers.test,
        'Should see correct kong request header in logs'
      ).to.eq('test');
      expect(
        requestDetails?.route.paths[0],
        'Should see correct kong request route path in logs'
      ).to.eq(path);
      expect(
        requestDetails?.service.path,
        'Should see correct kong request service path in logs'
      ).to.eq('/anything');
    });
  });

  pluginConfigHeaders.forEach((pluginConfigHeader) => {
    it(`should patch the http-log plugin method to ${pluginConfigHeader}`, async function () {
      const resp = await axios({
        method: 'patch',
        url: `${url}/${pluginId}`,
        data: {
          config: {
            method: pluginConfigHeader,
          },
        },
      });
      logResponse(resp);

      expect(resp.status, 'Status should be 200').to.equal(200);
      expect(
        resp.data.config.method,
        'Should see correct patched method'
      ).to.eq(pluginConfigHeader);

      await waitForConfigRebuild()
    });

    it(`should see request logs in http_endpoint with the new ${pluginConfigHeader} method`, async function () {
      const resp = await axios({
        url: `${proxyUrl}${path}`,
      });
      logResponse(resp);

      expect(resp.status, 'Status should be 200').to.equal(200);

      await eventually(async () => {
        serverLogs = await getHttpLogServerLogs();

        expect(
          serverLogs?.pop()?.reqMethod,
          `Should use ${pluginConfigHeader} method to log request data`
        ).to.eq(pluginConfigHeader);
      });
    });
  });

  it('should send resolved custom_fields_by_lua value to http_endpoint', async function () {
    let resp = await axios({
      method: 'patch',
      url: `${url}/${pluginId}`,
      data: {
        config: {
          custom_fields_by_lua: {
            kong: `return 'http-log plugin api test'`,
          },
          headers: { [customHeaderName]: 'test2' },
        },
      },
    });
    logResponse(resp);

    expect(
      resp.data.config.custom_fields_by_lua.kong,
      'Should see correct patched method'
    ).to.eq(`return 'http-log plugin api test'`);

    await waitForConfigRebuild()

    resp = await axios(`${proxyUrl}${path}`);
    logResponse(resp);

    expect(resp.status, 'Status should be 200').to.equal(200);

    await eventually(async () => {
      serverLogs = await getHttpLogServerLogs();
      const requestDetails = serverLogs?.pop()?.reqBody

      expect(
        requestDetails?.kong,
        'Should see return value of custom_fields_by_lua'
      ).to.eq('http-log plugin api test');
    });
  });

  // skipped due to https://konghq.atlassian.net/browse/KAG-503
  it.skip('should see http-log plugin X-header log in http_endpoint', async function () {
    serverLogs = await getHttpLogServerLogs();
    // always take the last item of http-log entries as it represents the last request logs
    const logHeaders = serverLogs[serverLogs.length - 1]?.reqBody.request.headers;

    expect(
      logHeaders?.some((headerObject) => {
        return (
          headerObject.name === customHeaderName.toLowerCase() &&
          headerObject.value === 'test2'
        );
      }),
      `Should see the correct plugin custom x header in request logs`
    ).to.be.true;
  });

  });

  //Note: Run the tests only on non-ARM architecture, as the Splunk server is only supported on this architecture.
  if (!checkForArm64()) {
    context('http-log with Splunk', function () {
      it('should create http-log plugin with http-log endpoint about Splunk server', async function () {
        const resp = await axios({
          method: 'patch',
          url: `${url}/${pluginId}`,
          data: {
            config: {
              "custom_fields_by_lua": null, //Reset the custom_fields_by_lua value
              method: 'POST',  //Reset the method value
              http_endpoint: splunkServerInfo.url,
              headers: splunkServerInfo.headers            
            },
          },
        });
        logResponse(resp);
        expect(resp.status, 'Status should be 200').to.equal(200);
        expect(
          resp.data.config.http_endpoint,
          'Should have correct http_endpoint'
        ).to.eq(splunkServerInfo.url);
        pluginId = resp.data.id;
        await waitForConfigRebuild()
      });
  
      it('should send http request logs to http_endpoint about Splunk server', async function () {
        const resp = await axios(`${proxyUrl}${path}`);
        logResponse(resp);
        expect(resp.status, 'Status should be 200').to.equal(200);
        await eventually(async () => {
          serverLogs = await getSplunkServerHttpLogs()
          expect(
            (JSON.parse(serverLogs.results[0]?._raw)).request.uri,
            `Path in log about request data should equal $path`
          ).to.eq(path);
        });
      });
  });
  }
    
  it('should delete the http-log plugin by id', async function () {
    const resp = await axios({
      method: 'delete',
      url: `${url}/${pluginId}`,
    });
    logResponse(resp);
    expect(resp.status, 'Status should be 204').to.equal(204);
  });

  after(async function () {
    await deleteGatewayRoute(routeId);
    await deleteGatewayService(serviceId);
    await deleteHttpLogServerLogs();
    if (!checkForArm64()) {
      await deleteSplunkServerHttpLogs(); //Note: Run the step only on non-ARM architecture, as the Splunk server is only supported on this architecture.
    }
  });
});
