import sys
import logging
from scripts.core.deck_validate import validations

def validate_and_exit():
    # Validate the generated Kong configuration file using decK.
    validation_passed = validations()
    if not validation_passed:
        logging.error("Halting migration due to failed deck validation.")
        logging.error("--- Migration FAILED ---")
        sys.exit(1)