import time
from scripts.post.report_data import ReportData

def initialize_report():
    report_data = ReportData()
    report_data.start_time = time.time()
    return report_data

def finalize_report_data(report_data):
    report_data.end_time = time.time()

def print_migration_summary(report_data):
    if report_data.mappings:
        print("\n--- Entity Mappings ---")
        for mapping in report_data.mappings:
            print(f"  - {mapping['apigee_type']} '{mapping['apigee_name']}' -> {mapping['kong_type']} '{mapping['kong_name']}'")
    else:
        print("\nNo entity mappings generated.")