import os
import xml.etree.ElementTree as ET
import yaml
import logging
import json
from urllib.parse import urlparse

# Finds all target endpoint XML files within the extracted API proxy bundle.
def find_target_endpoints(project_root, extracted_api_dir, api_name):
    targets_path = os.path.join(project_root, extracted_api_dir, api_name, "apiproxy", "targets")
    logging.info(f"Searching for target endpoints in: '{targets_path}'")

    if not os.path.isdir(targets_path):
        logging.warning(f"Target endpoints directory not found at '{targets_path}'. Skipping.")
        return []

    target_files = [os.path.join(targets_path, f) for f in os.listdir(targets_path) if f.endswith(".xml")]
    logging.info(f"Found {len(target_files)} target endpoint(s).")
    return target_files

# Loads pre-fetched TargetServer details from the local JSON file.
def load_local_targetservers(project_root):
    targetservers_path = os.path.join(project_root, "configs", "targetservers.json")
    if not os.path.exists(targetservers_path):
        logging.warning("Local 'targetservers.json' not found. TargetServer lookups will fail.")
        return {}
    
    with open(targetservers_path, 'r') as f:
        return json.load(f)

# Retrieves TargetServer details from the pre-fetched local data.
def get_target_server_details(server_name, local_targetservers):
    server_details = local_targetservers.get(server_name)
    if server_details:
        logging.info(f"    - Found TargetServer '{server_name}' in local data.")
        return server_details.get('host'), server_details.get('port')
    else:
        logging.warning(f"    - TargetServer '{server_name}' not found in local data. Using default.")
        parsed_default = urlparse("http://change_backend_url.com")
        return parsed_default.hostname, parsed_default.port or 80

# Parses target endpoint files and generates a Kong services YAML file.
def create_kong_services_yaml(project_root, output_dir, api_name, target_files, report_data):
    if not target_files:
        logging.info("No target endpoints found to process.")
        return

    local_targetservers = load_local_targetservers(project_root)

    kong_upstreams = []
    kong_services = []
    for target_file in target_files:
        try:
            tree = ET.parse(target_file)
            root = tree.getroot()
            http_conn = root.find('.//HTTPTargetConnection')
            if http_conn is None:
                continue
            
            # Derive the target endpoint name from its filename
            target_name = os.path.splitext(os.path.basename(target_file))[0]
            report_data.add_apigee_entity("TargetEndpoint", target_name)
            service_name = f"srv-{api_name}-{target_name}"
            service = {'name': service_name}

            # Case 1: Direct URL configuration
            url_element = http_conn.find('URL')
            if url_element is not None:
                logging.info(f"  - Found direct URL in target '{target_name}'")
                backend_url = url_element.text
                parsed_url = urlparse(backend_url)
                service.update({
                    'protocol': parsed_url.scheme or 'http',
                    'host': parsed_url.hostname,
                    'port': parsed_url.port or (443 if parsed_url.scheme == 'https' else 80),
                    'path': parsed_url.path
                })

                report_data.add_kong_entity("service", service_name)
                report_data.add_mapping("Apigee TargetEndpoint", target_name, "Kong Service", service_name)
            # Case 2: LoadBalancer with TargetServers configuration
            lb_element = http_conn.find('LoadBalancer')
            if lb_element is not None:
                logging.info(f"  - Found LoadBalancer in target '{target_name}'")
                upstream_name = f"up-{api_name}-{target_name}"
                
                # Set the service to point to the upstream
                service.update({
                    'protocol': 'http', # Protocol is managed by the upstream
                    'host': upstream_name
                })
                report_data.add_kong_entity("service", service_name)
                report_data.add_mapping("Apigee TargetEndpoint", target_name, "Kong Service", service_name)
                path_element = http_conn.find('Path')
                if path_element is not None:
                    service['path'] = path_element.text

                # Create the upstream object
                upstream = {'name': upstream_name, 'targets': []}
                
                # Map Apigee algorithm to Kong's - default to round-robin
                algo_element = lb_element.find('Algorithm')
                apigee_algo = algo_element.text.lower() if algo_element is not None else 'roundrobin'
                kong_algo_map = {
                    'roundrobin': 'round-robin',
                    'weighted': 'round-robin', # Kong handles weight on the target level
                    'leastconnection': 'least-connections'
                }
                upstream['algorithm'] = kong_algo_map.get(apigee_algo, 'round-robin')
                logging.info(f"    - Algorithm: '{apigee_algo}' -> Kong: '{upstream['algorithm']}'")

                # Add servers as targets to the upstream
                for server in lb_element.findall('Server'):
                    # Handle servers defined by name (requires API call)
                    if 'name' in server.attrib:
                        host, port = get_target_server_details(server.attrib['name'], local_targetservers)
                    # Handle servers defined inline
                    elif server.find('Host') is not None and server.find('Port') is not None:
                        host = server.find('Host').text
                        port = server.find('Port').text
                    else:
                        continue # Skip malformed server entries

                    target_string = f"{host}:{port}"
                    upstream['targets'].append({'target': target_string})
                    logging.info(f"    - Added target: {target_string}")
                
                report_data.add_kong_entity("upstream", upstream_name)
                kong_upstreams.append(upstream)

            kong_services.append(service)
            logging.info(f"  - Generated service '{service_name}' for target '{target_name}'")

        except ET.ParseError as e:
            logging.warning(f"Could not parse XML file '{target_file}'. Error: {e}")

    # Prepare the final YAML structure
    output_data = {'services': kong_services}
    if kong_upstreams:
        output_data['upstreams'] = kong_upstreams

    # Write the configuration to the Kong YAML file
    output_file_name = f"kong-{api_name}.yml"
    output_path = os.path.join(project_root, output_dir, output_file_name)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    with open(output_path, 'w') as f:
        yaml.dump(output_data, f, sort_keys=False, indent=2)
    
    logging.info(f"Kong services and upstreams configuration written to '{output_path}'")

# Orchestrates the migration of Apigee target endpoints to Kong services.
def migrate_targetendpoints(report_data=None):
    logging.info("--- Starting Target Endpoint Migration ---")
    # Get config values from environment variables
    api_name = os.environ.get("api_name")
    extracted_api_dir = os.environ.get("extracted_api_dir")
    output_dir = os.environ.get("output_dir")
    
    # Check for required configs
    if not all([api_name, extracted_api_dir, output_dir]):
        logging.error("Missing required configuration for target endpoint migration. Skipping.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    target_files = find_target_endpoints(project_root, extracted_api_dir, api_name)
    create_kong_services_yaml(project_root, output_dir, api_name, target_files, report_data)