import os
import json
import logging
import xml.etree.ElementTree as ET
import yaml
import importlib
from jinja2 import Environment, FileSystemLoader

# --- Configuration Loading ---

def load_policy_mappings(project_root):
    """
    Loads the Apigee policy to Kong plugin mappings from the JSON config file.
    """
    mapping_file_path = os.path.join(project_root, "mappers", "policy-to-plugin-mapper.json")
    if not os.path.exists(mapping_file_path):
        logging.warning("'policy-to-plugin-mapper.json' not found. Skipping policy migration.")
        return None

    try:
        with open(mapping_file_path, 'r') as f:
            mappings = json.load(f)
        if not mappings:
            logging.warning("'policy-to-plugin-mapper.json' is empty. Skipping policy migration.")
            return None
        logging.info("Successfully loaded policy-to-plugin mappings.")
        return mappings
    except json.JSONDecodeError:
        logging.error(f"Could not decode JSON from '{mapping_file_path}'. Please check the file format. Skipping policy migration.")
        return None

# --- Helper Functions ---

def policy_xml_to_dict(element):
    """
    Recursively converts an XML element tree into a dictionary.
    This allows Jinja2 templates to access policy attributes easily.
    """
    node = {}
    # Capture text content if present
    if element.text and element.text.strip():
        node['text'] = element.text.strip()
    
    # Capture attributes
    node.update(element.attrib)

    # Recursively process children
    for child in element:
        child_data = policy_xml_to_dict(child)
        tag = child.tag
        
        if tag in node:
            # If tag exists, convert to list or append to list
            if not isinstance(node[tag], list):
                node[tag] = [node[tag]]
            node[tag].append(child_data)
        else:
            node[tag] = child_data
            
    return node

def get_policy_type_and_root(policy_name, policies_path):
    """
    Parses the policy XML file to determine its Apigee policy type (Root Element)
    and returns the XML root element.
    """
    policy_file = os.path.join(policies_path, f"{policy_name}.xml")
    if not os.path.exists(policy_file):
        logging.warning(f"    - Policy XML file not found: '{policy_file}'")
        return None, None

    try:
        tree = ET.parse(policy_file)
        root = tree.getroot()
        return root.tag, root
    except ET.ParseError:
        logging.warning(f"    - Could not parse policy XML: '{policy_file}'")
        return None, None

def sanitize_plugin_config(plugin_name, config):
    """
    Sanitizes the plugin configuration to satisfy Kong Schema requirements
    and remove unknown fields that cause validation errors.
    """
    # 1. Remove globally problematic fields
    if 'run_on_preflight' in config:
        del config['run_on_preflight']

    if plugin_name == 'oauth2':
        # Ensure at least one grant type is enabled
        grant_types = ['enable_authorization_code', 'enable_client_credentials', 'enable_implicit_grant', 'enable_password_grant']
        if not any(config.get(gt) is True for gt in grant_types):
            config['enable_client_credentials'] = True

    # 2. Plugin specific sanitization
    elif plugin_name == 'rate-limiting':
        # Ensure at least one limit is set
        if not any(k in config for k in ['second', 'minute', 'hour', 'day', 'month', 'year']):
            config['minute'] = 10 # Default
            
    elif plugin_name == 'rate-limiting-advanced':
        # Remove unknown fields reported by deck
        if 'limit_by' in config:
            del config['limit_by']
        # Add required fields
        if 'limit' not in config:
            config['limit'] = [10]
        if 'window_size' not in config:
            config['window_size'] = [60]
            
    elif plugin_name == 'oas-validation':
        for field in ['allowed_content_types', 'notify_only', 'validate_request_header']:
            if field in config:
                del config[field]
        if 'api_spec' not in config:
            config['api_spec'] = "openapi: 3.0.0\ninfo:\n  title: Placeholder\n  version: 1.0.0\npaths: {}"
            
    elif plugin_name == 'xml-threat-protection':
        # Remove Apigee-specific fields that don't map to Kong fields directly
        unknown_fields = [
            'max_attribute_name_length', 'max_attribute_value_length', 
            'max_attributes_per_node', 'max_children_per_node', 
            'max_comment_length', 'max_dtd_length', 
            'max_element_name_length', 'max_node_depth', 'max_pi_length'
        ]
        for field in unknown_fields:
            if field in config:
                del config[field]
                
    elif plugin_name == 'basic-auth':
        if 'verify_anonymous' in config:
            del config['verify_anonymous']
            
    elif plugin_name == 'http-log':
        if 'http_endpoint' not in config:
            config['http_endpoint'] = "http://localhost:8080"
            
    elif plugin_name == 'request-validator':
        # Fix: body_schema must be a JSON Schema Object, not an Array.
        # If body_schema is a list string (starts with '['), it is invalid for body_schema.
        if 'body_schema' in config and isinstance(config['body_schema'], str) and config['body_schema'].strip().startswith('['):
            del config['body_schema']

        if 'body_schema' not in config and 'parameter_schema' not in config:
            # Add a dummy parameter schema (Array format) to pass validation
            config['parameter_schema'] = [{
                "name": "placeholder-param",
                "in": "query",
                "required": False,
                "schema": '{"type": "string"}',
                "style": "form",
                "explode": True
            }]
            
    elif plugin_name == 'acl':
        if 'allow' not in config and 'deny' not in config:
            config['allow'] = ['all']
            
    elif plugin_name == 'ip-restriction':
        if 'allow' not in config and 'deny' not in config:
            config['allow'] = ['0.0.0.0/0']
            
    elif plugin_name == 'pre-function':
        if not any(k in config for k in ['certificate', 'rewrite', 'access', 'header_filter', 'body_filter', 'log']):
            config['access'] = ["-- no-op"]

    return config

def render_plugin_config(plugin_name, policy_data, project_root, config=None):
    """
    Renders the Jinja2 template for the given Kong plugin using the policy data.
    """
    templates_dir = os.path.join(project_root, "templates")
    template_file = f"{plugin_name}.yml.j2"
    
    if not os.path.exists(os.path.join(templates_dir, template_file)):
        logging.warning(f"    - Template not found for plugin '{plugin_name}'. Skipping configuration.")
        return None

    # Use provided config or default to empty dict to avoid 'undefined' errors in templates
    render_config = config if config is not None else {}

    try:
        env = Environment(loader=FileSystemLoader(templates_dir))
        template = env.get_template(template_file)
        
        # Render the template with the policy dictionary
        rendered_yaml = template.render(policy=policy_data, config=render_config)
        
        # Parse the rendered YAML string back to a Python dict
        plugin_config = yaml.safe_load(rendered_yaml)
        
        def clean_nones(value):
            """Recursively remove keys with None values."""
            if isinstance(value, dict):
                return {k: clean_nones(v) for k, v in value.items() if v is not None}
            elif isinstance(value, list):
                return [clean_nones(v) for v in value if v is not None]
            else:
                return value

        # Ensure it's a list (templates usually define a list of plugins) or a dict
        final_config = None
        if isinstance(plugin_config, list) and len(plugin_config) > 0:
            final_config = plugin_config[0] # Return the first plugin definition
        elif isinstance(plugin_config, dict):
            final_config = plugin_config
            
        if final_config:
            if 'config' not in final_config or final_config['config'] is None:
                final_config['config'] = {}
            
            final_config = clean_nones(final_config)
            
            # Sanitize Config (Fix Schema Violations)
            final_config['config'] = sanitize_plugin_config(final_config['name'], final_config['config'])
            
            return final_config
            
        return None

    except Exception as e:
        logging.error(f"    - Failed to render template for '{plugin_name}': {e}")
        return None

# --- Core Migration Logic ---

def attach_plugin_to_entity(entity, plugin_config, entity_name):
    """
    Attaches a plugin to a Kong entity (Service or Route), ensuring no duplicates
    if the plugin type doesn't support it or if it's an exact match.
    """
    plugins = entity.setdefault('plugins', [])
    plugin_name = plugin_config['name']
    
    # Skip plugins known to be disabled or unavailable
    if plugin_name in ['xml-to-json']:
        logging.warning(f"      ! Plugin '{plugin_name}' is known to be disabled/unavailable on target Gateway. Skipping.")
        return
    
    # Check for existing plugin of the same type
    existing_plugin = next((p for p in plugins if p['name'] == plugin_name), None)
    
    if existing_plugin:
        # If exact duplicate (same config), just skip
        if existing_plugin == plugin_config:
            logging.info(f"      - Plugin '{plugin_name}' already attached to '{entity_name}' with identical config. Skipping duplicate.")
            return
        
        # If different config, we have a collision.
        # Most Kong OSS plugins do not support multiple instances on the same scope.
        logging.warning(f"      ! Plugin '{plugin_name}' already exists on '{entity_name}'. Skipping additional instance to prevent 'entity already exists' errors.")
        logging.warning(f"        - Existing config: {existing_plugin.get('config')}")
        logging.warning(f"        - Skipped config: {plugin_config.get('config')}")
        return

    plugins.append(plugin_config)

def process_flow_steps(flow_element, flow_phase, entity_type, entity_name, output_data, api_name, policies_path, policy_mappings, project_root, kong_objects, kong_object_name, report_data=None):
    """
    Iterates through Steps in a Flow (Request or Response), maps them to plugins, and attaches them.
    """
    if flow_element is None:
        return

    for step in flow_element.findall('Step'):
        policy_name_element = step.find('Name')
        condition_element = step.find('Condition') # Capture condition if present
        
        if policy_name_element is None:
            continue
        
        policy_name = policy_name_element.text
        
        # 1. Determine Policy Type from XML
        policy_type, policy_root = get_policy_type_and_root(policy_name, policies_path)
        if not policy_type:
            continue

        # 2. Convert Policy XML to Dict for Template
        policy_data = policy_xml_to_dict(policy_root)
        policy_data['_condition'] = condition_element.text if condition_element is not None else None
        policy_data['_flow_phase'] = flow_phase

        # 3. Try to use a specific Python Mapper for this policy type
        # This allows for complex logic defined in scripts/policies_mappers/
        plugin_config_obj = None
        try:
            module_name = f"scripts.policies_mappers.{policy_type}"
            module = importlib.import_module(module_name)
            mapper_class = getattr(module, policy_type)
            # Instantiate mapper with the policy root element
            mapper = mapper_class(policy_root)
            plugin_config_obj = mapper.map()
            if plugin_config_obj:
                logging.info(f"    - Mapped Policy '{policy_name}' using Python mapper '{policy_type}'")
        except (ImportError, AttributeError, Exception) as e:
            pass # Fallback to generic JSON mapping if python mapper fails or doesn't exist

        if plugin_config_obj:
            # If Python mapper succeeded, attach and continue
            pass
        else:
            # 4. Fallback: Find Mapping in JSON
            # 2. Find Mapping in JSON
            # The mapper is a list of dicts: [{"apigeePolicy": "...", "plugins": {...}}]
            mapping_entry = next((item for item in policy_mappings if item["apigeePolicy"] == policy_type), None)
            
            if not mapping_entry or not mapping_entry.get("plugins"):
                # logging.debug(f"    - No mapping found for policy type '{policy_type}'.")
                continue

            plugins_map = mapping_entry["plugins"]
            
            # 3. Determine Plugin based on Flow Phase (request/response)
            plugin_def = plugins_map.get(flow_phase)
            
            # Fallback: If mapped to 'request' but we are in 'response' (or vice versa) and no specific mapping exists,
            # check if the other phase is available and generic enough? 
            # For now, strict mapping based on phase.
            if not plugin_def:
                # Try to find a default if specific phase is missing but plugin is applicable?
                # Some plugins like 'rate-limiting' are usually 'request' but might be placed anywhere in Apigee.
                # If the mapper only defines 'request', we use it.
                if "request" in plugins_map:
                    plugin_def = plugins_map["request"]
                elif "response" in plugins_map:
                    plugin_def = plugins_map["response"]
            
            if not plugin_def or not plugin_def.get("plugin"):
                continue

            kong_plugin_name = plugin_def["plugin"]
            logging.info(f"    - Mapping Policy '{policy_name}' ({policy_type}) -> Plugin '{kong_plugin_name}' ({flow_phase})")

            if report_data is not None:
                report_data.add_mapping(
                    f"Policy ({policy_type})", 
                    policy_name, 
                    f"Plugin ({flow_phase})", 
                    f"{kong_plugin_name} (on {entity_type} '{entity_name}')"
                )

            # 5. Render Template with empty config (safe default)
            plugin_config_obj = render_plugin_config(kong_plugin_name, policy_data, project_root, config={})
        
        if not plugin_config_obj:
            # If template rendering failed or returned empty, create a basic scaffold
            plugin_config_obj = {'name': kong_plugin_name, 'config': {}, 'enabled': True}

        # 6. Attach to Kong Object
        if entity_type == "service":
            service = next((s for s in kong_objects if s['name'] == kong_object_name), None)
            if service:
                attach_plugin_to_entity(service, plugin_config_obj, kong_object_name)
                logging.info(f"      - Attached to Service: {kong_object_name}")
            else:
                logging.warning(f"      - Service '{kong_object_name}' not found. Plugin '{kong_plugin_name}' not attached.")
        else: # Route
            route_prefix = f"rt-{api_name}-{entity_name}-"
            attached_count = 0
            for route in output_data.get('routes', []):
                if route['name'].startswith(route_prefix):
                    attach_plugin_to_entity(route, plugin_config_obj, route['name'])
                    attached_count += 1
            
            if attached_count > 0:
                logging.info(f"      - Attached to {attached_count} Route(s) for Proxy '{entity_name}'")
            else:
                logging.warning(f"      - No routes found for Proxy '{entity_name}'. Plugin '{kong_plugin_name}' not attached.")

def migrate_entity_policies(entity_type, entity_name, entity_root, output_data, api_name, policies_path, policy_mappings, project_root, report_data=None):
    """
    Orchestrates policy migration for a specific Proxy or Target Endpoint.
    """
    logging.info(f"  - Processing {entity_type} endpoint: {entity_name}")

    # Determine the Kong object (service or route) and its name
    kong_objects = []
    kong_object_name = ""
    
    if entity_type == "service":
        kong_object_name = f"srv-{api_name}-{entity_name}"
        kong_objects = output_data.get('services', [])
    else: 
        # For routes, we attach to all routes generated for this proxy endpoint
        kong_objects = output_data.get('routes', [])

    # Collect all Flows: PreFlow, PostFlow, and Named Flows
    flows_to_process = []
    
    # PreFlow
    pre_flow = entity_root.find('PreFlow')
    if pre_flow is not None:
        flows_to_process.append(pre_flow)
        
    # Conditional Flows (Flows/Flow)
    flows_container = entity_root.find('Flows')
    if flows_container is not None:
        for flow in flows_container.findall('Flow'):
            flows_to_process.append(flow)
            
    # PostFlow
    post_flow = entity_root.find('PostFlow')
    if post_flow is not None:
        flows_to_process.append(post_flow)

    # Iterate over all collected flows
    for flow_element in flows_to_process:
        # Process Request Pipeline
        request_element = flow_element.find('Request')
        process_flow_steps(request_element, "request", entity_type, entity_name, output_data, api_name, policies_path, policy_mappings, project_root, kong_objects, kong_object_name, report_data)
        
        # Process Response Pipeline
        response_element = flow_element.find('Response')
        process_flow_steps(response_element, "response", entity_type, entity_name, output_data, api_name, policies_path, policy_mappings, project_root, kong_objects, kong_object_name, report_data)

def migrate_policies(report_data=None):
    """
    Orchestrates the entire policy migration process.
    """
    logging.info("--- Starting Policy Migration ---")
    api_name = os.environ.get("api_name")
    extracted_api_dir = os.environ.get("extracted_api_dir")
    output_dir = os.environ.get("output_dir")

    if not all([api_name, extracted_api_dir, output_dir]):
        logging.error("Missing required configuration for policy migration. Skipping.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    policy_mappings = load_policy_mappings(project_root)
    if not policy_mappings:
        return

    # Paths
    api_base_path = os.path.join(project_root, extracted_api_dir, api_name, "apiproxy")
    policies_path = os.path.join(api_base_path, "policies")
    proxies_path = os.path.join(api_base_path, "proxies")
    targets_path = os.path.join(api_base_path, "targets")
    output_path = os.path.join(project_root, output_dir, f"kong-{api_name}.yml")

    # Load the generated Kong YAML file to modify it
    try:
        with open(output_path, 'r') as f:
            output_data = yaml.safe_load(f) or {}
    except FileNotFoundError:
        logging.error(f"Kong YAML file not found at '{output_path}'. Cannot migrate policies.")
        return

    # 1. Migrate policies from Target Endpoints (attach to Services)
    for filename in os.listdir(targets_path):
        if filename.endswith(".xml"):
            entity_name = os.path.splitext(filename)[0]
            tree = ET.parse(os.path.join(targets_path, filename))
            migrate_entity_policies("service", entity_name, tree.getroot(), output_data, api_name, policies_path, policy_mappings, project_root, report_data)

    # 2. Migrate policies from Proxy Endpoints (attach to Routes)
    for filename in os.listdir(proxies_path):
        if filename.endswith(".xml"):
            entity_name = os.path.splitext(filename)[0]
            tree = ET.parse(os.path.join(proxies_path, filename))
            migrate_entity_policies("route", entity_name, tree.getroot(), output_data, api_name, policies_path, policy_mappings, project_root, report_data)

    # Write the updated configuration back to the file
    with open(output_path, 'w') as f:
        yaml.dump(output_data, f, sort_keys=False, indent=2)
    
    logging.info("Policy migration complete. Updated Kong configuration file.")