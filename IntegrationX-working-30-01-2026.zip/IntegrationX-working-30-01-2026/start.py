import logging
import os
import sys
from scripts.utils.logger_config import setup_logging
from scripts.utils.config_loader import load_and_set_env_variables
from scripts.pre.apigee_targetservers_info import apigee_targetservers
from scripts.pre.extract_apigee_api import extract_apigee_api
from scripts.pre.create_templates import create_plugin_templates
from scripts.core.targetendpoints import migrate_targetendpoints
from scripts.core.proxyendpoints import migrate_proxyendpoints
from scripts.utils.vars_expressions_converter import convert_apigee_expressions
from scripts.core.policy_migration import migrate_policies
from scripts.post.generate_report import generate_report
from scripts.utils.report_utils import initialize_report, finalize_report_data, print_migration_summary
from scripts.utils.validation_utils import validate_and_exit

def main():
    report_data = initialize_report()

    # Initialize the logging system for the application.
    setup_logging()
    
    logging.info("--- Apigee to Kong Migration Tool ---")
    logging.info(f"Current Working Directory: {os.getcwd()}")

    try:
        # Load all configurations from config.json into the environment.
        load_and_set_env_variables()

        # Fetch all Apigee TargetServer details for the environment.
        apigee_targetservers()

        # Find and extract the Apigee API zip file from the input directory.
        extract_apigee_api()

        # Ensure templates exist for all mapped plugins.
        create_plugin_templates()

        # Parse Apigee target endpoints and create corresponding Kong services and upstreams.
        migrate_targetendpoints(report_data)

        # Parse Apigee proxy endpoints and create corresponding Kong routes.
        migrate_proxyendpoints(report_data)

        # Convert Apigee-specific variables and expressions in the generated file to Kong format.
        convert_apigee_expressions()

        # Find and migrate Apigee policies to Kong plugins.
        migrate_policies(report_data)

        # Validate the generated Kong configuration file using decK.
        validate_and_exit()

        # Generate the final HTML report.
        finalize_report_data(report_data)
        generate_report()
        
        # --- This section will only be reached if all steps above succeed ---
        # Display entity mappings in the console
        print_migration_summary(report_data)
        
        logging.info("--- Migration Process Completed Successfully! ---")

    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}", exc_info=True) # Set to True for debugging
        logging.error("--- Migration FAILED ---")
        sys.exit(1)

if __name__ == "__main__":
    main()