package com.apigee.callout;

import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import java.util.UUID;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HeaderManipulator implements Execution {
    
    @Override
    public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {
        try {
            // Get request path and perform string operations
            String requestPath = messageContext.getVariable("proxy.pathsuffix");
            if (requestPath == null) {
                requestPath = "/default";
            }
            
            // String operations
            String upperPath = requestPath.toUpperCase();
            String lowerPath = requestPath.toLowerCase();
            String reversedPath = new StringBuilder(requestPath).reverse().toString();
            String pathLength = String.valueOf(requestPath.length());
            
            // Generate timestamp
            String timestamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(new Date());
            
            // Generate correlation ID
            String correlationId = UUID.randomUUID().toString();
            
            // Set 5 custom headers
            messageContext.setVariable("request.header.X-Request-Path-Upper", upperPath);
            messageContext.setVariable("request.header.X-Request-Path-Lower", lowerPath);
            messageContext.setVariable("request.header.X-Request-Path-Reversed", reversedPath);
            messageContext.setVariable("request.header.X-Request-Path-Length", pathLength);
            messageContext.setVariable("request.header.X-Correlation-ID", correlationId);
            
            // Set additional context variables
            messageContext.setVariable("custom.timestamp", timestamp);
            messageContext.setVariable("custom.processed", "true");
            
            return ExecutionResult.SUCCESS;
            
        } catch (Exception e) {
            messageContext.setVariable("custom.error", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
}
