#!/usr/bin/env python3
"""
API Contract Preserving Migration Engine
Ensures zero impact on API consumers during Apigee to Kong migration
"""

import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from collections import defaultdict

class APIContractPreservingEngine:
    def __init__(self, project_root: Path, config: Dict[str, Any]):
        self.logger = logging.getLogger(__name__)
        self.project_root = Path(project_root)
        self.config = config
        
        # Contract preservation rules
        self.preservation_rules = {
            'request_paths': True,
            'request_methods': True,
            'request_headers': True,
            'request_parameters': True,
            'response_status_codes': True,
            'response_headers': True,
            'response_content_types': True,
            'authentication_schemes': True,
            'rate_limiting_behavior': True,
            'error_response_formats': True
        }
        
        # Critical headers that must be preserved
        self.critical_headers = {
            'request': [
                'authorization', 'content-type', 'accept', 'user-agent',
                'x-api-key', 'x-forwarded-for', 'x-real-ip'
            ],
            'response': [
                'content-type', 'cache-control', 'etag', 'last-modified',
                'location', 'set-cookie', 'x-rate-limit-*'
            ]
        }
    
    def preserve_api_contract(self, apigee_config: Dict[str, Any], 
                            kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve API contract during migration"""
        
        preserved_config = kong_config.copy()
        
        try:
            # Extract API contract from Apigee
            apigee_contract = self._extract_complete_api_contract(apigee_config)
            
            # Apply contract preservation
            preserved_config = self._apply_path_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_method_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_header_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_auth_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_rate_limit_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_error_preservation(apigee_contract, preserved_config)
            preserved_config = self._apply_transformation_preservation(apigee_contract, preserved_config)
            
            # Add contract validation plugins
            preserved_config = self._add_contract_validation_plugins(apigee_contract, preserved_config)
            
            self.logger.info("API contract preservation completed successfully")
            
        except Exception as e:
            self.logger.error(f"API contract preservation failed: {e}")
            raise
        
        return preserved_config
    
    def _extract_complete_api_contract(self, apigee_config: Dict[str, Any]) -> Dict[str, Any]:
        """Extract complete API contract from Apigee configuration"""
        
        contract = {
            'api_name': apigee_config.get('api_name', 'unknown'),
            'base_paths': [],
            'routes': [],
            'methods': set(),
            'request_headers': defaultdict(list),
            'response_headers': defaultdict(list),
            'auth_requirements': [],
            'rate_limits': [],
            'transformations': {
                'request': [],
                'response': []
            },
            'error_responses': [],
            'content_types': {
                'request': set(),
                'response': set()
            },
            'status_codes': set()
        }
        
        # Extract from proxy endpoints
        for proxy in apigee_config.get('proxy_endpoints', []):
            base_path = proxy.get('base_path', '/')
            contract['base_paths'].append(base_path)
            
            # Extract routes from flows
            for flow in proxy.get('flows', []):
                route_info = self._extract_route_from_flow(flow, base_path)
                if route_info:
                    contract['routes'].append(route_info)
                    contract['methods'].update(route_info.get('methods', []))
        
        # Extract from policies
        for policy in apigee_config.get('policies', []):
            self._extract_contract_from_policy(policy, contract)
        
        # Convert sets to lists for JSON serialization
        contract['methods'] = list(contract['methods'])
        contract['content_types']['request'] = list(contract['content_types']['request'])
        contract['content_types']['response'] = list(contract['content_types']['response'])
        contract['status_codes'] = list(contract['status_codes'])
        
        return contract
    
    def _extract_route_from_flow(self, flow: Dict[str, Any], base_path: str) -> Optional[Dict[str, Any]]:
        """Extract route information from Apigee flow"""
        
        condition = flow.get('condition', '')
        if not condition:
            return None
        
        route_info = {
            'name': flow.get('name', 'unnamed'),
            'base_path': base_path,
            'paths': [],
            'methods': [],
            'conditions': condition
        }
        
        # Parse condition for path and method
        import re
        
        # Extract path patterns
        path_matches = re.findall(r'proxy\.pathsuffix\s+MatchesPath\s+"([^"]+)"', condition)
        for path_match in path_matches:
            full_path = f"{base_path.rstrip('/')}/{path_match.lstrip('/')}"
            route_info['paths'].append(full_path)
        
        # Extract methods
        method_matches = re.findall(r'request\.verb\s*=\s*"([^"]+)"', condition)
        route_info['methods'].extend(method_matches)
        
        # If no specific path, use base path
        if not route_info['paths']:
            route_info['paths'].append(base_path)
        
        # If no specific method, assume all methods
        if not route_info['methods']:
            route_info['methods'] = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS']
        
        return route_info
    
    def _extract_contract_from_policy(self, policy: Dict[str, Any], contract: Dict[str, Any]):
        """Extract contract information from Apigee policy"""
        
        policy_type = policy.get('policyType', '')
        policy_config = policy.get('config', {})
        
        # Authentication requirements
        if policy_type in ['VerifyAPIKey', 'OAuthV2', 'JWT', 'BasicAuthentication', 'SAML']:
            auth_info = {
                'type': policy_type,
                'name': policy.get('name', ''),
                'config': policy_config
            }
            contract['auth_requirements'].append(auth_info)
        
        # Rate limiting
        elif policy_type in ['Quota', 'SpikeArrest']:
            rate_limit_info = {
                'type': policy_type,
                'name': policy.get('name', ''),
                'config': policy_config
            }
            contract['rate_limits'].append(rate_limit_info)
        
        # Request/Response transformations
        elif policy_type == 'AssignMessage':
            transform_info = {
                'type': policy_type,
                'name': policy.get('name', ''),
                'config': policy_config
            }
            
            # Determine if it affects request or response
            if self._affects_request(policy_config):
                contract['transformations']['request'].append(transform_info)
            if self._affects_response(policy_config):
                contract['transformations']['response'].append(transform_info)
        
        # Content type transformations
        elif policy_type in ['JSONToXML', 'XMLToJSON']:
            transform_info = {
                'type': policy_type,
                'name': policy.get('name', ''),
                'config': policy_config
            }
            contract['transformations']['response'].append(transform_info)
            
            # Update content types
            if policy_type == 'JSONToXML':
                contract['content_types']['request'].add('application/json')
                contract['content_types']['response'].add('application/xml')
            elif policy_type == 'XMLToJSON':
                contract['content_types']['request'].add('application/xml')
                contract['content_types']['response'].add('application/json')
        
        # Error responses
        elif policy_type == 'RaiseFault':
            error_info = {
                'type': policy_type,
                'name': policy.get('name', ''),
                'status_code': policy_config.get('statusCode', 500),
                'message': policy_config.get('message', ''),
                'config': policy_config
            }
            contract['error_responses'].append(error_info)
            contract['status_codes'].add(error_info['status_code'])
    
    def _apply_path_preservation(self, apigee_contract: Dict[str, Any], 
                               kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Ensure all Apigee paths are preserved in Kong"""
        
        apigee_paths = set()
        for route in apigee_contract.get('routes', []):
            apigee_paths.update(route.get('paths', []))
        
        # Add base paths
        apigee_paths.update(apigee_contract.get('base_paths', []))
        
        # Check Kong routes
        kong_paths = set()
        for route in kong_config.get('routes', []):
            kong_paths.update(route.get('paths', []))
        
        # Add missing paths
        missing_paths = apigee_paths - kong_paths
        if missing_paths:
            self.logger.warning(f"Adding missing paths to preserve API contract: {missing_paths}")
            
            # Create additional routes for missing paths
            for missing_path in missing_paths:
                additional_route = {
                    'name': f"preserved-path-{len(kong_config.get('routes', []))}",
                    'paths': [missing_path],
                    'methods': list(apigee_contract.get('methods', ['GET'])),
                    'service': kong_config.get('routes', [{}])[0].get('service', {}),
                    'tags': ['contract-preservation', 'missing-path']
                }
                kong_config.setdefault('routes', []).append(additional_route)
        
        return kong_config
    
    def _apply_method_preservation(self, apigee_contract: Dict[str, Any], 
                                 kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Ensure all HTTP methods are preserved"""
        
        apigee_methods = set(apigee_contract.get('methods', []))
        
        # Update Kong routes to include all required methods
        for route in kong_config.get('routes', []):
            route_methods = set(route.get('methods', []))
            
            # If route has no methods specified, it accepts all methods
            if not route_methods:
                continue
            
            # Add missing methods
            missing_methods = apigee_methods - route_methods
            if missing_methods:
                route['methods'] = list(route_methods | missing_methods)
                self.logger.info(f"Added missing methods to route {route['name']}: {missing_methods}")
        
        return kong_config
    
    def _apply_header_preservation(self, apigee_contract: Dict[str, Any], 
                                 kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve critical headers"""
        
        # Add header preservation plugin if needed
        header_plugin = {
            'name': 'request-transformer',
            'config': {
                'add': {
                    'headers': []
                },
                'remove': {
                    'headers': []
                }
            },
            'tags': ['contract-preservation', 'header-preservation']
        }
        
        # Preserve critical request headers
        for header in self.critical_headers['request']:
            header_plugin['config']['add']['headers'].append(f"{header}:$(headers.{header})")
        
        # Add response header preservation
        response_header_plugin = {
            'name': 'response-transformer',
            'config': {
                'add': {
                    'headers': []
                }
            },
            'tags': ['contract-preservation', 'response-header-preservation']
        }
        
        # Add plugins to services
        for service in kong_config.get('services', []):
            service.setdefault('plugins', []).extend([header_plugin, response_header_plugin])
        
        return kong_config
    
    def _apply_auth_preservation(self, apigee_contract: Dict[str, Any], 
                               kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve authentication behavior"""
        
        auth_requirements = apigee_contract.get('auth_requirements', [])
        
        for auth_req in auth_requirements:
            auth_type = auth_req.get('type', '')
            
            # Ensure corresponding Kong auth plugin exists
            auth_plugin_name = self._map_auth_type_to_kong_plugin(auth_type)
            
            # Check if auth plugin exists
            auth_plugin_exists = False
            for plugin in kong_config.get('plugins', []):
                if plugin.get('name') == auth_plugin_name:
                    auth_plugin_exists = True
                    break
            
            if not auth_plugin_exists:
                # Add missing auth plugin
                auth_plugin = self._create_auth_plugin(auth_type, auth_req.get('config', {}))
                if auth_plugin:
                    kong_config.setdefault('plugins', []).append(auth_plugin)
                    self.logger.info(f"Added missing auth plugin: {auth_plugin_name}")
        
        return kong_config
    
    def _apply_rate_limit_preservation(self, apigee_contract: Dict[str, Any], 
                                     kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve rate limiting behavior"""
        
        rate_limits = apigee_contract.get('rate_limits', [])
        
        for rate_limit in rate_limits:
            limit_type = rate_limit.get('type', '')
            limit_config = rate_limit.get('config', {})
            
            # Create Kong rate limiting plugin
            if limit_type == 'Quota':
                rate_plugin = {
                    'name': 'rate-limiting',
                    'config': {
                        'minute': limit_config.get('count', 100),
                        'policy': 'local',
                        'fault_tolerant': True
                    },
                    'tags': ['contract-preservation', 'rate-limiting']
                }
                kong_config.setdefault('plugins', []).append(rate_plugin)
            
            elif limit_type == 'SpikeArrest':
                spike_plugin = {
                    'name': 'rate-limiting',
                    'config': {
                        'second': limit_config.get('rate', 10),
                        'policy': 'local',
                        'fault_tolerant': True
                    },
                    'tags': ['contract-preservation', 'spike-arrest']
                }
                kong_config.setdefault('plugins', []).append(spike_plugin)
        
        return kong_config
    
    def _apply_error_preservation(self, apigee_contract: Dict[str, Any], 
                                kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve error response behavior"""
        
        error_responses = apigee_contract.get('error_responses', [])
        
        for error_response in error_responses:
            status_code = error_response.get('status_code', 500)
            message = error_response.get('message', 'Internal Server Error')
            
            # Create request termination plugin for custom errors
            error_plugin = {
                'name': 'request-termination',
                'config': {
                    'status_code': status_code,
                    'message': message
                },
                'tags': ['contract-preservation', 'error-handling']
            }
            
            # Add condition-based error handling if needed
            kong_config.setdefault('plugins', []).append(error_plugin)
        
        return kong_config
    
    def _apply_transformation_preservation(self, apigee_contract: Dict[str, Any], 
                                         kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve request/response transformations"""
        
        request_transforms = apigee_contract.get('transformations', {}).get('request', [])
        response_transforms = apigee_contract.get('transformations', {}).get('response', [])
        
        # Add request transformation plugins
        for transform in request_transforms:
            transform_plugin = self._create_transformation_plugin(transform, 'request')
            if transform_plugin:
                kong_config.setdefault('plugins', []).append(transform_plugin)
        
        # Add response transformation plugins
        for transform in response_transforms:
            transform_plugin = self._create_transformation_plugin(transform, 'response')
            if transform_plugin:
                kong_config.setdefault('plugins', []).append(transform_plugin)
        
        return kong_config
    
    def _add_contract_validation_plugins(self, apigee_contract: Dict[str, Any], 
                                       kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Add plugins to validate API contract compliance"""
        
        # Add request validation plugin
        # Ensure the service exists before adding plugins to it
        if not kong_config.get('services') or not kong_config['services']:
            self.logger.warning("No services found in Kong config to add contract validation plugins.")
            return kong_config

        validation_plugin = {
            'name': 'request-validator',
            'config': {
                # Default permissive schema to avoid validation errors on deployment
                'parameter_schema': '[{"schema": "{\\"type\\":\\"object\\", \\"properties\\":{}}", "in": "query"}]',
                'body_schema': '{"type":"object", "properties":{}}'
            },
            'tags': ['contract-preservation', 'validation']
        }

        # Add CORS plugin to preserve cross-origin behavior
        cors_plugin = {
            'name': 'cors',
            'config': {
                'origins': ['*'],
                'methods': list(apigee_contract.get('methods', ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])),
                'headers': ['Accept', 'Accept-Version', 'Content-Length', 'Content-MD5', 'Content-Type', 'Date', 'X-Auth-Token', 'Authorization'],
                'exposed_headers': ['X-Auth-Token'],
                'credentials': True,
                'max_age': 3600
            },
            'tags': ['contract-preservation', 'cors']
        }

        # Add plugins to the service if they don't already exist
        service_plugins = kong_config['services'][0].setdefault('plugins', [])
        if not any(p['name'] == 'request-validator' for p in service_plugins):
            service_plugins.append(validation_plugin)
        if not any(p['name'] == 'cors' for p in service_plugins):
            service_plugins.append(cors_plugin)
        
        return kong_config
    
    def _map_auth_type_to_kong_plugin(self, auth_type: str) -> str:
        """Map Apigee auth type to Kong plugin"""
        mapping = {
            'VerifyAPIKey': 'key-auth',
            'OAuthV2': 'oauth2',
            'JWT': 'jwt',
            'BasicAuthentication': 'basic-auth',
            'SAML': 'openid-connect'
        }
        return mapping.get(auth_type, 'key-auth')
    
    def _create_auth_plugin(self, auth_type: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create Kong auth plugin from Apigee auth policy, robustly handling required fields"""
        import secrets
        plugin_name = self._map_auth_type_to_kong_plugin(auth_type)
        try:
            if plugin_name == 'key-auth':
                return {
                    'name': 'key-auth',
                    'config': {
                        'key_names': ['apikey', 'x-api-key'],
                        'hide_credentials': True
                    },
                    'tags': ['contract-preservation', 'auth']
                }
            elif plugin_name == 'oauth2':
                # Ensure provision_key is present
                provision_key = config.get('provision_key') or secrets.token_hex(16)
                return {
                    'name': 'oauth2',
                    'config': {
                        'scopes': config.get('scopes', ['read']),
                        'mandatory_scope': True,
                        'enable_authorization_code': True,
                        'provision_key': provision_key
                    },
                    'tags': ['contract-preservation', 'auth']
                }
            elif plugin_name == 'jwt':
                return {
                    'name': 'jwt',
                    'config': {
                        'secret_is_base64': False,
                        'claims_to_verify': ['exp']
                    },
                    'tags': ['contract-preservation', 'auth']
                }
        except Exception as e:
            self.logger.error(f"Failed to create auth plugin '{plugin_name}': {e}")
            return None
        return None
    
    def _create_transformation_plugin(self, transform: Dict[str, Any], 
                                    direction: str) -> Optional[Dict[str, Any]]:
        """Create Kong transformation plugin from Apigee transformation"""
        
        transform_type = transform.get('type', '')
        transform_config = transform.get('config', {})
        
        if direction == 'request':
            plugin_name = 'request-transformer'
        else:
            plugin_name = 'response-transformer'
        
        plugin_config = {
            'add': {'headers': []},
            'replace': {'headers': []},
            'remove': {'headers': []}
        }
        
        # Handle AssignMessage transformations
        if transform_type == 'AssignMessage':
            # Extract header modifications
            if 'headers' in transform_config:
                for header_name, header_value in transform_config['headers'].items():
                    plugin_config['add']['headers'].append(f"{header_name}:{header_value}")
        
        return {
            'name': plugin_name,
            'config': plugin_config,
            'tags': ['contract-preservation', 'transformation']
        }
    
    def _affects_request(self, config: Dict[str, Any]) -> bool:
        """Check if configuration affects request"""
        config_str = str(config).lower()
        return 'request' in config_str or 'req' in config_str
    
    def _affects_response(self, config: Dict[str, Any]) -> bool:
        """Check if configuration affects response"""
        config_str = str(config).lower()
        return 'response' in config_str or 'resp' in config_str