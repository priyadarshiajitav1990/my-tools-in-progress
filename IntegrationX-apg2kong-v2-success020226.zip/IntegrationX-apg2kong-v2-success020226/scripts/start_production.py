#!/usr/bin/env python3
"""
Production-Ready Apigee to Kong Migration Tool
Enterprise-grade migration with zero consumer impact and comprehensive features
"""

import sys
import os
import json
import traceback
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime
from typing import Dict, List, Any, Optional

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))

# Import enterprise components
try:
    from utils.enterprise_logger import get_enterprise_logger, log_function_call
    from utils.consumer_impact_validator import ConsumerImpactValidator
    from utils.api_contract_preserving_engine import APIContractPreservingEngine
    from utils.zero_downtime_migration_orchestrator import ZeroDowntimeMigrationOrchestrator
    from core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
    from utils.advanced_resource_handler import AdvancedResourceHandler
    from pre.extract_apigee_api import extract_apigee_api
except ImportError:
    # Fallback for direct execution
    from scripts.utils.enterprise_logger import get_enterprise_logger, LoggingContext, log_function_call
    from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
    from scripts.utils.api_contract_preserving_engine import APIContractPreservingEngine
    from scripts.utils.zero_downtime_migration_orchestrator import ZeroDowntimeMigrationOrchestrator
    from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
    from scripts.utils.advanced_resource_handler import AdvancedResourceHandler
    from scripts.pre.extract_apigee_api import extract_apigee_api

class ProductionMigrationTool:
    """Production-ready migration tool with enterprise standards"""
    
    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.config = self._load_configuration_initial()
        self.logger = get_enterprise_logger("apigee-kong-migration", self.config)
        self.config = self._apply_runtime_overrides(self.config)
        
        # Initialize enterprise components
        self._initialize_components()
        
        # Migration statistics
        self.stats = {
            'start_time': datetime.now(),
            'apis_processed': 0,
            'policies_migrated': 0,
            'plugins_generated': 0,
            'lua_fallbacks_used': 0,
            'resources_converted': 0,
            'consumer_impact_score': 0,
            'entities_skipped': 0,
            'errors': [],
            'warnings': []
        }
        
        self.logger.info("Production Migration Tool initialized")
    
    def _load_configuration_initial(self) -> Dict[str, Any]:
        """Load base configuration from file without overrides."""
        config_file = self.project_root / "configs" / "config.json"
        try:
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
            else:
                config = self._create_default_config()
                self._save_default_config(config)
            return config
        except Exception as e:
            print(f"Initial configuration loading failed: {e}")
            return self._create_default_config()

    @log_function_call("configuration_loading")
    def _apply_runtime_overrides(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Apply runtime overrides like demo mode and validate."""
        try:
            # Apply demo mode settings if enabled
            config = self._apply_demo_mode(config)
            
            # Validate final configuration
            self._validate_configuration(config)

            return config
            
        except Exception as e:
            self.logger.error(f"Failed to apply runtime configuration overrides: {e}")
            raise
    
    def _create_default_config(self) -> Dict[str, Any]:
        """Create default configuration with all supported variants"""
        return {
            "apigee": {
                "type": "edge_private_cloud",
                "admin_api": "http://apigee-management:8080/v1",
                "ssl_verify": False,
                "organization": "your-org",
                "environment": "prod",
                "auth": {
                    "type": "basic",
                    "credentials": "Basic <base64-encoded-credentials>"
                },
                "variants": {
                    "edge_cloud": {
                        "admin_api": "https://api.enterprise.apigee.com/v1",
                        "auth_type": "oauth2",
                        "ssl_verify": True
                    },
                    "edge_private_cloud": {
                        "admin_api": "http://management-server:8080/v1",
                        "auth_type": "basic",
                        "ssl_verify": False
                    },
                    "apigee_x": {
                        "admin_api": "https://apigee.googleapis.com/v1",
                        "auth_type": "gcp_service_account",
                        "ssl_verify": True
                    },
                    "apigee_hybrid": {
                        "admin_api": "https://apigee.googleapis.com/v1",
                        "auth_type": "gcp_service_account",
                        "ssl_verify": True
                    }
                }
            },
            "kong": {
                "version": "kong-enterprise-v3.13.0.0",
                "admin_api": "http://kong-admin:8001",
                "admin_token": "your-admin-token",
                "ssl_verify": True,
                "variants": {
                    "kong_oss": {
                        "version": "3.13.0",
                        "enterprise_features": False,
                        "admin_api": "http://kong-admin:8001"
                    },
                    "kong_enterprise": {
                        "version": "3.13.0.0",
                        "enterprise_features": True,
                        "rbac_enabled": True,
                        "dev_portal_enabled": True,
                        "admin_api": "http://kong-admin:8001"
                    },
                    "kong_konnect": {
                        "version": "latest",
                        "cloud_managed": True,
                        "admin_api": "https://us.api.konghq.com",
                        "enterprise_features": True
                    }
                }
            },
            "migration": {
                "input_dir": "input",
                "output_dir": "output",
                "extracted_api_dir": "extracted-apigee-apis",
                "enable_resource_conversion": True,
                "enable_conflict_resolution": True,
                "enable_plugin_optimization": True,
                "fallback_to_lua": True,
                "preserve_apigee_ordering": True,
                "generate_detailed_report": True,
                "enable_consumer_impact_validation": True,
                "enable_contract_preservation": True,
                "enable_zero_downtime_orchestration": False,
                "enable_deck_deployment": False,
                "max_acceptable_consumer_impact": "LOW"
            },
            "validation": {
                "deck_addr": "http://kong-admin:8001",
                "deck_key": "your-admin-token",
                "skip_gateway_validation": False,
                "validate_syntax": True,
                "validate_plugins": True
            },
            "logging": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "file_enabled": True,
                "console_enabled": True
            },
            "performance": {
                "parallel_processing": True,
                "max_workers": 4,
                "batch_size": 10,
                "timeout": 300
            }
        }
    
    def _save_default_config(self, config: Dict[str, Any]):
        """Save default configuration"""
        config_file = self.project_root / "configs" / "config.json"
        config_file.parent.mkdir(exist_ok=True)
        
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def _validate_configuration(self, config: Dict[str, Any]):
        """Validate configuration structure"""
        required_sections = ['apigee', 'kong', 'migration']
        
        for section in required_sections:
            if section not in config:
                raise ValueError(f"Missing required configuration section: {section}")
    
    def _apply_demo_mode(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Apply demo mode settings if enabled in the configuration"""
        if config.get("migration", {}).get("demo_mode", False):
            self.logger.info("Demo mode is enabled. Overriding Kong configuration for demo environment.")
            demo_settings = config.get("demo_kong_settings")
            
            if not demo_settings:
                self.logger.warning("`demo_mode` is true, but `demo_kong_settings` section is missing in config.json.")
                return config

            # Override Kong settings
            config["kong"]["admin_api"] = demo_settings.get("admin_api")
            config["kong"]["admin_token"] = demo_settings.get("admin_token")
            config["kong"]["ssl_verify"] = demo_settings.get("ssl_verify", False)
            
            # Override validation/deck settings
            config["validation"]["deck_addr"] = demo_settings.get("admin_api")
            config["validation"]["deck_key"] = demo_settings.get("admin_token")
            
            self.logger.info(f"Kong admin API set to: {config['kong']['admin_api']}")

        return config

    def _initialize_components(self):
        """Initialize all enterprise components"""
        try:
            self.consumer_validator = ConsumerImpactValidator()
            self.contract_engine = APIContractPreservingEngine(self.project_root, self.config)
            self.migration_orchestrator = ZeroDowntimeMigrationOrchestrator(self.project_root, self.config)
            self.policy_migration_engine = EnhancedPolicyMigrationWithLua(self.project_root, self.config)
            self.resource_handler = AdvancedResourceHandler()
            
            self.logger.info("All enterprise components initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Component initialization failed: {e}")
            raise
    
    @log_function_call("production_migration")
    def run_production_migration(self) -> bool:
        """Execute production-ready migration workflow"""
        with self._capture_logs() as log_capture:
            try:
                self.logger.info("=" * 80)
                self.logger.info("PRODUCTION APIGEE TO KONG MIGRATION STARTED")
                self.logger.info("=" * 80)
                
                # Phase 1: Environment Validation
                self._validate_environment()
                
                # Phase 2: Extract and Process APIs
                apis_data = self._extract_and_process_apis()
                
                # Phase 3: Migrate Each API
                migration_results = []
                total_apis = len(apis_data)
                
                self.logger.info(f"Starting migration of {total_apis} APIs")
                
                for i, api_data in enumerate(apis_data, 1):
                    api_name = api_data.get('api_name', f'unknown-api-{i}')
                    self.logger.info(f"Migrating API {i}/{total_apis}: {api_name}")
                    
                    result = self._migrate_single_api(api_data)
                    migration_results.append(result)
                    
                    # Log progress
                    if result['status'] == 'SUCCESS':
                        self.logger.info(f"Successfully migrated API {i}/{total_apis}: {api_name}")
                    else:
                        self.logger.error(f"Failed to migrate API {i}/{total_apis}: {api_name} - {result.get('error', 'Unknown error')}")
                
                # Phase 4: Generate Comprehensive Reports
                self._generate_comprehensive_reports(migration_results)
                
                # Phase 5: Migration Summary
                self._print_migration_summary(migration_results)
                
                self.logger.info("=" * 80)
                self.logger.info("PRODUCTION MIGRATION COMPLETED SUCCESSFULLY")
                self.logger.info("=" * 80)
                
                return True
                
            except Exception as e:
                self.logger.error(f"Production migration failed: {e}")
                self.stats['errors'].append(str(e))
                return False
    
    @log_function_call("environment_validation")
    def _validate_environment(self):
        """Validate environment prerequisites"""
        
        # Check Python version
        if sys.version_info < (3, 8):
            raise RuntimeError(f"Python 3.8+ required, found {sys.version_info.major}.{sys.version_info.minor}")
        
        # Check required directories
        required_dirs = ['configs', 'mappers', 'templates', 'scripts']
        for dir_name in required_dirs:
            dir_path = self.project_root / dir_name
            if not dir_path.exists():
                raise RuntimeError(f"Required directory not found: {dir_path}")
        
        # Check configuration files
        required_files = [
            'configs/config.json',
            'mappers/policy-to-plugin-mapper.json'
        ]
        for file_path in required_files:
            full_path = self.project_root / file_path
            if not full_path.exists():
                raise RuntimeError(f"Required file not found: {full_path}")
        
        self.logger.info("Environment validation completed successfully")
    
    def _check_library(self, library_name: str):
        """Check if a library is installed."""
        import importlib
        importlib.import_module(library_name)

    @log_function_call("api_extraction")
    def _extract_and_process_apis(self) -> List[Dict[str, Any]]:
        """Extract and process API configurations from all zip files in input directory"""
        
        apis_data = []
        input_dir = self.project_root / self.config['migration']['input_dir']
        
        if not input_dir.exists():
            self.logger.warning(f"Input directory not found: {input_dir}")
            input_dir.mkdir(parents=True, exist_ok=True)
        
        # Find all zip files in input directory
        zip_files = list(input_dir.glob("*.zip"))
        
        if not zip_files:
            self.logger.info("No zip files found in input directory, creating mock API data for testing")
            apis_data.append(self._create_comprehensive_mock_api())
        else:
            self.logger.info(f"Found {len(zip_files)} Apigee proxy bundles to migrate")
            
            # Process each zip file
            for zip_file in zip_files:
                try:
                    self.logger.info(f"Processing Apigee proxy bundle: {zip_file.name}")
                    api_data = extract_apigee_api(str(zip_file))
                    
                    if api_data:
                        apis_data.append(api_data)
                        self.logger.info(f"Successfully extracted API: {api_data.get('api_name', 'unknown')}")
                    else:
                        self.logger.error(f"Failed to extract API data from {zip_file.name}")
                        self.stats['errors'].append(f"API extraction failed: {zip_file.name}")
                        
                except Exception as e:
                    self.logger.error(f"Error processing {zip_file.name}: {e}")
                    self.stats['errors'].append(f"Processing error for {zip_file.name}: {str(e)}")
        
        self.stats['apis_processed'] = len(apis_data)
        self.logger.info(f"Total APIs ready for migration: {len(apis_data)}")
        
        return apis_data
    
    @log_function_call("single_api_migration")
    def _migrate_single_api(self, api_data: Dict[str, Any]) -> Dict[str, Any]:
        """Migrate a single API with full enterprise features"""
        
        api_name = api_data.get('api_name', 'unknown-api')
        
        with self._capture_logs() as log_capture:
            try:
                # Step 1: Process resource files
                processed_resources = self._process_api_resources(api_data)
                
                # Step 2: Migrate policies to plugins
                migrated_plugins = self._migrate_api_policies(api_data, processed_resources)
                
                # Step 3: Generate Kong configuration
                kong_config = self._generate_kong_configuration(api_data, migrated_plugins)
                
                # Step 4: Apply contract preservation
                preserved_config = self.contract_engine.preserve_api_contract(api_data, kong_config)
                
                # Step 5: Validate consumer impact
                impact_validation = self.consumer_validator.validate_migration_impact(api_data, preserved_config)
                
                # Step 6: Check if impact is acceptable
                self._validate_consumer_impact(impact_validation)
                
                # Step 7: Save migration artifacts
                output_info = self._save_migration_artifacts(api_name, preserved_config, impact_validation)
                
                # Step 8: Deploy to Kong (if enabled)
                deployment_result = None
                if self.config.get('migration', {}).get('enable_deck_deployment', False):
                    try:
                        sys.path.insert(0, str(self.project_root / "deployment"))
                        from deployment import DeckDeploymentManager
                        deployment_result = self._deploy_to_kong(api_name, preserved_config, output_info)
                    except ImportError:
                        self.logger.warning("Deployment module not found, skipping deployment")
                        deployment_result = {'status': 'SKIPPED', 'reason': 'Module not available'}
                else:
                    deployment_result = {'status': 'SKIPPED', 'reason': 'Deployment not enabled in config'}
                
                # Step 9: Verify deployment (if deployment was attempted)
                if deployment_result and deployment_result['status'] == 'SUCCESS':
                    self._verify_kong_deployment(api_name)

                # Step 10: Update statistics
                self._update_migration_statistics(migrated_plugins, impact_validation)
                
                return {
                    'api_name': api_name,
                    'status': 'SUCCESS',
                    'kong_config': preserved_config,
                    'impact_validation': impact_validation,
                    'output_info': output_info,
                    'migrated_plugins': migrated_plugins,
                    'deployment_result': deployment_result,
                    'statistics': {
                        'policies_processed': len(api_data.get('policies', [])),
                        'plugins_generated': sum(len(plugins) for plugins in migrated_plugins.values()),
                        'lua_fallbacks_used': self.policy_migration_engine.stats.get('lua_fallbacks_used', 0),
                        'resources_converted': len(processed_resources)
                    },
                    'logs': log_capture.getvalue()
                }
                
            except Exception as e:
                self.logger.error(f"API migration failed for {api_name}: {e}")
                return {
                    'api_name': api_name,
                    'status': 'FAILED',
                    'error': str(e),
                    'statistics': {}
                }
    
    def _process_api_resources(self, api_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process API resource files"""
        processed_resources = {}
        
        for policy in api_data.get('policies', []):
            policy_name = policy.get('name', 'unknown')
            try:
                policy_resources = self.resource_handler.process_resource_files(
                    policy, api_data.get('resources', {})
                )
                if policy_resources:
                    processed_resources[policy_name] = policy_resources
                    self.stats['resources_converted'] += len(policy_resources)
            except Exception as e:
                self.logger.warning(f"Resource processing failed for {policy_name}: {e}")
                self.stats['warnings'].append(f"Resource processing failed for {policy_name}")
        
        return processed_resources
    
    def _migrate_api_policies(self, api_data: Dict[str, Any], 
                            processed_resources: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
        """Migrate API policies to Kong plugins"""
        
        migrated_plugins = self.policy_migration_engine.migrate_policies_enterprise(
            api_data.get('policies', []),
            lambda policy_name, kong_plugin: self.logger.debug(
                f"MIGRATION: Apigee Policy [{policy_name}] -> Kong Plugin [{kong_plugin}]"
            ) if self.config.get("migration", {}).get("debug_mode") else None,
            processed_resources,
            api_data.get('api_name', 'unknown'),
            self.config
        )
        
        # Update statistics
        engine_stats = self.policy_migration_engine.get_migration_stats()
        self.stats['entities_skipped'] += engine_stats.get('policies_skipped', 0)
        self.stats['policies_migrated'] += engine_stats.get('policies_processed', 0)
        self.stats['plugins_generated'] += engine_stats.get('plugins_generated', 0)
        self.stats['lua_fallbacks_used'] += engine_stats.get('lua_fallbacks_used', 0)
        
        return migrated_plugins
    
    def _generate_kong_configuration(self, api_data: Dict[str, Any], 
                                   migrated_plugins: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        """Generate Kong configuration with enforced tagging, ordering, and custom plugin inclusion"""
        api_name = api_data.get('api_name', 'unknown-api')
        migration_tag = f"migration-id-{api_name}"
        # Ensure ordering is preserved if required
        preserve_ordering = self.config.get('migration', {}).get('preserve_apigee_ordering', True)
        # Compose base config
        kong_config = {
            "_format_version": "3.0",
            "_comment": f"Generated by Production Apigee to Kong Migration Tool v2.0 for API: {api_name}. "
                        f"Source: {api_name}, Generated at: {datetime.now().isoformat()}",
            "_info": {
                "generated_by": "Production Apigee to Kong Migration Tool v2.0",
                "generated_at": datetime.now().isoformat(),
                "source_api": api_name,
                "migration_type": "production-ready",
                "tool_version": "2.0.0",
            },
            "services": [{
                "name": f"srv-{api_name}",
                "url": api_data.get('target_url', 'http://backend.example.com'),
                "connect_timeout": 60000,
                "write_timeout": 60000,
                "read_timeout": 60000,
                "retries": 5,
                "tags": [migration_tag, api_name, "migrated-from-apigee", "production"],
                "plugins": []
            }],
            "routes": [{
                "name": f"rt-{api_name}",
                "service": {"name": f"srv-{api_name}"},
                "paths": api_data.get('paths', ['/api']),
                "methods": api_data.get('methods', ['GET', 'POST']),
                "strip_path": False,
                "preserve_host": True,
                "tags": [migration_tag, api_name, "migrated-from-apigee", "production"]
            }],
            "plugins": []
        }
        # Add migrated plugins with enforced tags and ordering
        all_plugins = []
        order_counter = 1
        for flow in (['request', 'both', 'response'] if preserve_ordering else ['request', 'response', 'both']):
            plugins = migrated_plugins.get(flow, [])
            for plugin in plugins:
                plugin_config = plugin.copy()
                # Enforce tags
                plugin_config['tags'] = list(set(plugin_config.get('tags', []) + [migration_tag, api_name, "production"]))
                # Enforce ordering if required
                if preserve_ordering:
                    plugin_config['order'] = order_counter
                    order_counter += 1
                all_plugins.append(plugin_config)
        # Attach all plugins to the service
        if kong_config.get('services'):
            kong_config['services'][0]['plugins'].extend(all_plugins)
        # Attach custom plugins if required (stub: extend as needed)
        # Example: if 'custom_plugins' in api_data, add them
        custom_plugins = api_data.get('custom_plugins', [])
        for custom_plugin in custom_plugins:
            custom_plugin['tags'] = list(set(custom_plugin.get('tags', []) + [migration_tag, api_name, "custom", "production"]))
            if preserve_ordering:
                custom_plugin['order'] = order_counter
                order_counter += 1
            kong_config['services'][0]['plugins'].append(custom_plugin)
        return kong_config
    
    def _validate_consumer_impact(self, impact_validation: Dict[str, Any]):
        """Validate consumer impact is acceptable"""
        
        impact_level = impact_validation.get('consumer_impact', 'UNKNOWN')
        max_acceptable = self.config.get('migration', {}).get('max_acceptable_consumer_impact', 'LOW')
        
        if impact_level == 'HIGH' and max_acceptable != 'HIGH':
            breaking_changes = impact_validation.get('breaking_changes', [])
            raise RuntimeError(
                f"Consumer impact ({impact_level}) exceeds acceptable level ({max_acceptable}). "
                f"Breaking changes: {breaking_changes}"
            )
        
        self.stats['consumer_impact_score'] += self._calculate_impact_score(impact_validation)
    
    def _save_migration_artifacts(self, api_name: str, kong_config: Dict[str, Any], 
                                impact_validation: Dict[str, Any]) -> Dict[str, str]:
        """Save migration artifacts to API-specific directory"""
        
        # Create API-specific output directory
        output_dir = self.project_root / "output" / api_name
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save Kong configuration as YAML
        kong_file = output_dir / f"kong-{api_name}.yml"
        self._save_as_yaml(kong_config, kong_file)
        
        # Save consumer compatibility report
        compatibility_report = self.consumer_validator.generate_consumer_compatibility_report(impact_validation)
        report_file = output_dir / f"{api_name}-consumer-compatibility-report.md"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(compatibility_report)
        
        # Save detailed migration report
        migration_report = self._generate_detailed_migration_report(api_name, kong_config, impact_validation)
        detailed_report_file = output_dir / f"{api_name}-migration-report.json"
        with open(detailed_report_file, 'w', encoding='utf-8') as f:
            json.dump(migration_report, f, indent=2, default=str)
        
        self.logger.info(f"Migration artifacts saved to: {output_dir}")
        
        return {
            'output_directory': str(output_dir),
            'kong_config_file': str(kong_file),
            'compatibility_report_file': str(report_file),
            'detailed_report_file': str(detailed_report_file)
        }
    
    def _save_as_yaml(self, data: Dict[str, Any], file_path: Path):
        """Save data as YAML file"""
        try:
            import yaml
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, indent=2, sort_keys=False)
        except ImportError:
            # Fallback to JSON if YAML not available
            json_file = file_path.with_suffix('.json')
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
            self.logger.warning(f"YAML not available, saved as JSON: {json_file}")
    
    def _generate_detailed_migration_report(self, api_name: str, kong_config: Dict[str, Any], 
                                          impact_validation: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed migration report"""
        
        return {
            "migration_summary": {
                "api_name": api_name,
                "migration_date": datetime.now().isoformat(),
                "migration_type": "production-ready",
                "tool_version": "2.0.0",
                "status": "completed"
            },
            "consumer_impact_analysis": impact_validation,
            "kong_configuration_summary": {
                "services": len(kong_config.get('services', [])),
                "routes": len(kong_config.get('routes', [])),
                "plugins": len(kong_config.get('plugins', [])),
                "format_version": kong_config.get('_format_version', 'unknown')
            },
            "migration_statistics": {
                "policies_processed": self.stats['policies_migrated'],
                "plugins_generated": self.stats['plugins_generated'],
                "lua_fallbacks_used": self.stats['lua_fallbacks_used'],
                "resources_converted": self.stats['resources_converted']
            },
            "quality_metrics": {
                "consumer_impact_score": self._calculate_impact_score(impact_validation),
                "contract_preservation_score": 100 if impact_validation.get('contract_preserved', True) else 0,
                "migration_completeness": 100  # Assume 100% for successful migrations
            },
            "recommendations": self._generate_recommendations(impact_validation)
        }
    
    def _update_migration_statistics(self, migrated_plugins: Dict[str, List[Dict[str, Any]]], 
                                   impact_validation: Dict[str, Any]):
        """Update global migration statistics"""
        
        # Update plugin counts
        total_plugins = sum(len(plugins) for plugins in migrated_plugins.values())
        self.stats['plugins_generated'] += total_plugins
        
        # Update impact score
        self.stats['consumer_impact_score'] += self._calculate_impact_score(impact_validation)
        
        # Update error and warning counts
        self.stats['errors'].extend(impact_validation.get('breaking_changes', []))
        self.stats['warnings'].extend(impact_validation.get('warnings', []))
    
    def _calculate_impact_score(self, impact_validation: Dict[str, Any]) -> int:
        """Calculate consumer impact score (0-100, lower is better)"""
        score = 0
        score += len(impact_validation.get('breaking_changes', [])) * 30
        score += len(impact_validation.get('warnings', [])) * 10
        return min(score, 100)
    
    def _generate_recommendations(self, impact_validation: Dict[str, Any]) -> List[str]:
        """Generate post-migration recommendations"""
        recommendations = []
        
        if impact_validation.get('breaking_changes'):
            recommendations.append("Address breaking changes before deploying to production")
        
        if impact_validation.get('warnings'):
            recommendations.append("Review warnings and test affected functionality thoroughly")
        
        recommendations.extend([
            "Run comprehensive API tests with real consumer applications",
            "Monitor API metrics closely for the first 24-48 hours after deployment",
            "Keep Apigee configuration as backup for quick rollback if needed",
            "Update API documentation to reflect any changes",
            "Notify API consumers about the migration completion"
        ])
        
        return recommendations
    
    def _deploy_to_kong(self, api_name: str, kong_config: Dict[str, Any], 
                       output_info: Dict[str, str]) -> Dict[str, Any]:
        """Deploy Kong configuration using deck"""
        try:
            sys.path.insert(0, str(self.project_root / "deployment"))
            from deployment import DeckDeploymentManager
            
            deployment_manager = DeckDeploymentManager(self.config)
            output_dir = Path(output_info['output_directory'])
            
            deployment_result = deployment_manager.deploy_api_configuration(
                api_name, kong_config, output_dir
            )
            
            if deployment_result['status'] == 'SUCCESS':
                self.logger.info(f"Successfully deployed API {api_name} to Kong")
            elif deployment_result['status'] == 'SKIPPED':
                self.logger.info(f"Deployment skipped for API {api_name}: {deployment_result.get('reason', 'Unknown')}")
            else:
                self.logger.error(f"Deployment failed for API {api_name}: {deployment_result.get('error', 'Unknown error')}")
            
            return deployment_result
            
        except Exception as e:
            self.logger.error(f"Deployment error for API {api_name}: {e}")
            return {'status': 'FAILED', 'error': str(e)}
    
    @log_function_call("deployment_verification")
    def _verify_kong_deployment(self, api_name: str):
        """Verify that Kong entities were created via Admin API."""
        try:
            import requests

            kong_admin_api = self.config['kong']['admin_api']
            workspace = self.config.get('demo_kong_settings', {}).get('workspace', 'default')
            
            service_name = f"srv-{api_name}"
            route_name = f"rt-{api_name}"
            
            # Verify Service
            service_url = f"{kong_admin_api}/{workspace}/services/{service_name}"
            response = requests.get(service_url, timeout=10)
            response.raise_for_status()
            self.logger.info(f"VERIFIED: Kong service '{service_name}' created successfully.")

            # Verify Route
            route_url = f"{kong_admin_api}/{workspace}/routes/{route_name}"
            response = requests.get(route_url, timeout=10)
            response.raise_for_status()
            self.logger.info(f"VERIFIED: Kong route '{route_name}' created successfully.")

            # Verify Plugins (at least one plugin for the service)
            plugins_url = f"{kong_admin_api}/{workspace}/services/{service_name}/plugins"
            response = requests.get(plugins_url, timeout=10)
            response.raise_for_status()
            self.logger.info(f"VERIFIED: Plugins for service '{service_name}' retrieved successfully.")

        except ImportError:
            # This is a more critical check now.
            self.logger.error("`requests` library not found. Cannot verify deployment.")
            self.logger.error("Please install it by running: pip install requests")
            self.stats['errors'].append("Deployment verification skipped: `requests` not found.")
            return
            self.logger.warning("`requests` library not found. Skipping deployment verification.")
        except Exception as e:
            self.logger.error(f"Failed to verify deployment for API '{api_name}': {e}")

    @contextmanager
    def _capture_logs(self):
        """A context manager to temporarily capture logs to a string buffer."""
        import io
        import logging
        log_stream = io.StringIO()
        
        # Create a handler that writes to the stream
        stream_handler = logging.StreamHandler(log_stream)
        
        # Get the root logger and add the handler
        root_logger = logging.getLogger()
        original_handlers = root_logger.handlers[:]
        
        # Temporarily replace handlers to capture everything
        root_logger.handlers = [stream_handler]
        
        try:
            yield log_stream
        finally:
            # Restore original handlers
            root_logger.handlers = original_handlers
            stream_handler.close()

    def _generate_comprehensive_reports(self, migration_results: List[Dict[str, Any]]):
        """Generate comprehensive migration reports"""
        
        # Create summary report
        summary_report = {
            "migration_summary": {
                "tool_version": "2.0.0",
                "migration_date": datetime.now().isoformat(),
                "total_apis": len(migration_results),
                "successful_migrations": len([r for r in migration_results if r['status'] == 'SUCCESS']),
                "failed_migrations": len([r for r in migration_results if r['status'] == 'FAILED']),
                "total_duration": str(datetime.now() - self.stats['start_time'])
            },
            "overall_statistics": self.stats,
            "api_results": migration_results,
            "quality_metrics": {
                "average_consumer_impact_score": self.stats['consumer_impact_score'] / max(len(migration_results), 1),
                "total_lua_fallbacks": self.stats['lua_fallbacks_used'],
                "migration_success_rate": len([r for r in migration_results if r['status'] == 'SUCCESS']) / max(len(migration_results), 1) * 100
            }
        }
        
        # Save summary report
        summary_file = self.project_root / "output" / "migration-summary-report.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary_report, f, indent=2, default=str)
        
        self.logger.info(f"Comprehensive migration report saved: {summary_file}")

        # HTML report generation is disabled as per user request to focus on core tool functionality.
        self.logger.warning("HTML report generation is currently disabled.")

    
    def _print_migration_summary(self, migration_results: List[Dict[str, Any]]):
        """Print comprehensive migration summary with required, migrated, failed, efficiency, and entity counts"""
        from tabulate import tabulate
        duration = datetime.now() - self.stats['start_time']
        successful = len([r for r in migration_results if r['status'] == 'SUCCESS'])
        failed = len([r for r in migration_results if r['status'] == 'FAILED'])
        print("\n" + "=" * 80)
        print("PRODUCTION MIGRATION SUMMARY")
        print("=" * 80)
        print(f"Tool Version: 2.0.0")
        print(f"Migration Duration: {duration}")
        print(f"APIs Processed: {len(migration_results)}")
        print(f"Successful Migrations: {successful}")
        print(f"Failed Migrations: {failed}")
        print(f"Success Rate: {(successful / max(len(migration_results), 1) * 100):.1f}%")
        total_policies = self.stats['policies_migrated'] + self.stats['entities_skipped']
        efficiency = (self.stats['policies_migrated'] / max(total_policies, 1)) * 100
        print(f"\nMigration Efficiency: {efficiency:.1f}%")
        print(f"  - Total Apigee Policies Found: {total_policies}")
        print(f"  - Policies Migrated: {self.stats['policies_migrated']}")
        print(f"  - Policies Skipped/Missed: {self.stats['entities_skipped']}")
        # Entity counts for Apigee and Kong
        apigee_counts = {}
        kong_counts = {}
        for result in migration_results:
            apigee_counts.setdefault('policies', 0)
            apigee_counts['policies'] += len(result.get('statistics', {}).get('policies_processed', []) if isinstance(result.get('statistics', {}).get('policies_processed', []), list) else [None])
            kong_counts.setdefault('plugins', 0)
            kong_counts['plugins'] += result.get('statistics', {}).get('plugins_generated', 0)
            kong_counts.setdefault('services', 0)
            kong_counts['services'] += len(result.get('kong_config', {}).get('services', []))
            kong_counts.setdefault('routes', 0)
            kong_counts['routes'] += len(result.get('kong_config', {}).get('routes', []))
        print("\nENTITY COUNTS:")
        entity_table = [
            ["Apigee", "Policies", apigee_counts.get('policies', 0)],
            ["Kong", "Plugins", kong_counts.get('plugins', 0)],
            ["Kong", "Services", kong_counts.get('services', 0)],
            ["Kong", "Routes", kong_counts.get('routes', 0)]
        ]
        print(tabulate(entity_table, headers=["Platform", "Entity Type", "Count"], tablefmt="fancy_grid"))
        # Missed/Failed Table
        missed_table = []
        for result in migration_results:
            if result['status'] == 'FAILED':
                missed_table.append([
                    result['api_name'],
                    'API',
                    result.get('error', 'Unknown error')
                ])
        if missed_table:
            print("\nMISSED/FAILED ENTITIES:")
            print(tabulate(missed_table, headers=["Name", "Type", "Reason"], tablefmt="fancy_grid"))
        # Summary Table
        summary_table = [
            ["Total entities processed", len(migration_results)],
            ["Migrated", successful],
            ["Missed/Failed", failed],
            ["Total time taken (s)", f"{duration.total_seconds():.2f}"],
            ["Efficiency", f"{efficiency:.2f}%"]
        ]
        print("\nOVERALL SUMMARY:")
        print(tabulate(summary_table, tablefmt="fancy_grid"))
        print(f"\nLua Fallbacks Used: {self.stats['lua_fallbacks_used']}")
        print(f"Resources Converted: {self.stats['resources_converted']}")
        print(f"Average Consumer Impact Score: {(self.stats['consumer_impact_score'] / max(len(migration_results), 1)):.1f}/100")
        print(f"\nOUTPUT STRUCTURE:")
        print(f"output/")
        for result in migration_results:
            if result['status'] == 'SUCCESS':
                api_name = result['api_name']
                print(f"├── {api_name}/")
                print(f"│   ├── kong-{api_name}.yml")
                print(f"│   ├── {api_name}-consumer-compatibility-report.md")
                print(f"│   └── {api_name}-migration-report.json")
        print(f"└── migration-summary-report.json")
        print(f"\nNEXT STEPS:")
        print(f"1. Review consumer compatibility reports for each API")
        print(f"2. Test Kong configurations in staging environment")
        print(f"3. Run comprehensive API tests")
        print(f"4. Deploy to production with monitoring")
        print(f"5. Monitor API metrics for 24-48 hours")
        print("=" * 80)
    
    def _create_comprehensive_mock_api(self) -> Dict[str, Any]:
        """Create comprehensive mock API data for testing"""
        return {
            'api_name': 'production-test-api',
            'policies': [
                {
                    'name': 'verify-api-key',
                    'policyType': 'VerifyAPIKey',
                    'enabled': True,
                    'config': {'APIKey': {'ref': 'request.header.x-api-key'}}
                },
                {
                    'name': 'rate-limit-policy',
                    'policyType': 'Quota',
                    'config': {'count': 1000, 'timeUnit': 'minute'}
                },
                {
                    'name': 'request-transform',
                    'policyType': 'AssignMessage',
                    'config': {
                        'Add': {'Headers': {'X-Processed-By': 'Apigee'}},
                        'request': True
                    }
                },
                {
                    'name': 'javascript-policy',
                    'policyType': 'JavaScript',
                    'config': {'ResourceURL': 'jsc://validate-request.js'}
                },
                {
                    'name': 'service-callout',
                    'policyType': 'ServiceCallout',
                    'config': {
                        'HTTPTargetConnection': {'URL': 'http://validation.example.com'},
                        'Request': {'Verb': 'POST'}
                    }
                }
            ],
            'resources': {
                'jsc://validate-request.js': '''
function validateRequest() {
    var method = context.getVariable("request.verb");
    if (method === "POST") {
        context.setVariable("request.header.validated", "true");
    }
    return true;
}
validateRequest();
'''
            },
            'target_url': 'https://api.backend.example.com',
            'paths': ['/api/v1/users', '/api/v1/orders'],
            'methods': ['GET', 'POST', 'PUT', 'DELETE']
        }

def main():
    """Main entry point"""
    try:
        print("Production Apigee to Kong Migration Tool v2.0")
        print("=" * 60)
        
        # Check virtual environment
        if not _check_virtual_environment():
            print("WARNING: Virtual environment not detected!")
            print("Please run: python setup_environment.py")
            return False
        
        # Initialize and run migration
        migration_tool = ProductionMigrationTool()
        success = migration_tool.run_production_migration()
        
        return success
        
    except KeyboardInterrupt:
        print("\nWARNING: Migration interrupted by user")
        return False
    except Exception as e:
        print(f"ERROR: Fatal error: {e}")
        traceback.print_exc()
        return False

def _check_virtual_environment() -> bool:
    """Check if running in virtual environment"""
    return (
        hasattr(sys, 'real_prefix') or
        (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix) or
        os.environ.get('VIRTUAL_ENV') is not None
    )

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)