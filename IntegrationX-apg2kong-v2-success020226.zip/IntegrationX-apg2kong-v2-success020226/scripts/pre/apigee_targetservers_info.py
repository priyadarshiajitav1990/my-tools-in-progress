import os
import json
import requests
import logging

# Fetches the list of all TargetServer names from the Apigee Management API.
def get_targetserver_list(apigee_config):
    api_base = apigee_config["admin_api"]
    org = apigee_config["org"]
    env = apigee_config["env"]
    auth = apigee_config["admin_auth"]
    ssl_verify = apigee_config.get("ssl_verify", True)

    url = f"{api_base}/organizations/{org}/environments/{env}/targetservers"
    headers = {'Authorization': auth}
    
    logging.info(f"  - Calling Apigee API to list TargetServers in env '{env}'...")
    if not ssl_verify:
        logging.warning("    - SSL verification is disabled for this request.")

    try:
        response = requests.get(url, headers=headers, timeout=10, verify=ssl_verify)
        response.raise_for_status()
        
        targetserver_names = response.json()
        logging.info(f"    - Success: Found {len(targetserver_names)} TargetServer(s).")
        return targetserver_names
    except requests.exceptions.SSLError:
        logging.error("    - API call failed due to an SSL certificate verification error.")

    except requests.exceptions.RequestException as e:
        logging.error(f"    - API call to list TargetServers failed: {e}")
        return None

# Fetches detailed information for a specific TargetServer.
def get_targetserver_details(server_name, apigee_config):
    api_base = apigee_config["admin_api"]
    org = apigee_config["org"]
    env = apigee_config["env"]
    auth = apigee_config["admin_auth"]
    ssl_verify = apigee_config.get("ssl_verify", True)

    url = f"{api_base}/organizations/{org}/environments/{env}/targetservers/{server_name}"
    headers = {'Authorization': auth}

    try:
        response = requests.get(url, headers=headers, timeout=5, verify=ssl_verify)
        response.raise_for_status()
        return response.json()

    except requests.exceptions.SSLError:
        logging.warning(f"    - API call for TargetServer '{server_name}' failed due to an SSL certificate verification error.")
        return None

    except requests.exceptions.RequestException as e:
        logging.warning(f"    - API call for TargetServer '{server_name}' failed: {e}")
        return None

# Orchestrates fetching all TargetServer information and saving it to JSON files.
def apigee_targetservers():
    logging.info("--- Starting Apigee TargetServer Information Fetch ---")
    
    apigee_config = {
        "admin_api": os.environ.get("apigee_admin_api"),
        "org": os.environ.get("apigee_org"),
        "env": os.environ.get("apigee_env"),
        "admin_auth": os.environ.get("apigee_admin_auth"),
        "ssl_verify": os.environ.get("apigee_ssl_verify", "true").lower() == "true"
    }

    # Check for missing or placeholder configurations
    required_configs = ["admin_api", "org", "env", "admin_auth"]
    missing_or_invalid = []
    for key in required_configs:
        if not apigee_config.get(key) or "base64encoded" in str(apigee_config.get(key)) or "apigee.com" in str(apigee_config.get(key)):
            missing_or_invalid.append(key)

    if missing_or_invalid:
        logging.info(f"No Apigee admin_api configured. Skipping TargetServer fetch.")
        logging.info("Success: No Apigee admin_api configured.")
        return

    # Correctly calculate project root from scripts/pre/apigee_targetservers_info.py
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(os.path.dirname(current_dir))
    
    configs_dir = os.path.join(project_root, "configs")
    os.makedirs(configs_dir, exist_ok=True)

    targetserver_names = get_targetserver_list(apigee_config)

    if targetserver_names is None:
        logging.info("Success: Apigee target servers are not fetched.")
        return

    # Save the list of names
    list_path = os.path.join(configs_dir, "targetservers_list.json")
    with open(list_path, 'w') as f:
        json.dump(targetserver_names, f, indent=2)
    logging.info(f"  - Saved TargetServer list to '{os.path.basename(list_path)}'")

    # Fetch details for each server and save to a comprehensive file
    all_targetservers_data = {}
    for name in targetserver_names:
        details = get_targetserver_details(name, apigee_config)
        if details:
            all_targetservers_data[name] = details

    if not all_targetservers_data:
        logging.info("Success: Apigee target servers are not fetched.")
        return

    details_path = os.path.join(configs_dir, "targetservers.json")
    with open(details_path, 'w') as f:
        json.dump(all_targetservers_data, f, indent=2)
    logging.info(f"  - Saved all TargetServer details to '{os.path.basename(details_path)}'")
    logging.info("TargetServer information fetch complete.")