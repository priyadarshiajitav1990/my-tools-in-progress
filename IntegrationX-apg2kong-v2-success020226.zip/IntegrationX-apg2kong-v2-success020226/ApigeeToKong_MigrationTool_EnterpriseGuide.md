# Apigee to Kong Migration Tool - Enterprise Product Documentation

## Overview
This tool automates the migration of Apigee API proxies to Kong Gateway 3.x+ configurations, ensuring high fidelity, robust mapping, and safe, tag-based deployment. It is designed for enterprise use, supporting custom plugins, advanced reporting, and production-grade deployment workflows.

---

## Table of Contents
1. Introduction
2. Features & Advantages
3. System Requirements
4. Installation & Setup
5. Usage Guide
6. Folder & File Structure Table
7. Configuration Files & Parameters
8. Custom Plugins
9. Flow Diagram
10. Troubleshooting & Support

---

## 1. Introduction
This tool migrates Apigee API proxies (policies, endpoints, flows) to Kong Gateway YAML configs, supporting Kong 3.x+ format and enterprise deployment best practices.

## 2. Features & Advantages
- **Automated, high-fidelity migration** of Apigee proxies to Kong
- **Kong 3.x+ native output** (_format_version: '3.0'), no manual conversion needed
- **Safe, tag-based deployment** (decK sync with --select-tag)
- **Custom plugin support** and Lua/JS resource conversion
- **Detailed migration summary** (tabular, entity mapping, efficiency)
- **Error handling:** 409 errors shown as success, clean console output
- **Extensible mapping** (JSON mappers for policies, variables)
- **Enterprise-ready:** robust, auditable, and maintainable

## 3. System Requirements
- **Python:** 3.8+
- **Kong Gateway:** 3.0+ (tested on 3.13.0.0)
- **decK CLI:** Latest (for validation and deployment)
- **pip packages:** See `configs/requirements.txt`
- **OS:** Windows/Linux/Mac (tested on Windows)

## 4. Installation & Setup
1. Clone the repository.
2. Create and activate a Python virtual environment:
   ```
   python -m venv .venv
   .venv\Scripts\activate  # Windows
   source .venv/bin/activate  # Linux/Mac
   ```
3. Install dependencies:
   ```
   pip install -r configs/requirements.txt
   ```
4. Install decK CLI and Kong Gateway (see Kong docs).
5. Configure `configs/config.json` and mapping files as needed.

## 5. Usage Guide
1. Place Apigee API zip(s) in the `input/` folder.
2. Run the tool:
   ```
   py start.py
   ```
3. Review output in `output/` (YAML, reports, summary).
4. Deployment is automatic; see console for status.

## 6. Folder & File Structure Table
| Folder         | Files/Subfolders                                 | Description                                                      |
|----------------|--------------------------------------------------|------------------------------------------------------------------|
| configs/       | config.json, requirements.txt, ...               | Main configuration and dependency files                          |
| input/         | (user) API zip files                             | Place Apigee API bundles here                                    |
| output/        | kong-*.yml, reports                              | Generated Kong configs, migration reports                        |
| mappers/       | *.json                                           | Mapping files for policies, variables                            |
| scripts/       | core/, pre/, post/, utils/                       | Main migration logic, utilities, reporting                       |
| templates/     | *.j2, custom-plugins/                            | Jinja2 templates for Kong plugins, custom plugin templates       |
| extracted-apigee-apis/ | migration-test-api/                      | Extracted Apigee API bundles                                     |
| old-files-backups/ | ...                                          | Backups of previous configs and mappings                         |
| targetservers/ | targetservers.json, ...                          | Target server definitions                                        |

## 7. Configuration Files & Parameters
- **configs/config.json**: Main tool configuration (API name, output dir, etc.)
- **mappers/policy-to-plugin-mapper.json**: Maps Apigee policies to Kong plugins
- **mappers/apigee-to-kong-var-mappers.json**: Variable/expression mapping
- **targetservers/targetservers.json**: Target server host/port mapping
- **templates/**: Jinja2 templates for all supported Kong plugins

### Example config.json
```json
{
  "api_name": "migration-test-api",
  "output_dir": "output",
  "kong_admin_addr": "http://localhost:8001",
  "kong_admin_token": "<token-if-needed>"
}
```

## 8. Custom Plugins
- Place custom plugin templates in `templates/custom-plugins/`
- Supported via mapping and Jinja2 rendering
- Lua/JS/Java/Python resources are auto-converted for Kong plugin compatibility
- Example: `custom-plugins/my-custom-plugin.yml.j2`

## 9. Flow Diagram
```
[Input: Apigee API ZIPs]
      |
      v
[Extract & Parse]
      |
      v
[Map Endpoints, Flows, Policies]
      |
      v
[Generate Kong YAML (3.x+)]
      |
      v
[Validate & Deploy with decK]
      |
      v
[Output: Kong YAML, Reports, Summary]
```

## 10. Troubleshooting & Support
- **409 errors:** Shown as success if entity exists
- **Unsupported path format:** Tool auto-converts wildcards/regex for Kong 3.x+
- **Plugin errors:** Ensure all custom plugins are installed in Kong
- **Missing mappers/configs:** Check `configs/` and `mappers/` for required files

---

## Contact & Support
For enterprise support, contact the tool maintainer or your DevOps team.

---

*This document is auto-generated and should be maintained with each release.*
