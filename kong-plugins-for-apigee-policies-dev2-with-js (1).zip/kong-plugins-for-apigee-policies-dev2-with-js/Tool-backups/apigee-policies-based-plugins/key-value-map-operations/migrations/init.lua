-- apigee-policies-based-plugins/key-value-map-operations/migrations/init.lua
return {
  "000_base_kvm_data",
}
