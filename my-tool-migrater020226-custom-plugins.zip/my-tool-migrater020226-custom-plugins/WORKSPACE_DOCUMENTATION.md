# Workspace Documentation

## Plugins

### jspolicy
- **Purpose:** Dynamic policy enforcement using Lua scripts.
- **Functionality:** Executes a main Lua script and optional helper script per request/response, supports conditional execution, ordering, tagging, and key-value pairs.
- **How it works:** Loads scripts from plugin directory, evaluates condition, executes scripts in configured order and flow.
- **YAML/JSON Configuration:**
```yaml
plugins:
- name: jspolicy
  config:
    script_name: "main_policy.lua"           # Mandatory
    dependency_name: "helper.lua"            # Optional
    condition: "kong.request.get_method() == 'POST'"  # Optional
    flow: "request"                          # Optional
    kv_pairs:
      user_role: "admin"
      max_limit: "100"
    ordering:
      before:
        - rate-limiting
      after:
        - key-auth
    tags:
      - custom
      - jspolicy
```
- **Mandatory:** script_name
- **Optional:** dependency_name, condition, flow, kv_pairs, ordering, tags

### kong-custom-luafileexecuter
- **Purpose:** Execute any Lua file (and optional helper) from a shared directory for dynamic API logic.
- **Functionality:** Loads and runs Lua scripts from lua-scripts-files, supports ordering, condition, flow, tagging, and key-value pairs. No Kong reload/restart needed for script changes.
- **How it works:** Reads config, loads scripts from lua-scripts-files, executes in specified order and flow if condition is met.
- **YAML/JSON Configuration:**
```yaml
plugins:
- name: luafileexecuter
  config:
    script_name: "main_policy.lua"           # Mandatory
    dependency_name: "helper.lua"            # Optional
    condition: "kong.request.get_method() == 'POST'"  # Optional
    flow: "request"                          # Optional
    kv_pairs:
      user_role: "admin"
      max_limit: "100"
    ordering:
      before:
        - rate-limiting
      after:
        - key-auth
    tags:
      - custom
      - luafileexecuter
```
- **Mandatory:** script_name
- **Optional:** dependency_name, condition, flow, kv_pairs, ordering, tags

### Other Plugins
- All other plugins in the workspace (e.g., testlow, testmedium, testscript, template, pypolicy, luascriptfiles) follow the same YAML/JSON configuration pattern:
```yaml
plugins:
- name: <plugin name>
  config:
    script_name: <lua-script-name>           # Mandatory
    dependency_name: <lua-script-name>       # Optional
    condition: <condition>                   # Optional
    flow: <request|response|both>            # Optional
    kv_pairs:
      key1: value1
      key2: value2
    ordering:
      before:
        - <plugin-name>
      after:
        - <plugin-name>
    tags:
      - <tag1>
      - <tag2>
```

## Python Scripts

### scripts/find_lua_dependencies.py
- **Purpose:** List all Lua dependencies required by scripts in lua-scripts-files.
- **Usage:**
  ```sh
  python3 scripts/find_lua_dependencies.py
  ```
- **Output:** Lists each Lua file and its required modules.

### scripts/build-custom-plugin.py
- **Purpose:** Dummy script for building custom plugins.
- **Usage:**
  ```sh
  python3 scripts/build-custom-plugin.py
  ```

### scripts/deploy-custom-plugin.py
- **Purpose:** Dummy script for deploying custom plugins.
- **Usage:**
  ```sh
  python3 scripts/deploy-custom-plugin.py
  ```

### scripts/place-custom-plugin.py
- **Purpose:** Dummy script for placing custom plugins.
- **Usage:**
  ```sh
  python3 scripts/place-custom-plugin.py
  ```

## CLI Tool & Setup

### setup.py
- **Purpose:** Create and activate a Python virtual environment, install all Python and system dependencies for the workspace.
- **Usage:**
  ```sh
  python3 setup.py
  source venv/bin/activate
  ```
- **What it does:**
  - Creates venv/ if not present
  - Installs Python dependencies (e.g., pyyaml)
  - Installs system packages (e.g., docker)

### Production-Ready Tool
- **Purpose:** CLI tool for plugin lifecycle management (creation, validation, deployment, rollback, etc.)
- **Setup:**
  - Ensure Python 3.7+, Docker, and Pongo are installed
  - Install Python dependencies in venv
- **Usage:**
  - Run CLI commands as described in README.md
  - Use zip bundle for distribution

## Testing
- All plugins validated with Pongo and Kong EE 3.13.0.0 (1 success / 0 failures each)
- Python scripts tested and working from scripts/
- Plugins support both YAML and JSON configuration formats

---
For further details, see individual plugin README.md files and scripts in the workspace.
