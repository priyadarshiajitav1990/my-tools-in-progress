# Production Ready Kong Plugin Tool - Full Documentation

## Overview
This bundle provides a complete, production-ready CLI tool for developing, validating, testing, deploying, installing, configuring, and rolling back custom Kong plugins. It is designed to be user-installable (no admin required), leverages Docker and Pongo for testing, and includes all necessary scripts, templates, and documentation.

## Included Directories & Files
- `config.json` — Example configuration file
- `lua-scripts-files/` — Example Lua scripts for plugins
- `outputs/` — Output directory for logs, build artifacts, etc.
- `kong-pongo/` — Pongo test environment for Kong plugin validation
- `production-ready-tool/` — Legacy scripts, templates, and documentation
- `kong-plugin-cli/` — The new CLI tool (Python), templates, and setup

## Quick Start
1. **Install Python 3.7+ and Docker** (user must be in the `docker` group)
2. **Install dependencies:**
   ```sh
   pip install --user pyyaml
   ```
3. **Run the CLI tool:**
   ```sh
   python3 kong-plugin-cli/production_ready_tool.py --help
   ```
4. **Create a new plugin skeleton:**
   ```sh
   python3 kong-plugin-cli/production_ready_tool.py create myplugin
   ```
5. **Validate a plugin:**
   ```sh
   python3 kong-plugin-cli/production_ready_tool.py validate myplugin
   ```
6. **Deploy, install, configure, or rollback:**
   ```sh
   python3 kong-plugin-cli/production_ready_tool.py deploy myplugin
   python3 kong-plugin-cli/production_ready_tool.py install myplugin
   python3 kong-plugin-cli/production_ready_tool.py configure myplugin
   python3 kong-plugin-cli/production_ready_tool.py rollback myplugin
   ```
7. **Show or set tool config:**
   ```sh
   python3 kong-plugin-cli/production_ready_tool.py config --show
   python3 kong-plugin-cli/production_ready_tool.py config --key pongo_path --value /custom/path/to/pongo
   ```

## Directory Details
- **config.json**: Example config for plugins or tool
- **lua-scripts-files/**: Contains `handler.lua`, `helper.lua`, `main_policy.lua`, `schema.lua` as plugin script examples
- **outputs/**: Place for output logs, build/test results, etc.
- **kong-pongo/**: Pongo test environment, including Dockerfile, scripts, and Kong versions
- **production-ready-tool/**: Bash scripts, templates, and legacy automation
- **kong-plugin-cli/**: Python CLI tool, plugin template, README, and setup.py for pip installability

## Requirements
- Python 3.7+
- Docker (user must be in `docker` group)
- Pongo (included in `kong-pongo/`)

## Usage Guidance
- All plugin lifecycle operations are available via the CLI tool
- No admin/root required for install or use
- All templates and scripts are bundled for offline/portable use
- See `kong-plugin-cli/README.md` for more details

## Support
For further help, see the documentation in each directory or contact your Kong administrator.
