import logging
import os
import sys
from scripts.utils.logger_config import setup_logging
from scripts.utils.config_loader import load_and_set_env_variables
from scripts.pre.apigee_targetservers_info import apigee_targetservers
from scripts.pre.extract_apigee_api import extract_apigee_api
from scripts.pre.create_templates import create_plugin_templates
from scripts.core.targetendpoints import migrate_targetendpoints
from scripts.core.proxyendpoints import migrate_proxyendpoints
from scripts.utils.vars_expressions_converter import convert_apigee_expressions
from scripts.core.policy_migration import migrate_policies
from scripts.post.generate_report import generate_report
from scripts.utils.report_utils import initialize_report, finalize_report_data, print_migration_summary
from scripts.utils.validation_utils import validate_and_exit

def main():
    report_data = initialize_report()

    # Initialize the logging system for the application.
    setup_logging()
    
    logging.info("--- Apigee to Kong Migration Tool ---")
    logging.info(f"Current Working Directory: {os.getcwd()}")

    try:
        # Load all configurations from config.json into the environment.
        load_and_set_env_variables()

        # Fetch all Apigee TargetServer details for the environment.
        apigee_targetservers()

        # Find and extract the Apigee API zip file from the input directory.
        extract_apigee_api()

        # Ensure templates exist for all mapped plugins.
        create_plugin_templates()

        # Parse Apigee target endpoints and create corresponding Kong services and upstreams.
        migrate_targetendpoints(report_data)

        # Parse Apigee proxy endpoints and create corresponding Kong routes.
        migrate_proxyendpoints(report_data)

        # Convert Apigee-specific variables and expressions in the generated file to Kong format.
        convert_apigee_expressions()

        # Find and migrate Apigee policies to Kong plugins.
        migrate_policies(report_data)


        # Validate the generated Kong configuration file using decK.
        validate_and_exit()

        # Finalize and print migration summary
        finalize_report_data(report_data)
        print_migration_summary(report_data)

        # Deploy to Kong using decK after validation
        kong_yaml = os.environ.get('KONG_YAML_PATH', 'output/kong-migration-test-api.yml')
        deck_addr = os.environ.get('KONG_ADMIN_ADDR', 'http://44.213.128.41:8001')
        deck_key = os.environ.get('KONG_ADMIN_TOKEN', None)
        api_name = os.environ.get('API_NAME', 'migration-test-api')
        # Use deck gateway sync with tag for safe deployment
        import subprocess
        deploy_cmd = f"deck gateway sync {kong_yaml} --kong-addr {deck_addr} --select-tag {api_name}"
        if deck_key:
            deploy_cmd += f" --headers kong-admin-token:{deck_key}"
        print(f"\n--- Deploying to Kong with: {deploy_cmd}")
        result = subprocess.run(deploy_cmd, shell=True, capture_output=True, text=True)
        output = result.stdout + result.stderr
        # Custom handling for 409 UNIQUE violation errors
        if 'HTTP status 409' in output and 'UNIQUE violation detected' in output:
            import re
            matches = re.findall(r"Create (\w+) ([^ ]+) failed: HTTP status 409 \(message: \"UNIQUE violation detected on '\{name=\\\"([^\\\"]+)\\\"\}'\"\)", output)
            for entity_type, entity_id, entity_name in matches:
                print(f"[SUCCESS] {entity_type} '{entity_id}' already exists in Kong as '{entity_name}'. Treated as up-to-date.")
            # Remove 409 error lines
            filtered = re.sub(r"while processing event: Create \w+ [^ ]+ failed: HTTP status 409 \(message: \"UNIQUE violation detected on '\{name=\\\"[^\\\"]+\\\"\}'\"\)\n?", "", output)
            # Remove decK's error summary if only 409s remain
            error_lines = re.findall(r"Error: \d+ errors occurred:", filtered)
            # Check if any other error types remain
            other_errors = re.findall(r"while processing event: Create .* failed: HTTP status (?!409)", filtered)
            if error_lines and not other_errors:
                filtered = re.sub(r"Error: \d+ errors occurred:\n?", "", filtered)
            print(filtered.strip())
        else:
            print(output.strip())
        print("--- Deployment to Kong completed. ---")
        
        logging.info("--- Migration Process Completed Successfully! ---")

    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}", exc_info=True) # Set to True for debugging
        logging.error("--- Migration FAILED ---")
        sys.exit(1)

if __name__ == "__main__":
    main()