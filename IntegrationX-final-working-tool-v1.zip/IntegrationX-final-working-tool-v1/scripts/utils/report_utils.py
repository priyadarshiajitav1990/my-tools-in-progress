import time
from scripts.post.report_data import ReportData

def initialize_report():
    report_data = ReportData()
    report_data.start_time = time.time()
    return report_data

def finalize_report_data(report_data):
    report_data.end_time = time.time()

def print_migration_summary(report_data):
    from tabulate import tabulate
    print("\n================ MIGRATION SUMMARY ================")
    # Mapping Table
    table = []
    for mapping in report_data.mappings:
        table.append([
            mapping.get('apigee_type', ''),
            mapping.get('apigee_name', ''),
            mapping.get('kong_type', ''),
            mapping.get('kong_name', ''),
            'migrated',
            ''
        ])
    for unmapped in getattr(report_data, 'unmapped_entities', []):
        table.append([
            unmapped.get('type', ''),
            unmapped.get('name', ''),
            '',
            '',
            'missed',
            unmapped.get('reason', '')
        ])
    headers = ["Apigee Type", "Apigee Name", "Kong Type", "Kong Name", "Status", "Reason"]
    print(tabulate(table, headers=headers, tablefmt="fancy_grid"))

    # Entity Counts Table
    print("\n---------------- ENTITY COUNTS ----------------")
    counts_table = []
    for etype, names in report_data.apigee_entities.items():
        counts_table.append(["Apigee", etype, len(names)])
    for etype, names in report_data.kong_entities.items():
        counts_table.append(["Kong", etype, len(names)])
    print(tabulate(counts_table, headers=["Platform", "Entity Type", "Count"], tablefmt="fancy_grid"))

    # Missed/Failed Table
    if getattr(report_data, 'unmapped_entities', []):
        print("\n---------------- MISSED/FAILED ENTITIES ----------------")
        missed_table = []
        for unmapped in report_data.unmapped_entities:
            missed_table.append([
                unmapped['type'],
                unmapped['name'],
                unmapped['reason']
            ])
        print(tabulate(missed_table, headers=["Type", "Name", "Reason"], tablefmt="fancy_grid"))

    # Summary Table
    total = len(report_data.mappings) + len(getattr(report_data, 'unmapped_entities', []))
    migrated = len(report_data.mappings)
    missed = len(getattr(report_data, 'unmapped_entities', []))
    duration = getattr(report_data, 'end_time', 0) - getattr(report_data, 'start_time', 0)
    efficiency = migrated / total if total else 0
    print("\n---------------- OVERALL SUMMARY ----------------")
    summary_table = [
        ["Total entities processed", total],
        ["Migrated", migrated],
        ["Missed", missed],
        ["Total time taken (s)", f"{duration:.2f}"],
        ["Efficiency", f"{efficiency:.2%}"]
    ]
    print(tabulate(summary_table, tablefmt="fancy_grid"))