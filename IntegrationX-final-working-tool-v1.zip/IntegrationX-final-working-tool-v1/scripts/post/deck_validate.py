import os
import subprocess
import logging

# Validates the generated Kong YAML file using 'deck file validate'.
def validate_deck_file(kong_yaml_path):
    logging.info(f"  - Running 'deck file validate' on '{os.path.basename(kong_yaml_path)}'...")
    
    command = ["deck", "file", "validate", kong_yaml_path]
    logging.info(f"    - Executing command: {' '.join(command)}")
    
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        
        if result.returncode == 0:
            logging.info("    - Deck file validation successful.")
            return True
        else:
            error_message = result.stderr.replace("\n", "\n      ")
            logging.error(f"Deck file validation FAILED. Errors:\n      {error_message}")
            return False
            
    except FileNotFoundError:
        logging.error("'deck' command not found. Please ensure decK is installed and in your system's PATH.")
        return False

# Validates the generated Kong YAML file against a running gateway.
def validate_deck_gateway(kong_yaml_path, deck_addr, deck_key):
    # First, ping the gateway to ensure basic connectivity.
    logging.info(f"  - Pinging Kong gateway at '{deck_addr}'...")
    ping_command = ["deck", "gateway", "ping", "--kong-addr", deck_addr]
    if deck_key and deck_key.upper() != "NA":
        ping_command.extend(["--headers", f"kong-admin-token:{deck_key}"])
    
    logging.info(f"    - Executing command: {' '.join(ping_command)}")

    try:
        ping_result = subprocess.run(ping_command, capture_output=True, text=True, check=False)
        if ping_result.returncode != 0:
            output = ping_result.stderr or ping_result.stdout
            logging.error("Deck gateway ping FAILED. Cannot connect to the Kong Admin API.")
            logging.error(f"Errors:\n      {output.replace("\n", "\n      ")}")
            return False
        else:
            logging.info("    - Deck gateway ping successful.")
    except FileNotFoundError:
        logging.error("'deck' command not found. Please ensure decK is installed and in your system's PATH.")
        return False

    logging.info(f"  - Running 'deck gateway validate' against '{deck_addr}'...")
    command = ["deck", "gateway", "validate", kong_yaml_path, "--kong-addr", deck_addr]

    # Add authentication header if a key is provided
    if deck_key and deck_key.upper() != "NA":
        command.extend(["--headers", f"kong-admin-token:{deck_key}"])

    logging.info(f"    - Executing command: {' '.join(command)}")

    try:
        result = subprocess.run(command, capture_output=True, text=True, check=False)

        if result.returncode == 0:
            logging.info("    - Deck gateway validation successful.")
            return True
        else:
            # Deck often prints gateway errors to stdout, so we check both
            output = result.stderr or result.stdout
            error_message = output.replace("\n", "\n      ")

            # Add more human-readable error details for common issues
            if "503" in output:
                hint = ("\nHint: A '503 Service Unavailable' error indicates an issue with the Kong Gateway itself, not the migration script.\n"
                        "      This often happens if Kong cannot connect to its database or is in a degraded state.\n"
                        "      1. Please check the logs of your Kong Gateway instance to diagnose the problem.\n"
                        "      2. To complete the migration without this check, set 'deck_skip_gateway_validation' to true in your config.json file."
                       )
                logging.warning(hint)

            logging.error(f"Deck gateway validation FAILED.")
            logging.error(f"Errors:\n      {output.replace("\n", "\n      ")}")
            return False

    except FileNotFoundError:
        logging.error("'deck' command not found. Please ensure decK is installed and in your system's PATH.")
        return False

# Orchestrates the validation process.
def validations():
    logging.info("--- Starting Deck Validations ---")
    # Get config values from environment variables
    api_name = os.environ.get("api_name")
    output_dir = os.environ.get("output_dir")
    deck_addr = os.environ.get("deck_addr")
    deck_key = os.environ.get("deck_key")
    skip_gateway_validation = os.environ.get("deck_skip_gateway_validation", "false").lower() == "true"

    if not all([api_name, output_dir, deck_addr, deck_key]):
        logging.error("Missing required configuration for validation. Skipping.")
        return False

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    kong_yaml_path = os.path.join(project_root, output_dir, f"kong-{api_name}.yml")

    if not os.path.exists(kong_yaml_path):
        logging.error(f"Kong YAML file not found at '{kong_yaml_path}'. Cannot run validation.")
        return False

    # Run file validation
    file_validation_passed = validate_deck_file(kong_yaml_path)

    # Only proceed to gateway validation if file validation passed
    if file_validation_passed:
        if skip_gateway_validation:
            logging.warning("Skipping deck gateway validation as per configuration ('deck_skip_gateway_validation': true).")
            return True

        gateway_validation_passed = validate_deck_gateway(kong_yaml_path, deck_addr, deck_key)
        return gateway_validation_passed
    else:
        logging.warning("Skipping gateway validation due to file validation failure.")
        return False