import os
import re
import uuid
import yaml

TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), '../templates')
REQUIRED_FIELDS = {
    'vault-auth.yml.j2': {'config': {'vault': {'id': '123e4567-e89b-12d3-a456-426614174000'}}},
    'request-callout.yml.j2': {'config': {'callouts': [{'name': 'REQUIRED_PLACEHOLDER', 'request': {'url': 'http://example.com'}}]}},
}

def fill_required_fields(template_path, required_fields):
    with open(template_path, 'r') as f:
        content = yaml.safe_load(f)
    changed = False
    for key, value in required_fields.items():
        if key not in content or not content[key]:
            content[key] = value
            changed = True
        elif isinstance(value, dict):
            for subkey, subval in value.items():
                if subkey not in content[key] or not content[key][subkey]:
                    content[key][subkey] = subval
                    changed = True
    if changed:
        with open(template_path, 'w') as f:
            yaml.dump(content, f, default_flow_style=False)
        print(f"Updated required fields in {os.path.basename(template_path)}")

def main():
    for fname, required in REQUIRED_FIELDS.items():
        tpath = os.path.join(TEMPLATE_DIR, fname)
        if os.path.exists(tpath):
            fill_required_fields(tpath, required)

if __name__ == '__main__':
    main()
