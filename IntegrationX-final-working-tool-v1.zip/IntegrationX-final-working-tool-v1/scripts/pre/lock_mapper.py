import os
import hashlib
import sys


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, '..', '..'))
MAPPER_PATH = os.path.join(PROJECT_ROOT, 'mappers', 'policy-to-plugin-mapper.json')
CHECKSUM_PATH = os.path.join(PROJECT_ROOT, 'mappers', 'policy-to-plugin-mapper.checksum')

def compute_checksum(filepath):
    sha256 = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while True:
            data = f.read(65536)
            if not data:
                break
            sha256.update(data)
    return sha256.hexdigest()

def save_checksum():
    checksum = compute_checksum(MAPPER_PATH)
    with open(CHECKSUM_PATH, 'w') as f:
        f.write(checksum)
    print(f"Checksum saved: {checksum}")

def validate_checksum():
    if not os.path.exists(CHECKSUM_PATH):
        print("Checksum file not found. Please run this script with 'save' argument after verifying the mapper file.")
        sys.exit(1)
    with open(CHECKSUM_PATH, 'r') as f:
        saved = f.read().strip()
    current = compute_checksum(MAPPER_PATH)
    if saved != current:
        print("ERROR: policy-to-plugin-mapper.json has been modified!")
        sys.exit(2)
    print("Checksum validation passed. File is immutable.")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'save':
        save_checksum()
    else:
        validate_checksum()

if __name__ == '__main__':
    main()
