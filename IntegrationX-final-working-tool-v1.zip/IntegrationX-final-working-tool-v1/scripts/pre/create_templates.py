import json
import os
import logging

def create_plugin_templates(project_root=None):
    """
    Ensures that a Jinja2 template exists for every Kong plugin defined in the mapper.
    """
    if project_root is None:
        # Calculate project root relative to this script (scripts/pre/create_templates.py)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current_dir))

    mapper_path = os.path.join(project_root, "mappers", "policy-to-plugin-mapper.json")
    templates_dir = os.path.join(project_root, "templates")

    if not os.path.exists(mapper_path):
        logging.warning(f"Mapper file not found at {mapper_path}. Cannot generate templates.")
        return

    if not os.path.exists(templates_dir):
        try:
            os.makedirs(templates_dir)
            logging.info(f"Created templates directory at {templates_dir}")
        except OSError as e:
            logging.error(f"Failed to create templates directory: {e}")
            return

    try:
        with open(mapper_path, 'r') as f:
            mapper = json.load(f)
    except Exception as e:
        logging.error(f"Failed to load mapper file: {e}")
        return

    unique_plugins = set()
    # mapper is a dict where each value is a list of plugin dicts
    for policy, plugins_list in mapper.items():
        if not isinstance(plugins_list, list):
            continue
        for plugin_entry in plugins_list:
            plugin_name = plugin_entry.get("plugin_name")
            if plugin_name:
                unique_plugins.add(plugin_name)
        

    logging.info(f"Identified {len(unique_plugins)} unique Kong plugins from mapper.")

    for plugin in unique_plugins:
        template_filename = f"{plugin}.yml.j2"
        template_path = os.path.join(templates_dir, template_filename)
        
        if not os.path.exists(template_path):
            try:
                with open(template_path, 'w') as f:
                    # Basic scaffold for the template
                    f.write(f"# Template for Kong plugin: {plugin}\n")
                    f.write(f"- name: {plugin}\n")
                    f.write("  config:\n")
                    f.write("    # TODO: Map configuration from Apigee policy\n")
                logging.info(f"Created missing template: {template_filename}")
            except IOError as e:
                logging.error(f"Failed to write template {template_filename}: {e}")