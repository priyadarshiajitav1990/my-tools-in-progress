local kong = kong
local plugin = {
  PRIORITY = 800,
  VERSION = "1.0.0",
}

local function load_script(file_name)
  local info = debug.getinfo(1, "S")
  local handler_path = info.source:sub(2)
  local plugin_dir = handler_path:match("(.*/)")
  local file_path = plugin_dir .. file_name
  local f, err = io.open(file_path, "r")
  if f then
    local script = f:read("*a")
    f:close()
    return script
  else
    kong.log.err("Cannot open script file " .. file_name .. ": " .. tostring(err))
    return nil
  end
end

local function execute_script(conf, phase)
  local main_name = conf["script_name"]
  local dep_name = conf["dependency_name"]
  local condition = conf["condition"]
  local flow = conf["flow"] or "both"
  local kv = conf["kv_pairs"] or {}
  if main_name and main_name ~= "" and (flow == phase or flow == "both") then
    local should_run = true
    if condition and condition ~= "" then
      local func, err = load("return " .. condition)
      if func then
        local ok, result = pcall(func)
        should_run = ok and result
      end
    end
    if should_run then
      -- Load dependency script if provided
      if dep_name and dep_name ~= "" then
        local dep_script = load_script(dep_name)
        if dep_script then
          local dep_func, err = load(dep_script)
          if dep_func then
            local ok, err = pcall(dep_func, kv)
            if not ok then
              kong.log.err("Dependency script error: " .. tostring(err))
            end
          else
            kong.log.err("Dependency script load error: " .. tostring(err))
          end
        end
      end
      -- Load and execute main script
      local main_script = load_script(main_name)
      if main_script then
        local main_func, err = load(main_script)
        if main_func then
          local ok, err = pcall(main_func, kv)
          if not ok then
            kong.log.err("Main script error: " .. tostring(err))
          end
        else
          kong.log.err("Main script load error: " .. tostring(err))
        end
      end
    end
  end
end

function plugin:access(conf)
  execute_script(conf, "request")
end

function plugin:header_filter(conf)
  execute_script(conf, "response")
end

function plugin:body_filter(conf)
  execute_script(conf, "response")
end

return plugin
