return function(kv)
  kong.log("main_policy executed with kv: " .. (kv and kv.user_role or "none"))
end