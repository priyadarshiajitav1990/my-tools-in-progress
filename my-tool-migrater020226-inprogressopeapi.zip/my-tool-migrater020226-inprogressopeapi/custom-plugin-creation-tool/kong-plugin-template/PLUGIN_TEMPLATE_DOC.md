# Kong Plugin Template: __PLUGIN_NAME__

## Overview
This is a template for creating Kong plugins similar to jspolicy. Replace all instances of `__PLUGIN_NAME__` with your desired plugin name and update script/config file names as needed.

## Features
- Main and dependency Lua script execution
- Conditional execution
- Request/response/both flow selection
- Key-value configuration
- Tagging support
- No plugin validation except for Lua script loading

## How to Use
1. Copy the `kong-plugin-template` folder to a new location.
2. Replace all `__PLUGIN_NAME__` with your new plugin name in all files and folder names.
3. Place your Lua scripts in the plugin directory.
4. Update the test spec and configuration as needed.
5. Use Pongo for integration testing.

## Example Configuration
```yaml
plugins:
  - name: __PLUGIN_NAME__
    config:
      script_name: main_policy.lua
      dependency_name: helper.lua
      condition: "ngx.var.request_method == 'GET'"
      flow: request
      kv_pairs:
        user_role: admin
        max_limit: "100"
    tags:
      - custom
      - policy
```

## Testing
Run `pongo run` in the plugin directory to execute integration tests.

## Notes
- No plugin validation is performed except for Lua script loading.
- You can freely modify, rename, or extend the template for your needs.
