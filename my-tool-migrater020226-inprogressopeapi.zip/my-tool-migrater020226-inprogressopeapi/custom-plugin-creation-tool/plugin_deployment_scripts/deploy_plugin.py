#!/usr/bin/env python3
"""
Plugin Deployment Script

- Reads deployment configuration from config.json (input directory, local/remote, remote info)
- Copies plugin files to Kong's plugin directory
- Configures and enables the plugin
- Restarts Kong, retries if needed, and rolls back if Kong fails to start
- Allows config override via command-line arguments
"""
import os
import sys
import json
import shutil
import subprocess
import argparse
import time

DEFAULT_CONFIG = {
    "input_directory": "../outputs/testplugin-standalone",
    "deploy_mode": "local",  # or "remote"
    "kong_plugin_dir": "/usr/local/share/lua/5.1/kong/plugins/",
    "plugin_name": "testplugin",
    "kong_restart_cmd": "kong restart",
    "kong_status_cmd": "kong health",
    "remote": {
        "host": "",
        "username": "",
        "password": "",
        "key": ""
    }
}

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")


def load_config(args):
    config = DEFAULT_CONFIG.copy()
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            config.update(json.load(f))
    # Override with CLI args
    if args.input_directory:
        config["input_directory"] = args.input_directory
    if args.deploy_mode:
        config["deploy_mode"] = args.deploy_mode
    if args.plugin_name:
        config["plugin_name"] = args.plugin_name
    if args.kong_plugin_dir:
        config["kong_plugin_dir"] = args.kong_plugin_dir
    return config


def copy_plugin_files(input_dir, kong_plugin_dir, plugin_name):
    dest_dir = os.path.join(kong_plugin_dir, plugin_name)
    if os.path.exists(dest_dir):
        shutil.rmtree(dest_dir)
    shutil.copytree(input_dir, dest_dir)
    print(f"Copied plugin files to {dest_dir}")
    return dest_dir


def enable_plugin(plugin_name):
    # Add plugin to Kong config (kong.conf or via Admin API)
    # Here, we assume declarative config or DB-less mode for simplicity
    # For DB mode, use Admin API to enable the plugin
    print(f"Enabling plugin '{plugin_name}' in Kong...")
    # This is a placeholder; actual implementation may vary
    # subprocess.run(["curl", "-i", "-X", "POST", f"http://localhost:8001/plugins", "--data", f"name={plugin_name}"])
    pass


def restart_kong(restart_cmd, status_cmd, max_retries=2):
    for attempt in range(1, max_retries+1):
        print(f"Restarting Kong (attempt {attempt})...")
        result = subprocess.run(restart_cmd, shell=True)
        time.sleep(3)
        status = subprocess.run(status_cmd, shell=True)
        if status.returncode == 0:
            print("Kong is running and healthy.")
            return True
        print("Kong failed to start. Retrying...")
    print("Kong failed to start after retries.")
    return False


def rollback_plugin(kong_plugin_dir, plugin_name):
    dest_dir = os.path.join(kong_plugin_dir, plugin_name)
    if os.path.exists(dest_dir):
        shutil.rmtree(dest_dir)
    print(f"Rolled back plugin files from {dest_dir}")


def main():
    parser = argparse.ArgumentParser(description="Deploy Kong plugin with rollback and health check.")
    parser.add_argument("--input_directory", help="Directory containing plugin files")
    parser.add_argument("--deploy_mode", choices=["local", "remote"], help="Deployment mode")
    parser.add_argument("--plugin_name", help="Plugin name")
    parser.add_argument("--kong_plugin_dir", help="Kong plugins directory")
    args = parser.parse_args()

    config = load_config(args)
    print("Loaded config:", config)

    if config["deploy_mode"] == "local":
        try:
            dest_dir = copy_plugin_files(config["input_directory"], config["kong_plugin_dir"], config["plugin_name"])
            enable_plugin(config["plugin_name"])
            success = restart_kong(config["kong_restart_cmd"], config["kong_status_cmd"])
            if not success:
                rollback_plugin(config["kong_plugin_dir"], config["plugin_name"])
                # Final check: ensure Kong is running healthy after rollback
                subprocess.run(config["kong_restart_cmd"], shell=True)
                status = subprocess.run(config["kong_status_cmd"], shell=True)
                if status.returncode == 0:
                    print("Kong is healthy after rollback.")
                else:
                    print("Kong is NOT healthy after rollback. Manual intervention required.")
        except Exception as e:
            print(f"Deployment failed: {e}")
            rollback_plugin(config["kong_plugin_dir"], config["plugin_name"])
    else:
        print("Remote deployment is not implemented in this script.")
        # Implement remote deployment (e.g., via SSH/SCP) as needed

if __name__ == "__main__":
    main()
