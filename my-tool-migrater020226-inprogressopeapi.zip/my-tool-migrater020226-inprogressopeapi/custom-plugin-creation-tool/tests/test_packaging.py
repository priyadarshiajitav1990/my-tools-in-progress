import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
from custom_plugin_develop import package_plugin, create_plugin_from_template, load_config
import os

class TestPackaging(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.plugin_dir = create_plugin_from_template(self.config)
        self.package_path = None

    def test_package_plugin(self):
        self.package_path = package_plugin(self.plugin_dir)
        self.assertTrue(os.path.exists(self.package_path))
        self.assertTrue(os.path.isdir(self.package_path))

    def tearDown(self):
        import shutil
        if self.plugin_dir and os.path.exists(self.plugin_dir):
            shutil.rmtree(self.plugin_dir)
        if self.package_path and os.path.exists(self.package_path):
            shutil.rmtree(self.package_path)

if __name__ == "__main__":
    unittest.main()
