import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
import os
from custom_plugin_develop import create_plugin_from_template, load_config

class TestPluginCreation(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.plugin_dir = None

    def test_create_plugin(self):
        self.plugin_dir = create_plugin_from_template(self.config)
        self.assertTrue(os.path.exists(self.plugin_dir))
        self.assertTrue(os.path.isdir(self.plugin_dir))

    def tearDown(self):
        if self.plugin_dir and os.path.exists(self.plugin_dir):
            import shutil
            shutil.rmtree(self.plugin_dir)

if __name__ == "__main__":
    unittest.main()
