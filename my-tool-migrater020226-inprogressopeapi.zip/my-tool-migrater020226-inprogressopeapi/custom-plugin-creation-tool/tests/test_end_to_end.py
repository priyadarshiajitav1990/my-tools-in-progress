import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
from custom_plugin_develop import load_config, create_plugin_from_template, resolve_dependencies, package_plugin, validate_with_pongo
import os

class TestEndToEnd(unittest.TestCase):
    def test_full_workflow(self):
        config = load_config()
        plugin_dir = create_plugin_from_template(config)
        resolve_dependencies(plugin_dir)
        package_path = package_plugin(plugin_dir)
        try:
            validate_with_pongo(package_path)
        except SystemExit:
            self.fail("End-to-end validation failed unexpectedly.")
        # Cleanup
        import shutil
        if plugin_dir and os.path.exists(plugin_dir):
            shutil.rmtree(plugin_dir)
        if package_path and os.path.exists(package_path):
            shutil.rmtree(package_path)

if __name__ == "__main__":
    unittest.main()
