import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
from custom_plugin_develop import validate_with_pongo, create_plugin_from_template, package_plugin, load_config
import os

class TestValidation(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.plugin_dir = create_plugin_from_template(self.config)
        self.package_path = package_plugin(self.plugin_dir)

    def test_validate_with_pongo(self):
        try:
            validate_with_pongo(self.package_path)
        except SystemExit:
            self.fail("Validation with pongo failed unexpectedly.")

    def tearDown(self):
        import shutil
        if self.plugin_dir and os.path.exists(self.plugin_dir):
            shutil.rmtree(self.plugin_dir)
        if self.package_path and os.path.exists(self.package_path):
            shutil.rmtree(self.package_path)

if __name__ == "__main__":
    unittest.main()
