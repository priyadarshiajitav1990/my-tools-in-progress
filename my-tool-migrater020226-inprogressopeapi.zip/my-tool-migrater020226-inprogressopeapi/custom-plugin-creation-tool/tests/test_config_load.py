import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
import os
import json
from custom_plugin_develop import load_config, CONFIG_PATH

class TestConfigLoad(unittest.TestCase):
    def test_load_config_success(self):
        config = load_config()
        self.assertIsInstance(config, dict)
        self.assertIn("plugin_name", config)

    def test_load_config_missing(self):
        backup = CONFIG_PATH + ".bak"
        os.rename(CONFIG_PATH, backup)
        with self.assertRaises(SystemExit):
            load_config()
        os.rename(backup, CONFIG_PATH)

if __name__ == "__main__":
    unittest.main()
