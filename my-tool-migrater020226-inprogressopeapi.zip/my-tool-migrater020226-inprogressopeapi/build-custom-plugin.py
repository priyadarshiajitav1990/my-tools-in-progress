import os
import shutil
import sys
import subprocess
import json

def build_custom_plugin(main_lua, helper_lua, plugin_name):
    workspace_root = os.path.dirname(os.path.abspath(__file__))
    template_dir = os.path.join(workspace_root, "kong-plugin-template")
    target_dir = os.path.join(workspace_root, f"kong-plugin-{plugin_name}")
    plugin_dir = os.path.join(target_dir, "kong", "plugins", plugin_name)
    spec_dir = os.path.join(target_dir, "spec")

    # Copy template
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    shutil.copytree(template_dir, target_dir)

    # Rename plugin directory and spec
    os.rename(os.path.join(target_dir, "kong/plugins/__PLUGIN_NAME__"), plugin_dir)
    os.rename(os.path.join(target_dir, "spec/__PLUGIN_NAME___spec.lua"), os.path.join(spec_dir, f"{plugin_name}_spec.lua"))

    # Replace __PLUGIN_NAME__ in all files
    for root, _, files in os.walk(target_dir):
        for file in files:
            path = os.path.join(root, file)
            with open(path, "r") as f:
                content = f.read()
            content = content.replace("__PLUGIN_NAME__", plugin_name)
            with open(path, "w") as f:
                f.write(content)

    # Place main and helper lua files, skip if source and destination are the same
    main_dst = os.path.join(plugin_dir, "main_policy.lua")
    helper_dst = os.path.join(plugin_dir, "helper.lua")
    if os.path.abspath(main_lua) != os.path.abspath(main_dst):
        shutil.copy(main_lua, main_dst)
    else:
        print(f"Skipping copy: {main_lua} is already at destination.")
    if os.path.abspath(helper_lua) != os.path.abspath(helper_dst):
        shutil.copy(helper_lua, helper_dst)
    else:
        print(f"Skipping copy: {helper_lua} is already at destination.")

    # Create a minimal rockspec for dependency management
    rockspec_filename = f"{plugin_name}-1.0-1.rockspec"
    rockspec = f"""rockspec_format = "3.0"
package = "{plugin_name}"
version = "1.0-1"
source = {{
    url = "file://kong/plugins/{plugin_name}/handler.lua"
}}
description = {{
    summary = "Custom Kong plugin generated from template",
    detailed = "Generated plugin with main and helper Lua scripts."
}}
dependencies = {{}}
"""
    with open(os.path.join(target_dir, rockspec_filename), "w") as f:
        f.write(rockspec)

    # Install dependencies (if any listed in rockspec)
    subprocess.run(["luarocks", "install", os.path.join(target_dir, rockspec_filename), "--local"], cwd=target_dir)

    print(f"Plugin '{plugin_name}' created at {target_dir}")
    print("Validating file structure...")
    assert os.path.exists(os.path.join(plugin_dir, "handler.lua")), "handler.lua missing"
    assert os.path.exists(os.path.join(plugin_dir, "schema.lua")), "schema.lua missing"
    assert os.path.exists(os.path.join(plugin_dir, "main_policy.lua")), "main_policy.lua missing"
    assert os.path.exists(os.path.join(plugin_dir, "helper.lua")), "helper.lua missing"
    print("Validation passed. Plugin is ready.")

def load_config():
    import json
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    with open(config_path) as f:
        return json.load(f)

if __name__ == "__main__":
    config = load_config()
    main_lua = os.path.join(config["src_root"], "main_policy.lua")
    helper_lua = os.path.join(config["src_root"], "helper.lua")
    plugin_name = config["plugin_name"]
    build_custom_plugin(main_lua, helper_lua, plugin_name)
