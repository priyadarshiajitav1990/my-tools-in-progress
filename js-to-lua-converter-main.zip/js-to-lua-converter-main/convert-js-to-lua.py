import os
import sys
import subprocess

# Define paths
script_dir = os.path.dirname(os.path.abspath(__file__))
translators_dir = os.path.join(script_dir, 'translators')

# Ensure the translators directory is in the Python path
if translators_dir not in sys.path:
    sys.path.append(translators_dir)

# Path to the js-to-lua-plugin.py script
js_to_lua_script = os.path.join(translators_dir, 'js-to-lua-plugin.py')

# Run the js-to-lua-plugin.py script
try:
    result = subprocess.run(['python', js_to_lua_script], check=True, capture_output=True, text=True)
    print("Conversion completed successfully.")
    print(result.stdout)
except subprocess.CalledProcessError as e:
    print("Error during conversion:")
    print(e.stderr)
