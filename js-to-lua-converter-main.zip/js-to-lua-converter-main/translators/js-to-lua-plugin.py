import os
import sys
import configparser
import logging
from js_to_lua.js_to_lua_transpiler import JavaScriptToLuaTranspiler

def find_javascript_files(start_path):
    """
    Finds all JavaScript files in a given directory and its subdirectories.

    Args:
        start_path (str): The path to the directory to start searching from.

    Returns:
        list: A list of paths to the JavaScript files found.
    """
    js_files = []
    for root, _, files in os.walk(start_path):
        for file in files:
            if file.endswith(".js"):
                js_files.append(os.path.join(root, file))
    return js_files

def create_kong_plugin(js_file_path, outputs_dir):
    """
    Creates a Kong Lua plugin from a JavaScript file.

    Args:
        js_file_path (str): The path to the JavaScript file.
        outputs_dir (str): The path to the outputs directory.
    """
    try:
        plugin_name = os.path.splitext(os.path.basename(js_file_path))[0]
        plugin_dir = os.path.join(outputs_dir, 'kong', 'plugins', plugin_name)
        os.makedirs(plugin_dir, exist_ok=True)

        schema_path = os.path.join(plugin_dir, 'schema.lua')

        js_content = None
        try:
            with open(js_file_path, 'r') as f:
                js_content = f.read()
        except Exception as e:
            logging.warning(f"Could not read JavaScript file '{js_file_path}': {e}.")
            logging.warning("A placeholder plugin will be created. You will need to manually transpile the code.")

        if js_content:
            transpiler = JavaScriptToLuaTranspiler()
            transpiler.transpile_and_inject(js_content, plugin_dir, plugin_name)
            logging.info(f"Created Kong plugin '{plugin_name}' in '{plugin_dir}'")
        else:
            # Create placeholder structure
            src_dir = os.path.join(plugin_dir, 'src')
            os.makedirs(src_dir, exist_ok=True)
            handler_path = os.path.join(plugin_dir, 'handler.lua')
            main_lua_path = os.path.join(src_dir, 'main.lua')

            with open(main_lua_path, 'w') as f:
                f.write(f"""-- {plugin_name}/src/main.lua
local M = {{}}

function M.execute(plugin_conf)
  -- This is a placeholder.
  -- TODO: Add transpiled Lua code here
end

return M
""")
            with open(handler_path, 'w') as f:
                f.write(f"""-- {plugin_name}/handler.lua
local main = require "kong.plugins.{plugin_name}.src.main"

local plugin = {{
  PRIORITY = 1000,
  VERSION = "0.1.0"
}}

function plugin:access(plugin_conf)
  local ok, err = pcall(main.execute, plugin_conf)
  if not ok then
    kong.log.err("Error in {plugin_name} plugin: ", err)
  end
end

return plugin
""")
            logging.info(f"Created placeholder Kong plugin '{plugin_name}' in '{plugin_dir}'")

        with open(schema_path, 'w') as f:
            f.write("""return {
  no_consumer = true,
  fields = {
    -- For each configuration variable, add a field here.
    -- For example, if your JavaScript code uses `context.getVariable('my_variable')`,
    -- you might add:
    -- my_variable = { type = "string", required = true, default = "default_value" }
  },
  self_check = function(schema, plugin_t, dao, is_update)
    -- Add custom validation here
    return true
  end
}""")

    except Exception as e:
        logging.error(f"Error creating plugin for '{js_file_path}': {e}")


def main():
    """
    Main function to find JavaScript files in Apigee bundles and create Kong plugins.
    """
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    script_dir = os.path.dirname(os.path.abspath(__file__))
    if script_dir not in sys.path:
        sys.path.append(script_dir)

    config = configparser.ConfigParser()
    config.read(os.path.join(script_dir, 'config.conf'))

    try:
        input_dir = config.get('paths', 'input_dir')
        outputs_dir = config.get('paths', 'output_dir')
    except (configparser.NoSectionError, configparser.NoOptionError) as e:
        logging.error(f"Error reading configuration file: {e}")
        return

    if not os.path.isabs(input_dir):
        input_dir = os.path.join(script_dir, input_dir)

    if not os.path.isabs(outputs_dir):
        outputs_dir = os.path.join(script_dir, outputs_dir)

    if not os.path.isdir(input_dir):
        logging.error(f"The specified input path does not exist or is not a directory: {input_dir}")
        return

    logging.info(f"Searching for JavaScript files in: {input_dir}")
    js_files_found = find_javascript_files(input_dir)

    if js_files_found:
        logging.info("Found the following JavaScript files:")
        for js_file in js_files_found:
            print(js_file)

        os.makedirs(outputs_dir, exist_ok=True)

        logging.info(f"\nCreating Kong Lua plugins in: {outputs_dir}")
        for js_file in js_files_found:
            create_kong_plugin(js_file, outputs_dir)
    else:
        logging.info("No JavaScript files found in the specified path.")

if __name__ == "__main__":
    main()