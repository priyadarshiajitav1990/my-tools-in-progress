const acorn = require('acorn');
const fs = require('fs');

let jsCode = '';

process.stdin.on('data', (chunk) => {
    jsCode += chunk;
});

process.stdin.on('end', () => {
    try {
        const ast = acorn.parse(jsCode, {
            ecmaVersion: 2020, // Support modern JavaScript features
            locations: false, // Don't include line/column locations to keep AST smaller
            sourceType: 'script', // 'script' or 'module'
            allowAwaitOutsideFunction: true, // Common in some server-side JS
            allowImportExportEverywhere: true, // Flexible import/export
        });
        console.log(JSON.stringify(ast, null, 2));
    } catch (error) {
        console.error(JSON.stringify({ error: error.message, stack: error.stack }, null, 2));
        process.exit(1);
    }
});
