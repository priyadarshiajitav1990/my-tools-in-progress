import re
import os
import logging
import json
from .js_ast_parser import JsAstParser
from .conceptual_mappings import CONCEPTUAL_MAPPINGS
from .variable_mappings import VARIABLE_MAPPINGS

class JavaScriptToLuaTranspiler:
    """
    An AST-based, best-effort transpiler to convert common Apigee
    JavaScript patterns into their Lua equivalents for Kong plugins.
    """
    def __init__(self):
        current_dir = os.path.dirname(__file__)
        js_parser_path = os.path.join(current_dir, 'js_parser')
        self.js_ast_parser = JsAstParser(js_parser_path)
        logging.info("JsAstParser instantiated.")

        self.variable_rules = []
        for mapping in VARIABLE_MAPPINGS:
            compiled_pattern = re.compile(mapping["pattern"])
            self.variable_rules.append({
                "pattern": compiled_pattern,
                "replacement": mapping["replacement"],
                "type": mapping["type"],
                "scope": mapping["scope"]
            })

        self.lua_output = []
        self.indent_level = 0
        self.transpiler_state = {
            'uses_request_vars': False,
            'uses_response_header_vars': False,
            'uses_response_body_vars': False,
            'needs_http_client': False,
            'needs_cjson': False,
            'declared_variables': set(),
            'untranslated_nodes': []
        }

    def _indent(self) -> str:
        return "  " * self.indent_level

    def _emit(self, code: str):
        self.lua_output.append(f"{self._indent()}{code}")

    def _visit(self, node):
        node_type = node.get('type')
        method_name = f'_visit_{node_type}'
        visitor = getattr(self, method_name, self._generic_visit)
        return visitor(node)

    def _generic_visit(self, node):
        logging.warning(f"AST Node type '{node.get('type')}' not implemented. Node: {json.dumps(node, indent=2)}")
        self.transpiler_state['untranslated_nodes'].append(node)
        self._emit(f"-- TODO: Untranslated AST node type: {node.get('type')}")
        return ''

    def _visit_Program(self, node):
        for body_node in node.get('body', []):
            self._visit(body_node)
        return '\n'.join(self.lua_output)

    def _visit_ExpressionStatement(self, node):
        self._visit(node['expression'])
        return ''

    def _reconstruct_js(self, node):
        if not node: return ''
        node_type = node.get('type')
        if node_type == 'Identifier':
            return node['name']
        if node_type == 'Literal':
            return node.get('raw', str(node.get('value')))
        if node_type == 'MemberExpression':
            obj = self._reconstruct_js(node.get('object'))
            prop = self._reconstruct_js(node.get('property'))
            if "context" in obj:
                if "request" in prop:
                    self.transpiler_state['uses_request_vars'] = True
                elif "response" in prop:
                    if "headers" in prop:
                        self.transpiler_state['uses_response_header_vars'] = True
                    elif "body" in prop:
                        self.transpiler_state['uses_response_body_vars'] = True
            if node.get('computed'):
                return f"{obj}[{prop}]"
            else:
                return f"{obj}.{prop}"
        if node_type == 'CallExpression':
            callee = self._reconstruct_js(node.get('callee'))
            args = [self._reconstruct_js(arg) for arg in node.get('arguments', [])]
            return f"{callee}({', '.join(args)})"
        return ''

    def _visit_CallExpression(self, node):
        js_code = self._reconstruct_js(node)
        for rule in self.variable_rules:
            match = rule["pattern"].search(js_code)
            if match:
                replacement = rule["replacement"]
                if match.groupdict():
                    for group_name, group_value in match.groupdict().items():
                        replacement = replacement.replace(f'\\g<{group_name}>', group_value)
                else:
                    groups = match.groups()
                    if groups:
                        for i, group in enumerate(groups):
                            replacement = replacement.replace(f'\\{i+1}', group)
                if rule['type'] == 'getter':
                    return replacement
                self._emit(replacement)
                return ''
        callee = self._visit(node['callee'])
        args = [self._visit(arg) for arg in node.get('arguments', [])]
        if 'get' in callee:
            return f"{callee}({', '.join(args)})"
        self._emit(f"{callee}({', '.join(args)})")
        return ''

    def _visit_Identifier(self, node):
        return node['name']

    def _visit_Literal(self, node):
        if isinstance(node['value'], str):
            return f'"{node["value"]}"'
        elif node['value'] is None:
            return 'nil'
        return str(node['value'])

    def _visit_VariableDeclaration(self, node):
        for declaration in node['declarations']:
            var_name = self._visit(declaration['id'])
            init_value = self._visit(declaration['init']) if declaration.get('init') else 'nil'
            self._emit(f"local {var_name} = {init_value}")
            self.transpiler_state['declared_variables'].add(var_name)
        return ''

    def _visit_VariableDeclarator(self, node):
        return ''

    def _visit_BinaryExpression(self, node):
        left = self._visit(node['left'])
        right = self._visit(node['right'])
        op = node['operator']
        lua_op_map = {'===': '==', '!==': '~=', '&&': 'and', '||': 'or'}
        lua_op = lua_op_map.get(op, op)
        return f"{left} {lua_op} {right}"
    
    def _visit_LogicalExpression(self, node):
        left = self._visit(node['left'])
        right = self._visit(node['right'])
        op = node['operator']
        lua_op_map = {'&&': 'and', '||': 'or'}
        lua_op = lua_op_map.get(op, op)
        return f"({left} {lua_op} {right})"
    
    def _visit_MemberExpression(self, node):
        obj = self._visit(node['object'])
        prop = self._visit(node['property'])
        if "context" in obj:
            if "request" in prop:
                self.transpiler_state['uses_request_vars'] = True
            elif "response" in prop:
                if "headers" in prop:
                    self.transpiler_state['uses_response_header_vars'] = True
                elif "body" in prop:
                    self.transpiler_state['uses_response_body_vars'] = True
        if node.get('computed'):
            return f"{obj}[{prop}]"
        else:
            return f"{obj}.{prop}"

    def _visit_BlockStatement(self, node):
        for body_node in node.get('body', []):
            self._visit(body_node)
        return ''

    def _visit_IfStatement(self, node):
        test = self._visit(node['test'])
        self._emit(f"if {test} then")
        self.indent_level += 1
        self._visit(node['consequent'])
        self.indent_level -= 1
        if node.get('alternate'):
            self._emit("else")
            self.indent_level += 1
            self._visit(node['alternate'])
            self.indent_level -= 1
        self._emit("end")
        return ''
    
    def _visit_ReturnStatement(self, node):
        argument = self._visit(node['argument']) if node.get('argument') else ''
        self._emit(f"return {argument}")
        return ''

    def _transform_js_ast_to_lua_code(self, js_ast: dict) -> str:
        self.lua_output = []
        self.indent_level = 0
        self.transpiler_state['untranslated_nodes'] = []
        self.transpiler_state['declared_variables'] = set()
        self.transpiler_state['uses_request_vars'] = False
        self.transpiler_state['uses_response_header_vars'] = False
        self.transpiler_state['uses_response_body_vars'] = False
        self._visit(js_ast)
        if self.transpiler_state['untranslated_nodes']:
            logging.warning("\n--- AST Transpilation Warnings (Manual Review Required) ---")
            for node in self.transpiler_state['untranslated_nodes']:
                logging.warning(f"Untranslated AST Node Type: '{node.get('type')}'")
            logging.warning("----------------------------------------------------------\n")
        return '\n'.join(self.lua_output)

    def transpile(self, js_content: str) -> (str, dict):
        logging.info("Starting AST-based transpilation.")
        try:
            js_ast = self.js_ast_parser.parse_js(js_content)
            logging.debug(f"Received JS AST: {json.dumps(js_ast, indent=2)}")
            lua_code = self._transform_js_ast_to_lua_code(js_ast)
            return lua_code, self.transpiler_state
        except RuntimeError as e:
            logging.error(f"Transpilation failed: {e}")
            return f'-- AST-based transpilation failed: {e}\n-- Original JS content:\n{js_content}', self.transpiler_state

    def transpile_and_inject(self, js_content: str, plugin_dir: str, plugin_name: str):
        lua_code, state = self.transpile(js_content)

        lifecycle_phase = "access"
        if state['uses_response_body_vars']:
            lifecycle_phase = "body_filter"
        elif state['uses_response_header_vars']:
            lifecycle_phase = "header_filter"

        src_dir = os.path.join(plugin_dir, 'src')
        os.makedirs(src_dir, exist_ok=True)
        main_lua_path = os.path.join(src_dir, 'main.lua')
        handler_path = os.path.join(plugin_dir, 'handler.lua')

        main_lua_template = f"""-- {plugin_name}/src/main.lua

local M = {{}}

-- Private function for the core logic
local function execute_logic(plugin_conf)
  -- Transpiled Lua code
{lua_code}
end

-- Public execute function called by the handler
function M.execute(plugin_conf)
  execute_logic(plugin_conf)
end

return M
"""
        with open(main_lua_path, "w") as f:
            f.write(main_lua_template)

        handler_template = f"""-- {plugin_name}/handler.lua
-- This file is the entry point for the Kong plugin.
-- It loads the main logic from src/main.lua and executes it in the chosen phase.

-- Import the main module
local main = require "kong.plugins.{plugin_name}.src.main"

-- Define the plugin specification
local plugin = {{
  PRIORITY = 1000,
  VERSION = "0.1.0"
}}

-- The phase at which this plugin will run
function plugin:{lifecycle_phase}(plugin_conf)
  -- Execute the main logic in a protected call to catch any errors
  local ok, err = pcall(main.execute, plugin_conf)
  if not ok then
    kong.log.err("Error in {plugin_name} plugin: ", err)
  end
end

return plugin
"""
        with open(handler_path, "w") as f:
            f.write(handler_template)
        
        return handler_path