import subprocess
import json
import os
import logging

class JsAstParser:
    def __init__(self, parser_path: str):
        self.parser_path = parser_path
        self.js_parser_script = os.path.join(self.parser_path, 'parse.js')

        if not os.path.exists(self.js_parser_script):
            raise FileNotFoundError(f"Node.js parser script not found at: {self.js_parser_script}")
        
        logging.info(f"Initialized JsAstParser with script: {self.js_parser_script}")

    def parse_js(self, js_code: str) -> dict:
        """
        Parses JavaScript code into an AST using the Node.js subprocess.
        """
        try:
            # Execute the Node.js script as a subprocess
            # Pass JS code via stdin, capture stdout and stderr
            process = subprocess.run(
                ['node', self.js_parser_script],
                input=js_code,
                capture_output=True,
                text=True, # Decode stdout/stderr as text
                check=False # Don't raise an exception for non-zero exit codes immediately
            )

            if process.returncode != 0:
                error_output = process.stderr.strip()
                try:
                    error_json = json.loads(error_output)
                    logging.error(f"Node.js parser error: {error_json.get('error', 'Unknown error')}")
                    logging.debug(f"Node.js parser stack: {error_json.get('stack', 'N/A')}")
                    raise RuntimeError(f"JavaScript parsing failed: {error_json.get('error', 'Unknown Node.js error')}")
                except json.JSONDecodeError:
                    logging.error(f"Node.js parser output (stderr): {error_output}")
                    raise RuntimeError(f"JavaScript parsing failed with non-JSON error: {error_output}")
            
            # Parse the JSON output from stdout
            ast = json.loads(process.stdout)
            return ast

        except FileNotFoundError:
            logging.error("Node.js executable not found. Please ensure Node.js is installed and in your PATH.")
            raise
        except json.JSONDecodeError as e:
            logging.error(f"Failed to decode AST JSON: {e}")
            logging.error(f"Node.js stdout: {process.stdout}")
            logging.error(f"Node.js stderr: {process.stderr}")
            raise RuntimeError(f"Invalid JSON AST received from parser: {e}")
        except Exception as e:
            logging.error(f"An unexpected error occurred during JavaScript parsing: {e}")
            raise
