# Apigee to Kong Variable Mappings
# This dictionary maps common Apigee JavaScript variable access patterns
# to their equivalent Kong Lua API calls.
#
# Key: Regex pattern to match Apigee JS variable access (e.g., context.getVariable('request.header.X-API-Key'))
# Value: A dictionary containing:
#   - 'replacement': The Kong Lua equivalent (can include capture groups from the regex)
#   - 'type': 'getter' or 'setter'
#   - 'scope': 'request', 'response', 'flow' (helps in determining where to place the Lua code)

VARIABLE_MAPPINGS = [
    # Request Headers
    {
        "pattern": r"""context\.getVariable\(['"]request\.header\.([a-zA-Z0-9_-]+)['"]\)""",
        "replacement": r'kong.request.get_header("\1")',
        "type": "getter",
        "scope": "request"
    },
    {
        "pattern": r"""context\.setVariable\(['"]request\.header\.([a-zA-Z0-9_-]+)['"],\s*(.*)\)""",
        "replacement": r'kong.service.request.set_header("\1", \2)',
        "type": "setter",
        "scope": "request"
    },
    # Response Headers
    {
        "pattern": r"""context\.getVariable\(['"]response\.header\.([a-zA-Z0-9_-]+)['"]\)""",
        "replacement": r'kong.response.get_header("\1")',
        "type": "getter",
        "scope": "response"
    },
    {
        "pattern": r"""context\.setVariable\(['"]response\.header\.([a-zA-Z0-9_-]+)['"],\s*(.*)\)""",
        "replacement": r'kong.response.set_header("\1", \2)',
        "type": "setter",
        "scope": "response"
    },
    # Request Body
    {
        "pattern": r"""context\.getVariable\(['"]request\.content['"]\)""",
        "replacement": r'kong.request.get_raw_body()',
        "type": "getter",
        "scope": "request"
    },
    {
        "pattern": r"""context\.setVariable\(['"]request\.content['"]\s*,\s*(.*)\)""",
        "replacement": r'kong.service.request.set_raw_body(\1)',
        "type": "setter",
        "scope": "request"
    },
    # Response Body
    {
        "pattern": r"""context\.getVariable\(['"]response\.content['"]\)""",
        "replacement": r'kong.response.get_raw_body()',
        "type": "getter",
        "scope": "response"
    },
    {
        "pattern": r"""context\.setVariable\(['"]response\.content['"]\s*,\s*(.*)\)""",
        "replacement": r'kong.response.set_raw_body(\1)',
        "type": "setter",
        "scope": "response"
    },
    # Request Path
    {
        "pattern": r"""context\.getVariable\(['"]request\.path['"]\)""",
        "replacement": r'kong.request.get_path()',
        "type": "getter",
        "scope": "request"
    },
    # Request URI
    {
        "pattern": r"""context\.getVariable\(['"]request\.uri['"]\)""",
        "replacement": r'kong.request.get_uri()',
        "type": "getter",
        "scope": "request"
    },
    # Request Verb/Method
    {
        "pattern": r"""context\.getVariable\(['"]request\.verb['"]\)""",
        "replacement": r'kong.request.get_method()',
        "type": "getter",
        "scope": "request"
    },
    # Request Query Params
    {
        "pattern": r"""context\.getVariable\(['"]request\.queryparam\.([a-zA-Z0-9_-]+)['"]\)""",
        "replacement": r'kong.request.get_query_arg("\1")',
        "type": "getter",
        "scope": "request"
    },
    # Response Status Code
    {
        "pattern": r"""context\.getVariable\(['"]response\.status\.code['"]\)""",
        "replacement": r'kong.response.get_status()',
        "type": "getter",
        "scope": "response"
    },
    {
        "pattern": r"""context\.setVariable\(['"]response\.status\.code['"]\s*,\s*(.*)\)""",
        "replacement": r'kong.response.set_status(\1)',
        "type": "setter",
        "scope": "response"
    },
    # Flow Variables (generic - stored in Kong ctx)
    {
        "pattern": r"""context\.getVariable\(['"]([a-zA-Z0-9_.-]+)['"]\)""", # Catches any other variable
        "replacement": r'kong.ctx.\1',
        "type": "getter",
        "scope": "flow"
    },
    {
        "pattern": r"""context\.setVariable\(['"]([a-zA-Z0-9_.-]+)['"]\s*,\s*(.*)\)""", # Catches any other variable
        "replacement": r'kong.ctx.\1 = \2',
        "type": "setter",
        "scope": "flow"
    },
    # JavaScript console.log mapping
    {
        "pattern": r"""console\.log\((.*)\)""",
        "replacement": r'kong.log.info(\1)',
        "type": "function",
        "scope": "any"
    },
    # General logging with context.setVariable for error/warn (less direct, more conceptual)
    # This is a bit tricky as Apigee's logging is more about setting variables that are then logged by policies.
    # For a direct JS equivalent, we'll map to Kong's logging.
    {
        "pattern": r"""context\.setVariable\(['"]error\.message['"]\s*,\s*(.*)\)""",
        "replacement": r'kong.log.err(\1)',
        "type": "setter",
        "scope": "any"
    },
    {
        "pattern": r"""context\.setVariable\(['"]warning\.message['"]\s*,\s*(.*)\)""",
        "replacement": r'kong.log.warn(\1)',
        "type": "setter",
        "scope": "any"
    },
    # JSON parsing and stringify (common patterns)
    {
        "pattern": r"""JSON\.parse\((.*)\)""",
        "replacement": r'cjson.decode(\1)',
        "type": "function",
        "scope": "any"
    },
    {
        "pattern": r"""JSON\.stringify\((.*)\)""",
        "replacement": r'cjson.encode(\1)',
        "type": "function",
        "scope": "any"
    },
    # --- String Methods ---
    # str.toUpperCase() -> string.upper(str)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.toUpperCase\(\)""",
        "replacement": r'string.upper(\1)',
        "type": "function",
        "scope": "any"
    },
    # str.toLowerCase() -> string.lower(str)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.toLowerCase\(\)""",
        "replacement": r'string.lower(\1)',
        "type": "function",
        "scope": "any"
    },
    # str.trim() -> string.gsub(str, "^%s*(.-)%s*$", "%1")
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.trim\(\)""",
        "replacement": r'string.gsub(\1, "^%s*(.-)%s*$", "%%1")',
        "type": "function",
        "scope": "any"
    },
    # str.startsWith(prefix) -> string.sub(str, 1, #prefix) == prefix
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.startsWith\((.+?)\)""",
        "replacement": r'string.sub(\1, 1, #\2) == \2',
        "type": "function",
        "scope": "any"
    },
    # str.endsWith(suffix) -> string.sub(str, -#suffix) == suffix
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.endsWith\((.+?)\)""",
        "replacement": r'string.sub(\1, -#\2) == \2',
        "type": "function",
        "scope": "any"
    },
    # str.replace(old, new) -> string.gsub(str, old, new, 1) (first occurrence)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.replace\((.+?),\s*(.+?)\)""",
        "replacement": r'string.gsub(\1, \2, \3, 1)',
        "type": "function",
        "scope": "any"
    },
    # str.replaceAll(old, new) -> string.gsub(str, old, new) (all occurrences)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.replaceAll\((.+?),\s*(.+?)\)""",
        "replacement": r'string.gsub(\1, \2, \3)',
        "type": "function",
        "scope": "any"
    },
    # str.substring(start, end) -> string.sub(str, start + 1, end) (JS is 0-indexed)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.substring\((.+?),\s*(.+?)\)""",
        "replacement": r'string.sub(\1, \2 + 1, \3)',
        "type": "function",
        "scope": "any"
    },
    # str.slice(start, end) -> string.sub(str, start + 1, end) (similar to substring for positive indices)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.slice\((.+?)(?:,\s*(.+?))?\)""",
        "replacement": r'string.sub(\1, \2 + 1, \3 or -1)', # -1 in Lua means till end
        "type": "function",
        "scope": "any"
    },
    # --- Array Methods ---
    # arr.length -> #arr
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.length""",
        "replacement": r'#\1',
        "type": "getter",
        "scope": "any"
    },
    # arr.push(item) -> table.insert(arr, item)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.push\((.+?)\)""",
        "replacement": r'table.insert(\1, \2)',
        "type": "function",
        "scope": "any"
    },
    # arr.pop() -> table.remove(arr)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.pop\(\)""",
        "replacement": r'table.remove(\1)',
        "type": "function",
        "scope": "any"
    },
    # arr.join(separator) -> table.concat(arr, separator)
    {
        "pattern": r"""([a-zA-Z_][a-zA-Z0-9_]*)\.join\((.+?)\)""",
        "replacement": r'table.concat(\1, \2)',
        "type": "function",
        "scope": "any"
    },
    # --- Number Conversions ---
    # parseInt(str) -> tonumber(str)
    {
        "pattern": r"""parseInt\((.+?)\)""",
        "replacement": r'tonumber(\1)',
        "type": "function",
        "scope": "any"
    },
    # parseFloat(str) -> tonumber(str)
    {
        "pattern": r"""parseFloat\((.+?)\)""",
        "replacement": r'tonumber(\1)',
        "type": "function",
        "scope": "any"
    },
    # --- Global Objects ---
    # isNaN(value) -> not tonumber(value) (simplified check)
    {
        "pattern": r"""isNaN\((.+?)\)""",
        "replacement": r'not tonumber(\1)',
        "type": "function",
        "scope": "any"
    },
    # isFinite(value) -> tonumber(value) and tonumber(value) ~= math.huge and tonumber(value) ~= -math.huge
    {
        "pattern": r"""isFinite\((.+?)\)""",
        "replacement": r'tonumber(\1) and tonumber(\1) ~= math.huge and tonumber(\1) ~= -math.huge',
        "type": "function",
        "scope": "any"
    },
]