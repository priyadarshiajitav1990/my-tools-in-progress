return {
  no_consumer = true,
  fields = {
    -- For each configuration variable, add a field here.
    -- For example, if your JavaScript code uses `context.getVariable('my_variable')`,
    -- you might add:
    -- my_variable = { type = "string", required = true, default = "default_value" }
  },
  self_check = function(schema, plugin_t, dao, is_update)
    -- Add custom validation here
    return true
  end
}