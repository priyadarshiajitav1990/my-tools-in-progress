-- set-my-headers/src/main.lua

local M = {}

-- Private function for the core logic
local function execute_logic(plugin_conf)
  -- Transpiled Lua code
local apiKey = kong.request.get_header("apikey")
kong.log.info()
if (apiKey and apiKey.length > 0) then
  kong.ctx.custom.apiKeyStatus = "present"
else
  kong.ctx.custom.apiKeyStatus = "missing"
end
end

-- Public execute function called by the handler
function M.execute(plugin_conf)
  execute_logic(plugin_conf)
end

return M
