-- set-my-headers/handler.lua
-- This file is the entry point for the Kong plugin.
-- It loads the main logic from src/main.lua and executes it in the chosen phase.

-- Import the main module
local main = require "kong.plugins.set-my-headers.src.main"

-- Define the plugin specification
local plugin = {
  PRIORITY = 1000,
  VERSION = "0.1.0"
}

-- The phase at which this plugin will run
function plugin:access(plugin_conf)
  -- Execute the main logic in a protected call to catch any errors
  local ok, err = pcall(main.execute, plugin_conf)
  if not ok then
    kong.log.err("Error in set-my-headers plugin: ", err)
  end
end

return plugin
