-- set_header/handler.lua
local main = require "kong.plugins.set_header.src.main"

local plugin = {
  PRIORITY = 1000,
  VERSION = "0.1.0"
}

function plugin:access(plugin_conf)
  local ok, err = pcall(main.execute, plugin_conf)
  if not ok then
    kong.log.err("Error in set_header plugin: ", err)
  end
end

return plugin
