# Apigee to Kong JS to Lua Transpiler

This tool helps migrate Apigee JavaScript policies to Kong Lua plugins. It transpiles JavaScript code to Lua, creating a basic Kong plugin structure that can be deployed to Kong Gateway.

## Project Structure

```
.
├── config.conf                 # Main configuration file for input/output paths.
├── js-to-lua-plugin.py         # The main Python script to run the transpiler.
├── js_to_lua/                  # The core Python package for the transpiler.
│   ├── conceptual_mappings.py  # Mappings for high-level JS concepts to Lua.
│   ├── js_ast_parser.py        # Parses JS code into an AST using a Node.js script.
│   ├── js_to_lua_transpiler.py # The main transpiler logic.
│   ├── variable_mappings.py    # Mappings for JS/Apigee variables to Kong/Lua variables.
│   └── js_parser/              # Node.js project for parsing JavaScript.
│       └── parse.js
└── outputs/                    # Default output directory for generated Kong plugins.
```

## How It Works

The transpiler works in several stages:

1.  **Parsing:** The `js-to-lua-plugin.py` script reads a JavaScript file and uses the Node.js script in `js_to_lua/js_parser/parse.js` to generate an Abstract Syntax Tree (AST).
2.  **Transpilation:** The AST is traversed, and each node is converted into its Lua equivalent based on rules defined in `js_to_lua_transpiler.py`.
    -   **Conceptual Mapping:** High-level concepts like `context.getVariable()` are mapped to their Lua equivalents (e.g., `kong.request.get_header()`) using `conceptual_mappings.py`.
    -   **Variable Mapping:** Pre-defined Apigee variables are mapped to Kong variables using `variable_mappings.py`.
3.  **Plugin Generation:** The transpiled Lua code is placed into a standard Kong plugin structure in the `outputs` directory. This includes:
    -   `handler.lua`: Contains the core logic and registers the plugin to a Kong execution phase (e.g., `access`, `header_filter`).
    -   `schema.lua`: Defines the configuration schema for the plugin.
    -   `src/main.lua`: The transpiled Lua code.

## Dependencies

- Python 3.6+
- Node.js (for the JavaScript AST parser)

## Setup

1.  Install Python dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2.  Install Node.js dependencies:
    ```bash
    cd js_to_lua/js_parser
    npm install
    cd ../..
    ```

## Configuration

Configuration is done via the `config.conf` file.

-   **input_dir**: Path to the directory containing the Apigee JavaScript policy files.
-   **output_dir**: Path where the generated Kong plugins will be saved.

Example `config.conf`:
```ini
[paths]
input_dir = ../tool-v1/inputs
output_dir = outputs
```

## Usage

Run the main script from the root directory:

```bash
python js-to-lua-plugin.py
```

The script will automatically find `.js` files in the `input_dir`, transpile them, and create the corresponding Kong plugin directories in the `output_dir`.

## Disclaimer

This is a best-effort transpiler. The generated Lua code might require manual adjustments. Always review and test the generated plugins thoroughly.
