import os
import json
import yaml
import re
import logging

# Recursively traverses a data structure and applies conversion logic to string values.
def convert_values(data, mappers):
    if isinstance(data, dict):
        for key, value in data.items():
            data[key] = convert_values(value, mappers)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            data[i] = convert_values(item, mappers)
    elif isinstance(data, str):
        return apply_conversions(data, mappers)
    return data

# Applies the series of conversion rules from the mappers to a single string.
def apply_conversions(original_str, mappers):
    converted_str = original_str

    # 1. Apply pattern-based replacements (e.g., MatchesPath)
    for item in mappers.get('pattern_map', []):
        # This function will be called for each match, allowing dynamic replacements
        def replacer(match):
            # The replacement string can contain placeholders like {0}, {1} for captured groups
            try:
                return item['replacement'].format(*match.groups())
            except IndexError:
                return item['replacement'] # In case there are no captured groups

        converted_str = re.sub(item['pattern'], replacer, converted_str)

    # 2. Apply simple variable name replacements
    for apigee_var, kong_var in mappers.get('variable_map', {}).items():
        # Use word boundary to avoid replacing parts of other words
        converted_str = re.sub(r'\b' + re.escape(apigee_var) + r'\b', kong_var, converted_str)

    # 3. Apply operator replacements
    for apigee_op, kong_op in mappers.get('operator_map', {}).items():
        converted_str = converted_str.replace(apigee_op, kong_op)

    if original_str != converted_str:
        logging.info(f"    - Converted: '{original_str}' -> '{converted_str}'")

    return converted_str

# Orchestrates the conversion of the entire Kong YAML file.
def convert_apigee_expressions():
    logging.info("--- Starting Apigee to Kong Expression Conversion ---")
    api_name = os.environ.get("api_name")
    output_dir = os.environ.get("output_dir")

    if not all([api_name, output_dir]):
        logging.error("Missing required configuration for expression conversion. Skipping.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    kong_yaml_path = os.path.join(project_root, output_dir, f"kong-{api_name}.yml")
    mappers_path = os.path.join(project_root, "configs", "apigee-to-kong-var-mappers.json")

    if not os.path.exists(kong_yaml_path):
        logging.error(f"Kong YAML file not found at '{kong_yaml_path}'. Cannot run conversion.")
        return
    if not os.path.exists(mappers_path):
        logging.error(f"Mappers file not found at '{mappers_path}'. Cannot run conversion.")
        return

    # Load mappers and the target YAML file
    with open(mappers_path, 'r') as f:
        mappers = json.load(f)
    with open(kong_yaml_path, 'r') as f:
        kong_data = yaml.safe_load(f)

    # Recursively convert all string values in the data
    converted_data = convert_values(kong_data, mappers)

    # Write the converted data back to the file
    with open(kong_yaml_path, 'w') as f:
        yaml.dump(converted_data, f, sort_keys=False, indent=2)

    logging.info("Expression conversion complete.")