import os
import xml.etree.ElementTree as ET
import yaml
import re
import logging

# Finds all proxy endpoint XML files within the extracted API proxy bundle.
def find_proxy_endpoints(project_root, extracted_api_dir, api_name):
    proxies_path = os.path.join(project_root, extracted_api_dir, api_name, "apiproxy", "proxies")
    logging.info(f"Searching for proxy endpoints in: '{proxies_path}'")

    if not os.path.isdir(proxies_path):
        logging.warning(f"Proxy endpoints directory not found at '{proxies_path}'. Skipping.")
        return []

    proxy_files = [os.path.join(proxies_path, f) for f in os.listdir(proxies_path) if f.endswith(".xml")]
    logging.info(f"Found {len(proxy_files)} proxy endpoint(s).")
    return proxy_files

# Helper to parse Apigee condition strings for path and verb.
def parse_condition(condition_str):
    path_match = re.search(r'proxy\.pathsuffix\s+MatchesPath\s+"([^"]+)"', condition_str)
    verb_match = re.search(r'request\.verb\s*=\s*"([^"]+)"', condition_str)
    
    path = path_match.group(1) if path_match else None
    verb = verb_match.group(1).upper() if verb_match else None
    
    return path, verb

# Parses proxy endpoint files and generates Kong routes.
def create_kong_routes(project_root, output_dir, api_name, proxy_files, report_data):
    if not proxy_files:
        logging.info("No proxy endpoints found to process.")
        return

    output_file_name = f"kong-{api_name}.yml"
    output_path = os.path.join(project_root, output_dir, output_file_name)

    # Load existing data from the YAML file
    try:
        with open(output_path, 'r') as f:
            output_data = yaml.safe_load(f) or {}
    except FileNotFoundError:
        logging.error(f"Kong YAML file not found at '{output_path}'. Cannot add routes.")
        return

    output_data.setdefault('routes', [])
    route_counter = 0

    for proxy_file in proxy_files:
        try:
            tree = ET.parse(proxy_file)
            root = tree.getroot()
            proxy_endpoint_name = os.path.splitext(os.path.basename(proxy_file))[0]

            base_path = root.find('.//BasePath').text if root.find('.//BasePath') is not None else ''
            
            # Find all VirtualHosts, which map to Kong's 'hosts' parameter.
            http_proxy_conn = root.find('.//HTTPProxyConnection')
            virtual_hosts = []
            if http_proxy_conn is not None:
                for vh_element in http_proxy_conn.findall('VirtualHost'):
                    if vh_element.text and vh_element.text.strip():
                        virtual_hosts.append(vh_element.text.strip())

            # Find the default target to route to
            default_target_name = "default" # Default assumption
            default_route_rule = None
            # ElementTree doesn't support the `not()` predicate, so we find all and loop.
            for rule in root.findall('.//RouteRule'):
                if rule.find('Condition') is None:
                    default_route_rule = rule
                    break # Found the default rule

            if default_route_rule is not None and default_route_rule.find('TargetEndpoint') is not None:
                default_target_name = default_route_rule.find('TargetEndpoint').text

            conditional_flows = root.findall('.//Flows/Flow')

            # First, create routes for all conditional flows that have a path.
            for flow in conditional_flows:
                condition_element = flow.find('Condition')
                if condition_element is None or not condition_element.text.strip():
                    continue

                flow_path, flow_verb = parse_condition(condition_element.text)
                if not flow_path:
                    continue # Skip flows without a path condition

                # Determine the target for this specific flow
                target_name = default_target_name
                route_rule = flow.find('.//RouteRule') # Check for a RouteRule inside the flow
                if route_rule is not None and route_rule.find('TargetEndpoint') is not None:
                    target_name = route_rule.find('TargetEndpoint').text

                # Construct the full path
                full_path = os.path.join(base_path, flow_path.lstrip('/')).replace('\\', '/')

                report_data.add_apigee_entity("ProxyEndpoint", proxy_endpoint_name)
                route_counter += 1
                route_name = f"rt-{api_name}-{proxy_endpoint_name}-{route_counter}"
                route = {
                    'name': route_name,
                    'paths': [full_path],
                    'service': {'name': f"srv-{api_name}-{target_name}"}
                }
                if flow_verb:
                    route['methods'] = [flow_verb]
                if virtual_hosts:
                    route['hosts'] = virtual_hosts

                output_data['routes'].append(route)
                report_data.add_kong_entity("route", route_name)
                report_data.add_mapping("Apigee ProxyEndpoint", proxy_endpoint_name, "Kong Route", route_name)
                logging.info(f"  - Generated route '{route_name}' for flow with path '{full_path}'")

            # Second, always create a default, lower-priority route for the base path.
            # This catches requests that don't match any of the specific flows above.
            report_data.add_apigee_entity("ProxyEndpoint", proxy_endpoint_name)
            route_counter += 1
            route_name = f"rt-{api_name}-{proxy_endpoint_name}-default-{route_counter}"
            route = {
                'name': route_name,
                'paths': [base_path],
                'service': {'name': f"srv-{api_name}-{default_target_name}"},
                'strip_path': False # Important for a base path catch-all
            }
            if virtual_hosts:
                route['hosts'] = virtual_hosts
            output_data['routes'].append(route)
            report_data.add_kong_entity("route", route_name)
            report_data.add_mapping("Apigee ProxyEndpoint", proxy_endpoint_name, "Kong Route", route_name)
            logging.info(f"  - Generated default catch-all route '{route_name}' with path '{base_path}'")

        except ET.ParseError as e:
            logging.warning(f"Could not parse XML file '{proxy_file}'. Error: {e}")

    # Write the updated data back to the Kong YAML file
    with open(output_path, 'w') as f:
        yaml.dump(output_data, f, sort_keys=False, indent=2)
    
    logging.info(f"Kong routes added to '{output_path}'")

# Orchestrates the migration of Apigee proxy endpoints to Kong routes.
def migrate_proxyendpoints(report_data=None):
    logging.info("--- Starting Proxy Endpoint Migration ---")
    api_name = os.environ.get("api_name")
    extracted_api_dir = os.environ.get("extracted_api_dir")
    output_dir = os.environ.get("output_dir")

    if not all([api_name, extracted_api_dir, output_dir]):
        logging.error("Missing required configuration for proxy endpoint migration. Skipping.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    proxy_files = find_proxy_endpoints(project_root, extracted_api_dir, api_name)
    create_kong_routes(project_root, output_dir, api_name, proxy_files, report_data)