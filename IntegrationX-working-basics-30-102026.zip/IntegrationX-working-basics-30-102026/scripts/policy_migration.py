import os
import json
import logging
import xml.etree.ElementTree as ET
import yaml

# --- Configuration Loading ---

def load_policy_mappings(project_root):
    """
    Loads the Apigee policy to Kong plugin mappings from the JSON config file.
    """
    mapping_file_path = os.path.join(project_root, "configs", "policy-to-plugin-mapper.json")
    if not os.path.exists(mapping_file_path):
        logging.warning("'policy-to-plugin-mapper.json' not found. Skipping policy migration.")
        return None

    try:
        with open(mapping_file_path, 'r') as f:
            mappings = json.load(f)
        if not mappings:
            logging.warning("'policy-to-plugin-mapper.json' is empty. Skipping policy migration.")
            return None
        logging.info("Successfully loaded policy-to-plugin mappings.")
        return mappings
    except json.JSONDecodeError:
        logging.error(f"Could not decode JSON from '{mapping_file_path}'. Please check the file format. Skipping policy migration.")
        return None

# --- Policy to Plugin Translation ---

def translate_spike_arrest(policy_root):
    """
    Translates Apigee SpikeArrest policy config to Kong rate-limiting plugin config.
    This is an example implementation. Each policy-to-plugin translation will need a dedicated function.
    """
    rate_element = policy_root.find('.//Rate')
    if rate_element is None:
        return None

    rate_text = rate_element.text
    if not rate_text:
        return None

    # Apigee format is "30ps" (per second) or "15pm" (per minute)
    if rate_text.endswith('ps'):
        limit = int(rate_text[:-2])
        return {'second': limit}
    elif rate_text.endswith('pm'):
        limit = int(rate_text[:-2])
        return {'minute': limit}

    return None

def get_plugin_config(policy_name, policy_type, policies_path):
    """
    Parses a policy's XML file and translates its configuration.
    This acts as a dispatcher to the correct translation function.
    """
    policy_file = os.path.join(policies_path, f"{policy_name}.xml")
    if not os.path.exists(policy_file):
        logging.warning(f"  - Policy XML file not found: '{policy_file}'")
        return None

    try:
        tree = ET.parse(policy_file)
        root = tree.getroot()

        # Dispatch to the correct translator based on policy type
        if policy_type == "SpikeArrest":
            return translate_spike_arrest(root)
        # Add other translators here, e.g.:
        # if policy_type == "OAuthV2":
        #     return translate_oauthv2(root)

        logging.warning(f"  - No translator available for policy type '{policy_type}'.")
        return None

    except ET.ParseError:
        logging.warning(f"  - Could not parse policy XML: '{policy_file}'")
        return None

# --- Core Migration Logic ---

def find_and_migrate_policies(entity_type, entity_name, entity_root, output_data, api_name, policies_path, policy_mappings):
    """
    Finds policies in an entity's flows (Proxy or Target) and attaches them to the corresponding Kong object.
    """
    # Determine the Kong object (service or route) and its name
    if entity_type == "service":
        kong_object_name = f"srv-{api_name}-{entity_name}"
        kong_objects = output_data.get('services', [])
    else: # Routes are more complex as they are not 1-to-1 with proxy endpoints
        # For simplicity, this example applies proxy-level policies to all routes of that proxy.
        # A more advanced implementation would map flow conditions to specific routes.
        logging.warning("Policy-to-route mapping is complex. Applying PreFlow/PostFlow policies to all related routes.")

    # Find PreFlow, PostFlow, and conditional Flows
    flows = {
        'PreFlow': entity_root.find('.//PreFlow'),
        'PostFlow': entity_root.find('.//PostFlow')
    }

    for flow_type, flow_element in flows.items():
        if flow_element is None:
            continue

        # Process policies in Request and Response pipelines
        for pipeline_element in flow_element: # <Request> or <Response>
            for step in pipeline_element.findall('.//Step'):
                policy_name_element = step.find('Name')
                if policy_name_element is None:
                    continue
                
                policy_name = policy_name_element.text
                policy_type = next((p_type for p_type, p_name in policy_mappings.items() if p_name == policy_name), None)
                
                # Find the Kong plugin mapping for this policy type
                kong_plugin_name = policy_mappings.get(policy_type)
                if not kong_plugin_name:
                    continue

                logging.info(f"  - Found policy '{policy_name}' (type: {policy_type}), maps to Kong plugin '{kong_plugin_name}'.")

                # Get the translated plugin configuration
                plugin_config = get_plugin_config(policy_name, policy_type, policies_path)
                if plugin_config is None:
                    logging.warning(f"    - Could not generate config for plugin '{kong_plugin_name}'. Skipping.")
                    continue

                plugin_instance = {'name': kong_plugin_name, 'config': plugin_config}

                # Attach the plugin to the corresponding Kong object(s)
                if entity_type == "service":
                    service = next((s for s in kong_objects if s['name'] == kong_object_name), None)
                    if service:
                        service.setdefault('plugins', []).append(plugin_instance)
                        logging.info(f"    - Attached plugin '{kong_plugin_name}' to service '{kong_object_name}'.")
                else: # Attach to all routes for this proxy endpoint
                    for route in output_data.get('routes', []):
                        if f"-{entity_name}-" in route['name']:
                            route.setdefault('plugins', []).append(plugin_instance)
                            logging.info(f"    - Attached plugin '{kong_plugin_name}' to route '{route['name']}'.")


def migrate_policies():
    """
    Orchestrates the entire policy migration process.
    """
    logging.info("--- Starting Policy Migration ---")
    api_name = os.environ.get("api_name")
    extracted_api_dir = os.environ.get("extracted_api_dir")
    output_dir = os.environ.get("output_dir")

    if not all([api_name, extracted_api_dir, output_dir]):
        logging.error("Missing required configuration for policy migration. Skipping.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    policy_mappings = load_policy_mappings(project_root)
    if not policy_mappings:
        return

    # Paths
    api_base_path = os.path.join(project_root, extracted_api_dir, api_name, "apiproxy")
    policies_path = os.path.join(api_base_path, "policies")
    proxies_path = os.path.join(api_base_path, "proxies")
    targets_path = os.path.join(api_base_path, "targets")
    output_path = os.path.join(project_root, output_dir, f"kong-{api_name}.yml")

    # Load the generated Kong YAML file to modify it
    try:
        with open(output_path, 'r') as f:
            output_data = yaml.safe_load(f) or {}
    except FileNotFoundError:
        logging.error(f"Kong YAML file not found at '{output_path}'. Cannot migrate policies.")
        return

    # 1. Migrate policies from Target Endpoints (attach to Services)
    for filename in os.listdir(targets_path):
        if filename.endswith(".xml"):
            entity_name = os.path.splitext(filename)[0]
            tree = ET.parse(os.path.join(targets_path, filename))
            find_and_migrate_policies("service", entity_name, tree.getroot(), output_data, api_name, policies_path, policy_mappings)

    # 2. Migrate policies from Proxy Endpoints (attach to Routes)
    for filename in os.listdir(proxies_path):
        if filename.endswith(".xml"):
            entity_name = os.path.splitext(filename)[0]
            tree = ET.parse(os.path.join(proxies_path, filename))
            find_and_migrate_policies("route", entity_name, tree.getroot(), output_data, api_name, policies_path, policy_mappings)

    # Write the updated configuration back to the file
    with open(output_path, 'w') as f:
        yaml.dump(output_data, f, sort_keys=False, indent=2)
    
    logging.info("Policy migration complete. Updated Kong configuration file.")