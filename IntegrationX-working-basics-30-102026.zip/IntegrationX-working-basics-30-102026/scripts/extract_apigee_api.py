import os
import zipfile
import sys
import logging

# Finds a zip file in the input directory, derives and returns the API name and zip path.
def find_zip_and_get_api_name(project_root, input_dir_name):
    input_dir_path = os.path.join(project_root, input_dir_name)
    logging.info(f"Searching for zip files in '{input_dir_path}'...")

    if not os.path.isdir(input_dir_path):
        logging.error(f"Input directory '{input_dir_path}' not found.")
        return None, None

    for filename in os.listdir(input_dir_path):
        if filename.endswith(".zip"):
            print(f"Found zip file: {filename}")
            base_name = os.path.splitext(filename)[0]
            
            # Remove '_rev' and anything after it to get the api_name
            if '_rev' in base_name:
                api_name = base_name.split('_rev')[0]
            else:
                api_name = base_name

            logging.info(f"Derived API name: {api_name}")
            return os.path.join(input_dir_path, filename), api_name
            
    logging.warning("No zip file found in the input directory.")
    return None, None


# Creates a directory for the API and extracts the zip file into it.
def extract_zip_to_api_dir(project_root, zip_file_path, api_name, base_extract_dir_name):
    if not api_name or not zip_file_path:
        logging.error("Cannot extract, missing API name or zip file path.")
        return

    extract_path = os.path.join(project_root, base_extract_dir_name, api_name)
    logging.info(f"Creating directory: '{extract_path}'")
    os.makedirs(extract_path, exist_ok=True)

    logging.info(f"Extracting '{os.path.basename(zip_file_path)}' to '{extract_path}'...")
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    logging.info("Extraction complete.")

# Orchestrates the API extraction process using loaded configurations.
def extract_apigee_api():
    logging.info("--- Starting Apigee API Extraction ---")
    # Get config values from environment variables
    input_dir = os.environ.get("input_dir")
    extracted_api_dir = os.environ.get("extracted_api_dir")

    if not all([input_dir, extracted_api_dir]):
        logging.error("Missing required configuration (input_dir, extracted_api_dir).")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    zip_path, api_name = find_zip_and_get_api_name(project_root, input_dir)

    if zip_path and api_name:
        # Set the derived api_name as an environment variable for other scripts to use
        os.environ['api_name'] = api_name
        logging.info(f"  - Set environment variable: api_name")
        extract_zip_to_api_dir(project_root, zip_path, api_name, extracted_api_dir)