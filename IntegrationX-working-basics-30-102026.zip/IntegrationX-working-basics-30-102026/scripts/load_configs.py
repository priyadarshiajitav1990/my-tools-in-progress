import os
import json
import logging

import sys
# Loads configurations from a JSON file and sets them as environment variables.
def load_and_set_env_variables():
    logging.info("Loading configurations...")

    # Determine the project root (one level up from the 'scripts' directory)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    config_path = os.path.join(project_root, "configs", "config.json")

    if not os.path.exists(config_path):
        logging.error(f"Configuration file 'config.json' not found in the 'configs' directory.")
        logging.error("Please copy 'config.example.json' to 'config.json' and fill in your environment details.")
        # We exit here because the application cannot run without configuration.
        sys.exit(1)

    try:
        with open(config_path, 'r') as config_file:
            configs = json.load(config_file)

        for key, value in configs.items():
            # Environment variables must be strings
            os.environ[key] = str(value)
            logging.info(f"  - Set environment variable: {key}")
        logging.info("Configurations loaded successfully.")
    except json.JSONDecodeError:
        logging.error(f"Could not decode JSON from '{config_path}'. Please check the file format.")
        sys.exit(1)
    except Exception as e:
        logging.error(f"An unexpected error occurred while loading configurations: {e}")
        sys.exit(1)