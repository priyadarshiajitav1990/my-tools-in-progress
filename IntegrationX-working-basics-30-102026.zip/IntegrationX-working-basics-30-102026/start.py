import logging
import time
import sys
from scripts.logger_config import setup_logging
from scripts.load_configs import load_and_set_env_variables
from scripts.apigee_targetservers_info import apigee_targetservers
from scripts.extract_apigee_api import extract_apigee_api
from scripts.targetendpoints import migrate_targetendpoints
from scripts.proxyendpoints import migrate_proxyendpoints
from scripts.vars_expressions_converter import convert_apigee_expressions
from scripts.policy_migration import migrate_policies
from scripts.deck_validate import validations
from scripts.report_data import ReportData
from scripts.generate_report import generate_report

def main():
    report_data = ReportData()
    report_data.start_time = time.time()

    # Initialize the logging system for the application.
    setup_logging()
    
    logging.info("--- Apigee to Kong Migration Tool ---")

    try:
        # Load all configurations from config.json into the environment.
        load_and_set_env_variables()

        # Fetch all Apigee TargetServer details for the environment.
        apigee_targetservers()

        # Find and extract the Apigee API zip file from the input directory.
        extract_apigee_api()

        # Parse Apigee target endpoints and create corresponding Kong services and upstreams.
        migrate_targetendpoints(report_data)

        # Parse Apigee proxy endpoints and create corresponding Kong routes.
        migrate_proxyendpoints(report_data)

        # Convert Apigee-specific variables and expressions in the generated file to Kong format.
        convert_apigee_expressions()

        # Find and migrate Apigee policies to Kong plugins.
        migrate_policies()

        # Validate the generated Kong configuration file using decK.
        validation_passed = validations()
        if not validation_passed:
            # This is a controlled exit, not an unexpected crash.
            # The validations() function has already logged the specific reason.
            logging.error("Halting migration due to failed deck validation.")
            logging.error("--- Migration FAILED ---")
            sys.exit(1)

        # Generate the final HTML report.
        report_data.end_time = time.time()
        generate_report()
        
        # --- This section will only be reached if all steps above succeed ---
        # Display entity mappings in the console
        if report_data.mappings:
            print("\n--- Entity Mappings ---")
            for mapping in report_data.mappings:
                print(f"  - {mapping['apigee_type']} '{mapping['apigee_name']}' -> {mapping['kong_type']} '{mapping['kong_name']}'")
        else:
            print("\nNo entity mappings generated.")

        logging.info("--- Migration Process Completed Successfully! ---")

    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}", exc_info=False) # Set to False for cleaner final error
        logging.error("--- Migration FAILED ---")
        sys.exit(1)

if __name__ == "__main__":
    main()