
# app.py (Flask on Cloud Run / Functions)
from flask import Flask, request, jsonify
import os

app = Flask(__name__)

BACKENDS = {
    "us": os.getenv("BACKEND_US", "https://us-backend.example.com"),
    "eu": os.getenv("BACKEND_EU", "https://eu-backend.example.com"),
    "apac": os.getenv("BACKEND_APAC", "https://apac-backend.example.com"),
}

@app.route("/route", methods=["GET"])
def route():
    # Inputs from Apigee via query params or headers
    region = request.args.get("region", "us").lower()
    path = request.args.get("path", "").lstrip("/")
    tenant = request.headers.get("X-Tenant", "default")

    base = BACKENDS.get(region, BACKENDS["us"])
    # Example multi-tenant base path shaping
    target_url = f"{base}/{tenant}/{path}" if tenant != "default" else f"{base}/{path}"

    return jsonify({
        "target_url": target_url,
        "selected_region": region,
        "tenant": tenant
    })
