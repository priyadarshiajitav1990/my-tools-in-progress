-- py_to_lua_polyfills.lua
-- Polyfills for common Python built-ins in Lua

function enumerate(tbl)
    local i = 0
    return function()
        i = i + 1
        if tbl[i] ~= nil then
            return i, tbl[i]
        end
    end
end

function zip(tbl1, tbl2)
    local i = 0
    return function()
        i = i + 1
        if tbl1[i] ~= nil and tbl2[i] ~= nil then
            return tbl1[i], tbl2[i]
        end
    end
end

function range(start_, stop_, step_)
    local t = {}
    local start = start_ or 1
    local stop = stop_ or start_
    local step = step_ or 1
    if stop_ == nil then
        stop = start_
        start = 1
    end
    for i = start, stop, step do
        table.insert(t, i)
    end
    return t
end

function map(f, tbl)
    local t = {}
    for i, v in ipairs(tbl) do
        t[i] = f(v)
    end
    return t
end

function filter(f, tbl)
    local t = {}
    for i, v in ipairs(tbl) do
        if f(v) then table.insert(t, v) end
    end
    return t
end

function any(tbl)
    for _, v in ipairs(tbl) do
        if v then return true end
    end
    return false
end

function all(tbl)
    for _, v in ipairs(tbl) do
        if not v then return false end
    end
    return true
end

function sum(tbl)
    local s = 0
    for _, v in ipairs(tbl) do
        s = s + v
    end
    return s
end

function min_(tbl)
    local m = tbl[1]
    for i = 2, #tbl do
        if tbl[i] < m then m = tbl[i] end
    end
    return m
end

function max_(tbl)
    local m = tbl[1]
    for i = 2, #tbl do
        if tbl[i] > m then m = tbl[i] end
    end
    return m
end
