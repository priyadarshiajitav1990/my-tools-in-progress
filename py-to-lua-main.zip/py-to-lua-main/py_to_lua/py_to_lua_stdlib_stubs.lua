-- py_to_lua_stdlib_stubs.lua
-- Stubs for common Python standard library modules in Lua

math = math or {}
math.sqrt = math.sqrt or function(x) return x^0.5 end
math.pi = math.pi or 3.141592653589793
math.sin = math.sin or function(x) return 0 end -- stub
math.cos = math.cos or function(x) return 0 end -- stub
math.tan = math.tan or function(x) return 0 end -- stub

os = os or {}
os.getenv = os.getenv or function(var) return nil end
os.system = os.system or function(cmd) return 0 end
os.path = os.path or {}
os.path.join = os.path.join or function(a, b) return a..'/'..b end

sys = sys or {}
sys.argv = sys.argv or {}
sys.exit = sys.exit or function(code) os.exit(code or 0) end

random = random or {}
random.random = random.random or function() return math.random() end
random.randint = random.randint or function(a, b) return math.random(a, b) end

-- Add more stubs as needed for your scripts
