"""
AST Transformer to convert Python AST to an intermediate representation suitable for Lua code generation.
"""
import ast
from typing import Any

class ASTTransformer(ast.NodeVisitor):
    def visit_Nonlocal(self, node: ast.Nonlocal):
        return {'type': 'Nonlocal', 'names': node.names}

    def visit_Global(self, node: ast.Global):
        return {'type': 'Global', 'names': node.names}

    def visit_Pass(self, node: ast.Pass):
        return {'type': 'Pass'}

    def visit_Break(self, node: ast.Break):
        return {'type': 'Break'}

    def visit_Continue(self, node: ast.Continue):
        return {'type': 'Continue'}

    def visit_Raise(self, node: ast.Raise):
        return {'type': 'Raise', 'exc': self.visit(node.exc) if node.exc else None, 'cause': self.visit(node.cause) if node.cause else None}

    def visit_Assert(self, node: ast.Assert):
        return {'type': 'Assert', 'test': self.visit(node.test), 'msg': self.visit(node.msg) if node.msg else None}

    def visit_Starred(self, node: ast.Starred):
        return {'type': 'Starred', 'value': self.visit(node.value)}
    def visit_Import(self, node: ast.Import):
        return {
            'type': 'Import',
            'names': [alias.name for alias in node.names],
            'asnames': [alias.asname for alias in node.names],
        }

    def visit_ImportFrom(self, node: ast.ImportFrom):
        return {
            'type': 'ImportFrom',
            'module': node.module,
            'names': [alias.name for alias in node.names],
            'asnames': [alias.asname for alias in node.names],
            'level': node.level,
        }

    def visit_Attribute(self, node: ast.Attribute):
        return {
            'type': 'Attribute',
            'value': self.visit(node.value),
            'attr': node.attr,
        }

    def visit_Call(self, node: ast.Call):
        # Recognize REST API and HTTP request patterns
        func = self.visit(node.func)
        args = [self.visit(arg) for arg in node.args]
        keywords = [self.visit(kw) for kw in node.keywords]
        return {
            'type': 'Call',
            'func': func,
            'args': args,
            'keywords': keywords,
        }

    def visit_keyword(self, node: ast.keyword):
        return {
            'type': 'keyword',
            'arg': node.arg,
            'value': self.visit(node.value),
        }

    def transform(self, node: ast.AST) -> Any:
        """Transform Python AST node to intermediate representation."""
        return self.visit(node)

    def visit_Module(self, node: ast.Module):
        return {'type': 'Module', 'body': [self.visit(stmt) for stmt in node.body]}

    def visit_FunctionDef(self, node: ast.FunctionDef):
        return {
            'type': 'FunctionDef',
            'name': node.name,
            'args': [arg.arg for arg in node.args.args],
            'body': [self.visit(stmt) for stmt in node.body],
            'decorator_list': [self.visit(d) for d in node.decorator_list],
        }

    def visit_ClassDef(self, node: ast.ClassDef):
        return {
            'type': 'ClassDef',
            'name': node.name,
            'bases': [self.visit(b) for b in node.bases],
            'body': [self.visit(stmt) for stmt in node.body],
            'decorator_list': [self.visit(d) for d in node.decorator_list],
        }

    def visit_Lambda(self, node: ast.Lambda):
        return {
            'type': 'Lambda',
            'args': [arg.arg for arg in node.args.args],
            'body': self.visit(node.body),
        }

    def visit_ListComp(self, node: ast.ListComp):
        return {
            'type': 'ListComp',
            'elt': self.visit(node.elt),
            'generators': [self.visit(gen) for gen in node.generators],
        }

    def visit_DictComp(self, node: ast.DictComp):
        return {
            'type': 'DictComp',
            'key': self.visit(node.key),
            'value': self.visit(node.value),
            'generators': [self.visit(gen) for gen in node.generators],
        }

    def visit_comprehension(self, node: ast.comprehension):
        return {
            'type': 'comprehension',
            'target': self.visit(node.target),
            'iter': self.visit(node.iter),
            'ifs': [self.visit(if_) for if_ in node.ifs],
            'is_async': node.is_async,
        }

    def visit_With(self, node: ast.With):
        return {
            'type': 'With',
            'items': [self.visit(item) for item in node.items],
            'body': [self.visit(stmt) for stmt in node.body],
        }

    def visit_withitem(self, node: ast.withitem):
        return {
            'type': 'withitem',
            'context_expr': self.visit(node.context_expr),
            'optional_vars': self.visit(node.optional_vars) if node.optional_vars else None,
        }

    def visit_Try(self, node: ast.Try):
        return {
            'type': 'Try',
            'body': [self.visit(stmt) for stmt in node.body],
            'handlers': [self.visit(h) for h in node.handlers],
            'orelse': [self.visit(stmt) for stmt in node.orelse],
            'finalbody': [self.visit(stmt) for stmt in node.finalbody],
        }

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        return {
            'type': 'ExceptHandler',
            'type_': self.visit(node.type) if node.type else None,
            'name': node.name,
            'body': [self.visit(stmt) for stmt in node.body],
        }

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        return self.visit_FunctionDef(node)

    def visit_Await(self, node: ast.Await):
        return {'type': 'Await', 'value': self.visit(node.value)}

    def visit_AsyncFor(self, node: ast.AsyncFor):
        return self.visit_For(node)

    def visit_AsyncWith(self, node: ast.AsyncWith):
        return self.visit_With(node)

    def visit_Yield(self, node: ast.Yield):
        return {'type': 'Yield', 'value': self.visit(node.value) if node.value else None}

    def visit_YieldFrom(self, node: ast.YieldFrom):
        return {'type': 'YieldFrom', 'value': self.visit(node.value)}

    def visit_Decorator(self, node):
        return {'type': 'Decorator', 'value': self.visit(node)}

    def generic_visit(self, node):
        return {'type': type(node).__name__}
