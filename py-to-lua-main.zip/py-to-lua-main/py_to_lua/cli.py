"""
CLI entry point for Python-to-Lua converter.
"""
import sys
from py_to_lua.parser import PythonParser
from py_to_lua.ast_transformer import ASTTransformer
from py_to_lua.lua_generator import LuaGenerator

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Convert Python code to Lua.")
    parser.add_argument('python_file', nargs='?', help='Python source file to convert')
    parser.add_argument('--output', '-o', help='Output file for Lua code (default: stdout)')
    parser.add_argument('--version', action='version', version='py-to-lua 1.0.0')
    args = parser.parse_args()

    if not args.python_file:
        parser.print_help()
        sys.exit(1)

    try:
        with open(args.python_file, 'r') as f:
            source = f.read()
    except FileNotFoundError:
        print(f"File not found: {args.python_file}")
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}")
        sys.exit(1)

    try:
        py_parser = PythonParser()
        tree = py_parser.parse(source)
        transformer = ASTTransformer()
        ir = transformer.transform(tree)
        generator = LuaGenerator()
        lua_code = generator.generate(tree)
        if args.output:
            try:
                with open(args.output, 'w') as out_f:
                    out_f.write(lua_code)
                print(f"Lua code written to {args.output}")
            except Exception as e:
                print(f"Error writing output file: {e}")
                sys.exit(1)
        else:
            print(lua_code)
    except SyntaxError as e:
        print(f"Syntax error in Python source: {e}")
        sys.exit(2)
    except Exception as e:
        print(f"Error during conversion: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
