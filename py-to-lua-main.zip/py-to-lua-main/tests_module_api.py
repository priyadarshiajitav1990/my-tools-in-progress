"""
Tests for module, import, and REST API/request/response handling in Python-to-Lua converter.
"""
from py_to_lua.parser import PythonParser
from py_to_lua.lua_generator import LuaGenerator

def test_import():
    source = 'import os, sys'
    parser = PythonParser()
    tree = parser.parse(source)
    lua_code = LuaGenerator().generate(tree)
    assert '-- import: os, sys' in lua_code

def test_importfrom():
    source = 'from math import sqrt, pi'
    parser = PythonParser()
    tree = parser.parse(source)
    lua_code = LuaGenerator().generate(tree)
    assert '-- from math import sqrt, pi' in lua_code

def test_requests_get():
    source = 'import requests\nrequests.get("http://example.com")'
    parser = PythonParser()
    tree = parser.parse(source)
    lua_code = LuaGenerator().generate(tree)
    assert '-- HTTP GET request' in lua_code

def test_requests_post():
    source = 'import requests\nrequests.post("http://example.com", data={"a":1})'
    parser = PythonParser()
    tree = parser.parse(source)
    lua_code = LuaGenerator().generate(tree)
    assert '-- HTTP POST request' in lua_code

def test_flask_route():
    source = '@app.route("/hello")\ndef hello():\n    return "hi"'
    parser = PythonParser()
    tree = parser.parse(source)
    lua_code = LuaGenerator().generate(tree)
    assert '-- REST API route handler' in lua_code or '-- decorator not supported' in lua_code

if __name__ == "__main__":
    test_import()
    test_importfrom()
    test_requests_get()
    test_requests_post()
    test_flask_route()
    print("All module/import/REST API tests passed.")
