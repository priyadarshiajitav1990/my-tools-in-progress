from setuptools import setup, find_packages

setup(
    name='py-to-lua',
    version='1.0.0',
    description='Python to Lua code converter',
    author='priyadarshijena1990',
    packages=find_packages(),
    package_data={
        'py_to_lua': ['py_to_lua_polyfills.lua', 'py_to_lua_stdlib_stubs.lua'],
    },
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'py-to-lua=py_to_lua.cli:main',
        ],
    },
    install_requires=[],
    python_requires='>=3.7',
)