"""
Basic tests for Python-to-Lua converter.
"""
from py_to_lua.parser import PythonParser
from py_to_lua.ast_transformer import ASTTransformer
from py_to_lua.lua_generator import LuaGenerator

def test_simple_expr():
    source = '42'
    parser = PythonParser()
    tree = parser.parse(source)
    transformer = ASTTransformer()
    ir = transformer.transform(tree)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert lua_code.strip() == '42'

def test_string():
    source = '"hello"'
    parser = PythonParser()
    tree = parser.parse(source)
    transformer = ASTTransformer()
    ir = transformer.transform(tree)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert lua_code.strip() == '"hello"'


def test_assign():
    source = 'x = 1'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert lua_code.strip() == 'x = 1'

def test_binop():
    source = 'a + b'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert lua_code.strip() == '(a + b)'

def test_funcdef():
    source = 'def foo(a, b):\n    return a + b'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'function foo(a, b)' in lua_code
    assert 'return (a + b)' in lua_code

def test_if():
    source = 'if x == 1:\n    y = 2\nelse:\n    y = 3'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'if x == 1 then' in lua_code
    assert 'y = 2' in lua_code
    assert 'else' in lua_code
    assert 'y = 3' in lua_code

def test_for():
    source = 'for i in range(5):\n    print(i)'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'for i in range(5) do' in lua_code
    assert 'print(i)' in lua_code

def test_while():
    source = 'while x < 10:\n    x = x + 1'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'while x < 10 do' in lua_code
    assert 'x = (x + 1)' in lua_code

def test_list():
    source = '[1, 2, 3]'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '{1, 2, 3}' in lua_code

def test_dict():
    source = '{"a": 1, "b": 2}'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '["a"]=1' in lua_code and '["b"]=2' in lua_code

def test_class():
    source = 'class Foo:\n    def bar(self):\n        return 1'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- class Foo' in lua_code
    assert 'function bar(self)' in lua_code or 'function bar(self)' in lua_code.replace(' ', '')

if __name__ == "__main__":
    test_simple_expr()
    test_string()
    test_assign()
    test_binop()
    test_funcdef()
    test_if()
    test_for()
    test_while()
    test_list()
    test_dict()
    test_class()
    print("All tests passed.")
