"""
Expanded tests for Python-to-Lua converter: built-ins, stdlib, and edge cases.
"""
from py_to_lua.parser import PythonParser
from py_to_lua.ast_transformer import ASTTransformer
from py_to_lua.lua_generator import LuaGenerator

def test_enumerate():
    source = 'for i, v in enumerate([10, 20, 30]):\n    print(i, v)'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'enumerate' in lua_code

def test_zip():
    source = 'for a, b in zip([1,2],[3,4]):\n    print(a, b)'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'zip' in lua_code

def test_range():
    source = 'for i in range(3):\n    print(i)'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'range' in lua_code

def test_math():
    source = 'import math\nprint(math.sqrt(16))'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'math.sqrt' in lua_code

def test_os_path():
    source = 'import os\nos.path.join("a", "b")'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'os.path.join' in lua_code

def test_random():
    source = 'import random\nrandom.randint(1, 10)'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'random.randint' in lua_code

def test_sys_argv():
    source = 'import sys\nsys.argv'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'sys.argv' in lua_code

if __name__ == "__main__":
    test_enumerate()
    test_zip()
    test_range()
    test_math()
    test_os_path()
    test_random()
    test_sys_argv()
    print("All expanded stdlib/built-in tests passed.")
