# custom-plugin-developments

This directory is standalone and contains all scripts, templates, and dependencies required for custom Kong plugin development.

## Python dependencies
- All required Python modules are installed in `.python_libs`.
- A `requirements.txt` is provided for reference.

## Lua dependencies
- Lua modules are installed locally in `.luarocks` using LuaRocks.

## Usage

No external downloads required. All dependencies are resolved locally.

### Workflow
1. **Configure your plugin**: Edit `config.json` to set your plugin name, source Lua script directory, destination, and deployment options (local or remote).
2. **Place your Lua scripts**: Put your main Lua script(s) in the directory specified by `src_root` in `config.json`.
3. **Build the plugin**: Run:
  ```bash
  PYTHONPATH=.python_libs python3 build-custom-plugin.py
  ```
  This will create a new custom Kong plugin using your Lua scripts and configuration.
4. **Place the plugin**: Run:
  ```bash
  PYTHONPATH=.python_libs python3 place-custom-plugin.py
  ```
  This will copy the plugin files to the local or remote destination as configured.
5. **Deploy the plugin**: Run:
  ```bash
  PYTHONPATH=.python_libs python3 deploy-custom-plugin.py
  ```
  This will install dependencies and validate/deploy the plugin locally or remotely, based on your config.

Lua scripts and tests use the local `.luarocks` tree.

## Structure
- `build-custom-plugin.py`, `place-custom-plugin.py`, `deploy-custom-plugin.py`: Main scripts
- `config.json`: Configuration
- `kong-plugin-template/`: Plugin template
- `.python_libs/`: Python dependencies
- `.luarocks/`: Lua dependencies
- `requirements.txt`: Python dependency list

## Notes
- No internet connection required after setup.
- For additional Lua modules, use:
  ```bash
  luarocks --tree=.luarocks install <module>
  ```
- For additional Python modules, use:
  ```bash
  pip install <module> --target .python_libs
  ```
