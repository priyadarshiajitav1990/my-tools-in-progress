# Production Ready Kong Plugin CLI Tool

A self-contained, user-installable CLI tool for Kong plugin development, validation, deployment, and management.

## Features
- **No admin access required**: Install and run as a normal user
- **Docker-based validation**: Uses local Docker image and Pongo for plugin testing
- **Plugin lifecycle**: Create, validate, test, deploy, install, configure, and rollback plugins
- **Configurable**: All options available via CLI and config file
- **Packaged bundle**: All templates and scripts included

## Installation
- Clone or download this repo
- (Optional) Install dependencies: `pip install pyyaml`
- Make the tool executable: `chmod +x production_ready_tool.py`
- (Optional) Add to your PATH or use as `python3 production_ready_tool.py`

## Usage

```sh
# Show help
python3 production_ready_tool.py --help

# Create a new plugin skeleton
python3 production_ready_tool.py create myplugin

# Validate plugin with Docker/Pongo
python3 production_ready_tool.py validate myplugin

# Deploy plugin (mock)
python3 production_ready_tool.py deploy myplugin

# Install plugin (mock)
python3 production_ready_tool.py install myplugin

# Configure plugin (mock)
python3 production_ready_tool.py configure myplugin

# Rollback plugin (mock)
python3 production_ready_tool.py rollback myplugin

# Show or set tool config
python3 production_ready_tool.py config --show
python3 production_ready_tool.py config --key pongo_path --value /custom/path/to/pongo
```

## Configuration
- Config file: `~/.production_ready_tool.yaml`
- Default options:
  - `kong_plugin_dir`: Where plugins are created/managed
  - `docker_image`: Docker image for validation
  - `kong_license_env`: Env var for Kong EE license
  - `pongo_path`: Path to Pongo binary
  - `kong_version`: Kong version for validation
  - `rollback_on_failure`: Enable rollback on failure
  - `plugin_template`: Path to plugin template YAML

## Requirements
- Python 3.7+
- Docker (user must be in `docker` group)
- Pongo (for validation)

## Extending
- Add more commands or real deployment logic as needed
- All plugin lifecycle steps are modular and can be customized

---
For more, see the code in `production_ready_tool.py`.
