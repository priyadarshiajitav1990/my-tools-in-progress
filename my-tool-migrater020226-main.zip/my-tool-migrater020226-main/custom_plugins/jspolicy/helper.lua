return function(kv)
  kong.log("helper executed with kv: " .. (kv and kv.max_limit or "none"))
end