# jspolicy Kong Custom Plugin

This plugin allows configuration of one main Lua script file and one optional dependency script file. It supports an optional condition, request/response flow, ordering, tagging, and multiple key-value pairs that are passed to the scripts.

## Features
- Compatible with Kong Enterprise Edition v3.13.0.0
- Executes scripts in request and response flows
- Supports execution ordering using `before` and `after`
- Supports tagging like built-in plugins
- Passes configurable key-value pairs to scripts

## File Structure
- `handler.lua`: Main plugin logic
- `schema.lua`: Plugin configuration schema
- `README.md`: This documentation
- Place your Lua script files in this directory

## Configuration Example
```yaml
plugins:
- name: jspolicy
  config:
    script_name: "main_policy.lua"
    dependency_name: "helper.lua"
    condition: "kong.request.get_method() == 'POST'"
    flow: "request"
    kv_pairs:
      user_role: "admin"
      max_limit: "100"
  tags:
    - custom
    - jspolicy
  ordering:
    before:
      - rate-limiting
    after:
      - key-auth
```

## Ordering and Tagging
- Use the `ordering` field to specify `before` and `after` plugin execution order.
- Use the `tags` field to tag the plugin instance for management and discovery.
