local typedefs = require "kong.db.schema.typedefs"

return {
  name = "jspolicy",
  fields = {
    { consumer = typedefs.no_consumer },
    { protocols = typedefs.protocols_http },
    { tags = typedefs.tags },
    { ordering = { type = "record", required = false, fields = {
      { before = { type = "array", elements = { type = "string" }, required = false } },
      { after = { type = "array", elements = { type = "string" }, required = false } },
    } } },
    { config = {
      type = "record",
      fields = {
        { script_name = { type = "string", required = true } },
        { flow = { type = "string", required = true, one_of = { "request", "response" } } },
        { dependency_name = { type = "string", required = false } },
        { condition = { type = "string", required = false } },
        { kv_pairs = { type = "map", keys = { type = "string" }, values = { type = "string" }, required = false } },
      },
    }, },
  },
}
