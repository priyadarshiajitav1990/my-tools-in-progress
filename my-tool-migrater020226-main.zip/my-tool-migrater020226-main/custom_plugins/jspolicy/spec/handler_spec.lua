local handler = require "jspolicy.handler"
local kong = { log = { err = print } }
_G.kong = kong

describe("jspolicy plugin", function()
  it("executes main and dependency script with kv", function()
    local conf = {
      script_name = "main_policy.lua",
      dependency_name = "helper.lua",
      condition = "true",
      flow = "request",
      kv_pairs = { user_role = "admin", max_limit = "100" }
    }
    assert.has_no.errors(function()
      handler.access(conf)
    end)
  end)

  it("does not execute scripts when condition is false", function()
    local conf = {
      script_name = "main_policy.lua",
      dependency_name = "helper.lua",
      condition = "false",
      flow = "request",
      kv_pairs = { user_role = "admin", max_limit = "100" }
    }
    assert.has_no.errors(function()
      handler.access(conf)
    end)
  end)
end)
