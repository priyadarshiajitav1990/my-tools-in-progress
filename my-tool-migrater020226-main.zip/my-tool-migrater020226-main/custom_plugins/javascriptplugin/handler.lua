local kong = kong
local plugin = {
  PRIORITY = 800,
  VERSION = "1.0.0",
  -- Kong EE 3.13.0.0 supports before/after ordering and tagging
  -- These are set in the schema, but can be referenced here if needed
}

local function execute_scripts(conf, phase)
  for i = 1, 10 do
    local script = conf["script_" .. i]
    local condition = conf["condition_" .. i]
    local script_phase = conf["phase_" .. i] or "both"
    if script and script ~= "" then
      -- Only run if phase matches (or "both")
      if script_phase == phase or script_phase == "both" then
        local should_run = true
        if condition and condition ~= "" then
          local func, err = load("return " .. condition)
          if func then
            local ok, result = pcall(func)
            should_run = ok and result
          end
        end
        if should_run then
          local func, err = load(script)
          if func then
            local ok, err = pcall(func)
            if not ok then
              kong.log.err("Script " .. i .. " error: " .. tostring(err))
            end
          else
            kong.log.err("Script " .. i .. " load error: " .. tostring(err))
          end
        end
      end
    end
  end
end

function plugin:access(conf)
  execute_scripts(conf, "access")
end

function plugin:header_filter(conf)
  execute_scripts(conf, "header_filter")
end

function plugin:body_filter(conf)
  execute_scripts(conf, "body_filter")
end

return plugin
