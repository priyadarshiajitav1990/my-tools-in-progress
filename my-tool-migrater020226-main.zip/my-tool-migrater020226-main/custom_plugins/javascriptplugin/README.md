
# javascriptplugin Kong Custom Plugin

Supports Kong Enterprise Edition v3.13.0.0

This plugin allows configuration of up to 10 Lua script blocks, each with an optional condition and phase (request/response). Each script will be executed in the configured phase (access, header_filter, body_filter, or both) if its condition (if provided) evaluates to true.

## Features
- Compatible with Kong Enterprise Edition v3.13.0.0
- Executes scripts in request (access) and response (header_filter/body_filter) flows
- Supports execution ordering using `before` and `after` (see Kong plugin ordering)
- Supports tagging like built-in plugins
- Up to 10 scripts, each with:
  - Optional condition (Lua expression)
  - Optional phase selection ("access", "header_filter", "body_filter", or "both")

## File Structure
- `handler.lua`: Main plugin logic
- `schema.lua`: Plugin configuration schema
- `README.md`: This documentation

## Configuration Example
```yaml
plugins:
- name: javascriptplugin
  config:
    script_1: |
      kong.log("Script 1 executed!")
    condition_1: "kong.request.get_method() == 'GET'"
    phase_1: "access"
    script_2: |
      kong.log("Script 2 executed!")
    phase_2: "header_filter"
    # ... up to script_10/condition_10/phase_10
  tags:
    - custom
    - javascript
  ordering:
    before:
      - rate-limiting
    after:
      - key-auth
```

## Ordering and Tagging
- Use the `ordering` field to specify `before` and `after` plugin execution order.
- Use the `tags` field to tag the plugin instance for management and discovery.
