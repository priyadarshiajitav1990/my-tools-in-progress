-- Placeholder schema for set_my_headers plugin
return {
  name = "set_my_headers",
  fields = {
    { consumer = typedefs.no_consumer },
    { service = typedefs.no_service },
    { route = typedefs.no_route },
    { protocols = typedefs.protocols },
    { config = {
      type = "record",
      fields = {
        -- Add plugin-specific config fields here
      },
    } },
  },
}
