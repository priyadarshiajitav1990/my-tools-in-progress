import os
import logging
import requests
import time
import subprocess
import sys

class KongManager:
    def __init__(self, kong_admin_url, logger=None):
        self.kong_admin_url = kong_admin_url
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def _execute_command(self, command, cwd=None, error_message="Command failed"):
        """Executes a shell command and logs its output."""
        self.logger.debug(f"Executing command: {' '.join(command)}")
        try:
            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                check=True,
                shell=True
            )
            self.logger.debug(f"Command stdout: {result.stdout}")
            if result.stderr:
                self.logger.warning(f"Command stderr: {result.stderr}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"{error_message}: {e}")
            self.logger.error(f"Command stdout: {e.stdout}")
            self.logger.error(f"Command stderr: {e.stderr}")
            return False
        except FileNotFoundError:
            self.logger.error(f"Command not found. Make sure '{command[0]}' is in your PATH.")
            return False
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while executing command: {e}")
            return False

    def is_kong_running(self):
        """Checks if Kong is accessible via its Admin API."""
        try:
            response = requests.get(f"{self.kong_admin_url}/status") # Or /
            response.raise_for_status()
            self.logger.info("Kong Admin API is reachable.")
            return True
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Kong Admin API not reachable at {self.kong_admin_url}: {e}")
            return False

    def get_enabled_plugins(self):
        """Fetches the list of currently enabled plugins in Kong."""
        try:
            response = requests.get(f"{self.kong_admin_url}/plugins")
            response.raise_for_status()
            plugins_data = response.json()
            enabled_plugins = [p['name'] for p in plugins_data.get('data', [])]
            self.logger.debug(f"Currently enabled plugins: {enabled_plugins}")
            return set(enabled_plugins)
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error fetching enabled plugins from Kong: {e}")
            return None

    def enable_plugin(self, plugin_name):
        """
        Enables a plugin in Kong by creating a new plugin configuration.
        Assumes the plugin has already been installed/placed.
        """
        self.logger.info(f"Attempting to enable plugin: {plugin_name}")
        payload = {
            "name": plugin_name,
            # No specific service/route/consumer by default,
            # meaning it's enabled globally.
            # Can be extended to be specific if needed.
        }
        try:
            response = requests.post(f"{self.kong_admin_url}/plugins", json=payload)
            response.raise_for_status()
            self.logger.info(f"Plugin '{plugin_name}' enabled successfully. Response: {response.json()}")
            return True
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error enabling plugin '{plugin_name}': {e}")
            if e.response is not None:
                self.logger.error(f"Kong API Error Response: {e.response.text}")
            return False
    
    def restart_kong(self, restart_command=None, wait_time=10, max_retries=5):
        """
        Restarts the Kong service and waits for it to become available.
        restart_command: A shell command to execute for restarting Kong.
                         E.g., "kong restart", "sudo systemctl restart kong",
                         "docker restart <kong_container_name>"
        """
        self.logger.info("Attempting to restart Kong service...")
        if not restart_command:
            self.logger.warning("No specific Kong restart command provided. "
                                "Kong restart cannot be automated without a command.")
            self.logger.warning("Please provide a 'restart_command' for automated Kong restarts.")
            return False
        
        if not self._execute_command([restart_command], error_message="Kong restart command failed"):
            self.logger.error("Failed to execute Kong restart command.")
            return False

        self.logger.info(f"Kong restart command executed. Waiting {wait_time} seconds for Kong to come back online...")
        time.sleep(wait_time)

        for i in range(max_retries):
            if self.is_kong_running():
                self.logger.info("Kong is back online and reachable.")
                return True
            self.logger.warning(f"Kong not yet reachable, retry {i+1}/{max_retries}...")
            time.sleep(wait_time)
        
        self.logger.error("Kong did not come back online after restart within the allotted time/retries.")
        return False
    
    def verify_plugin_enabled(self, plugin_name):
        """Verifies if a specific plugin is enabled in Kong."""
        enabled_plugins = self.get_enabled_plugins()
        if enabled_plugins is None:
            self.logger.error(f"Could not verify plugin '{plugin_name}' enablement due to API error.")
            return False
        
        if plugin_name in enabled_plugins:
            self.logger.info(f"Plugin '{plugin_name}' is verified as enabled in Kong.")
            return True
        else:
            self.logger.warning(f"Plugin '{plugin_name}' is NOT enabled in Kong.")
            return False
