import os
import logging
import requests
import zipfile
import io
import subprocess # Import subprocess module

class PluginDeployer:
    def __init__(self, kong_admin_url, logger=None):
        self.kong_admin_url = kong_admin_url
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def _execute_command(self, command, cwd=None, error_message="Command failed"):
        """Executes a shell command and logs its output."""
        self.logger.debug(f"Executing command: {' '.join(command)}")
        try:
            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                check=True, # Raise CalledProcessError for non-zero exit codes
                shell=True # Use shell=True for simpler command strings (but be careful with user input)
            )
            self.logger.debug(f"Command stdout: {result.stdout}")
            if result.stderr:
                self.logger.warning(f"Command stderr: {result.stderr}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"{error_message}: {e}")
            self.logger.error(f"Command stdout: {e.stdout}")
            self.logger.error(f"Command stderr: {e.stderr}")
            return False
        except FileNotFoundError:
            self.logger.error(f"Command not found. Make sure '{command[0]}' is in your PATH.")
            return False
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while executing command: {e}")
            return False

    def _generate_rockspec(self, plugin_name, plugin_path):
        """Generates a basic .rockspec file for the plugin if one doesn't exist."""
        rockspec_filename = f"{plugin_name}-0.1.0-1.rockspec" # Standard versioning
        rockspec_path = os.path.join(plugin_path, rockspec_filename)

        if os.path.exists(rockspec_path):
            self.logger.info(f"Rockspec already exists for '{plugin_name}': {rockspec_path}")
            return rockspec_path

        self.logger.info(f"Generating rockspec for '{plugin_name}' at {rockspec_path}...")
        rockspec_content = f"""
package = "{plugin_name}"
version = "0.1.0-1"
source = {{
   url = "git://github.com/your-org/{plugin_name}.git",
   tag = "0.1.0"
}}
description = {{
   summary = "A custom Kong plugin: {plugin_name}",
   homepage = "http://github.com/your-org/{plugin_name}",
   license = "MIT"
}}
dependencies = {{
   "lua >= 5.1"
}}
build = {{
   type = "builtin",
   modules = {{
      ["kong.plugins.{plugin_name}.handler"] = "handler.lua",
      ["kong.plugins.{plugin_name}.schema"] = "schema.lua",
   }},
   copy_directories = {{
     "kong", # This is crucial for Kong plugins structure
   }}
}}
"""
        try:
            with open(rockspec_path, "w") as f:
                f.write(rockspec_content)
            self.logger.info(f"Rockspec '{rockspec_filename}' generated successfully.")
            return rockspec_path
        except Exception as e:
            self.logger.error(f"Error generating rockspec for '{plugin_name}': {e}")
            return None

    def _lint_plugin(self, rockspec_path):
        """Lints the plugin using luarocks lint."""
        self.logger.info(f"Linting plugin with rockspec: {rockspec_path}")
        command = ["luarocks", "lint", rockspec_path]
        return self._execute_command(command, cwd=os.path.dirname(rockspec_path), error_message="Luarocks lint failed")

    def _pack_plugin(self, rockspec_path):
        """Packages the plugin using luarocks pack."""
        self.logger.info(f"Packaging plugin with rockspec: {rockspec_path}")
        command = ["luarocks", "pack", rockspec_path]
        if self._execute_command(command, cwd=os.path.dirname(rockspec_path), error_message="Luarocks pack failed"):
            # Luarocks pack creates a .rock file in the CWD (where rockspec is)
            rock_file = os.path.join(os.path.dirname(rockspec_path), f"{os.path.basename(rockspec_path).replace('.rockspec', '.rock')}")
            if os.path.exists(rock_file):
                self.logger.info(f"Plugin packaged successfully: {rock_file}")
                return rock_file
            else:
                self.logger.error(f"Luarocks pack succeeded but .rock file not found at expected path: {rock_file}")
                return None
        return None


    def _upload_plugin_via_api(self, plugin_name, plugin_path):
        """
        Uploads a custom Lua plugin to Kong via its Admin API.
        The plugin directory is zipped and sent.
        This method remains as a fallback or for direct directory upload if .rock file upload isn't directly supported.
        """
        zip_buffer = io.BytesIO()
        try:
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(plugin_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        # Archive path should be relative to the plugin_path
                        arcname = os.path.relpath(file_path, plugin_path)
                        zipf.write(file_path, arcname)
            
            zip_buffer.seek(0)
            
            files = {'file': (f'{plugin_name}.zip', zip_buffer.read(), 'application/zip')}
            
            upload_url = f"{self.kong_admin_url}/plugins/custom" # Example endpoint, might vary
            
            self.logger.info(f"Attempting to upload plugin '{plugin_name}' from '{plugin_path}' to {upload_url}...")
            response = requests.post(upload_url, files=files)
            response.raise_for_status()
            self.logger.info(f"Plugin '{plugin_name}' uploaded successfully. Response: {response.json()}")
            return True
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error uploading plugin '{plugin_name}': {e}")
            if e.response is not None:
                self.logger.error(f"Kong API Error Response: {e.response.text}")
            return False
        except Exception as e:
            self.logger.error(f"An unexpected error occurred during plugin zipping/upload for '{plugin_name}': {e}")
            return False

    def deploy_plugin(self, plugin_name, plugin_path):
        """
        Deploys a single custom Lua plugin to the remote Kong server.
        Involves: rockspec generation, linting, packaging with Luarocks,
        and then uploading the packaged plugin.
        """
        self.logger.info(f"Deploying plugin: {plugin_name} from {plugin_path}")

        if not os.path.isdir(plugin_path):
            self.logger.error(f"Plugin directory not found for '{plugin_name}': {plugin_path}")
            return False
        
        rockspec_path = self._generate_rockspec(plugin_name, plugin_path)
        if not rockspec_path:
            self.logger.error(f"Failed to generate rockspec for '{plugin_name}'. Aborting deployment.")
            return False

        if not self._lint_plugin(rockspec_path):
            self.logger.error(f"Plugin '{plugin_name}' failed Luarocks lint. Aborting deployment.")
            return False
        
        # Packaging the plugin to a .rock file
        # The .rock file can be considered an artifact. For direct Kong Admin API deployment,
        # Kong usually expects the plugin directory itself, zipped.
        # So we validate and pack, but still upload the directory for Kong Admin API.
        rock_file_path = self._pack_plugin(rockspec_path) # Generate .rock for artifact/future use

        if self._upload_plugin_via_api(plugin_name, plugin_path):
            self.logger.info(f"Plugin '{plugin_name}' successfully placed on remote server (via API upload) after Luarocks validation and packaging.")
            return True
        else:
            self.logger.error(f"Failed to place plugin '{plugin_name}' on remote server after Luarocks operations.")
            return False