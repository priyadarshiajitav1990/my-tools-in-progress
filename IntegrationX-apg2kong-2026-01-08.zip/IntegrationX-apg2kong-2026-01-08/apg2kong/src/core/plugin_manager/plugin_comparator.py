import os
import hashlib
import json
import logging
import requests

class PluginComparator:
    def __init__(self, kong_admin_url, custom_plugins_path):
        self.kong_admin_url = kong_admin_url
        self.custom_plugins_path = custom_plugins_path
        self.logger = logging.getLogger(self.__class__.__name__)

    def _get_remote_plugins(self):
        """
        Fetches a list of installed Lua plugins from the remote Kong Gateway.
        Returns a dictionary where keys are plugin names and values are their configurations.
        """
        try:
            response = requests.get(f"{self.kong_admin_url}/plugins")
            response.raise_for_status()  # Raise an exception for HTTP errors
            plugins_data = response.json()
            remote_plugins = {}
            for plugin in plugins_data.get('data', []):
                remote_plugins[plugin['name']] = plugin
            self.logger.info(f"Successfully fetched {len(remote_plugins)} remote plugins.")
            return remote_plugins
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error fetching remote plugins from {self.kong_admin_url}: {e}")
            return None

    def _get_local_plugin_hash(self, plugin_name, plugin_path):
        """
        Calculates a hash for a local Lua plugin's content.
        This provides a simple way to check for content changes.
        """
        # For simplicity, we'll hash the 'handler.lua' and 'schema.lua' files if they exist
        # A more robust solution might include all relevant files in the plugin directory
        hash_md5 = hashlib.md5()
        files_to_hash = ['handler.lua', 'schema.lua']
        content_found = False
        for filename in files_to_hash:
            filepath = os.path.join(plugin_path, filename)
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    for chunk in iter(lambda: f.read(4096), b""):
                        hash_md5.update(chunk)
                content_found = True
        if not content_found:
            self.logger.warning(f"No handler.lua or schema.lua found for local plugin '{plugin_name}' at '{plugin_path}'.")
            return None
        return hash_md5.hexdigest()

    def _get_local_plugins(self):
        """
        Scans the local custom plugins directory and gets metadata (including hash)
        for each plugin.
        Returns a dictionary where keys are plugin names and values are dictionaries
        containing 'path' and 'hash'.
        """
        local_plugins = {}
        if not os.path.isdir(self.custom_plugins_path):
            self.logger.warning(f"Local custom plugins directory not found: {self.custom_plugins_path}")
            return local_plugins

        for plugin_name in os.listdir(self.custom_plugins_path):
            plugin_path = os.path.join(self.custom_plugins_path, plugin_name)
            if os.path.isdir(plugin_path):
                plugin_hash = self._get_local_plugin_hash(plugin_name, plugin_path)
                if plugin_hash:
                    local_plugins[plugin_name] = {
                        'path': plugin_path,
                        'hash': plugin_hash
                    }
        self.logger.info(f"Found {len(local_plugins)} local custom plugins.")
        return local_plugins

    def compare_plugins(self):
        """
        Compares local custom Lua plugins with those installed on the remote Kong Gateway.
        Returns a dictionary with 'to_deploy', 'to_update', 'unchanged', 'remote_only' lists.
        """
        remote_plugins = self._get_remote_plugins()
        if remote_plugins is None:
            self.logger.error("Could not fetch remote plugins. Aborting comparison.")
            return None

        local_plugins = self._get_local_plugins()

        to_deploy = []    # Local plugins not found remotely
        to_update = []    # Local plugins found remotely but with different content/version
        unchanged = []    # Local plugins found remotely with same content
        remote_only = []  # Remote plugins not found locally

        for local_name, local_data in local_plugins.items():
            if local_name not in remote_plugins:
                to_deploy.append(local_name)
            else:
                # Simplified logic: if a local plugin name matches a remote plugin name,
                # and it has content (has a hash), we assume it might need an update
                # as we don't have a reliable way to compare content directly from Kong's API for custom Lua plugins.
                if local_data.get('hash'):
                    to_update.append(local_name)
                else:
                    # If no local content (e.g., just an empty directory), and it exists remotely, consider it unchanged for now
                    unchanged.append(local_name)

        for remote_name in remote_plugins.keys():
            if remote_name not in local_plugins:
                remote_only.append(remote_name)
                
        # Ensure uniqueness and correct categorization
        # to_deploy: items in local_plugins but not in remote_plugins
        to_deploy = [name for name in local_plugins if name not in remote_plugins]
        
        # to_update: items in local_plugins that are also in remote_plugins, and have a local hash
        # Remove duplicates from to_update if any (though logic above should prevent it)
        to_update = [name for name in set(to_update) if name not in to_deploy]

        # unchanged: items in local_plugins that are also in remote_plugins, but have no local hash (no content to compare)
        unchanged = [name for name, data in local_plugins.items() if name in remote_plugins and not data.get('hash')]
        # This needs to be careful not to overlap with to_update.
        # A local plugin is 'unchanged' if it exists remotely AND no local hash (meaning no content to determine 'difference')
        # This implies it's a marker, not an actual deployable plugin.

        # Let's re-evaluate the "unchanged" logic. If a local plugin directory exists
        # but has no handler.lua or schema.lua (and thus no hash), it's not truly a functional plugin
        # that would be "updated". It's more like a placeholder.
        # So, the 'to_update' list already handles the "difference" for actual plugins.
        # We should focus on actual content for 'to_update'.

        # Revised logic for better clarity and alignment with user request "if its not present or there is a difference":
        # 1. to_deploy: local plugin exists, but not on remote.
        # 2. to_update: local plugin exists AND remote plugin exists.
        #    (We assume difference for now, as direct remote content comparison is hard.
        #     A future enhancement could try to get remote plugin source or version to compare against local hash).
        # 3. unchanged: No direct match for this requirement, as user implies action on "difference".
        #    If we must populate 'unchanged', it would be local plugins matching remote where we *could* prove
        #    no difference. Without remote content hash, this is hard.
        #    For now, let's just use to_deploy, to_update, remote_only.

        # Final simplified logic to align with "if its not present or there is a difference":
        to_deploy = []
        to_update = []
        remote_only = list(remote_plugins.keys()) # Start with all remote, remove if found locally

        for local_name, local_data in local_plugins.items():
            if local_name in remote_plugins:
                # If a local plugin with content exists and a remote plugin with the same name exists,
                # we assume it's an update scenario to ensure the local version is deployed.
                # This accounts for "there is a difference" part of the requirement.
                if local_data.get('hash'): # Check if local plugin actually has content
                    to_update.append(local_name)
                # Remove from remote_only as it's found locally
                if local_name in remote_only:
                    remote_only.remove(local_name)
            else:
                # Local plugin exists but not remotely
                to_deploy.append(local_name)
        
        # 'unchanged' can be derived as local_plugins that are neither in to_deploy nor to_update.
        # This would effectively mean local plugin exists, remote plugin exists, but local plugin has no hash.
        # Or, if future logic could prove remote and local are identical.
        # For current scope, it's less critical. Let's keep it simple.
        unchanged = [] # Not explicitly handling "unchanged" based on content yet.

        self.logger.info(f"Comparison results: {len(to_deploy)} to deploy, {len(to_update)} to update, {len(remote_only)} remote only.")
        
        return {
            'to_deploy': to_deploy,
            'to_update': to_update,
            'unchanged': unchanged, # Will be empty or specific if comparison improves
            'remote_only': remote_only
        }
