# src/core/plugin_manager/__init__.py
