import os
import logging
from abc import ABC, abstractmethod

class BaseConverter(ABC):
    """Abstract Base Class for all language to Lua converters."""
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def convert(self, source_code_path: str, output_dir: str) -> str:
        """
        Converts source code from one language to Lua.
        Args:
            source_code_path: Path to the input source code file.
            output_dir: Directory where the converted Lua plugin should be saved.
        Returns:
            Path to the converted Lua plugin directory, or None if conversion fails.
        """
        pass

class ScriptConverterFactory:
    _converters = {}

    @classmethod
    def register_converter(cls, file_extension: str, converter_class):
        """Registers a converter class for a given file extension."""
        if not issubclass(converter_class, BaseConverter):
            raise ValueError("Converter class must inherit from BaseConverter")
        cls._converters[file_extension] = converter_class
        logging.info(f"Registered converter for .{file_extension} files: {converter_class.__name__}")

    @classmethod
    def get_converter(cls, file_path: str) -> BaseConverter:
        """
        Returns an instance of the appropriate converter for the given file path.
        Raises ValueError if no converter is registered for the file type.
        """
        file_extension = os.path.splitext(file_path)[1].lstrip('.').lower()
        converter_class = cls._converters.get(file_extension)
        if not converter_class:
            raise ValueError(f"No converter registered for file type: .{file_extension}")
        return converter_class()

# Initialize logging for the factory
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
