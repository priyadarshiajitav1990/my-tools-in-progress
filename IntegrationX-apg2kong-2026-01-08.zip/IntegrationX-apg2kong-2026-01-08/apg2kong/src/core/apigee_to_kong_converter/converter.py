import logging
import os
import json # for saving kong config

from .apigee_parser import ApigeeParser
from .policy_mapper import PolicyMapper
from .kong_generator import KongConfigGenerator
from ..conversion.script_converter import ScriptConverterFactory # To convert JS/PY/Java to Lua

class ApigeeToKongConverter:
    def __init__(self, policy_mapping_file="configs/policy-mapping.json", logger=None):
        self.logger = logger or logging.getLogger(self.__class__.__name__)
        self.apigee_parser = ApigeeParser(logger=self.logger)
        self.policy_mapper = PolicyMapper(policy_mapping_file=policy_mapping_file, logger=self.logger)
        self.kong_generator = KongConfigGenerator(logger=self.logger)

    def convert_bundle(self, apigee_bundle_path: str, output_kong_config_path: str, converted_plugins_output_dir: str) -> bool:
        """
        Orchestrates the conversion of an Apigee proxy bundle to Kong declarative configuration.
        Args:
            apigee_bundle_path: Path to the unzipped Apigee proxy bundle.
            output_kong_config_path: Path where the generated Kong JSON configuration will be saved.
            converted_plugins_output_dir: Directory where converted language plugins (JS/PY/Java) will be stored.
        Returns:
            True if conversion is successful, False otherwise.
        """
        self.logger.info(f"Starting conversion for Apigee bundle: {apigee_bundle_path}")

        # 1. Parse Apigee Bundle
        parsed_apigee_data = self.apigee_parser.parse_proxy_bundle(apigee_bundle_path)
        if not parsed_apigee_data:
            self.logger.error(f"Failed to parse Apigee bundle: {apigee_bundle_path}")
            return False

        # 2. Convert resources (JS/PY/Java) to Lua plugins
        converted_plugins_info = [] # Store name and type for policy mapping
        resources = parsed_apigee_data.get('resources', {})
        for res_type, file_paths in resources.items():
            for file_path in file_paths:
                try:
                    converter = ScriptConverterFactory.get_converter(file_path)
                    lua_plugin_dir_path = converter.convert(file_path, converted_plugins_output_dir)
                    if lua_plugin_dir_path:
                        plugin_name_from_dir = os.path.basename(lua_plugin_dir_path).replace(f"_{res_type}_plugin", "")
                        converted_plugins_info.append({"original_file": file_path, "plugin_name": plugin_name_from_dir, "plugin_type": res_type, "lua_path": lua_plugin_dir_path})
                        self.logger.info(f"Resource '{file_path}' converted to Lua plugin at: {lua_plugin_dir_path}")
                    else:
                        self.logger.warning(f"Failed to convert resource '{file_path}'.")
                except ValueError as e:
                    self.logger.warning(f"Skipping conversion for resource '{file_path}': {e}")
                except Exception as e:
                    self.logger.error(f"Error during conversion of resource '{file_path}': {e}")


        # 3. Map Apigee Policies to Kong Plugins
        kong_plugins_for_bundle = []
        for policy_name, apigee_policy in parsed_apigee_data.get('policies', {}).items():
            # Need to pass converted_plugins_info to policy_mapper if a policy references a converted resource
            mapped_plugin = self.policy_mapper.map_policy(apigee_policy['type'], apigee_policy['config']) # Add converted_plugins_info as arg
            if mapped_plugin:
                kong_plugins_for_bundle.append(mapped_plugin)
            else:
                self.logger.warning(f"Could not map Apigee policy '{policy_name}' of type '{apigee_policy['type']}'.")
        
        # 4. Generate Kong JSON Configuration
        kong_config = self.kong_generator.generate_kong_json(parsed_apigee_data, kong_plugins_for_bundle)
        if not kong_config:
            self.logger.error(f"Failed to generate Kong configuration for bundle: {apigee_bundle_path}")
            return False

        # 5. Save Kong JSON to file
        try:
            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_kong_config_path), exist_ok=True)
            with open(output_kong_config_path, 'w') as f:
                json.dump(kong_config, f, indent=2)
            self.logger.info(f"Kong configuration successfully saved to: {output_kong_config_path}")
            return True
        except Exception as e:
            self.logger.error(f"Error saving Kong configuration to {output_kong_config_path}: {e}")
            return False
