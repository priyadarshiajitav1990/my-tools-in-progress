import os
import xml.etree.ElementTree as ET
import logging

class ApigeeParser:
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def _parse_xml_file(self, file_path):
        """Parses an XML file and returns its root element."""
        if not os.path.exists(file_path):
            self.logger.warning(f"XML file not found: {file_path}")
            return None
        try:
            tree = ET.parse(file_path)
            return tree.getroot()
        except ET.ParseError as e:
            self.logger.error(f"Error parsing XML file {file_path}: {e}")
            return None

    def parse_proxy_bundle(self, bundle_path):
        """
        Parses an Apigee proxy bundle directory to extract configurations.
        Args:
            bundle_path: Path to the root of the unzipped Apigee proxy bundle.
        Returns:
            A dictionary containing parsed Apigee configurations.
        """
        self.logger.info(f"Parsing Apigee proxy bundle at: {bundle_path}")
        
        proxy_data = {
            "name": os.path.basename(bundle_path),
            "proxies": [],
            "targets": [],
            "policies": {},
            "resources": {} # For JS/Java/Python resources
        }

        # --- Parse Proxy Endpoints ---
        proxy_endpoints_path = os.path.join(bundle_path, "apiproxy", "proxies")
        if os.path.exists(proxy_endpoints_path):
            for proxy_file in os.listdir(proxy_endpoints_path):
                if proxy_file.endswith(".xml"):
                    file_path = os.path.join(proxy_endpoints_path, proxy_file)
                    root = self._parse_xml_file(file_path)
                    if root is not None:
                        proxy_data["proxies"].append(self._extract_proxy_endpoint_data(root))
        
        # --- Parse Target Endpoints ---
        target_endpoints_path = os.path.join(bundle_path, "apiproxy", "targets")
        if os.path.exists(target_endpoints_path):
            for target_file in os.listdir(target_endpoints_path):
                if target_file.endswith(".xml"):
                    file_path = os.path.join(target_endpoints_path, target_file)
                    root = self._parse_xml_file(file_path)
                    if root is not None:
                        proxy_data["targets"].append(self._extract_target_endpoint_data(root))

        # --- Parse Policies ---
        policies_path = os.path.join(bundle_path, "apiproxy", "policies")
        if os.path.exists(policies_path):
            for policy_file in os.listdir(policies_path):
                if policy_file.endswith(".xml"):
                    file_path = os.path.join(policies_path, policy_file)
                    root = self._parse_xml_file(file_path)
                    if root is not None:
                        policy_name = os.path.splitext(policy_file)[0]
                        proxy_data["policies"][policy_name] = self._extract_policy_data(root)
                        
        # --- Extract Resources (JS, Java, Python) ---
        resources_path = os.path.join(bundle_path, "apiproxy", "resources")
        if os.path.exists(resources_path):
            for res_type in os.listdir(resources_path): # e.g., 'jsc', 'java', 'py'
                type_path = os.path.join(resources_path, res_type)
                if os.path.isdir(type_path):
                    proxy_data["resources"][res_type] = []
                    for resource_file in os.listdir(type_path):
                        # Filter for common script/jar extensions
                        if resource_file.endswith(('.js', '.java', '.py', '.jar')):
                            proxy_data["resources"][res_type].append(os.path.join(type_path, resource_file))

        self.logger.info(f"Finished parsing bundle. Found {len(proxy_data['proxies'])} proxies, "
                         f"{len(proxy_data['targets'])} targets, {len(proxy_data['policies'])} policies.")
        return proxy_data

    def _extract_proxy_endpoint_data(self, root_element):
        """Extracts relevant data from a ProxyEndpoint XML root."""
        data = {
            "name": root_element.attrib.get('name'),
            "base_path": None,
            "flows": [],
            "pre_flow": [],
            "post_flow": [],
            "fault_rules": []
        }
        
        # Extract BasePath
        for http_proxy_conn in root_element.findall('HTTPProxyConnection'):
            base_path = http_proxy_conn.find('BasePath')
            if base_path is not None:
                data['base_path'] = base_path.text
                break
        
        # Extract flows, preflow, postflow, faultrules (simplified for now)
        for pre_flow in root_element.findall('PreFlow'):
            data['pre_flow'].extend(self._extract_flow_steps(pre_flow))
        for post_flow in root_element.findall('PostFlow'):
            data['post_flow'].extend(self._extract_flow_steps(post_flow))
        for flow in root_element.findall('Flows/Flow'):
            data['flows'].append({
                "name": flow.attrib.get('name'),
                "condition": flow.find('Condition').text if flow.find('Condition') is not None else None,
                "request": self._extract_flow_steps(flow.find('Request')),
                "response": self._extract_flow_steps(flow.find('Response'))
            })
        for fault_rules in root_element.findall('FaultRules/FaultRule'):
            data['fault_rules'].extend(self._extract_flow_steps(fault_rules))

        return data

    def _extract_target_endpoint_data(self, root_element):
        """Extracts relevant data from a TargetEndpoint XML root."""
        data = {
            "name": root_element.attrib.get('name'),
            "url": None,
            "pre_flow": [],
            "post_flow": [],
            "fault_rules": []
        }

        for http_target_conn in root_element.findall('HTTPTargetConnection'):
            url = http_target_conn.find('URL')
            if url is not None:
                data['url'] = url.text
                break
        
        for pre_flow in root_element.findall('PreFlow'):
            data['pre_flow'].extend(self._extract_flow_steps(pre_flow))
        for post_flow in root_element.findall('PostFlow'):
            data['post_flow'].extend(self._extract_flow_steps(post_flow))
        for fault_rules in root_element.findall('FaultRules/FaultRule'):
            data['fault_rules'].extend(self._extract_flow_steps(fault_rules))
            
        return data

    def _extract_policy_data(self, root_element):
        """Extracts generic data from a Policy XML root."""
        policy_type = root_element.tag
        policy_name = root_element.attrib.get('name')
        data = {
            "type": policy_type,
            "name": policy_name,
            "config": {}
        }
        # Generic extraction of child elements as config
        for child in root_element:
            data['config'][child.tag] = child.text # Simplistic, full XML to JSON conversion needed for robustness
        return data

    def _extract_flow_steps(self, flow_element):
        """Extracts steps (policies) from a flow (PreFlow, PostFlow, Request, Response, FaultRule)."""
        steps = []
        if flow_element is None:
            return steps

        for step in flow_element.findall('Step'):
            policy_name = step.find('Name')
            if policy_name is not None:
                steps.append({
                    "name": policy_name.text,
                    "condition": step.find('Condition').text if step.find('Condition') is not None else None
                })
        return steps
