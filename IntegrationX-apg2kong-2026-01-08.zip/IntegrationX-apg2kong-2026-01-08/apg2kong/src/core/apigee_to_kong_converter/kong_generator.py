import logging
import json

class KongConfigGenerator:
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def generate_kong_json(self, apigee_parsed_data: dict, mapped_plugins: list) -> dict:
        """
        Generates a Kong declarative configuration (DB-less mode) JSON
        from parsed Apigee data and mapped Kong plugins.
        Args:
            apigee_parsed_data: Dictionary containing parsed Apigee proxy, target, and policy data.
            mapped_plugins: List of Kong plugin configurations derived from Apigee policies.
        Returns:
            A dictionary representing the Kong declarative configuration.
        """
        self.logger.info(f"Generating Kong JSON for Apigee proxy: {apigee_parsed_data.get('name', 'unknown')}")
        
        kong_config = {
            "_format_version": "1.1", # Or latest version if dynamic
            "services": [],
            "plugins": [] # Global plugins, service-specific plugins will be under service/route
        }

        # Handle mapped plugins first (these might be global or apply to specific routes/services)
        # For simplicity, initially add all mapped_plugins as global plugins.
        # In a real scenario, this would depend on where the Apigee policy was applied (proxy, target, flow).
        for plugin_config in mapped_plugins:
            kong_config["plugins"].append(plugin_config)

        # Assuming one Apigee proxy maps to one Kong Service with one or more Routes
        for proxy_endpoint in apigee_parsed_data.get('proxies', []):
            service_name = f"{apigee_parsed_data['name']}-{proxy_endpoint['name']}"
            target_url = None
            
            # Find the corresponding target URL
            for target_endpoint in apigee_parsed_data.get('targets', []):
                # Simple heuristic: if target name is similar or referenced
                # This needs to be more robust, typically via a target endpoint reference in the proxy.
                # For now, if only one target, use it.
                if len(apigee_parsed_data.get('targets', [])) == 1:
                    target_url = apigee_parsed_data['targets'][0].get('url')
                elif proxy_endpoint.get('target_endpoint_name') == target_endpoint.get('name'): # Example of a more robust way
                     target_url = target_endpoint.get('url')

            if not target_url:
                self.logger.warning(f"Could not determine target URL for service '{service_name}'. Skipping service creation.")
                continue

            service = {
                "name": service_name,
                "host": self._extract_host_from_url(target_url),
                "port": self._extract_port_from_url(target_url),
                "protocol": self._extract_protocol_from_url(target_url),
                "routes": [
                    {
                        "name": f"{service_name}-route",
                        "paths": [proxy_endpoint.get('base_path', f"/{apigee_parsed_data['name']}")],
                        "strip_path": True # Common for proxies
                    }
                ],
                "plugins": [] # Service-specific plugins
            }

            # Map plugins to specific routes/services based on Apigee flow
            # This is where the complexity lies. For this initial version,
            # we'll simplify and add all mapped_plugins to the service.
            # In a full implementation, you'd iterate through Apigee flows (pre-flow, flows, post-flow)
            # and attach plugins to specific Kong routes or services based on conditions.

            # Example: attach to service (simplified)
            for plugin_config in mapped_plugins:
                # Need to determine if plugin is global or specific to this service/route
                # For now, let's assume if it's not a global plugin type, it attaches here.
                # This is a major simplification.
                service["plugins"].append(plugin_config)


            kong_config["services"].append(service)

        self.logger.info(f"Generated Kong configuration with {len(kong_config['services'])} services.")
        return kong_config

    def _extract_host_from_url(self, url):
        """Extracts host from a URL string."""
        if not url: return None
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.hostname

    def _extract_port_from_url(self, url):
        """Extracts port from a URL string."""
        if not url: return 80 # Default to 80
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.port if parsed.port else (443 if parsed.scheme == 'https' else 80)

    def _extract_protocol_from_url(self, url):
        """Extracts protocol from a URL string."""
        if not url: return "http"
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.scheme if parsed.scheme else "http"
