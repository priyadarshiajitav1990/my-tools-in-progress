import asyncio
import os
import tempfile
import shutil
import json
import yaml
from unittest.mock import MagicMock
import logging
import pytest

from core.apigee_bundle_parser import ApigeeBundleParser
from core.kong_config_generator import KongConfigGenerator
from core.logger import setup_logging

# Set up logging for tests
setup_logging()
logger = logging.getLogger(__name__)


async def create_mock_apigee_bundle(
    temp_dir, proxy_xml_content, target_xml_content=None, policy_xml_content=None
):
    """Helper to create a mock Apigee bundle structure."""
    apiproxy_dir = os.path.join(temp_dir, "apiproxy")
    proxies_dir = os.path.join(apiproxy_dir, "proxies")
    targets_dir = os.path.join(apiproxy_dir, "targets")
    policies_dir = os.path.join(apiproxy_dir, "policies")

    os.makedirs(proxies_dir, exist_ok=True)
    os.makedirs(targets_dir, exist_ok=True)
    os.makedirs(policies_dir, exist_ok=True)

    # Write proxy endpoint XML
    with open(os.path.join(proxies_dir, "default.xml"), "w") as f:
        f.write(proxy_xml_content)

    # Write target endpoint XML if provided
    if target_xml_content:
        with open(os.path.join(targets_dir, "default.xml"), "w") as f:
            f.write(target_xml_content)

    # Write policy XML if provided
    if policy_xml_content:
        # Assuming policy_xml_content is a dict {filename: content}
        for filename, content in policy_xml_content.items():
            with open(os.path.join(policies_dir, filename), "w") as f:
                f.write(content)

    return temp_dir


@pytest.mark.asyncio
async def test_conditional_flow_with_method_predicate():
    """
    Test a conditional flow in Apigee mapping to a Kong route with a method predicate.
    """
    logger.info("Running test_conditional_flow_with_method_predicate...")

    proxy_xml = """<?xml version="1.0" encoding="UTF-8"?>
<ProxyEndpoint name="default">
    <HTTPProxyConnection>
        <BasePath>/test</BasePath>
        <VirtualHost>default</VirtualHost>
    </HTTPProxyConnection>
    <Flows>
        <Flow name="GetFlow">
            <Condition>(request.verb = "GET")</Condition>
            <Request>
                <Step><Name>VerifyAPIKey</Name></Step>
            </Request>
            <Response/>
            <Description/>
        </Flow>
        <Flow name="PostFlow">
            <Condition>(request.verb = "POST")</Condition>
            <Request>
                <Step><Name>QuotaPolicy</Name></Step>
            </Request>
            <Response/>
            <Description/>
        </Flow>
    </Flows>
    <RouteRule name="default">
        <TargetEndpoint>default</TargetEndpoint>
    </RouteRule>
</ProxyEndpoint>"""

    target_xml = """<?xml version="1.0" encoding="UTF-8"?>
<TargetEndpoint name="default">
    <HTTPTargetConnection>
        <URL>http://mocktarget.com</URL>
    </HTTPTargetConnection>
</TargetEndpoint>"""

    policy_xmls = {
        "VerifyAPIKey.xml": """<?xml version="1.0" encoding="UTF-8"?>
<VerifyAPIKey name="VerifyAPIKey">
    <APIKey ref="request.header.x-api-key"/>
</VerifyAPIKey>""",
        "QuotaPolicy.xml": """<?xml version="1.0" encoding="UTF-8"?>
<Quota name="QuotaPolicy">
    <Identifier ref="request.header.client_id"/>
    <Allow count="100"/>
    <Interval>1</Interval>
    <TimeUnit>hour</TimeUnit>
</Quota>""",
    }

    with tempfile.TemporaryDirectory() as temp_dir:
        bundle_path = await create_mock_apigee_bundle(
            temp_dir, proxy_xml, target_xml, policy_xmls
        )

        apigee_parser = ApigeeBundleParser(bundle_path, logger)
        parsed_data = await apigee_parser.parse()

        # Mock policy-to-plugin mapping for testing
        kong_config_generator = KongConfigGenerator(logger)
        # Manually inject a mock policy mapping if needed for testing specific plugins
        kong_config_generator.normalized_policy_to_plugin_mapping = {
            "VerifyAPIKey": [{"name": "kong-oauth2-key-auth", "config": {}}],
            "Quota": [{"name": "kong-rate-limiting", "config": {"hour": 100}}],
        }
        kong_config_yaml = await kong_config_generator.generate(parsed_data, "TestAPI")
        kong_config = yaml.safe_load(
            kong_config_yaml
        )  # Convert to dict for easier assertion
        logger.debug(
            f"Generated Kong config for conditional flow test: {json.dumps(kong_config, indent=2)}"
        )

        # Assertions
        assert "services" in kong_config
        assert "routes" in kong_config
        assert len(kong_config["services"]) == 1
        assert (
            len(kong_config["routes"]) == 3
        )  # 1 default from RouteRule + 2 from conditional flows (GET and POST)

        # Check default route (from RouteRule)
        default_route = next(
            (r for r in kong_config["routes"] if r["name"] == "TestAPI-default"), None
        )
        assert default_route is not None
        assert "/test" in default_route["paths"]
        assert (
            default_route.get("expression") is None
        )  # Default route should not have an expression

        # Check GET conditional route
        get_conditional_route = next(
            (r for r in kong_config["routes"] if r["name"] == "default-flow-GetFlow"),
            None,
        )
        assert get_conditional_route is not None
        assert get_conditional_route["expression"] == '(request.verb=="GET")'
        assert any(
            p["name"] == "kong-oauth2-key-auth"
            for p in get_conditional_route.get("plugins", [])
        )

        # Check POST conditional route
        post_conditional_route = next(
            (r for r in kong_config["routes"] if r["name"] == "default-flow-PostFlow"),
            None,
        )
        assert post_conditional_route is not None
        assert post_conditional_route["expression"] == '(request.verb=="POST")'
        logger.debug(
            f"Plugins for POST conditional route: {post_conditional_route.get('plugins', [])}"
        )
        assert any(
            p["name"] == "kong-rate-limiting"
            for p in post_conditional_route.get("plugins", [])
        )
        logger.info("✓ test_conditional_flow_with_method_predicate passed.")


@pytest.mark.asyncio
async def test_policy_execution_order_in_flow():
    """
    Test that the order of policies in an Apigee flow is maintained in Kong plugins.
    """
    logger.info("Running test_policy_execution_order_in_flow...")

    proxy_xml = """<?xml version="1.0" encoding="UTF-8"?>
<ProxyEndpoint name="default">
    <HTTPProxyConnection>
        <BasePath>/order-test</BasePath>
        <VirtualHost>default</VirtualHost>
    </HTTPProxyConnection>
    <Flows>
        <Flow name="OrderedFlow">
            <Request>
                <Step><Name>PolicyOne</Name></Step>
                <Step><Name>PolicyTwo</Name></Step>
                <Step><Name>PolicyThree</Name></Step>
            </Request>
            <Response/>
            <Description/>
        </Flow>
    </Flows>
    <RouteRule name="default">
        <TargetEndpoint>default</TargetEndpoint>
    </RouteRule>
</ProxyEndpoint>"""

    target_xml = """<?xml version="1.0" encoding="UTF-8"?>
<TargetEndpoint name="default">
    <HTTPTargetConnection>
        <URL>http://mocktarget.com</URL>
    </HTTPTargetConnection>
</TargetEndpoint>"""

    policy_xmls = {
        "PolicyOne.xml": """<?xml version="1.0" encoding="UTF-8"?>
<VerifyAPIKey name="PolicyOne"/>""",
        "PolicyTwo.xml": """<?xml version="1.0" encoding="UTF-8"?>
<VerifyAPIKey name="PolicyTwo"/>""",
        "PolicyThree.xml": """<?xml version="1.0" encoding="UTF-8"?>
<VerifyAPIKey name="PolicyThree"/>""",
    }

    with tempfile.TemporaryDirectory() as temp_dir:
        bundle_path = await create_mock_apigee_bundle(
            temp_dir, proxy_xml, target_xml, policy_xmls
        )

        apigee_parser = ApigeeBundleParser(bundle_path, logger)
        parsed_data = await apigee_parser.parse()

        kong_config_generator = KongConfigGenerator(logger)
        kong_config_generator.policy_to_plugin_map = {
            "VerifyAPIKey": [{"name": "kong-oauth2-key-auth", "config": {}}]
        }

        kong_config_yaml = await kong_config_generator.generate(
            parsed_data, "OrderedAPI"
        )
        kong_config = yaml.safe_load(kong_config_yaml)

        assert "services" in kong_config
        assert "routes" in kong_config
        assert len(kong_config["services"]) == 1
        assert len(kong_config["routes"]) == 1

        route = kong_config["routes"][0]
        # Expecting both paths due to how KongConfigGenerator handles base_path
        assert "/order-test" in route["paths"]
        assert "/order-test/" in route["paths"]

        plugins = kong_config["services"][0].get("plugins", [])
        assert len(plugins) == 3

        # Assert the order of plugins
        assert plugins[0]["name"] == "key-auth"
        assert plugins[1]["name"] == "key-auth"
        assert plugins[2]["name"] == "key-auth"
        logger.info("✓ test_policy_execution_order_in_flow passed.")


@pytest.mark.asyncio
@pytest.mark.asyncio
async def test_dynamic_routing_with_target_url_ref():
    """
    Test dynamic routing where the target URL is referenced from a variable.
    """
    logger.info("Running test_dynamic_routing_with_target_url_ref...")

    proxy_xml = """<?xml version="1.0" encoding="UTF-8"?>
<ProxyEndpoint name="default">
    <HTTPProxyConnection>
        <BasePath>/dynamic-route</BasePath>
        <VirtualHost>default</VirtualHost>
    </HTTPProxyConnection>
    <PreFlow name="PreFlow">
        <Request>
            <Step><Name>SetDynamicTarget</Name></Step>
        </Request>
    </PreFlow>
    <RouteRule name="default">
        <TargetEndpoint>DynamicTarget</TargetEndpoint>
    </RouteRule>
</ProxyEndpoint>"""

    target_xml = """<?xml version="1.0" encoding="UTF-8"?>
<TargetEndpoint name="DynamicTarget">
    <HTTPTargetConnection>
        <URL>http://{private.target.url}</URL>
    </HTTPTargetConnection>
</TargetEndpoint>"""

    policy_xmls = {
        "SetDynamicTarget.xml": """<?xml version="1.0" encoding="UTF-8"?>
<AssignMessage name="SetDynamicTarget">
    <AssignVariable>
        <Name>private.target.url</Name>
        <Value>http://backend-service.com</Value>
    </AssignVariable>
    <IgnoreUnresolvedVariables>true</IgnoreUnresolvedVariables>
    <FaultRules/>
</AssignMessage>"""
    }

    with tempfile.TemporaryDirectory() as temp_dir:
        bundle_path = await create_mock_apigee_bundle(
            temp_dir, proxy_xml, target_xml, policy_xmls
        )

        apigee_parser = ApigeeBundleParser(bundle_path, logger)
        parsed_data = await apigee_parser.parse()

        kong_config_generator = KongConfigGenerator(logger)
        kong_config_generator.normalized_policy_to_plugin_mapping = {
            "AssignMessage": [
                {
                    "name": "kong-request-transformer",
                    "config": {
                        "add": {"headers": ["x-target-url: {private.target.url}"]}
                    },
                }
            ]
        }
        kong_config_yaml = await kong_config_generator.generate(
            parsed_data, "DynamicRouteAPI"
        )
        kong_config = yaml.safe_load(kong_config_yaml)
        logger.debug(
            f"Generated Kong config for dynamic routing test: {json.dumps(kong_config, indent=2)}"
        )

        assert "services" in kong_config
        assert "routes" in kong_config
        assert len(kong_config["services"]) == 1
        assert len(kong_config["routes"]) == 1

        service = kong_config["services"][0]
        assert service["name"] == "DynamicRouteAPI-default"  # Corrected service name

        # Check upstream created for the target endpoint
        upstreams = kong_config.get("upstreams", [])
        assert len(upstreams) == 1
        upstream = upstreams[0]
        assert (
            upstream["name"] == "DynamicRouteAPI-DynamicTarget"
        )  # Upstream name is prefixed
        assert len(upstream.get("targets", [])) == 1
        assert (
            upstream["targets"][0]["target"] == "http://{private.target.url}"
        )  # Expect the variable reference

        route = kong_config["routes"][0]
        # Expecting both paths due to how KongConfigGenerator handles base_path
        assert "/dynamic-route" in route["paths"]
        assert "/dynamic-route/" in route["paths"]

        plugins = service.get("plugins", [])
        assert any(p["name"] == "kong-request-transformer" for p in plugins)

        logger.info("✓ test_dynamic_routing_with_target_url_ref passed.")


async def main():
    """Run all advanced flow tests"""
    print("Starting advanced flow tests...\n")
    try:
        await test_conditional_flow_with_method_predicate()
        print()
        await test_policy_execution_order_in_flow()
        print()
        await test_dynamic_routing_with_target_url_ref()
        print()
        print("🎉 All advanced flow tests passed successfully!")
    except Exception as e:
        logger.error(f"❌ An advanced flow test failed: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
