import argparse
import logging
import configparser
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Set
from urllib.parse import urljoin

# --- Configuration ---
# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration Loading ---
config = configparser.ConfigParser()
CONFIG_FILE_PATH = Path(__file__).parent / "deploy.conf"
if CONFIG_FILE_PATH.is_file():
    config.read(CONFIG_FILE_PATH)
else:
    logging.warning(f"Configuration file not found at {CONFIG_FILE_PATH}. Using fallback defaults.")

def get_config_value(section, key, fallback):
    """Gets a value from the config file, with a fallback."""
    return config.get(section, key, fallback=fallback)

# Load defaults from config file
DEFAULT_SSH_TARGET = get_config_value("remote_server", "ssh_target", "user@your-kong-server")
DEFAULT_KONG_ADMIN_URL = get_config_value("remote_server", "kong_admin_url", "http://localhost:8001")
DEFAULT_SSH_KEY_PATH = Path(__file__).parent.parent / get_config_value("remote_server", "ssh_key", "keys/your-key.pem")

# --- Script Configuration ---
# Project root assumes this script is in a 'scripts' directory
PROJECT_ROOT = Path(__file__).parent.parent
PLUGINS_DIR = PROJECT_ROOT / "custom_plugins"
KONG_CONF_PATH_REMOTE = "/etc/kong/kong.conf" # A common default, might need to be an arg

# --- Helper Functions ---

def run_local_command(command, cwd=None):
    """Runs a command locally and streams its output."""
    logging.info(f"Running local command: {' '.join(command)}")
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            cwd=cwd
        )
        for line in iter(process.stdout.readline, ''):
            logging.info(line.strip())
        process.wait()
        if process.returncode != 0:
            logging.error(f"Local command failed with return code {process.returncode}.")
            return False
        return True
    except FileNotFoundError as e:
        logging.error(f"Command not found: {e}. Ensure the command is in your PATH.")
        return False
    except Exception as e:
        logging.error(f"An error occurred while running local command: {e}")
        return False

def run_remote_command(ssh_target, command, ssh_key):
    """Runs a command on a remote server via SSH."""
    remote_cmd = ["ssh", "-i", str(ssh_key), ssh_target, command]
    logging.info(f"Running remote command: {command}")
    try:
        process = subprocess.Popen(
            remote_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8'
        )
        for line in iter(process.stdout.readline, ''):
            logging.info(f"[REMOTE] {line.strip()}")
        process.wait()
        if process.returncode != 0:
            logging.error(f"Remote command failed with return code {process.returncode}.")
            return False
        return True
    except Exception as e:
        logging.error(f"An error occurred during remote execution: {e}")
        return False

def copy_to_remote(ssh_target, local_path, remote_path, recursive=False, ssh_key=None):
    """Copies a file or directory to a remote server via SCP."""
    scp_cmd = ["scp", "-i", str(ssh_key)]
    if recursive:
        scp_cmd.append("-r")
    scp_cmd.extend([str(local_path), f"{ssh_target}:{remote_path}"])
    logging.info(f"Copying {'directory' if recursive else 'file'} {local_path} to {ssh_target}:{remote_path}")
    return run_local_command(scp_cmd)

def get_remote_command_output(ssh_target, command, ssh_key):
    """Runs a command on a remote server via SSH and returns its stdout."""
    remote_cmd = ["ssh", "-i", str(ssh_key), ssh_target, command]
    logging.info(f"Running remote command for output: {command}")
    try:
        result = subprocess.run(
            remote_cmd,
            capture_output=True,
            text=True,
            check=False,  # We handle the error manually
            encoding='utf-8',
            timeout=15  # Add a timeout
        )
        if result.returncode != 0:
            # Log stderr from the remote command for better debugging
            logging.error(f"Remote command failed with return code {result.returncode}. Stderr: {result.stderr.strip()}")
            return None
        output = result.stdout.strip()
        logging.info(f"[REMOTE STDOUT] {output}")
        return output
    except subprocess.TimeoutExpired:
        logging.error("Remote command timed out.")
        return None
    except Exception as e:
        logging.error(f"An error occurred during remote execution for output: {e}")
        return None

def wait_for_kong_healthy(ssh_target: str, kong_admin_url: str, ssh_key: Path, retries=12, delay=5):
    """Waits for the Kong instance on the remote server to become healthy."""
    logging.info("Waiting for remote Kong to become healthy...")
    status_endpoint = urljoin(kong_admin_url, "/status")
    remote_curl_cmd = f'curl -sS -o /dev/null -w "%{{http_code}}" -m 5 {status_endpoint}'
    for i in range(retries):
        logging.info(f"Checking remote Kong health... ({i+1}/{retries})")
        status_code = get_remote_command_output(ssh_target, remote_curl_cmd, ssh_key)
        if status_code and status_code == "200":
            logging.info("Remote Kong is healthy (200 OK).")
            return True
        logging.info(f"Waiting... Remote Kong status: {status_code or 'unreachable'}")
        time.sleep(delay)
    logging.error("Remote Kong did not become healthy in time.")
    return False

# --- Deployment Steps ---

def _verify_ssh_key_exists(ssh_key_path: Path) -> bool:
    """Checks if the specified SSH key file exists."""
    if not ssh_key_path.is_file():
        logging.error(f"SSH key not found at the specified path: {ssh_key_path}")
        logging.error("Please ensure the key file exists or provide a correct path using --ssh-key.")
        return False
    return True

def verify_plugin(plugin_name: str) -> bool:
    """Verifies the plugin has the required files."""
    logging.info(f"--- Step: Verifying plugin '{plugin_name}' ---")
    plugin_dir = PLUGINS_DIR / plugin_name
    if not plugin_dir.is_dir():
        logging.error(f"Plugin directory not found: {plugin_dir}")
        return False
    
    handler_file = plugin_dir / "handler.lua"
    schema_file = plugin_dir / "schema.lua"

    if not handler_file.exists() or not schema_file.exists():
        logging.error(f"Plugin '{plugin_name}' is missing handler.lua or schema.lua.")
        return False
    
    logging.info("Plugin structure is valid (handler.lua and schema.lua exist).")
    return True

def _find_lua_dependencies(plugin_dir: Path) -> List[str]:
    """Scans .lua files for dependencies and returns a list of module names."""
    dependencies: Set[str] = set()
    # Common modules that are part of Kong or standard Lua and don't need to be in rockspec
    known_builtins = {
        "kong", "cjson", "resty", "ngx",
        "math", "string", "table", "io", "os", "coroutine", "package", "debug"
    }
    
    # Regex to handle require("module") and require "module"
    require_pattern = re.compile(r"""require\s*(?:(?:\(\s*["']([^"']+)["']\s*\))|["']([^"']+)["'])""")

    for lua_file in plugin_dir.rglob("*.lua"):
        try:
            with open(lua_file, "r", encoding="utf-8", errors='ignore') as f:
                for line in f:
                    # Ignore comment lines
                    if line.strip().startswith("--"):
                        continue
                    
                    match = require_pattern.search(line)
                    if match:
                        # The module name could be in group 1 or 2
                        dep = match.group(1) or match.group(2)
                        if dep:
                            # Check if it's a sub-module of a known builtin, e.g., kong.log or resty.http
                            base_module = dep.split('.')[0]
                            # Add dependency if it's not a known builtin and not a relative path (e.g. require ".utils")
                            if base_module not in known_builtins and not dep.startswith("."):
                                dependencies.add(dep)
        except Exception as e:
            logging.warning(f"Could not read or parse {lua_file} for dependencies: {e}")
    
    return sorted(list(dependencies))

def generate_rockspec(plugin_name: str, version="0.1.0-1") -> bool:
    """Generates a .rockspec file for the plugin, including detected dependencies."""
    logging.info(f"--- Step (Rock): Generating .rockspec for '{plugin_name}' ---")
    plugin_dir = PLUGINS_DIR / plugin_name
    rockspec_path = plugin_dir / f"{plugin_name}-{version}.rockspec"
    
    # Auto-detect dependencies and format them for the rockspec file
    detected_deps = _find_lua_dependencies(plugin_dir)
    deps_for_rockspec = ['"lua >= 5.1"'] + [f'"{dep}"' for dep in detected_deps]
    dependencies_str = ",\n   ".join(deps_for_rockspec)
    
    rockspec_content = f"""
package = "kong-plugin-{plugin_name}"
version = "{version}"

source = {{
   type = "builtin",
}}

description = {{
   summary = "Custom Kong plugin: {plugin_name}",
}}

dependencies = {{
   {dependencies_str}
}}

build = {{
   type = "builtin",
   modules = {{
      ["kong.plugins.{plugin_name}.handler"] = "handler.lua",
      ["kong.plugins.{plugin_name}.schema"] = "schema.lua",
   }}
}}
"""
    try:
        with open(rockspec_path, "w", encoding="utf-8") as f:
            f.write(rockspec_content)
        logging.info(f"Successfully generated rockspec file: {rockspec_path}")
        return True
    except Exception as e:
        logging.error(f"Failed to write rockspec file: {e}")
        return False

def deploy_and_install_on_remote(ssh_target: str, plugin_name: str, ssh_key: Path, version="0.1.0-1") -> bool:
    """Copies plugin source to remote, packs it, and installs it."""
    logging.info(f"--- Step (Rock): Packaging and Installing '{plugin_name}' on Remote Host ---")
    local_plugin_dir = PLUGINS_DIR / plugin_name
    remote_tmp_dir = f"/tmp/{plugin_name}-src"
    rockspec_file = f"{plugin_name}-{version}.rockspec"
    rock_filename = f"kong-plugin-{plugin_name}-{version}.src.rock"

    # 1. Copy the entire plugin source directory to a temp location on the remote server
    if not run_remote_command(ssh_target, f"rm -rf {remote_tmp_dir} && mkdir -p {remote_tmp_dir}", ssh_key):
        logging.error(f"Failed to create remote temporary directory: {remote_tmp_dir}")
        return False
    if not copy_to_remote(ssh_target, local_plugin_dir, f"/tmp/", recursive=True, ssh_key=ssh_key):
        logging.error("Failed to copy plugin source to remote server.")
        return False
    
    # 2. Run 'luarocks pack' on the remote server
    pack_cmd = f"cd {remote_tmp_dir} && luarocks pack {rockspec_file}"
    if not run_remote_command(ssh_target, pack_cmd, ssh_key):
        logging.error("Failed to package rock on remote server.")
        return False

    # 3. Install the newly created rock file on the remote server
    install_cmd = f"cd {remote_tmp_dir} && sudo luarocks install {rock_filename}"
    if not run_remote_command(ssh_target, install_cmd, ssh_key):
        logging.error("Failed to install rock on remote server.")
        return False

    # 4. Clean up the temporary source directory
    run_remote_command(ssh_target, f"rm -rf {remote_tmp_dir}", ssh_key)
    logging.info("Successfully installed plugin on remote server.")
    return True

def sync_plugin_to_remote(ssh_target: str, plugin_name: str, remote_plugins_root: str, ssh_key: Path) -> bool:
    """Copies the plugin source directory to the remote server, creating the required Kong structure."""
    logging.info(f"--- Step (Sync): Syncing plugin '{plugin_name}' files to remote host ---")
    local_plugin_dir = PLUGINS_DIR / plugin_name
    # Per Kong docs, structure should be <path-in-lua-package-path>/kong/plugins/<plugin-name>
    remote_plugin_dir = f"{remote_plugins_root}/kong/plugins/{plugin_name}"

    logging.info(f"Ensuring remote directory exists and has correct permissions: {remote_plugin_dir}")
    # Create the directory and give ownership to the SSH user to allow SCP to write files.
    # This assumes the user has sudo privileges.
    permission_cmd = f"sudo mkdir -p {remote_plugin_dir} && sudo chown -R $(whoami) {remote_plugins_root}"
    if not run_remote_command(ssh_target, permission_cmd, ssh_key):
        logging.error(f"Failed to create remote directory or set permissions: {remote_plugin_dir}")
        return False

    logging.info(f"Copying plugin files to {ssh_target}:{remote_plugin_dir}")
    # Copy each file from the local plugin directory to the remote directory.
    files_to_copy = [f for f in local_plugin_dir.iterdir() if f.is_file()]
    if not files_to_copy:
        logging.warning(f"No files found in local plugin directory {local_plugin_dir} to sync.")
        return True  # Not a failure, just nothing to do.

    for local_file in files_to_copy:
        if not copy_to_remote(ssh_target, local_file, remote_plugin_dir + "/", ssh_key=ssh_key):
            logging.error(f"Failed to copy {local_file.name} to remote server.")
            return False
    
    logging.info("Plugin files synced successfully.")
    return True

def enable_plugin_in_kong(ssh_target: str, plugin_name: str, ssh_key: Path) -> bool:
    """Enables the plugin in the remote kong.conf."""
    logging.info(f"--- Step: Enabling '{plugin_name}' in Kong Configuration ---")
    check_cmd = f"grep -q 'plugins.*{plugin_name}' {KONG_CONF_PATH_REMOTE}"
    
    logging.info("Checking if plugin is already enabled...")
    if run_remote_command(ssh_target, check_cmd, ssh_key):
        logging.info(f"Plugin '{plugin_name}' is already enabled in {KONG_CONF_PATH_REMOTE}.")
        return True

    logging.info("Plugin not found in config, attempting to add it.")
    
    add_cmd = (
        f"sudo sed -i.bak "
        f"\"s|^[[:space:]]*plugins[[:space:]]*=[[:space:]]*[a-zA-Z0-9_, ]*|&,{plugin_name}|g\" "
        f"{KONG_CONF_PATH_REMOTE}"
    )

    if not run_remote_command(ssh_target, add_cmd, ssh_key):
        logging.error("Failed to enable plugin using `sed`. Check remote permissions and config file.")
        logging.error(f"A backup of the config was attempted at {KONG_CONF_PATH_REMOTE}.bak")
        return False
        
    logging.info(f"Successfully enabled plugin '{plugin_name}' in {KONG_CONF_PATH_REMOTE}.")
    return True

def restart_kong(ssh_target: str, kong_admin_url: str, ssh_key: Path) -> bool:
    """Restarts Kong on the remote server and checks its health."""
    logging.info("--- Step: Restarting Kong on remote server ---")
    
    # Prefer systemd for restarting services as it's more robust.
    systemd_cmd = "sudo systemctl restart kong"
    if not run_remote_command(ssh_target, systemd_cmd, ssh_key):
        logging.warning("Failed to execute 'systemctl restart kong'. Trying 'kong restart' as a fallback.")
        fallback_cmd = "sudo kong restart"
        if not run_remote_command(ssh_target, fallback_cmd, ssh_key):
            logging.error("Failed to execute both 'systemctl restart' and 'kong restart'.")
            logging.error("Please check remote logs. Try `sudo journalctl -u kong` or `sudo kong health`.")
            return False
    
    logging.info("Kong restart command issued. Waiting for it to become healthy.")
    
    # Pass ssh_target to the health check waiter
    if not wait_for_kong_healthy(ssh_target, kong_admin_url, ssh_key):
        logging.error("Kong failed to become healthy after restart.")
        logging.error("Please check remote logs for errors. Try `sudo journalctl -u kong` or `sudo tail -f /usr/local/kong/logs/error.log`.")
        return False
    
    logging.info("Kong restarted successfully and is healthy.")
    return True

# --- Main Orchestrator ---

def handle_deploy_command(args):
    """The logic for the 'deploy' command."""
    logging.info(f"Starting deployment process for plugin: {args.plugin_name} using '{args.method}' method.")

    if not _verify_ssh_key_exists(Path(args.ssh_key)):
        sys.exit(1)

    if not verify_plugin(args.plugin_name):
        logging.error("Deployment aborted due to plugin verification failure.")
        sys.exit(1)

    if args.method == 'rock':
        if not generate_rockspec(args.plugin_name):
            logging.error("Deployment aborted due to rockspec generation failure.")
            sys.exit(1)

        if not deploy_and_install_on_remote(args.ssh_target, args.plugin_name, ssh_key=args.ssh_key):
            logging.error("Deployment aborted due to remote installation failure.")
            sys.exit(1)
    elif args.method == 'sync':
        if not sync_plugin_to_remote(args.ssh_target, args.plugin_name, args.remote_plugins_root, ssh_key=args.ssh_key):
             logging.error("Deployment aborted due to remote sync failure.")
             sys.exit(1)

    if not enable_plugin_in_kong(args.ssh_target, args.plugin_name, ssh_key=Path(args.ssh_key)):
        logging.error("Deployment aborted due to configuration failure.")
        sys.exit(1)

    if not restart_kong(args.ssh_target, args.kong_admin_url, ssh_key=Path(args.ssh_key)):
        logging.error("Deployment finished, but Kong is unhealthy. Please investigate the remote server.")
        sys.exit(1)

    logging.info(f"Successfully deployed and enabled plugin '{args.plugin_name}'.")
    print(f"\n✅ Plugin '{args.plugin_name}' deployed successfully to {args.ssh_target}.")

def remove_plugin_from_kong(ssh_target: str, plugin_name: str, ssh_key: Path) -> bool:
    """Removes the plugin from the 'plugins' list in the remote kong.conf."""
    logging.info(f"--- Step: Disabling '{plugin_name}' in Kong Configuration ---")
    
    # This multi-step sed command is more robust than a single regex.
    # 1. Remove 'plugin_name,' (handles 'plugin_name,other')
    # 2. Remove ',plugin_name' (handles 'other,plugin_name')
    # 3. Remove 'plugin_name' (handles the case where it's the only plugin)
    # This ensures the 'plugins =' line remains valid.
    disable_cmd = (
        f"sudo sed -i.bak "
        f"-e 's/{plugin_name},//' "
        f"-e 's/,{plugin_name}//' "
        f"-e 's/\\b{plugin_name}\\b//' "
        f"{KONG_CONF_PATH_REMOTE}"
    )

    if not run_remote_command(ssh_target, disable_cmd, ssh_key=ssh_key):
        logging.error(f"Failed to disable plugin '{plugin_name}' using sed. A backup may be at {KONG_CONF_PATH_REMOTE}.bak")
        return False
    
    logging.info(f"Successfully disabled plugin '{plugin_name}' in remote configuration.")
    return True

def uninstall_rock_on_remote(ssh_target: str, plugin_name: str, ssh_key: Path) -> bool:
    """Uninstalls the plugin's rock file from the remote server."""
    logging.info(f"--- Step: Uninstalling '{plugin_name}' rock from remote host ---")
    # The package name follows the convention "kong-plugin-<plugin_name>"
    package_name = f"kong-plugin-{plugin_name}"
    uninstall_cmd = f"sudo luarocks remove {package_name}"

    if not run_remote_command(ssh_target, uninstall_cmd, ssh_key):
        logging.error(f"Failed to uninstall rock '{package_name}'. It might not be installed.")
        # We return True here because the goal is for the plugin to be gone.
        # If it's already not there, that's a success state for the rollback.
        return True
        
    logging.info(f"Successfully uninstalled rock '{package_name}' from remote server.")
    return True

def handle_rollback_command(args):
    """The logic for the 'rollback' command."""
    logging.info(f"Starting rollback process for plugin: {args.plugin_name}")

    if not _verify_ssh_key_exists(Path(args.ssh_key)):
        sys.exit(1)

    if not remove_plugin_from_kong(args.ssh_target, args.plugin_name, ssh_key=Path(args.ssh_key)): sys.exit(1)
    if not uninstall_rock_on_remote(args.ssh_target, args.plugin_name, ssh_key=Path(args.ssh_key)): sys.exit(1)
    if not restart_kong(args.ssh_target, args.kong_admin_url, ssh_key=Path(args.ssh_key)): sys.exit(1)

    logging.info(f"Successfully rolled back and uninstalled plugin '{args.plugin_name}'.")
    print(f"\n✅ Plugin '{args.plugin_name}' was successfully rolled back from {args.ssh_target}.")

def handle_exec_command(args):
    """The logic for the 'exec' command."""
    logging.info(f"Executing remote command on {args.ssh_target}: '{args.command}'")

    if not _verify_ssh_key_exists(Path(args.ssh_key)):
        sys.exit(1)

    if not run_remote_command(args.ssh_target, args.command, ssh_key=Path(args.ssh_key)):
        logging.error("Remote command execution failed.")
        sys.exit(1)
    logging.info("Remote command executed successfully.")

def handle_doctor_command(args):
    """Runs a series of checks to diagnose the deployment environment."""
    logging.info("--- Running Diagnostic Doctor ---")
    all_ok = True

    def check(description, success):
        nonlocal all_ok
        status = "✅ OK" if success else "❌ FAILED"
        logging.info(f"{description:<50} [{status}]")
        if not success:
            all_ok = False

    # 1. Local: Check for plugins directory
    check("Local: 'plugins' directory exists", PLUGINS_DIR.is_dir())

    # 2. Local: Check for SSH key
    key_exists = Path(args.ssh_key).is_file()
    check("Local: SSH key file exists", key_exists)
    if not key_exists:
        logging.error("Cannot perform remote checks without the SSH key.")
        sys.exit(1)

    # 3. Remote: Check SSH connection
    logging.info("--- Checking Remote Server ---")
    ssh_ok = run_remote_command(args.ssh_target, "echo 'Connection successful'", args.ssh_key)
    check(f"Remote: SSH connection to {args.ssh_target}", ssh_ok)

    if not ssh_ok:
        logging.error("SSH connection failed. Please verify the following:")
        logging.error(f"  1. The 'ssh_target' in '{CONFIG_FILE_PATH.name}' is correct.")
        logging.error("  2. The remote server is running and accessible from your network.")
        logging.error("  3. Your SSH key is authorized on the remote server.")
    if ssh_ok:
        # 4. Remote: Check for luarocks
        luarocks_ok = run_remote_command(args.ssh_target, "command -v luarocks", args.ssh_key)
        check("Remote: 'luarocks' command is available", luarocks_ok)

        # 5. Remote: Check Kong health
        kong_healthy = wait_for_kong_healthy(args.ssh_target, args.kong_admin_url, ssh_key=Path(args.ssh_key), retries=1, delay=1)
        check("Remote: Kong instance is healthy", kong_healthy)

    logging.info("--- Doctor Summary ---")
    if all_ok:
        logging.info("✅ All checks passed. Your environment appears to be configured correctly.")
    else:
        logging.error("❌ Some checks failed. Please review the logs above to diagnose the issues.")

def main():
    """Main function to parse arguments and run the appropriate command."""
    parser = argparse.ArgumentParser(description="Deploy and manage custom Kong Lua plugins on a remote server.")
    subparsers = parser.add_subparsers(title="Commands", dest="command_name", help="Available commands", required=False)

    # --- Parent Parser for common arguments ---
    # This avoids repeating the same arguments for every subcommand.
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument("--ssh-target", default=DEFAULT_SSH_TARGET, help=f"The SSH target. Overrides the value in deploy.conf. Default: '{DEFAULT_SSH_TARGET}'.")
    parent_parser.add_argument("--ssh-key", default=DEFAULT_SSH_KEY_PATH, help=f"Path to the SSH private key. Overrides the value in deploy.conf. Default: '{DEFAULT_SSH_KEY_PATH}'.")
    parent_parser.add_argument("--kong-admin-url", default=DEFAULT_KONG_ADMIN_URL, help=f"The Kong Admin API URL. Overrides the value in deploy.conf. Default: '{DEFAULT_KONG_ADMIN_URL}'.")

    # --- Deploy Command ---
    parser_deploy = subparsers.add_parser("deploy", parents=[parent_parser], help="Package and deploy a plugin to the remote server. (Default command)")
    parser_deploy.add_argument("plugin_name", help="The name of the custom plugin directory (e.g., custom_extract_variables).")
    parser_deploy.add_argument("--method", choices=['rock', 'sync'], default='rock', help="Deployment method: 'rock' or 'sync'.")
    parser_deploy.add_argument("--remote-plugins-root", default="/usr/local/share/lua/5.1", help="Remote root for plugins (used with --method=sync).")
    parser_deploy.set_defaults(func=handle_deploy_command)

    # --- Exec Command ---
    # Note: 'exec' doesn't need kong_admin_url, so it doesn't use the full parent.
    exec_parent_parser = argparse.ArgumentParser(add_help=False)
    exec_parent_parser.add_argument("--ssh-target", default=DEFAULT_SSH_TARGET, help=f"The SSH target. Overrides the value in deploy.conf. Default: '{DEFAULT_SSH_TARGET}'.")
    exec_parent_parser.add_argument("--ssh-key", default=DEFAULT_SSH_KEY_PATH, help=f"Path to the SSH private key. Overrides the value in deploy.conf. Default: '{DEFAULT_SSH_KEY_PATH}'.")
    parser_exec = subparsers.add_parser("exec", parents=[exec_parent_parser], help="Execute a shell command on the remote server.")
    parser_exec.add_argument("command", help="The shell command to execute on the remote server.")
    parser_exec.set_defaults(func=handle_exec_command)
    
    # --- Rollback Command ---
    parser_rollback = subparsers.add_parser("rollback", parents=[parent_parser], help="Disable and uninstall a plugin from the remote server.")
    parser_rollback.add_argument("plugin_name", help="The name of the plugin to roll back.")
    parser_rollback.set_defaults(func=handle_rollback_command)

    # --- Doctor Command ---
    parser_doctor = subparsers.add_parser("doctor", parents=[parent_parser], help="Run diagnostic checks on the local and remote environment.")
    parser_doctor.set_defaults(func=handle_doctor_command)

    # If the first argument is not a recognized command, assume the user wants to
    # run the 'deploy' command. This makes 'py deploy.py <plugin-name>' work.
    if len(sys.argv) > 1 and sys.argv[1] not in subparsers.choices:
        sys.argv.insert(1, 'deploy')
    elif len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()