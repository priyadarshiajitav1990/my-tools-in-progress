import argparse
import logging
import sys
import os

# Import the environment manager to ensure venv is active
try:
    from environment_manager import check_venv_active, setup_venv
except ImportError:
    print("Error: environment_manager.py not found. Please ensure it's in the root directory.")
    sys.exit(1)

# Import plugin management modules
from src.core.plugin_manager.plugin_comparator import PluginComparator
from src.core.plugin_manager.plugin_deployer import PluginDeployer
from src.core.plugin_manager.kong_manager import KongManager

# Import conversion module
from src.core.apigee_to_kong_converter.converter import ApigeeToKongConverter


# Ensure running in venv
check_venv_active()

# Setup basic logging (will be enhanced later in 'Error Handling & Logging Enhancements')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("GeminiCLI")

def main():
    parser = argparse.ArgumentParser(
        description="Gemini CLI for Apigee to Kong Migration.",
        formatter_class=argparse.RawTextHelpFormatter
    )

    # Global options
    parser.add_argument(
        '-v', '--verbose', action='store_true',
        help='Enable verbose output for detailed logging.'
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # --- Environment Setup Command ---
    setup_env_parser = subparsers.add_parser(
        'setup-env',
        help='Setup the Python virtual environment and install dependencies.',
        description='This command creates a virtual environment if it does not exist '
                    'and installs all packages listed in requirements.txt. '
                    'It also verifies that all dependencies are compatible.'
    )
    setup_env_parser.set_defaults(func=run_setup_env)

    # --- Plugin Management Command Group ---
    plugin_parser = subparsers.add_parser(
        'plugin',
        help='Manage Kong plugins (compare, deploy, enable).'
    )
    plugin_subparsers = plugin_parser.add_subparsers(dest='plugin_command', help='Plugin management commands')

    # Plugin compare command
    plugin_compare_parser = plugin_subparsers.add_parser(
        'compare',
        help='Compare local custom Lua plugins with remote Kong plugins.'
    )
    plugin_compare_parser.add_argument('--kong-admin-url', required=True, help='Kong Admin API URL.')
    plugin_compare_parser.add_argument('--local-plugins-path', default='./custom_plugins_to_place', help='Path to local custom plugins.')
    plugin_compare_parser.set_defaults(func=run_plugin_compare)

    # Plugin deploy command (single plugin)
    plugin_deploy_parser = plugin_subparsers.add_parser(
        'deploy',
        help='Deploy a single local custom Lua plugin to remote Kong.'
    )
    plugin_deploy_parser.add_argument('plugin_name', help='Name of the plugin to deploy.')
    plugin_deploy_parser.add_argument('plugin_path', help='Path to the local plugin directory.')
    plugin_deploy_parser.add_argument('--kong-admin-url', required=True, help='Kong Admin API URL.')
    plugin_deploy_parser.add_argument('--restart-kong-command', help='Optional: Command to restart Kong (e.g., "sudo systemctl restart kong").')
    plugin_deploy_parser.set_defaults(func=run_plugin_deploy)

    # Plugin load-all command
    plugin_load_all_parser = plugin_subparsers.add_parser(
        'load-all',
        help='Load (deploy and enable) all custom plugins from a local directory to remote Kong.'
    )
    plugin_load_all_parser.add_argument('--kong-admin-url', required=True, help='Kong Admin API URL.')
    plugin_load_all_parser.add_argument('--local-plugins-path', default='./custom_plugins_to_place', help='Path to local custom plugins directory.')
    plugin_load_all_parser.add_argument('--restart-kong-command', help='Optional: Command to restart Kong (e.g., "sudo systemctl restart kong"). Will restart only once if plugins are deployed/updated.')
    plugin_load_all_parser.set_defaults(func=run_plugin_load_all)


    # --- Conversion Command ---
    convert_parser = subparsers.add_parser(
        'convert',
        help='Convert an Apigee proxy bundle to Kong declarative configuration.'
    )
    convert_parser.add_argument('apigee_bundle_path', help='Path to the unzipped Apigee proxy bundle.')
    convert_parser.add_argument('output_kong_config_path', help='Path to save the generated Kong JSON configuration.')
    convert_parser.add_argument('--converted-plugins-output-dir', default='./converted_lua_plugins', help='Directory for converted JS/PY/Java Lua plugins.')
    convert_parser.add_argument('--policy-mapping-file', default='configs/policy-mapping.json', help='Path to the Apigee to Kong policy mapping JSON file.')
    convert_parser.set_defaults(func=run_convert_bundle)

    # --- Workflow Command Group (placeholder for now) ---
    workflow_parser = subparsers.add_parser(
        'workflow',
        help='Manage the end-to-end API migration workflow.'
    )
    workflow_subparsers = workflow_parser.add_subparsers(dest='workflow_command', help='Workflow commands')

    workflow_start_parser = workflow_subparsers.add_parser(
        'start',
        help='Start the API migration workflow.'
    )
    workflow_start_parser.set_defaults(func=run_workflow_start)
    
    workflow_resume_parser = workflow_subparsers.add_parser(
        'resume',
        help='Resume an interrupted API migration workflow.'
    )
    workflow_resume_parser.set_defaults(func=run_workflow_resume)

    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Verbose logging enabled.")

    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()

# --- Command Handler Functions ---
def run_setup_env(args):
    logger.info("Running environment setup...")
    setup_venv()

def run_plugin_compare(args):
    logger.info(f"Comparing plugins with Kong Admin URL: {args.kong_admin_url}")
    comparator = PluginComparator(args.kong_admin_url, args.local_plugins_path)
    comparison_results = comparator.compare_plugins()
    if comparison_results:
        logger.info(f"Plugins to Deploy: {comparison_results.get('to_deploy')}")
        logger.info(f"Plugins to Update: {comparison_results.get('to_update')}")
        logger.info(f"Plugins Unchanged: {comparison_results.get('unchanged')}")
        logger.info(f"Plugins Remote Only: {comparison_results.get('remote_only')}")
    else:
        logger.error("Failed to perform plugin comparison.")


def run_plugin_deploy(args):
    logger.info(f"Deploying plugin '{args.plugin_name}' from '{args.plugin_path}'...")
    deployer = PluginDeployer(args.kong_admin_url)
    kong_manager = KongManager(args.kong_admin_url)

    if not kong_manager.is_kong_running():
        logger.error("Kong is not running. Cannot deploy plugin.")
        return

    success = deployer.deploy_plugin(args.plugin_name, args.plugin_path)
    if success:
        logger.info(f"Plugin '{args.plugin_name}' deployed successfully.")
        
        logger.info(f"Enabling plugin '{args.plugin_name}'...")
        if kong_manager.enable_plugin(args.plugin_name):
            logger.info(f"Plugin '{args.plugin_name}' enabled successfully.")
        else:
            logger.error(f"Failed to enable plugin '{args.plugin_name}'.")
            return False # Indicate failure

        if args.restart_kong_command:
            logger.info(f"Restarting Kong with command: '{args.restart_kong_command}'...")
            if kong_manager.restart_kong(args.restart_kong_command):
                logger.info("Kong restarted successfully.")
                if kong_manager.verify_plugin_enabled(args.plugin_name):
                    logger.info(f"Plugin '{args.plugin_name}' verified as enabled after restart.")
                else:
                    logger.error(f"Plugin '{args.plugin_name}' could not be verified after restart.")
            else:
                logger.error("Kong restart failed or Kong did not come back online.")
        else:
            logger.warning("No Kong restart command provided. Manual restart may be required for plugin to take effect.")
        return True # Indicate success
    else:
        logger.error(f"Failed to deploy plugin '{args.plugin_name}'.")
        return False # Indicate failure

def run_plugin_load_all(args):
    logger.info(f"Loading all custom plugins from '{args.local_plugins_path}'...")
    deployer = PluginDeployer(args.kong_admin_url)
    comparator = PluginComparator(args.kong_admin_url, args.local_plugins_path)
    kong_manager = KongManager(args.kong_admin_url)

    if not kong_manager.is_kong_running():
        logger.error("Kong is not running. Cannot load plugins.")
        return

    comparison_results = comparator.compare_plugins()
    if not comparison_results:
        logger.error("Failed to compare plugins. Aborting load-all operation.")
        return

    plugins_to_process = comparison_results.get('to_deploy', []) + comparison_results.get('to_update', [])
    if not plugins_to_process:
        logger.info("No new or updated plugins found to load.")
        return

    restart_needed = False
    for plugin_name in plugins_to_process:
        plugin_path = os.path.join(args.local_plugins_path, plugin_name)
        logger.info(f"Processing plugin: '{plugin_name}' from '{plugin_path}'")
        
        if deployer.deploy_plugin(plugin_name, plugin_path):
            logger.info(f"Plugin '{plugin_name}' deployed successfully. Attempting to enable.")
            if kong_manager.enable_plugin(plugin_name):
                logger.info(f"Plugin '{plugin_name}' enabled.")
                restart_needed = True # Mark that at least one plugin was deployed/updated/enabled
            else:
                logger.error(f"Failed to enable plugin '{plugin_name}'.")
        else:
            logger.error(f"Failed to deploy plugin '{plugin_name}'. Skipping enablement.")
    
    if restart_needed and args.restart_kong_command:
        logger.info("One or more plugins were deployed/updated. Restarting Kong...")
        if kong_manager.restart_kong(args.restart_kong_command):
            logger.info("Kong restarted successfully after loading all plugins.")
            # Verify all processed plugins
            all_verified = True
            for plugin_name in plugins_to_process:
                if not kong_manager.verify_plugin_enabled(plugin_name):
                    all_verified = False
                    logger.error(f"Verification failed for plugin '{plugin_name}' after full load and restart.")
            if all_verified:
                logger.info("All processed plugins verified as enabled after restart.")
            else:
                logger.error("Some plugins failed verification after full load and restart.")
        else:
            logger.error("Kong restart failed or Kong did not come back online after loading all plugins.")
    elif restart_needed and not args.restart_kong_command:
        logger.warning("No Kong restart command provided, but plugins were updated. Manual restart recommended.")
    else:
        logger.info("No plugins required deployment or update, or no restart command provided.")


def run_convert_bundle(args):
    logger.info(f"Converting Apigee bundle from '{args.apigee_bundle_path}'...")
    converter = ApigeeToKongConverter(policy_mapping_file=args.policy_mapping_file)
    success = converter.convert_bundle(args.apigee_bundle_path, args.output_kong_config_path, args.converted_plugins_output_dir)
    if success:
        logger.info(f"Apigee bundle converted successfully to '{args.output_kong_config_path}'.")
    else:
        logger.error("Apigee bundle conversion failed.")

def run_workflow_start(args):
    logger.info("Starting API migration workflow...")
    # Placeholder for Workflow Orchestrator
    pass

def run_workflow_resume(args):
    logger.info("Resuming API migration workflow...")
    # Placeholder for Workflow Orchestrator
    pass


if __name__ == '__main__':
    main()
