
# Patch sys.path for direct execution
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
sys.path.insert(0, os.path.join(os.path.abspath(os.path.dirname(__file__)), 'core'))

import logging
import argparse
import asyncio
import json
import zipfile
import yaml

from core.logger import setup_logging
# Import the new CLI and Web Server modules
from cli import apg2kong_cli # Explicitly import the CLI module
import web_server

def generate_custom_plugins_if_missing():
    """
    Checks for the existence of custom Kong plugin files and logs warnings if missing.
    For now, this only checks existence and does not auto-generate.
    """
    logger = logging.getLogger()
    policy_mapping_path = os.path.join(os.path.dirname(__file__), 'configs', 'policy-to-plugin.json')
    kong_plugins_dir = os.path.join(os.path.dirname(__file__), 'kong_plugins')

    try:
        with open(policy_mapping_path, 'r') as f:
            policy_mapping = json.load(f)
    except FileNotFoundError:
        logger.error(f"Policy mapping file not found: {policy_mapping_path}")
        return
    except json.JSONDecodeError as e:
        logger.error(f"Error decoding policy mapping file {policy_mapping_path}: {e}")
        return

    for apigee_policy, kong_plugins in policy_mapping.items():
        for plugin_name in kong_plugins:
            if plugin_name.startswith("kong-"):
                plugin_path = os.path.join(kong_plugins_dir, plugin_name)
                
                # List of required Lua files for a custom plugin
                required_lua_files = ["handler.lua", "schema.lua", "access.lua", "logger.lua"]
                
                for lua_file in required_lua_files:
                    file_path = os.path.join(plugin_path, lua_file)
                    if not os.path.exists(file_path):
                        logger.warning(f"Custom Kong plugin '{plugin_name}' is missing '{lua_file}'. "
                                       f"Please ensure '{plugin_path}' contains all necessary Lua files "
                                       f"for the '{apigee_policy}' policy to function correctly.")
    logger.info("Custom Kong plugin file check completed.")


def unzip_apigee_proxy(zip_file_path: str, output_dir: str):
    """
    Unzips an Apigee proxy bundle into the specified output directory.
    """
    if not os.path.exists(zip_file_path):
        abs_path = os.path.abspath(zip_file_path)
        logging.error(f"Input ZIP file not found at the specified path: {abs_path}")
        raise FileNotFoundError(f"No such file or directory: '{zip_file_path}'")

    if not zipfile.is_zipfile(zip_file_path):
        logging.error(f"Error: '{zip_file_path}' is not a valid ZIP file.")
        raise zipfile.BadZipFile(f"Error: '{zip_file_path}' is not a valid ZIP file.")

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            zip_ref.extractall(output_dir)
        logging.info(f"Successfully unzipped '{zip_file_path}' to '{output_dir}'.")
    except Exception as e:
        logging.error(f"An unexpected error occurred while unzipping: {e}")
        raise

def find_script_files(directory: str) -> dict:
    """
    Recursively searches the given directory for .js, .jar, and .py files.
    Returns a dictionary with lists of file paths for each extension.
    """
    script_files = {
        "js": [],
        "jar": [],
        "py": []
    }
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".js"):
                script_files["js"].append(os.path.join(root, file))
            elif file.endswith(".jar"):
                script_files["jar"].append(os.path.join(root, file))
            elif file.endswith(".py"):
                script_files["py"].append(os.path.join(root, file))
    return script_files

async def migrate_workflow(input_zip_path: str, ssh_target: str, ssh_key_path: str, kong_admin_url: str):
    """
    Orchestrates the full Apigee to Kong migration workflow.
    """
    logging.info(f"Starting migration workflow for: {input_zip_path}")

    # Step 1: Unzip the Apigee proxy zip
    apigee_api_dir = os.path.join(os.path.dirname(__file__), 'apigee_api')
    try:
        unzip_apigee_proxy(input_zip_path, apigee_api_dir)
    except Exception as e:
        logging.error(f"Failed to unzip Apigee proxy: {e}")
        return

    # Step 2: Search for custom script files
    logging.info(f"Searching for custom script files in '{apigee_api_dir}'...")
    script_files = find_script_files(apigee_api_dir)
    logging.info(f"Found JS files: {script_files['js']}")
    logging.info(f"Found JAR files: {script_files['jar']}")
    logging.info(f"Found PY files: {script_files['py']}")

    # Step 3: Transpile custom script files to Lua plugins
    custom_plugins_dir = os.path.join(os.path.dirname(__file__), 'custom_plugins')
    if script_files["js"]:
        logging.info(f"Transpiling JS files to Lua plugins. Output directory: {custom_plugins_dir}")
        await transpile_js_to_lua(script_files["js"], custom_plugins_dir)
    if script_files["jar"]:
        logging.info(f"Transpiling JAR files to Lua plugins. Output directory: {custom_plugins_dir}")
        await transpile_jar_to_lua(script_files["jar"], custom_plugins_dir)
    if script_files["py"]:
        logging.info(f"Transpiling Python files to Lua plugins. Output directory: {custom_plugins_dir}")
        await transpile_py_to_lua(script_files["py"], custom_plugins_dir)

    # Step 4: Deploy custom Lua plugins to Kong Gateway
    logging.info("Deploying custom Lua plugins...")
    
    if os.path.exists(custom_plugins_dir):
        for plugin_dir_name in os.listdir(custom_plugins_dir):
            plugin_path = os.path.join(custom_plugins_dir, plugin_dir_name)
            if os.path.isdir(plugin_path):
                if not await deploy_custom_lua_plugin(plugin_dir_name, ssh_target, ssh_key_path, kong_admin_url):
                    logging.error(f"Migration aborted due to failure in deploying plugin '{plugin_dir_name}'.")
                    return
    else:
        logging.info("No custom plugins directory found to deploy.")

    # Step 5: Use appropriate mappers (Apigee to Kong) to create Kong API configuration.
    logging.info("Generating Kong API configuration...")

    # Load policy-to-plugin mapping
    policy_to_plugin_path = os.path.join(os.path.dirname(__file__), 'configs', 'policy-to-plugin.json')
    try:
        with open(policy_to_plugin_path, 'r') as f:
            policy_to_plugin_map = json.load(f)
    except FileNotFoundError:
        logging.error(f"Policy mapping file not found: {policy_to_plugin_path}")
        return
    except json.JSONDecodeError as e:
        logging.error(f"Error decoding policy mapping file {policy_to_plugin_path}: {e}")
        return

    try:
        from core.apigee_bundle_parser import ApigeeBundleParser
        from core.kong_config_generator import KongConfigGenerator

        # Assuming the Apigee API bundle is structured such that the API name can be derived
        # For now, let's assume the API name is the directory name within apigee_api_dir
        apigee_api_name = os.path.basename(os.listdir(apigee_api_dir)[0]) if os.listdir(apigee_api_dir) else "default-api-name"
        
        logger = logging.getLogger()
        apigee_parser = ApigeeBundleParser(apigee_api_dir, logger)
        apigee_data = await apigee_parser.parse()
        
        kong_generator = KongConfigGenerator(logger)
        kong_config_yaml = await kong_generator.generate(apigee_data, apigee_api_name)
        
        logging.info("Successfully generated Kong API configuration in dictionary format.")

        # Step 6: Generate Kong API Configuration YAML under output/
        output_dir = os.path.join(os.path.dirname(__file__), 'output')
        os.makedirs(output_dir, exist_ok=True)
        
        if not os.access(output_dir, os.W_OK):
            logging.error(f"Output directory '{output_dir}' is not writable.")
            return
        
        output_yaml_path = os.path.join(output_dir, f"{apigee_api_name}_kong_config.yaml")
        
        # Use a YAML library to dump the config
        kong_config_dict = yaml.safe_load(kong_config_yaml)

        try:
            with open(output_yaml_path, 'w') as f:
                yaml.dump(kong_config_dict, f, default_flow_style=False, sort_keys=False)
            logging.info(f"Successfully wrote Kong API configuration to {output_yaml_path}")
        except Exception as e:
            logging.error(f"Error writing Kong API configuration YAML to file: {e}")
            return

        # Print summary of unmapped policies
        if kong_generator.unmapped_policies_summary:
            logging.warning("\n--- Summary of Unmapped Apigee Policies (Functionality May Be Lost) ---")
            for item in kong_generator.unmapped_policies_summary:
                logging.warning(f"  - Policy Name: {item['policy_name']}, Type: {item['policy_type']}, Status: {item['status']}, Message: {item['message']}")
            logging.warning("----------------------------------------------------------------------")
        
    except Exception as e:
        logging.error(f"Error generating Kong API configuration: {e}")
        return

    # Step 7: Validate against the remote Kong using the deck gateway command
    logging.info("Validating generated Kong configuration...")
    if not await validate_kong_config(output_yaml_path, kong_admin_url):
        logging.error("Kong configuration validation failed. Aborting migration.")
        return

    # Step 8: Deploy using deck gateway command
    logging.info("Deploying generated Kong configuration...")
    if not await deploy_kong_config(output_yaml_path, kong_admin_url):
        logging.error("Kong configuration deployment failed. Aborting migration.")
        return

    logging.info("Migration workflow completed successfully.")    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    jstolua_tool_path = os.path.join(os.path.dirname(__file__), 'tools', 'jstolua_tool.py')

    for js_file in js_files:
        try:
            js_file_name = os.path.basename(js_file)
            plugin_name = os.path.splitext(js_file_name)[0]
            plugin_output_dir = os.path.join(output_dir, plugin_name)

            command = [
                sys.executable,  # Use the Python interpreter that's running main.py
                jstolua_tool_path,
                js_file,
                output_dir,
                plugin_name
            ]
            
            logging.info(f"Running command: {' '.join(command)}")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logging.info(f"Successfully transpiled {js_file} to Lua plugin.")
            else:
                logging.error(f"Failed to transpile {js_file}. Stderr: {stderr.decode().strip()}")
        except Exception as e:
            logging.error(f"Error transpiling JS file {js_file}: {e}")


async def transpile_jar_to_lua(jar_files: list, output_dir: str):
    """
    Transpiles JAR files to Lua plugins using jartolua_tool.py.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    jartolua_tool_path = os.path.join(os.path.dirname(__file__), 'tools', 'jartolua_tool.py')

    for jar_file in jar_files:
        try:
            jar_file_name = os.path.basename(jar_file)
            plugin_name = os.path.splitext(jar_file_name)[0]
            plugin_output_dir = os.path.join(output_dir, plugin_name)

            command = [
                sys.executable,  # Use the Python interpreter that's running main.py
                jartolua_tool_path,
                jar_file,
                output_dir,
                plugin_name
            ]
            
            logging.info(f"Running command: {' '.join(command)}")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logging.info(f"Successfully transpiled {jar_file} to Lua plugin.")
            else:
                logging.error(f"Failed to transpile {jar_file}. Stderr: {stderr.decode().strip()}")
        except Exception as e:
            logging.error(f"Error transpiling JAR file {jar_file}: {e}")

async def transpile_py_to_lua(py_files: list, output_dir: str):
    """
    Transpiles Python files to Lua plugins using pytolua_tool.py.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    pytolua_tool_path = os.path.join(os.path.dirname(__file__), 'tools', 'pytolua_tool.py')

    for py_file in py_files:
        try:
            py_file_name = os.path.basename(py_file)
            plugin_name = os.path.splitext(py_file_name)[0]
            plugin_output_dir = os.path.join(output_dir, plugin_name)

            command = [
                sys.executable,  # Use the Python interpreter that's running main.py
                pytolua_tool_path,
                py_file,
                output_dir,
                plugin_name
            ]
            
            logging.info(f"Running command: {' '.join(command)}")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logging.info(f"Successfully transpiled {py_file} to Lua plugin.")
            else:
                logging.error(f"Failed to transpile {py_file}. Stderr: {stderr.decode().strip()}")
        except Exception as e:
            logging.error(f"Error transpiling Python file {py_file}: {e}")

async def deploy_custom_lua_plugin(plugin_name: str, ssh_target: str, ssh_key_path: str, kong_admin_url: str):
    """
    Deploys a custom Lua plugin to the remote Kong Gateway using configs/deploy.py.
    """
    deploy_script_path = os.path.join(os.path.dirname(__file__), 'configs', 'deploy.py')
    
    # Assuming plugin_name is the directory name within custom_plugins
    # and the deploy script expects just the name.
    
    command = [
        sys.executable,
        deploy_script_path,
        "deploy",
        plugin_name,
        "--method", "rock",  # Using the rock method for deployment
        "--ssh-target", ssh_target,
        "--ssh-key", ssh_key_path,
        "--kong-admin-url", kong_admin_url
    ]
    
    logging.info(f"Running deployment command for plugin '{plugin_name}': {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0:
        logging.info(f"Successfully deployed custom Lua plugin '{plugin_name}'.")
        return True
    else:
        logging.error(f"Failed to deploy custom Lua plugin '{plugin_name}'.")
        logging.error(f"Stdout: {stdout.decode().strip()}")
        logging.error(f"Stderr: {stderr.decode().strip()}")
        return False

    # Step 8: Deploy using deck gateway command
    logging.info("Deploying generated Kong configuration...")
    if not await deploy_kong_config(output_yaml_path, kong_admin_url):
        logging.error("Kong configuration deployment failed. Aborting migration.")
        return

    logging.info("Migration workflow completed successfully.")


async def transpile_jar_to_lua(jar_files: list, output_dir: str):
    """
    Transpiles JAR files to Lua plugins using jartolua_tool.py.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    jartolua_tool_path = os.path.join(os.path.dirname(__file__), 'tools', 'jartolua_tool.py')

    for jar_file in jar_files:
        try:
            jar_file_name = os.path.basename(jar_file)
            plugin_name = os.path.splitext(jar_file_name)[0]
            plugin_output_dir = os.path.join(output_dir, plugin_name)

            command = [
                sys.executable,  # Use the Python interpreter that's running main.py
                jartolua_tool_path,
                jar_file,
                output_dir,
                plugin_name
            ]
            
            logging.info(f"Running command: {' '.join(command)}")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logging.info(f"Successfully transpiled {jar_file} to Lua plugin.")
            else:
                logging.error(f"Failed to transpile {jar_file}. Stderr: {stderr.decode().strip()}")
        except Exception as e:
            logging.error(f"Error transpiling JAR file {jar_file}: {e}")

async def transpile_py_to_lua(py_files: list, output_dir: str):
    """
    Transpiles Python files to Lua plugins using pytolua_tool.py.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    pytolua_tool_path = os.path.join(os.path.dirname(__file__), 'tools', 'pytolua_tool.py')

    for py_file in py_files:
        try:
            py_file_name = os.path.basename(py_file)
            plugin_name = os.path.splitext(py_file_name)[0]
            plugin_output_dir = os.path.join(output_dir, plugin_name)

            command = [
                sys.executable,  # Use the Python interpreter that's running main.py
                pytolua_tool_path,
                py_file,
                output_dir,
                plugin_name
            ]
            
            logging.info(f"Running command: {' '.join(command)}")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logging.info(f"Successfully transpiled {py_file} to Lua plugin.")
            else:
                logging.error(f"Failed to transpile {py_file}. Stderr: {stderr.decode().strip()}")
        except Exception as e:
            logging.error(f"Error transpiling Python file {py_file}: {e}")

async def deploy_custom_lua_plugin(plugin_name: str, ssh_target: str, ssh_key_path: str, kong_admin_url: str):
    """
    Deploys a custom Lua plugin to the remote Kong Gateway using configs/deploy.py.
    """
    deploy_script_path = os.path.join(os.path.dirname(__file__), 'configs', 'deploy.py')
    
    # Assuming plugin_name is the directory name within custom_plugins
    # and the deploy script expects just the name.
    
    command = [
        sys.executable,
        deploy_script_path,
        "deploy",
        plugin_name,
        "--method", "rock",  # Using the rock method for deployment
        "--ssh-target", ssh_target,
        "--ssh-key", ssh_key_path,
        "--kong-admin-url", kong_admin_url
    ]
    
    logging.info(f"Running deployment command for plugin '{plugin_name}': {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0:
        logging.info(f"Successfully deployed custom Lua plugin '{plugin_name}'.")
        return True
    else:
        logging.error(f"Failed to deploy custom Lua plugin '{plugin_name}'.")
        logging.error(f"Stdout: {stdout.decode().strip()}")
        logging.error(f"Stderr: {stderr.decode().strip()}")
        return False

    # Step 8: Deploy using deck gateway command
    logging.info("Deploying generated Kong configuration...")
    if not await deploy_kong_config(output_yaml_path, kong_admin_url):
        logging.error("Kong configuration deployment failed. Aborting migration.")
        return

    logging.info("Migration workflow completed successfully.")









async def validate_kong_config(kong_config_path: str, kong_admin_url: str) -> bool:
    """
    Validates the generated Kong configuration YAML against a remote Kong instance using 'deck gateway validate'.
    """
    command = [
        "deck", "validate",
        "-s", kong_config_path
    ]
    
    logging.info(f"Running Kong configuration validation: {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0:
        logging.info(f"Kong configuration validation successful for {kong_config_path}.")
        return True
    else:
        logging.error(f"Kong configuration validation failed for {kong_config_path}.")
        logging.error(f"Stdout: {stdout.decode().strip()}")
        logging.error(f"Stderr: {stderr.decode().strip()}")
        return False

async def deploy_kong_config(kong_config_path: str, kong_admin_url: str) -> bool:
    """
    Deploys the generated Kong configuration YAML to a remote Kong instance using 'deck gateway deploy'.
    """
    command = [
        "deck", "gateway", "deploy",
        "--kong-addr", kong_admin_url,
        "--state", kong_config_path
    ]
    
    logging.info(f"Running Kong configuration deployment: {' '.join(command)}")
    process = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode == 0:
        logging.info(f"Kong configuration deployed successfully from {kong_config_path}.")
        return True
    else:
        logging.error(f"Kong configuration deployment failed from {kong_config_path}.")
        logging.error(f"Stdout: {stdout.decode().strip()}")
        logging.error(f"Stderr: {stderr.decode().strip()}")
        return False

async def main():
    """
    Main entry point for the Apigee to Kong migration application.
    Dispatches to either CLI or Web server mode.
    """
    # Patch logging config for CLI: remove correlation_id if not present
    import logging.config
    import yaml
    log_cfg_path = os.path.join(os.path.dirname(__file__), 'logging.yml')
    if os.path.exists(log_cfg_path):
        with open(log_cfg_path, 'rt') as f:
            config = yaml.safe_load(f.read())
            # Patch all formatters to remove correlation_id for CLI
            for fmt_key, fmt_val in config.get('formatters', {}).items():
                fmt = fmt_val.get('format', '')
                if '%(correlation_id)s' in fmt:
                    config['formatters'][fmt_key]['format'] = fmt.replace('%(correlation_id)s', '%(name)s')
            logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=logging.INFO)
    logging.info("apg2kong migration engine started.")

    # Check and warn about missing custom plugin files
    generate_custom_plugins_if_missing()


    parser = argparse.ArgumentParser(description="Apigee to Kong Migration Tool", add_help=False)
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Web server command
    web_parser = subparsers.add_parser("web", help="Start the web server.")

    # CLI conversion command
    cli_parser = subparsers.add_parser("cli", help="Run in CLI mode to convert an Apigee bundle.")
    cli_parser.add_argument("-i", "--input", required=True, help="Path to the Apigee proxy bundle ZIP file.")
    cli_parser.add_argument("-o", "--output", required=True, help="Path to the output directory for Kong configuration.")

    # Full migration command
    migrate_parser = subparsers.add_parser("migrate", help="Run the full Apigee to Kong migration workflow.")
    migrate_parser.add_argument("-i", "--input_zip", required=True, help="Path to the Apigee proxy bundle ZIP file.")
    migrate_parser.add_argument("--ssh-target", default="user@your-kong-server", help="SSH target for deploying custom plugins (e.g., user@your-kong-server).")
    migrate_parser.add_argument("--ssh-key-path", default=os.path.join(os.path.dirname(__file__), 'keys', 'coforge-ssh.pem'), help="Path to the SSH private key for deployment.")
    migrate_parser.add_argument("--kong-admin-url", default="http://localhost:8001", help="Kong Admin API URL (e.g., http://localhost:8001).")

    args = parser.parse_args()

    if args.command == "web":
        logging.info("Starting web server...")
        web_server.start_web_server_sync()
    elif args.command == "cli":
        logging.info("Running in CLI conversion mode...")
        # For CLI mode, we need to manually set sys.argv for the cli_main to parse it correctly
        sys.argv = [sys.argv[0], 'convert', '--input', args.input, '--output', args.output]
        from cli.apg2kong_cli import main as cli_main
        cli_main()
    elif args.command == "migrate":
        logging.info(f"Running full migration workflow for {args.input_zip}...")
        await migrate_workflow(args.input_zip, args.ssh_target, args.ssh_key_path, args.kong_admin_url)
    else:
        parser.print_help()

    logging.info("apg2kong migration engine finished.")





if __name__ == "__main__":
    asyncio.run(main())
