import logging
import os
from typing import List
from apg2kong.services.remote_service import RemoteService


class PluginService:
    """
    Service responsible for managing custom and generated plugins.
    Uses RemoteService for actual file transfer and command execution.
    """

    def __init__(
        self,
        remote_service: RemoteService,
        remote_plugin_path: str,
        restart_command: str,
        logger: logging.Logger = None,
    ):
        self.remote_service = remote_service
        self.remote_plugin_path = remote_plugin_path
        self.restart_command = restart_command
        self.logger = logger or logging.getLogger("apg2kong")

    def sync_plugins(self, local_dirs: List[str]) -> bool:
        """
        Syncs plugins from multiple local directories to the remote server.
        Returns True if any changes were made.
        """
        changes_detected = False

        for local_dir in local_dirs:
            if not os.path.exists(local_dir):
                self.logger.debug(
                    f"Plugin directory {local_dir} does not exist. Skipping."
                )
                continue

            for item in os.listdir(local_dir):
                full_path = os.path.join(local_dir, item)
                if os.path.isfile(full_path):
                    # sync_plugin returns True if file was uploaded
                    if self.remote_service.sync_plugin(
                        full_path, self.remote_plugin_path
                    ):
                        changes_detected = True

        return changes_detected

    def deploy_and_restart(self, force_restart: bool = False):
        """
        Restarts Kong if needed.
        """
        if force_restart:
            self.logger.info("Restarting Kong to apply plugin changes...")
            self.remote_service.restart_kong(self.restart_command)
        else:
            self.logger.info("No plugin changes detected. Skipping Kong restart.")
