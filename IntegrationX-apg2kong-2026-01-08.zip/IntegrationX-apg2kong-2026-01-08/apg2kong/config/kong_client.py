import requests
import logging
import subprocess
import os
from typing import Optional


class KongClient:
    """
    Service for interacting with the Kong Gateway via Admin API and Deck.
    """

    def __init__(self, admin_url: str, logger: logging.Logger = None):
        self.admin_url = admin_url.rstrip("/")
        self.logger = logger or logging.getLogger("apg2kong")

    def is_healthy(self) -> bool:
        """Checks if Kong Admin API is reachable."""
        try:
            response = requests.get(f"{self.admin_url}/status", timeout=5)
            if response.status_code == 200:
                return True
            # Fallback for older Kong versions
            response = requests.get(f"{self.admin_url}/", timeout=5)
            return response.status_code == 200
        except requests.RequestException as e:
            self.logger.warning(f"Kong health check failed: {e}")
            return False

    def validate_config(self, config_path: str) -> bool:
        """
        Validates a declarative configuration file using decK.
        """
        self.logger.info(f"Validating Kong config: {config_path}")
        try:
            # Assuming 'deck' is in PATH
            cmd = ["deck", "gateway", "validate", "--state", config_path]
            result = subprocess.run(cmd, check=False, capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info("Deck validation successful.")
                return True
            else:
                self.logger.error(f"Deck validation failed:\n{result.stderr}")
                return False
        except FileNotFoundError:
            self.logger.error("Deck command not found. Please install decK.")
            return False
        except Exception as e:
            self.logger.error(f"Validation exception: {e}")
            return False

    def deploy_config(self, config_path: str) -> bool:
        """
        Deploys a declarative configuration file using decK (sync).
        """
        self.logger.info(f"Deploying Kong config: {config_path}")
        try:
            # deck gateway sync --state file.yaml --kong-addr ...
            cmd = [
                "deck",
                "gateway",
                "sync",
                "--state",
                config_path,
                "--kong-addr",
                self.admin_url,
                "--no-color",
            ]
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            self.logger.info(f"Deck sync successful:\n{result.stdout}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Deck sync failed:\n{e.stderr}")
            return False
