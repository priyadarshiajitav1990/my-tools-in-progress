import os
import sys
import subprocess
import venv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
VENV_DIR = ROOT_DIR / "venv"
REQUIREMENTS_FILE = ROOT_DIR / "requirements.txt"


def is_venv():
    return hasattr(sys, "real_prefix") or (
        hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix
    )


def create_venv():
    print(f"Creating virtual environment in {VENV_DIR}...")
    venv.create(VENV_DIR, with_pip=True)


def install_requirements():
    print("Installing dependencies from requirements.txt...")
    if sys.platform == "win32":
        pip_executable = VENV_DIR / "Scripts" / "pip"
    else:
        pip_executable = VENV_DIR / "bin" / "pip"

    subprocess.check_call(
        [str(pip_executable), "install", "-r", str(REQUIREMENTS_FILE)]
    )


def run_application():
    # Determine the python executable in the venv
    if sys.platform == "win32":
        python_executable = VENV_DIR / "Scripts" / "python"
    else:
        python_executable = VENV_DIR / "bin" / "python"

    # Ensure src is in PYTHONPATH so we can import apg2kong as a package
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT_DIR / "src") + os.pathsep + env.get("PYTHONPATH", "")

    # Arguments to pass to the main application
    args = [str(python_executable), "-m", "apg2kong.main"] + sys.argv[1:]

    print(f"Starting application in venv: {' '.join(args)}")
    try:
        subprocess.check_call(args, env=env)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)
    except KeyboardInterrupt:
        sys.exit(0)


def main():
    # 1. Check if requirements.txt exists
    if not REQUIREMENTS_FILE.exists():
        print(f"Error: {REQUIREMENTS_FILE} not found.")
        sys.exit(1)

    # 2. Check/Create Venv
    if not VENV_DIR.exists():
        create_venv()
        install_requirements()

    # 3. If we are not in the venv, switch to it by subprocess
    if not is_venv():
        # Check if we need to install requirements (e.g. if venv existed but requirements changed)
        # For production speed, we assume if venv exists, it's good, or we can force update.
        # Here we just run the app using the venv python.
        run_application()
    else:
        # If we are already in venv (e.g. activated manually), just run the main module
        import apg2kong.main

        # Note: main.py usually has an async main, but here we might just import and let it run if it has __main__ block
        # But usually bootstrap runs via subprocess. The else block here is for manual activation.
        # We'll just print a message or try to run it.
        print(
            "Venv is active. Please run via 'python -m apg2kong.main' or use the bootstrap to launch subprocess."
        )
        run_application()


if __name__ == "__main__":
    main()
