import logging
import os
import asyncio
from pathlib import Path
from typing import Optional

from apg2kong.core.tracker import MigrationTracker
from apg2kong.core.converter import ApigeeToKongConverter
from apg2kong.core.kong_client import KongClient
from apg2kong.services.plugin_service import PluginService


class WorkflowEngine:
    def __init__(
        self,
        logger: logging.Logger,
        tracker: MigrationTracker,
        converter: ApigeeToKongConverter,
        kong_client: KongClient,
        plugin_service: PluginService,
        output_dir: str,
        generated_plugins_dir: str,
    ):
        """
        Initializes the WorkflowEngine with injected dependencies.
        This ensures loose coupling and easier testing.
        """
        self.logger = logger
        self.tracker = tracker
        self.converter = converter
        self.kong_client = kong_client
        self.plugin_service = plugin_service
        self.output_dir = output_dir
        self.generated_plugins_dir = generated_plugins_dir

    async def start_workflow(
        self, manifest_file: str, input_zip_file: str, resume: bool = False
    ) -> bool:
        """
        Executes the migration workflow for a single API bundle.
        """
        api_name = Path(input_zip_file).stem
        self.logger.info(f"Initializing workflow for API: {api_name}")

        # 1. Check/Resume State
        if resume and self.tracker.state["current_api"] == api_name:
            self.logger.info(
                f"Resuming {api_name} from step {self.tracker.state['workflow_step']}"
            )
        else:
            self.tracker.start_api(api_name)

        try:
            # 2. Pre-flight Checks
            if self.tracker.state["workflow_step"] == "INIT":
                self.logger.info("Performing pre-flight checks...")
                if not self.kong_client.is_healthy():
                    raise Exception("Kong Admin API is not reachable.")
                self.tracker.update_step("PLUGINS_SYNC")

            # 3. Sync Custom Plugins
            if self.tracker.state["workflow_step"] == "PLUGINS_SYNC":
                self.logger.info("Step: Syncing Plugins")
                # We sync both custom static plugins and any previously generated ones
                # Note: In a real flow, generated plugins might come after conversion.
                # Here we assume we might have some ready or we sync what we have.
                # The PluginService handles the logic of "only restart if changed".
                changes = self.plugin_service.sync_plugins(
                    [
                        self.generated_plugins_dir,
                        # Add other custom plugin dirs if passed via config
                    ]
                )
                self.plugin_service.deploy_and_restart(force_restart=changes)
                self.tracker.update_step("CONVERSION")

            # 4. Conversion (Apigee -> Kong)
            output_config = os.path.join(self.output_dir, f"{api_name}.yaml")
            if self.tracker.state["workflow_step"] == "CONVERSION":
                success = await self.converter.convert_bundle(
                    input_zip_file, output_config, self.generated_plugins_dir
                )
                if not success:
                    raise Exception("Conversion failed.")
                self.tracker.update_step("DECK_VALIDATE")

            # 5. Validation (Deck)
            if self.tracker.state["workflow_step"] == "DECK_VALIDATE":
                if not self.kong_client.validate_config(output_config):
                    raise Exception("Deck validation failed.")
                self.tracker.update_step("DECK_DEPLOY")

            # 6. Deployment
            if self.tracker.state["workflow_step"] == "DECK_DEPLOY":
                if not self.kong_client.deploy_config(output_config):
                    raise Exception("Deck deployment failed.")
                self.tracker.complete_api()
                self.logger.info(f"Migration for {api_name} completed successfully.")
                return True

        except Exception as e:
            self.logger.error(f"Workflow failed for {api_name}: {e}")
            self.tracker.fail_api(str(e))
            return False

        return False
