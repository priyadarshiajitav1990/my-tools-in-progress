import logging
import logging.config
import yaml
import os

# --- Correlation ID stubs for CLI compatibility ---
import contextvars
import uuid

_correlation_id_ctx = contextvars.ContextVar('correlation_id', default=None)

def get_correlation_id():
    return _correlation_id_ctx.get()

def set_correlation_id(correlation_id):
    _correlation_id_ctx.set(correlation_id)

def generate_correlation_id():
    return str(uuid.uuid4())

class CorrelationIdContext:
    def __init__(self, correlation_id):
        self.token = None
        self.correlation_id = correlation_id
    def __enter__(self):
        self.token = _correlation_id_ctx.set(self.correlation_id)
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token:
            _correlation_id_ctx.reset(self.token)

def setup_logging(default_path='logging.yml', default_level=logging.INFO):
    """
    Setup logging configuration
    """
    path = default_path
    if os.path.exists(path):
        with open(path, 'rt') as f:
            try:
                config = yaml.safe_load(f.read())
                # Ensure logs directory exists
                log_dir = os.path.dirname(config['handlers']['fileHandler']['filename'])
                if not os.path.exists(log_dir):
                    os.makedirs(log_dir)

                # Patch formatters to avoid KeyError for missing fields
                for formatter in config.get('formatters', {}).values():
                    fmt = formatter.get('format')
                    if fmt:
                        # Replace user/correlation_id with safe default if missing
                        fmt = fmt.replace('%(user)s', '%(user)s')
                        fmt = fmt.replace('%(correlation_id)s', '%(correlation_id)s')
                        # Use a custom formatter class that fills missing fields
                        formatter['()'] = 'core.logger.SafeFormatter'
                        formatter['format'] = fmt

                logging.config.dictConfig(config)
            except Exception as e:
                logging.basicConfig(level=default_level)
                logging.warning(f"Failed to load logging configuration from {path}. Using basic config. Error: {e}")
    else:
        logging.basicConfig(level=default_level)
        logging.warning(f"Logging configuration file not found at {path}. Using basic config.")

# --- SafeFormatter to avoid KeyError for missing fields ---
class SafeFormatter(logging.Formatter):
    def format(self, record):
        if not hasattr(record, 'user'):
            record.user = '-'
        if not hasattr(record, 'correlation_id'):
            record.correlation_id = '-'
        return super().format(record)

