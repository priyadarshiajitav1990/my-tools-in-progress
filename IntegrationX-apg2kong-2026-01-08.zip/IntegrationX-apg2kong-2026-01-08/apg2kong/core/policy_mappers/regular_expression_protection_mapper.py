from .base_policy_mapper import BasePolicyMapper

class RegularExpressionProtectionMapper(BasePolicyMapper):
    """
    Maps Apigee Regular-Expression-Protection policy to custom_regex_protection plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_regex_protection",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
