from .base_policy_mapper import BasePolicyMapper

class FlowCalloutMapper(BasePolicyMapper):
    """
    Maps Apigee Flow-Callout policy to custom_flow_callout plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_flow_callout",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
