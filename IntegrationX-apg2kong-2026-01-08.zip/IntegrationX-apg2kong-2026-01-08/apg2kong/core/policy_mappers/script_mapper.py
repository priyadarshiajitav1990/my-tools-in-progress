from typing import Dict, Any, List, Optional
from core.policy_mappers.base_policy_mapper import BasePolicyMapper
from core.exceptions import MappingError # Import custom exception

class ScriptPolicyMapper(BasePolicyMapper):
    def __init__(self, logger, kong_config_generator, policy_to_plugin_map):
        super().__init__(logger, kong_config_generator, policy_to_plugin_map)

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Map Apigee Script policy to a Kong plugin.
        This mapper will handle JavaScript, Python, and Lua scripts.
        """
        self.logger.info(f"Mapping Apigee Script policy '{policy_name}' to Kong plugin.")

        # Resolve Apigee variables in the policy configuration
        resolved_policy_config = self._resolve_variables_in_config(policy_config)

        # Determine script type (Lua, JavaScript, Python)
        script_type = None
        resource_ref = resolved_policy_config.get('ResourceURL')
        if not resource_ref:
            raise MappingError(f"No ResourceURL found for Script policy '{policy_name}'. Cannot determine script type.", policy_name=policy_name, policy_type='Script')
        
        if resource_ref.endswith('.lua'):
            script_type = 'lua'
        elif resource_ref.endswith('.js'):
            script_type = 'javascript'
        elif resource_ref.endswith('.py'):
            script_type = 'python'
        else:
            raise MappingError(f"Unknown script type for policy '{policy_name}' with resource '{resource_ref}'.", policy_name=policy_name, policy_type='Script')

        # Generate Kong plugin name based on convention: kong_<filename without extension>, hyphens replaced by underscores
        script_file_name = resource_ref.split('/')[-1].split('.')[0] # Get filename without path and extension
        kong_plugin_name = f"kong_{script_file_name.replace('-', '_')}"

        # Create Kong plugin configuration
        plugin_config = {
            'name': kong_plugin_name,
            'config': {
                'apigee_policy_name': policy_name,
                'apigee_script_type': script_type,
                'apigee_resource_url': resource_ref,
                # Additional configuration can be extracted from policy_config if needed
            }
        }
        self.logger.info(f"Mapped Apigee Script policy '{policy_name}' to Kong plugin '{kong_plugin_name}'.")
        return [plugin_config]