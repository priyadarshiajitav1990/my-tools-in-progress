from .base_policy_mapper import BasePolicyMapper

class PublishMessageMapper(BasePolicyMapper):
    """
    Maps Apigee Publish-Message policy to custom_publish_message plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_publish_message",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
