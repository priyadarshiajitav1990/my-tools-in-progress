from logging import Logger
from typing import Dict, Any, List
from .base_policy_mapper import BasePolicyMapper

class CORSPolicyMapper(BasePolicyMapper):
    """
    Maps Apigee CORS policies to Kong CORS plugin configurations.
    """

    def can_map(self, policy_type: str) -> bool:
        return policy_type == "CORS"

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps an Apigee CORS policy to Kong CORS plugin configuration.
        """
        self.logger.info(f"Mapping CORS policy '{policy_name}' to Kong CORS plugin")

        kong_plugin_config = {
            "name": "cors",
            "config": {
                "origins": policy_config.get('allow_origins', ['*']),
                "methods": policy_config.get('allow_methods', ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']),
                "headers": policy_config.get('allow_headers', []),
                "exposed_headers": policy_config.get('expose_headers', []),
                "credentials": policy_config.get('allow_credentials', False),
                "max_age": policy_config.get('max_age'),
                "preflight_continue": policy_config.get('continue_on_error', False)
            }
        }

        # Handle origin patterns
        if 'allow_origin_patterns' in policy_config:
            # Kong supports wildcard patterns in origins
            patterns = policy_config['allow_origin_patterns']
            if isinstance(patterns, list):
                kong_plugin_config["config"]["origins"].extend(patterns)

        # Handle preflight requests
        if policy_config.get('generate_preflight_response', True):
            kong_plugin_config["config"]["preflight_continue"] = False

        # Handle error responses
        if policy_config.get('error_on_missing_preflight', False):
            kong_plugin_config["config"]["preflight_continue"] = False

        self.logger.debug(f"Mapped CORS policy to Kong plugin config: {kong_plugin_config}")
        return kong_plugin_config
