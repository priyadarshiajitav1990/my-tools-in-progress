from .base_policy_mapper import BasePolicyMapper

class ResetQuotaMapper(BasePolicyMapper):
    """
    Maps Apigee Reset-Quota policy to custom_reset_quota plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_reset_quota",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
