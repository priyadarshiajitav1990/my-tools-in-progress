from logging import Logger
from typing import Dict, Any, List
from .base_policy_mapper import BasePolicyMapper

class AssignMessagePolicyMapper(BasePolicyMapper):
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)
        self.logger.debug("AssignMessagePolicyMapper initialized.")

    def can_map(self, policy_type: str) -> bool:
        return policy_type == "AssignMessage"

    def map(self, policy_name: str, policy_data: dict) -> List[Dict[str, Any]]:
        """
        Maps an Apigee AssignMessage policy to a Kong custom plugin configuration.
        `policy_data` here is the full policy dictionary as parsed by ApigeeBundleParser,
        containing 'type', 'name', 'config', 'enabled', and 'continue_on_error'.
        """
        self.logger.info(f"Mapping AssignMessage policy '{policy_name}'")

        kong_plugins = []
        plugin_name = self.get_plugin_mappings("AssignMessage")[0] # Should be kong_assign_message_plugin

        apigee_policy_config = policy_data.get('config', {})
        continue_on_error = policy_data.get('continue_on_error', False)

        # Construct the Kong plugin's config object directly from the parsed Apigee config
        kong_plugin_config = {
            "set": apigee_policy_config.get('set', {}),
            "add": apigee_policy_config.get('add', {}),
            "remove": apigee_policy_config.get('remove', {}),
            "copy": apigee_policy_config.get('copy', {}),
            "assign_variables": apigee_policy_config.get('assign_variables', []),
            "continue_on_error": continue_on_error
        }

        plugin_conf = {
            "name": plugin_name,
            "config": kong_plugin_config
        }
        
        kong_plugins.append(plugin_conf)
        self.logger.debug(f"Mapped AssignMessage policy '{policy_name}' to Kong plugin: {plugin_conf}")
        return kong_plugins
