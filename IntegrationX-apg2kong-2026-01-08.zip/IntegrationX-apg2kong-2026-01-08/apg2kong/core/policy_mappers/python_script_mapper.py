from .base_policy_mapper import BasePolicyMapper

class PythonScriptMapper(BasePolicyMapper):
    """
    Maps Apigee Python-Script policy to an existing Kong plugin if available, else to custom_python_script.
    """
    def map_to_plugins(self):
        plugin_name = self.policy_config.get('plugin_name') or "custom_python_script"
        return [{
            "name": plugin_name,
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
