from .base_policy_mapper import BasePolicyMapper

class SetOAuthv2InfoMapper(BasePolicyMapper):
    """
    Maps Apigee Set-OAuthv2-Info policy to custom_set_oauthv2_info plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_set_oauthv2_info",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
