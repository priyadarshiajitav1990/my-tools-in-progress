from typing import Dict, Any, List
from core.policy_mappers.base_policy_mapper import BasePolicyMapper

class JsonToXmlMapper(BasePolicyMapper):
    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        warning_message = f"Apigee JSONToXML policy '{policy_name}' is not fully supported and will not be mapped to a Kong plugin. Functionality may be lost."
        self.logger.warning(warning_message)
        self.config_generator.unmapped_policies_summary.append({
            'policy_name': policy_name,
            'policy_type': 'JSONToXML',
            'status': 'Unmapped',
            'message': warning_message
        })
        return []