from logging import Logger
from typing import Dict, Any, List
from .base_policy_mapper import BasePolicyMapper

class OAuth2PolicyMapper(BasePolicyMapper):
    """
    Maps Apigee OAuth2 policies to Kong OAuth2 plugin configurations.
    """

    def can_map(self, policy_type: str) -> bool:
        return policy_type == "OAuthV2"

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps an Apigee OAuthV2 policy to Kong OAuth2 plugin configuration.

        Apigee OAuthV2 policy supports multiple operations:
        - GenerateAccessToken
        - VerifyAccessToken
        - GenerateAuthorizationCode
        - GenerateRefreshToken
        - etc.
        """
        self.logger.info(f"Mapping OAuthV2 policy '{policy_name}' to Kong OAuth2 plugin")

        kong_plugin_config = {
            "name": "oauth2",
            "config": {}
        }

        # Extract operation type from policy config
        operation = policy_config.get('operation', 'VerifyAccessToken')

        if operation == 'VerifyAccessToken':
            # For token verification, configure Kong OAuth2 plugin for introspection
            kong_plugin_config["config"] = {
                "provision_key": policy_config.get('provision_key', 'provision_key'),
                "token_introspection_endpoint": policy_config.get('introspection_endpoint'),
                "client_id": policy_config.get('client_id'),
                "client_secret": policy_config.get('client_secret'),
                "introspect_access_token": True,
                "scope": policy_config.get('scopes', []),
                "mandatory_scope": policy_config.get('mandatory_scope', False),
                "hide_credentials": policy_config.get('hide_credentials', False)
            }

            # Handle token validation settings
            if 'access_token' in policy_config:
                # If specific token reference is provided
                token_ref = policy_config['access_token'].get('ref')
                if token_ref:
                    # Convert Apigee variable reference to Kong variable
                    kong_token_ref = self.config_generator._convert_apigee_ref_to_kong_var(token_ref)
                    kong_plugin_config["config"]["token_introspection_endpoint"] = kong_token_ref

        elif operation == 'GenerateAccessToken':
            # For token generation, this might need custom implementation
            # Kong OAuth2 plugin primarily handles verification
            self.logger.warning(f"OAuthV2 operation '{operation}' requires custom implementation for token generation")
            kong_plugin_config["config"] = {
                "provision_key": policy_config.get('provision_key', 'provision_key'),
                "enable_authorization_code": True,
                "enable_implicit_grant": policy_config.get('grant_type') == 'implicit',
                "enable_client_credentials": policy_config.get('grant_type') == 'client_credentials',
                "enable_password_grant": policy_config.get('grant_type') == 'password',
                "token_expiration": policy_config.get('expires_in', 7200),
                "refresh_token_ttl": policy_config.get('refresh_token_expires_in', 604800)
            }

        elif operation in ['GenerateAuthorizationCode', 'GenerateRefreshToken']:
            # These operations might need to be handled differently
            self.logger.warning(f"OAuthV2 operation '{operation}' mapping is not fully implemented")
            kong_plugin_config["config"] = {
                "provision_key": policy_config.get('provision_key', 'provision_key')
            }

        # Handle scopes
        if 'scopes' in policy_config:
            scopes = policy_config['scopes']
            if isinstance(scopes, list):
                kong_plugin_config["config"]["scope"] = scopes
            elif isinstance(scopes, str):
                kong_plugin_config["config"]["scope"] = [scopes]

        # Handle redirect URI
        if 'redirect_uri' in policy_config:
            kong_plugin_config["config"]["redirect_uri"] = policy_config['redirect_uri']

        # Handle client credentials
        if 'client_id' in policy_config:
            kong_plugin_config["config"]["client_id"] = policy_config['client_id']
        if 'client_secret' in policy_config:
            kong_plugin_config["config"]["client_secret"] = policy_config['client_secret']

        # Handle token validation
        if 'access_token' in policy_config:
            access_token_config = policy_config['access_token']
            if isinstance(access_token_config, dict):
                token_ref = access_token_config.get('ref')
                if token_ref:
                    kong_token_ref = self.config_generator._convert_apigee_ref_to_kong_var(token_ref)
                    kong_plugin_config["config"]["token_introspection_endpoint"] = kong_token_ref

        # Handle refresh token settings
        if 'refresh_token' in policy_config:
            refresh_config = policy_config['refresh_token']
            if isinstance(refresh_config, dict):
                kong_plugin_config["config"]["enable_refresh_token"] = True
                if 'expires_in' in refresh_config:
                    kong_plugin_config["config"]["refresh_token_ttl"] = refresh_config['expires_in']

        # Handle error handling
        if 'continue_on_error' in policy_config and policy_config['continue_on_error']:
            kong_plugin_config["config"]["run_on_preflight"] = False

        self.logger.debug(f"Mapped OAuthV2 policy to Kong plugin config: {kong_plugin_config}")
        return kong_plugin_config
