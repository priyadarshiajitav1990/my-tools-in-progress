from logging import Logger
from typing import Dict, Any, List
import json

class BasePolicyMapper:
    """
    Base class for all policy mappers.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        self.logger = logger
        self.config_generator = config_generator
        self.policy_mapping = policy_mapping

    def get_plugin_mappings(self, policy_type: str) -> List[str]:
        """
        Looks up the Kong plugin(s) associated with an Apigee policy type from the loaded policy mapping.
        """
        return self.policy_mapping.get(policy_type, [])

    def can_map(self, policy_type: str) -> bool:
        """
        Returns true if the mapper can map the given policy type.
        """
        raise NotImplementedError

    def map(self, policy_name: str, policy_config: dict) -> List[Dict[str, Any]]:
        """
        Maps the given policy to a Kong plugin configuration.
        This default implementation attempts to map based on the policy_mapping provided.
        Specific policy mappers should override this method for custom logic.
        """
        policy_type = self.__class__.__name__.replace('Mapper', '') # Infer policy type from mapper class name
        
        # Look up a direct mapping for this policy type
        mapped_plugins = self.policy_mapping.get(policy_type, [])

        if mapped_plugins:
            self.logger.debug(f"Using generic mapping for policy '{policy_name}' of type '{policy_type}'.")
            
            # Apply variable resolution to plugin configs
            resolved_plugins = []
            for plugin_config_template in mapped_plugins:
                # Ensure plugin_config_template is a deep copy to avoid modifying the original map
                resolved_config_copy = json.loads(json.dumps(plugin_config_template))
                resolved_plugins.append(self._resolve_variables_in_config(resolved_config_copy))
            
            return resolved_plugins
        else:
            # If no generic mapping, mark as unmapped
            warning_message = f"Apigee {policy_type} policy '{policy_name}' is not fully supported and will not be mapped to a Kong plugin. Functionality may be lost."
            self.logger.warning(warning_message)
            self.config_generator.unmapped_policies_summary.append({
                'policy_name': policy_name,
                'policy_type': policy_type,
                'status': 'Unmapped',
                'message': warning_message
            })
            return []


    def _resolve_variables_in_config(self, config: Any) -> Any:
        """
        Recursively resolves Apigee variables in string values within a config dictionary or list.
        """
        if isinstance(config, dict):
            return {k: self._resolve_variables_in_config(v) for k, v in config.items()}
        elif isinstance(config, list):
            return [self._resolve_variables_in_config(elem) for elem in config]
        elif isinstance(config, str):
            # Use the _resolve_value method from the KongConfigGenerator instance
            return self.config_generator._resolve_value(config)
        else:
            return config
