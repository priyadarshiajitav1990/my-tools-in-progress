import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class ExtractVariablesCustomMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        # Both ExtractVariablesApigeeExtractVariablesPolicyMapper and ExtractVariablesCustomMapper
        # map 'ExtractVariables'. This custom mapper can be used for more complex scenarios
        # or when specific 'extract_variables' elements are present.
        # For now, we'll keep it simple and assume either can map.
        return policy_type == 'ExtractVariables'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping ExtractVariables policy '{policy_name}' using custom mapper to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("ExtractVariables")

        for plugin_name in kong_plugins:
            if plugin_name == "kong_extract_variables_plugin":
                lua_code = self._generate_lua_code(policy_name, policy_config)
                self._generate_extract_variables_plugin_files(policy_name, policy_config, lua_code)
                plugins_to_generate.append({
                    "name": "kong-extract-variables-plugin", # This should match folder name
                    "config": {
                        "apigee_policy_name": policy_name,
                        "apigee_policy_config": policy_config,
                        "lua_code": lua_code
                    }
                })
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for ExtractVariables policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_extract_variables_plugin_files(self, policy_name: str, policy_config: dict, lua_code: str):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-extract-variables-plugin")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local setmetatable = setmetatable
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local custom_lua_code = conf.lua_code
    local apigee_policy_config = conf.apigee_policy_config

    ngx.log(ngx.INFO, "[ExtractVariablesCustom] Processing policy: ", apigee_policy_name)
    ngx.log(ngx.INFO, "[ExtractVariablesCustom] Policy config: ", cjson.encode(apigee_policy_config))

    -- Execute the custom Lua code for extraction logic
    if custom_lua_code then
        local func, err = loadstring(custom_lua_code)
        if not func then
            ngx.log(ngx.ERR, "[ExtractVariablesCustom] Error loading custom Lua code: ", err)
            return kong.response.exit(500, "Internal Server Error")
        end
        local ok, res = pcall(func)
        if not ok then
            ngx.log(ngx.ERR, "[ExtractVariablesCustom] Error executing custom Lua code: ", res)
            return kong.response.exit(500, "Internal Server Error")
        end
    end
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for ExtractVariablesCustom policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "kong-extract-variables-plugin",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ apigee_policy_config = {{ type = "table", required = true }} }},
                {{ lua_code = {{ type = "string", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for ExtractVariablesCustom policy at: {schema_path}")

    def _generate_lua_code(self, policy_name: str, policy_config: dict) -> str:
        # This function needs to be re-implemented to generate comprehensive Lua code
        # for all types of variable extractions (URIPath, QueryParam, Header, FormParam, JSONPayload, XMLPayload)
        # For now, it will be a placeholder reflecting the original logic.
        lua_code_parts = []

        # Example: Extracting from query parameters (re-using original logic, but simplified)
        # In a full implementation, this would be more robust to handle different sources.
        if policy_config.get('QueryParam'):
            var_prefix = policy_config.get('VariablePrefix', 'extracted')
            for qp_config in policy_config['QueryParam']:
                param_name = qp_config.get('_name')
                variable_name = qp_config.get('Pattern', {}).get('_text')
                if param_name and variable_name:
                    variable_name = variable_name.replace("{{", "").replace("}}", "")
                    lua_code_parts.append(f"""
    local query_params = ngx.req.get_uri_args()
    local value = query_params["{param_name}"]
    if value then
        ngx.ctx["{var_prefix}.{variable_name}"] = value
        ngx.log(ngx.INFO, "[ExtractVariablesCustom] Extracted query param {param_name}: ", value)
    end
""")
        
        # Placeholder for JSONPath extraction (from original _generate_json_path_code)
        for ev in policy_config.get('extract_variables', []):
            if ev.get('json_path'):
                variable_name = ev.get('name')
                json_path = ev.get('json_path', {}).get('pattern')
                if variable_name and json_path:
                    lua_code_parts.append(f"""
    local json_body = kong.request.get_body()
    if json_body then
        local cjson = require "cjson"
        local body = cjson.decode(json_body)
        local jsonpath = require "jsonpath" -- Assuming jsonpath lib is available
        local result = jsonpath.query(body, "{json_path}")
        if result and #result > 0 then
            ngx.ctx["{variable_name}"] = result[1]
            ngx.log(ngx.INFO, "[ExtractVariablesCustom] Extracted JSON path {json_path} to {variable_name}: ", result[1])
        end
    end
""")
            # Placeholder for XPath extraction (from original _generate_xpath_code)
            elif ev.get('xpath'):
                variable_name = ev.get('name')
                xpath = ev.get('xpath', {}).get('pattern')
                if variable_name and xpath:
                    lua_code_parts.append(f"""
    local xml_body = kong.request.get_body()
    if xml_body then
        local xml2lua = require "xml2lua" -- Assuming xml2lua lib is available
        local xpath = require "xpath" -- Assuming xpath lib is available
        local handler = xml2lua:new()
        handler:parse(xml_body)
        local result = xpath.select(handler.root, "{xpath}")
        if result and #result > 0 then
            ngx.ctx["{variable_name}"] = result[1].value
            ngx.log(ngx.INFO, "[ExtractVariablesCustom] Extracted XPath {xpath} to {variable_name}: ", result[1].value)
        end
    end
""")

        return "".join(lua_code_parts)

