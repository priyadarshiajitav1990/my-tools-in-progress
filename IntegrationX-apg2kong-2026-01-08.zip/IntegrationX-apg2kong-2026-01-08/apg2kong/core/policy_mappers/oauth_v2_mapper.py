from .base_policy_mapper import BasePolicyMapper

class OAuthV2Mapper(BasePolicyMapper):
    """
    Maps Apigee OAuth-v2 policy to Kong oauth2 plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "oauth2",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
