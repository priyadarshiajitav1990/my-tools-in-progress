from .base_policy_mapper import BasePolicyMapper

class RevokeOAuthv2Mapper(BasePolicyMapper):
    """
    Maps Apigee Revoke-OAuthv2 policy to custom_revoke_oauthv2 plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_revoke_oauthv2",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
