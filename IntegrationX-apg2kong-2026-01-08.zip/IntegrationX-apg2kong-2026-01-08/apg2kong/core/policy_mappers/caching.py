from logging import Logger
from typing import Dict, Any, List
from .base_policy_mapper import BasePolicyMapper

class CachingPolicyMapper(BasePolicyMapper):
    """
    Maps Apigee caching policies to Kong proxy-cache plugin configurations.
    """

    def can_map(self, policy_type: str) -> bool:
        return policy_type in ["ResponseCache", "LookupCache", "PopulateCache"]

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps an Apigee caching policy to Kong proxy-cache plugin configuration.

        Supports:
        - ResponseCache: Cache API responses
        - LookupCache: Retrieve cached values
        - PopulateCache: Store values in cache
        """
        self.logger.info(f"Mapping caching policy '{policy_name}' of type '{policy_config.get('type', 'ResponseCache')}' to Kong proxy-cache plugin")

        kong_plugin_config = {
            "name": "proxy-cache",
            "config": {
                "request_method": ["GET", "HEAD"],
                "response_code": [200, 301, 404],
                "content_type": [],
                "cache_ttl": policy_config.get('timeout_in_sec', 300),
                "vary_headers": [],
                "vary_query_params": []
            }
        }

        policy_type = policy_config.get('type', 'ResponseCache')

        if policy_type == 'ResponseCache':
            # Configure response caching
            kong_plugin_config["config"]["cache_ttl"] = policy_config.get('timeout_in_sec', 300)

            # Handle cache key configuration
            if 'cache_key' in policy_config:
                cache_key_config = policy_config['cache_key']
                if isinstance(cache_key_config, dict):
                    # Build cache key from multiple components
                    key_elements = []
                    if 'prefix' in cache_key_config:
                        key_elements.append(cache_key_config['prefix'])

                    # Handle query parameters in cache key
                    if 'query_params' in cache_key_config:
                        query_params = cache_key_config['query_params']
                        if isinstance(query_params, list):
                            kong_plugin_config["config"]["vary_query_params"] = query_params

                    # Handle headers in cache key
                    if 'headers' in cache_key_config:
                        headers = cache_key_config['headers']
                        if isinstance(headers, list):
                            kong_plugin_config["config"]["vary_headers"] = headers

            # Handle cache conditions
            if 'condition' in policy_config:
                # Skip caching based on condition - this might need custom logic
                self.logger.warning(f"ResponseCache condition '{policy_config['condition']}' requires custom implementation")

            # Handle cache bypass
            if policy_config.get('skip_cache', False):
                kong_plugin_config["config"]["cache_ttl"] = 0

        elif policy_type == 'LookupCache':
            # For lookup operations, this is typically handled in request processing
            # May need to use request-transformer or custom plugin
            self.logger.warning(f"LookupCache policy '{policy_name}' requires custom implementation for cache retrieval")
            kong_plugin_config = {
                "name": "request-transformer",
                "config": {
                    "add": {
                        "headers": []
                    }
                }
            }

            # Configure cache lookup parameters
            if 'cache_key' in policy_config:
                cache_key = policy_config['cache_key']
                if isinstance(cache_key, dict):
                    lookup_key = cache_key.get('value', '')
                    if lookup_key:
                        kong_plugin_config["config"]["_apigee_cache_lookup_key"] = lookup_key

            if 'assign_to' in policy_config:
                assign_config = policy_config['assign_to']
                if isinstance(assign_config, dict):
                    variable_name = assign_config.get('property')
                    if variable_name:
                        kong_plugin_config["config"]["_apigee_assign_variable"] = variable_name

        elif policy_type == 'PopulateCache':
            # For population operations, this is typically handled in response processing
            # May need to use response-transformer or custom plugin
            self.logger.warning(f"PopulateCache policy '{policy_name}' requires custom implementation for cache storage")
            kong_plugin_config = {
                "name": "response-transformer",
                "config": {
                    "add": {
                        "headers": []
                    }
                }
            }

            # Configure cache population parameters
            if 'cache_key' in policy_config:
                cache_key = policy_config['cache_key']
                if isinstance(cache_key, dict):
                    populate_key = cache_key.get('value', '')
                    if populate_key:
                        kong_plugin_config["config"]["_apigee_cache_populate_key"] = populate_key

            if 'value' in policy_config:
                cache_value = policy_config['value']
                if isinstance(cache_value, dict):
                    value_ref = cache_value.get('ref')
                    if value_ref:
                        kong_value_ref = self.config_generator._convert_apigee_ref_to_kong_var(value_ref)
                        kong_plugin_config["config"]["_apigee_cache_value_ref"] = kong_value_ref

            # Handle TTL
            if 'timeout_in_sec' in policy_config:
                kong_plugin_config["config"]["_apigee_cache_ttl"] = policy_config['timeout_in_sec']

        # Handle error handling
        if policy_config.get('continue_on_error', False):
            kong_plugin_config["config"]["_apigee_continue_on_error"] = True

        self.logger.debug(f"Mapped caching policy to Kong plugin config: {kong_plugin_config}")
        return kong_plugin_config
