from .base_policy_mapper import BasePolicyMapper

class GetOAuthv2InfoMapper(BasePolicyMapper):
    """
    Maps Apigee Get-OAuthv2-Info policy to custom_get_oauthv2_info plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_get_oauthv2_info",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
