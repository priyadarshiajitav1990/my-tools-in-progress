from .base_policy_mapper import BasePolicyMapper

class StatisticsCollectorMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'StatisticsCollector'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping StatisticsCollector policy '{policy_name}' to Kong statsd plugin.")

        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("StatisticsCollector")

        for plugin_name in kong_plugins:
            if plugin_name == "statsd":
                # Map Apigee StatisticsCollector policy to Kong statsd plugin
                statsd_config = self._map_statsd_config(policy_config)
                plugins_to_generate.append({
                    "name": "statsd",
                    "config": statsd_config
                })
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for StatisticsCollector policy. Skipping.")

        return {"plugins": plugins_to_generate}

    def _map_statsd_config(self, policy_config: dict) -> dict:
        """
        Map Apigee StatisticsCollector policy configuration to Kong statsd plugin configuration.
        """
        config = {}

        # Extract Statsd server configuration
        if 'Statsd' in policy_config:
            statsd_config = policy_config['Statsd']
            config['host'] = statsd_config.get('Host', 'localhost')
            config['port'] = statsd_config.get('Port', 8125)

            # Map protocol settings
            if statsd_config.get('UseSSL') == 'true':
                config['protocol'] = 'udp'  # Kong statsd doesn't directly support SSL, but we can set protocol

        # Extract metric collection configuration
        if 'Metrics' in policy_config:
            metrics_config = policy_config['Metrics']

            # Map metric collection settings
            if 'Collection' in metrics_config:
                collection_config = metrics_config['Collection']
                config['prefix'] = collection_config.get('Prefix', 'apigee')

                # Map sampling rate
                if 'SampleRate' in collection_config:
                    sample_rate = float(collection_config['SampleRate'])
                    config['sample_rate'] = sample_rate

            # Map specific metrics to collect
            if 'Metric' in metrics_config:
                metric_configs = metrics_config['Metric']
                if isinstance(metric_configs, list):
                    # Handle multiple metrics
                    config['metrics'] = []
                    for metric_config in metric_configs:
                        metric = self._map_metric_config(metric_config)
                        if metric:
                            config['metrics'].append(metric)
                else:
                    # Handle single metric
                    metric = self._map_metric_config(metric_configs)
                    if metric:
                        config['metrics'] = [metric]

        # Extract time configuration
        if 'Time' in policy_config:
            time_config = policy_config['Time']
            if 'IntervalInSeconds' in time_config:
                # Kong statsd plugin doesn't have direct interval config, but we can set it
                config['flush_interval'] = int(time_config['IntervalInSeconds'])

        # Set default values for Kong statsd plugin
        config.setdefault('host', 'localhost')
        config.setdefault('port', 8125)
        config.setdefault('prefix', 'kong')
        config.setdefault('sample_rate', 1.0)
        config.setdefault('protocol', 'udp')
        config.setdefault('metrics', [])

        return config

    def _map_metric_config(self, metric_config: dict) -> dict:
        """
        Map individual Apigee metric configuration to Kong statsd metric format.
        """
        metric = {}

        if 'Name' in metric_config:
            metric['name'] = metric_config['Name']

        if 'Type' in metric_config:
            # Map Apigee metric types to Statsd metric types
            apigee_type = metric_config['Type']
            if apigee_type == 'Counter':
                metric['type'] = 'counter'
            elif apigee_type == 'Gauge':
                metric['type'] = 'gauge'
            elif apigee_type == 'Timer':
                metric['type'] = 'timer'
            elif apigee_type == 'Histogram':
                metric['type'] = 'histogram'
            else:
                metric['type'] = 'counter'  # default

        if 'Value' in metric_config:
            value_config = metric_config['Value']
            if 'Ref' in value_config:
                # Handle variable reference
                metric['value'] = f"{{{{ {value_config['Ref']} }}}}"
            elif 'Value' in value_config:
                metric['value'] = value_config['Value']

        if 'Condition' in metric_config:
            # Map condition for when to collect the metric
            condition = metric_config['Condition']
            metric['condition'] = condition

        return metric
