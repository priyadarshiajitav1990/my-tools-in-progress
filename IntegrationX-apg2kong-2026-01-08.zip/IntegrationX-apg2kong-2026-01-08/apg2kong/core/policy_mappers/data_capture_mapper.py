from .base_policy_mapper import BasePolicyMapper

class DataCaptureMapper(BasePolicyMapper):
    """
    Maps Apigee Data-Capture policy to http-log, file-log, and tcp-log plugins.
    """
    def map_to_plugins(self):
        return [
            {"name": "http-log", "config": {}},
            {"name": "file-log", "config": {}},
            {"name": "tcp-log", "config": {}}
        ]
