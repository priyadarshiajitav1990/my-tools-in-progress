from .base_policy_mapper import BasePolicyMapper
from logging import Logger
from typing import Dict, Any

class ResponseCacheMapper(BasePolicyMapper):
    """
    Maps Apigee Response-Cache policy to proxy-cache plugin.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)

    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'ResponseCache'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping ResponseCache policy '{policy_name}' to Kong proxy-cache plugin")

        return {
            'name': 'proxy-cache',
            'config': {
                'strategy': 'memory',
                'cache_ttl': int(policy_config.get('expiry_settings', {}).get('timeout_in_seconds', 300)),
                'content_type': ['application/json; charset=utf-8', 'text/plain'],
                'cache_key': [policy_config.get('cache_key', {}).get('key_fragment', {}).get('ref')]
            }
        }
