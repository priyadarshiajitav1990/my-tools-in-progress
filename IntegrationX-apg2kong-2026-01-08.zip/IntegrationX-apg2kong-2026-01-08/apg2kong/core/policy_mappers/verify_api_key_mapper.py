from typing import Dict, Any, List
import json
from .base_policy_mapper import BasePolicyMapper
from logging import Logger


class VerifyAPIKeyMapper(BasePolicyMapper):
    """
    Maps Apigee Verify-API-Key policy to Kong key-auth plugin.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)

    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'VerifyAPIKey'

    def map(self, policy_name: str, policy_config: dict) -> List[Dict[str, Any]]:
        # First, check if a generic mapping exists in policy_mapping for "VerifyAPIKey"
        self.logger.debug(f"VerifyAPIKeyMapper: self.policy_mapping: {self.policy_mapping}")
        mapped_plugins_from_generic = self.policy_mapping.get("VerifyAPIKey")
        self.logger.debug(f"VerifyAPIKeyMapper: mapped_plugins_from_generic: {mapped_plugins_from_generic}")
        if mapped_plugins_from_generic:
            self.logger.debug(f"Using generic mapping for VerifyAPIKey policy '{policy_name}'.")
            # Apply variable resolution to plugin configs obtained from generic mapping
            resolved_plugins = []
            for plugin_config_template in mapped_plugins_from_generic:
                resolved_config_copy = json.loads(json.dumps(plugin_config_template)) # Deep copy
                resolved_plugins.append(self._resolve_variables_in_config(resolved_config_copy))
            return resolved_plugins
        
        # Fallback to specific logic if no generic mapping is found
        self.logger.info(f"Using specific mapping logic for VerifyAPIKey policy '{policy_name}' to Kong key-auth plugin")
        
        key_location = policy_config.get('api_key_ref', 'request.header.apikey')
        
        # Default values
        key_in = 'header'
        key_name = 'apikey'
        
        if key_location.startswith('request.queryparam.'):
            key_in = 'query'
            key_name = key_location.split('.')[-1]
        elif key_location.startswith('request.header.'):
            key_in = 'header'
            key_name = key_location.split('.')[-1]
        elif key_location.startswith('request.formparam.'):
            key_in = 'form'
            key_name = key_location.split('.')[-1]
        
        # Return as a list, consistent with BasePolicyMapper's map signature
        return [{
            'name': 'key-auth',
            'config': {
                'key_names': [key_name]
            }
        }]

