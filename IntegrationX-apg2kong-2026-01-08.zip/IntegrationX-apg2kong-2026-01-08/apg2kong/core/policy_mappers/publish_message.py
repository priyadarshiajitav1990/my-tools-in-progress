import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class PublishMessageMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'PublishMessage'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping PublishMessage policy '{policy_name}' to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("PublishMessage")

        for plugin_name in kong_plugins:
            if plugin_name == "kong_publish_message_plugin":
                # Assuming all logic for PublishMessage is handled by the custom plugin
                self._generate_publish_message_plugin_files(policy_name, policy_config)
                plugins_to_generate.append({
                    "name": "kong-publish-message-plugin", # This should match folder name
                    "config": {
                        "apigee_policy_name": policy_name,
                        "apigee_policy_config": policy_config
                    }
                })
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for PublishMessage policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_publish_message_plugin_files(self, policy_name: str, policy_config: dict):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-publish-message-plugin")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local apigee_policy_config = conf.apigee_policy_config

    ngx.log(ngx.INFO, "[PublishMessage] Processing policy: ", apigee_policy_name)
    ngx.log(ngx.INFO, "[PublishMessage] Policy config: ", cjson.encode(apigee_policy_config))

    -- Placeholder for actual PublishMessage logic
    -- This is where logic to publish a message to a queue/topic would go.
    -- Example: local topic = apigee_policy_config.Topic
    -- publish_message_to_topic(topic, "message_content")
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for PublishMessage policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "kong-publish-message-plugin",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ apigee_policy_config = {{ type = "table", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for PublishMessage policy at: {schema_path}")
