from .base_policy_mapper import BasePolicyMapper
from logging import Logger
from typing import Dict, Any

class JSONThreatProtectionMapper(BasePolicyMapper):
    """
    Maps Apigee JSON-Threat-Protection policy to request-validator plugin.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)

    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'JSONThreatProtection'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping JSONThreatProtection policy '{policy_name}' to Kong request-validator plugin")
        
        schema = {
            "type": "object",
            "properties": {},
            "maxProperties": int(policy_config.get('object_entry_count', 15)),
        }
        
        return {
            "name": "request-validator",
            "config": {
                "body_schema": schema,
                "parameter_schema": {
                    "type": "object",
                    "properties": {
                        "q": { "type": "string", "maxLength": int(policy_config.get('string_value_length', 500)) }
                    }
                }
            }
        }
