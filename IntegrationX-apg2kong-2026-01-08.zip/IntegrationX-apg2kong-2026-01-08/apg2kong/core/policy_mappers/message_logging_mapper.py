from .base_policy_mapper import BasePolicyMapper
from logging import Logger
from typing import Dict, Any

class MessageLoggingMapper(BasePolicyMapper):
    """
    Maps Apigee Message-Logging policy to http-log plugin.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)

    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'MessageLogging'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping MessageLogging policy '{policy_name}' to Kong http-log plugin")

        syslog_config = policy_config.get('syslog', {})
        host = syslog_config.get('host', 'localhost')
        port = syslog_config.get('port', 514)
        
        return {
            'name': 'http-log',
            'config': {
                'http_endpoint': f'http://{host}:{port}',
                'method': 'POST',
                'content_type': 'application/json',
                'body': syslog_config.get('message', '')
            }
        }
