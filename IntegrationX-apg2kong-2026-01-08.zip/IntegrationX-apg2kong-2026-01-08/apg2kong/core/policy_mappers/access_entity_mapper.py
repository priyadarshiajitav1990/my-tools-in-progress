from .base_policy_mapper import BasePolicyMapper

class AccessEntityMapper(BasePolicyMapper):
    """
    Maps Apigee Access-Entity policy to custom_access_entity Kong plugin.
    """
    def map_to_plugins(self):
        custom_plugin = {
            "name": "custom_access_entity",
            "config": {
                # Map relevant config from self.policy_config
            }
        }
        return [custom_plugin]
