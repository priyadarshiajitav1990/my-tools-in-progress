import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class RegularExpressionProtectionMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'RegularExpressionProtection'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping RegularExpressionProtection policy '{policy_name}' to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("RegularExpressionProtection")

        for plugin_name in kong_plugins:
            if plugin_name == "kong_regular_expression_protection_plugin":
                lua_code = self._generate_lua_code(policy_config)
                if lua_code:
                    plugins_to_generate.append({
                        "name": "kong-regular-expression-protection-plugin", # This should match folder name
                        "config": {
                            "apigee_policy_name": policy_name,
                            "lua_code": lua_code
                        }
                    })
                # Ensure the custom plugin files are generated
                self._generate_regular_expression_protection_plugin_files(policy_name, policy_config, lua_code)
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for RegularExpressionProtection policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_regular_expression_protection_plugin_files(self, policy_name: str, policy_config: dict, lua_code: str):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-regular-expression-protection-plugin")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local custom_lua_code = conf.lua_code -- Retrieve the generated Lua code

    ngx.log(ngx.INFO, "[RegularExpressionProtection] Processing policy: ", apigee_policy_name)

    -- Execute the custom Lua code for regex protections
    if custom_lua_code then
        local func, err = loadstring(custom_lua_code)
        if not func then
            ngx.log(ngx.ERR, "[RegularExpressionProtection] Error loading custom Lua code: ", err)
            return kong.response.exit(500, "Internal Server Error")
        end
        local ok, res = pcall(func)
        if not ok then
            ngx.log(ngx.ERR, "[RegularExpressionProtection] Error executing custom Lua code: ", res)
            return kong.response.exit(500, "Internal Server Error")
        end
    end
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for RegularExpressionProtection policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "kong-regular-expression-protection-plugin",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ lua_code = {{ type = "string", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for RegularExpressionProtection policy at: {schema_path}")

    def _generate_lua_code(self, policy_config: dict) -> str:
        lua_code = ""
        for pattern in policy_config.get('Patterns', []):
            lua_code += self._generate_pattern_code(pattern)
        return lua_code

    def _generate_pattern_code(self, pattern: dict) -> str:
        pattern_str = pattern.get('Pattern')
        variable = pattern.get('Variable')
        if not pattern_str or not variable:
            return ""

        return f"""
local var_value = ngx.var.{variable} -- Assuming 'variable' refers to ngx.var directly or a header
if var_value and string.match(var_value, "{pattern_str}") then
    ngx.log(ngx.WARN, "Request variable '{variable}' contains a malicious pattern: '{pattern_str}'")
    return kong.response.exit(400, "Bad Request: Request contains a malicious pattern")
end
"""
