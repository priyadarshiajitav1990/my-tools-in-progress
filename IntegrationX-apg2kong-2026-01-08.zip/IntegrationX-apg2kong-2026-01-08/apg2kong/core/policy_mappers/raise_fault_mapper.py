from .base_policy_mapper import BasePolicyMapper
from logging import Logger
from typing import Dict, Any

class RaiseFaultMapper(BasePolicyMapper):
    """
    Maps Apigee Raise-Fault policy to response-transformer plugin.
    """
    def __init__(self, logger: Logger, config_generator, policy_mapping: Dict[str, Any]):
        super().__init__(logger, config_generator, policy_mapping)

    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'RaiseFault'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping RaiseFault policy '{policy_name}' to Kong response-transformer plugin")

        fault_response = policy_config.get('fault_response', {})
        status_code = fault_response.get('status_code', 500)
        reason_phrase = fault_response.get('reason_phrase', 'Internal Server Error')
        payload = fault_response.get('payload', {})
        content = payload.get('content', '')
        content_type = payload.get('contentType', 'text/plain')
        
        return {
            'name': 'response-transformer',
            'config': {
                'add': {
                    'headers': [f'Content-Type:{content_type}'],
                    'json': [f'message:{content}']
                },
                'replace': {
                    'status': status_code,
                    'body': reason_phrase
                }
            }
        }
