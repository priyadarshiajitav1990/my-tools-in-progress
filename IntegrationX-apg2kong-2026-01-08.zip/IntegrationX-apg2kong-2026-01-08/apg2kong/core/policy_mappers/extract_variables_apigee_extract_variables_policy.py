import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class ExtractVariablesApigeeExtractVariablesPolicyMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'ExtractVariables'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping ExtractVariables policy '{policy_name}' to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("ExtractVariables")

        for plugin_name in kong_plugins:
            if plugin_name == "apigee-extract-variables-policy":
                self._generate_extract_variables_plugin(policy_name, policy_config)
                plugins_to_generate.append(
                    {
                        "name": "apigee-extract-variables-policy",
                        "config": {
                            "apigee_policy_name": policy_name,
                            "apigee_policy_config": policy_config
                        }
                    }
                )
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for ExtractVariables policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_extract_variables_plugin(self, policy_name: str, policy_config: dict):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-custom-apigee-extract-variables-policy")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local setmetatable = setmetatable
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local apigee_policy_config = conf.apigee_policy_config

    ngx.log(ngx.INFO, "[ExtractVariables] Processing policy: ", apigee_policy_name)

    -- Placeholder for actual extraction logic
    ngx.log(ngx.INFO, "[ExtractVariables] Policy config: ", cjson.encode(apigee_policy_config))

    -- Example: Extracting from query parameters (very basic, needs full implementation)
    local query_params = ngx.req.get_uri_args()
    if apigee_policy_config.QueryParam then
        local var_prefix = apigee_policy_config.VariablePrefix or "extracted"
        for _, qp_config in ipairs(apigee_policy_config.QueryParam) do
            local param_name = qp_config._name
            local variable_name = qp_config.Pattern._text
            
            -- Remove curly braces from variable name if present
            variable_name = variable_name:gsub("{{", ""):gsub("}}", "")] = value
                ngx.log(ngx.INFO, "[ExtractVariables] Extracted query param ", param_name, ": ", value)
            end
        end
    end
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for ExtractVariables policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "apigee-extract-variables-policy",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ apigee_policy_config = {{ type = "table", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for ExtractVariables policy at: {schema_path}")
