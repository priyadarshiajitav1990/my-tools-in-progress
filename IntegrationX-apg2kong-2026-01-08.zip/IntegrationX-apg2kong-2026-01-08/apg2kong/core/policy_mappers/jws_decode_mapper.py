from .base_policy_mapper import BasePolicyMapper

class JWSDecodeMapper(BasePolicyMapper):
    """
    Maps Apigee JWS-Decode policy to custom_decode_jws plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_decode_jws",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
