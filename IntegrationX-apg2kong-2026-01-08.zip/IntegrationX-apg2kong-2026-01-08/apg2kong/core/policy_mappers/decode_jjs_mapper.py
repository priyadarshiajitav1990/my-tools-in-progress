from .base_policy_mapper import BasePolicyMapper

class DecodeJJSMapper(BasePolicyMapper):
    """
    Maps Apigee Decode-JJS policy to an existing Kong plugin if available, else to custom_decode_jjs.
    """
    def map_to_plugins(self):
        plugin_name = self.policy_config.get('plugin_name') or "custom_decode_jjs"
        return [{
            "name": plugin_name,
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
