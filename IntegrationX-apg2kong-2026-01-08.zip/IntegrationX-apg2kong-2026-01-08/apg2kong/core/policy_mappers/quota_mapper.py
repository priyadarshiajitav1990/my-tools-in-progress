from typing import Dict, Any, List
from core.policy_mappers.base_policy_mapper import BasePolicyMapper

class QuotaMapper(BasePolicyMapper):
    pass