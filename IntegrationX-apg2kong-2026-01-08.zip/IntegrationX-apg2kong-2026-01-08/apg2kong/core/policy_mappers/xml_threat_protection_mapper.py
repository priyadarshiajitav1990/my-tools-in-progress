from .base_policy_mapper import BasePolicyMapper

class XMLThreatProtectionMapper(BasePolicyMapper):
    """
    Maps Apigee XML-Threat-Protection policy to request-size-limiting and custom_xml_threat_protection plugins.
    """
    def map_to_plugins(self):
        return [
            {"name": "request-size-limiting", "config": {}},
            {"name": "custom_xml_threat_protection", "config": {}}
        ]
