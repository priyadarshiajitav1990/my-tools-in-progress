import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class JsonThreatProtectionRequestValidatorMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'JSONThreatProtection'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping JSONThreatProtection policy '{policy_name}' to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("JSONThreatProtection")

        for plugin_name in kong_plugins:
            if plugin_name == "request-size-limiting":
                max_payload_size = policy_config.get('MaxPayloadSize')
                if max_payload_size:
                    plugins_to_generate.append({
                        "name": "request-size-limiting",
                        "config": {
                            "allowed_payload_size": int(max_payload_size)
                        }
                    })
            elif plugin_name == "request-validator":
                # Placeholder for request-validator logic
                self.logger.warning(f"JSONThreatProtection policy '{policy_name}': Kong's 'request-validator' plugin mapping requires further implementation for schema validation.")
                # Add a placeholder config for now, actual schema mapping would go here
                plugins_to_generate.append({
                    "name": "request-validator",
                    "config": {
                        # "json_schema": "...", # This would be derived from Apigee's schema validation config
                        "verbose_response": True
                    }
                })
            elif plugin_name == "kong_json_threat_protection_plugin":
                lua_code = self._generate_lua_code(policy_config)
                if lua_code:
                    plugins_to_generate.append({
                        "name": "kong-json-threat-protection-plugin", # This should match folder name
                        "config": {
                            "apigee_policy_name": policy_name,
                            "lua_code": lua_code # Pass generated Lua code as config
                        }
                    })
                # Also ensure the custom plugin files are generated
                self._generate_json_threat_protection_plugin_files(policy_name, policy_config, lua_code)
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for JSONThreatProtection policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_json_threat_protection_plugin_files(self, policy_name: str, policy_config: dict, lua_code: str):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-json-threat-protection-plugin")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local custom_lua_code = conf.lua_code -- Retrieve the generated Lua code

    ngx.log(ngx.INFO, "[JSONThreatProtection] Processing policy: ", apigee_policy_name)

    -- Execute the custom Lua code for additional threat protections
    if custom_lua_code then
        -- This is a simplified execution. In a real scenario, you'd want to
        -- safely load and execute this code, potentially in a sandboxed environment.
        -- For this exercise, we assume the code is trusted and well-formed.
        local func, err = loadstring(custom_lua_code)
        if not func then
            ngx.log(ngx.ERR, "[JSONThreatProtection] Error loading custom Lua code: ", err)
            return kong.response.exit(500, "Internal Server Error")
        end
        local ok, res = pcall(func)
        if not ok then
            ngx.log(ngx.ERR, "[JSONThreatProtection] Error executing custom Lua code: ", res)
            return kong.response.exit(500, "Internal Server Error")
        end
    end
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for JSONThreatProtection policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "kong-json-threat-protection-plugin",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ lua_code = {{ type = "string", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for JSONThreatProtection policy at: {schema_path}")

    def _generate_lua_code(self, policy_config: dict) -> str:
        lua_code = ""

        max_container_depth = policy_config.get('MaxContainerDepth')
        if max_container_depth:
            lua_code += self._generate_max_depth_code(int(max_container_depth))

        max_array_element_count = policy_config.get('MaxArrayElementCount')
        if max_array_element_count:
            lua_code += self._generate_max_array_elements_code(int(max_array_element_count))

        max_object_entry_count = policy_config.get('MaxObjectEntryCount')
        if max_object_entry_count:
            lua_code += self._generate_max_object_entries_code(int(max_object_entry_count))

        return lua_code

    def _generate_max_depth_code(self, max_depth: int) -> str:
        return f"""
local json_body = kong.request.get_body()
if not json_body then return end -- No JSON body to process
local cjson = require "cjson"
local body, err = cjson.decode(json_body)
if err then
    ngx.log(ngx.ERR, "Failed to decode JSON body: ", err)
    return kong.response.exit(400, "Bad Request: Invalid JSON body")
end

function get_depth(t)
    local depth = 1
    if type(t) == "table" then
        for k, v in pairs(t) do
            depth = math.max(depth, 1 + get_depth(v))
        end
    end
    return depth
end

if get_depth(body) > {max_depth} then
    ngx.log(ngx.WARN, "JSON container depth exceeds limit (", get_depth(body), " > {max_depth})")
    return kong.response.exit(400, "Bad Request: JSON container depth exceeds limit")
end
"""

    def _generate_max_array_elements_code(self, max_elements: int) -> str:
        return f"""
local json_body = kong.request.get_body()
if not json_body then return end
local cjson = require "cjson"
local body, err = cjson.decode(json_body)
if err then
    ngx.log(ngx.ERR, "Failed to decode JSON body: ", err)
    return kong.response.exit(400, "Bad Request: Invalid JSON body")
end

function count_array_elements_recursive(t)
    local count = 0
    if type(t) == "table" then
        if type(t[1]) == "nil" and type(t) == "table" then -- heuristic for object vs array
            -- it's an object, iterate values
            for k, v in pairs(t) do
                count = count + count_array_elements_recursive(v)
            end
        else -- it's an array
            count = #t
            for i, v in ipairs(t) do
                count = count + count_array_elements_recursive(v)
            end
        end
    end
    return count
end

if count_array_elements_recursive(body) > {max_elements} then
    ngx.log(ngx.WARN, "JSON array element count exceeds limit (", count_array_elements_recursive(body), " > {max_elements})")
    return kong.response.exit(400, "Bad Request: JSON array element count exceeds limit")
end
"""

    def _generate_max_object_entries_code(self, max_entries: int) -> str:
        return f"""
local json_body = kong.request.get_body()
if not json_body then return end
local cjson = require "cjson"
local body, err = cjson.decode(json_body)
if err then
    ngx.log(ngx.ERR, "Failed to decode JSON body: ", err)
    return kong.response.exit(400, "Bad Request: Invalid JSON body")
end

function count_object_entries_recursive(t)
    local count = 0
    if type(t) == "table" then
        if type(t[1]) == "nil" and type(t) == "table" then -- heuristic for object vs array
            -- it's an object, count its entries and recurse
            count = 0
            for k, v in pairs(t) do
                count = count + 1 + count_object_entries_recursive(v)
            end
        else -- it's an array, just recurse
            for i, v in ipairs(t) do
                count = count + count_object_entries_recursive(v)
            end
        end
    end
    return count
end

if count_object_entries_recursive(body) > {max_entries} then
    ngx.log(ngx.WARN, "JSON object entry count exceeds limit (", count_object_entries_recursive(body), " > {max_entries})")
    return kong.response.exit(400, "Bad Request: JSON object entry count exceeds limit")
end
"""
