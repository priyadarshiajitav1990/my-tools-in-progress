from .base_policy_mapper import BasePolicyMapper

class JWSVerifyMapper(BasePolicyMapper):
    """
    Maps Apigee JWS-Verify policy to custom_verify_jws plugin.
    """
    def map_to_plugins(self):
        return [{
            "name": "custom_verify_jws",
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
