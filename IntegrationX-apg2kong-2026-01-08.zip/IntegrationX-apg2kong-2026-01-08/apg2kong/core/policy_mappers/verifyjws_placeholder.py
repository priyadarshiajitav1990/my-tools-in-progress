import os
from .base_policy_mapper import BasePolicyMapper
import json # Added to encode policy_config for logging

class VerifyJWSMapper(BasePolicyMapper):
    def can_map(self, policy_type: str) -> bool:
        return policy_type == 'VerifyJWS'

    def map(self, policy_name: str, policy_config: dict) -> dict:
        self.logger.info(f"Mapping VerifyJWS policy '{policy_name}' to Kong plugin(s).")
        
        plugins_to_generate = []
        kong_plugins = self.get_plugin_mappings("VerifyJWS")

        for plugin_name in kong_plugins:
            if plugin_name == "kong_jws_verify_plugin":
                # Assuming all logic for VerifyJWS is handled by the custom plugin
                self._generate_jws_verify_plugin_files(policy_name, policy_config)
                plugins_to_generate.append({
                    "name": "kong-jws-verify-plugin", # This should match folder name
                    "config": {
                        "apigee_policy_name": policy_name,
                        "apigee_policy_config": policy_config
                    }
                })
            else:
                self.logger.warning(f"Unknown plugin '{plugin_name}' for VerifyJWS policy. Skipping.")
                
        return {"plugins": plugins_to_generate}

    def _generate_jws_verify_plugin_files(self, policy_name: str, policy_config: dict):
        plugin_dir = os.path.join("custom-lua-plugins", "kong-jws-verify-plugin")
        os.makedirs(plugin_dir, exist_ok=True)

        # Generate handler.lua
        handler_content = f"""
local BasePlugin = require "kong.plugins.base_plugin"
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    local apigee_policy_name = conf.apigee_policy_name
    local apigee_policy_config = conf.apigee_policy_config

    ngx.log(ngx.INFO, "[VerifyJWS] Processing policy: ", apigee_policy_name)
    ngx.log(ngx.INFO, "[VerifyJWS] Policy config: ", cjson.encode(apigee_policy_config))

    -- Placeholder for actual VerifyJWS logic
    -- This is where logic to verify a JWS token would go.
    -- Example: local jws_token = kong.request.get_header("Authorization")
    -- if not verify_jws_function(jws_token, apigee_policy_config) then
    --              return kong.response.exit(401, "Unauthorized: Invalid JWS Token")
    --          end
end

return _M
"""
        handler_path = os.path.join(plugin_dir, "handler.lua")
        with open(handler_path, "w") as f:
            f.write(handler_content)
        self.logger.info(f"Generated handler.lua for VerifyJWS policy at: {handler_path}")

        # Generate schema.lua
        schema_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
    name = "kong-jws-verify-plugin",
    fields = {{
        {{ consumer = typedefs.no_consumer }},
        {{ route = typedefs.no_route }},
        {{ service = typedefs.no_service }},
        {{ _config = {{
            type = "record",
            fields = {{
                {{ apigee_policy_name = {{ type = "string", required = true }} }},
                {{ apigee_policy_config = {{ type = "table", required = true }} }},
            }},
        }} }},
    }},
}}
"""
        schema_path = os.path.join(plugin_dir, "schema.lua")
        with open(schema_path, "w") as f:
            f.write(schema_content)
        self.logger.info(f"Generated schema.lua for VerifyJWS policy at: {schema_path}")
