from logging import Logger
from typing import Dict, Any, List
from .base_policy_mapper import BasePolicyMapper

class ErrorHandlingPolicyMapper(BasePolicyMapper):
    """
    Maps Apigee error handling policies to Kong response-transformer plugin configurations.
    """

    def can_map(self, policy_type: str) -> bool:
        return policy_type in ["RaiseFault", "ContinueOnError"]

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps an Apigee error handling policy to Kong plugin configuration.

        Supports:
        - RaiseFault: Generate custom error responses
        - ContinueOnError: Control error handling behavior
        """
        self.logger.info(f"Mapping error handling policy '{policy_name}' of type '{policy_config.get('type', 'RaiseFault')}' to Kong plugin")

        policy_type = policy_config.get('type', 'RaiseFault')

        if policy_type == 'RaiseFault':
            kong_plugin_config = {
                "name": "response-transformer",
                "config": {
                    "add": {
                        "headers": [],
                        "json": []
                    },
                    "remove": {
                        "headers": [],
                        "json": []
                    }
                }
            }

            # Handle HTTP status code
            if 'http_status_code' in policy_config:
                status_code = policy_config['http_status_code']
                kong_plugin_config["config"]["_apigee_fault_status_code"] = status_code

            # Handle reason phrase
            if 'reason_phrase' in policy_config:
                reason = policy_config['reason_phrase']
                kong_plugin_config["config"]["_apigee_fault_reason_phrase"] = reason

            # Handle fault response content
            if 'fault_response' in policy_config:
                fault_response = policy_config['fault_response']
                if isinstance(fault_response, dict):
                    # Handle Set payload
                    if 'set' in fault_response and 'payload' in fault_response['set']:
                        payload_config = fault_response['set']['payload']
                        if isinstance(payload_config, dict):
                            content_type = payload_config.get('content_type', 'application/json')
                            content = payload_config.get('content', '')

                            # Add content type header
                            kong_plugin_config["config"]["add"]["headers"].append(f"Content-Type:{content_type}")

                            # Set response body
                            if content_type == 'application/json':
                                kong_plugin_config["config"]["add"]["json"].append(f"response_body:{content}")
                            else:
                                kong_plugin_config["config"]["_apigee_fault_body"] = content

                    # Handle Set headers
                    if 'set' in fault_response and 'headers' in fault_response['set']:
                        headers = fault_response['set']['headers']
                        if isinstance(headers, list):
                            for header in headers:
                                if isinstance(header, dict) and 'name' in header and 'value' in header:
                                    header_str = f"{header['name']}:{header['value']}"
                                    kong_plugin_config["config"]["add"]["headers"].append(header_str)

            # Handle variables to include in fault response
            if 'variables' in policy_config:
                variables = policy_config['variables']
                if isinstance(variables, list):
                    kong_plugin_config["config"]["_apigee_fault_variables"] = variables

        elif policy_type == 'ContinueOnError':
            # This is typically a policy attribute rather than a separate policy
            # It affects how other policies handle errors
            kong_plugin_config = {
                "name": "request-transformer",
                "config": {
                    "_apigee_continue_on_error": True
                }
            }

            # This setting is usually applied to other policies rather than being a standalone plugin
            self.logger.warning(f"ContinueOnError policy '{policy_name}' affects error handling behavior of other policies")

        # Handle condition for when to trigger the fault
        if 'condition' in policy_config:
            condition = policy_config['condition']
            kong_plugin_config["config"]["_apigee_fault_condition"] = condition

        self.logger.debug(f"Mapped error handling policy to Kong plugin config: {kong_plugin_config}")
        return kong_plugin_config
