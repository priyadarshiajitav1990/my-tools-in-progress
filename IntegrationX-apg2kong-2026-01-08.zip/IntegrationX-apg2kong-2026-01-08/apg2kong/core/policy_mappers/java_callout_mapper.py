from typing import Dict, Any, List, Optional
from core.policy_mappers.base_policy_mapper import BasePolicyMapper
from core.exceptions import MappingError # Import custom exception

class JavaCalloutMapper(BasePolicyMapper):
    def __init__(self, logger, kong_config_generator, policy_to_plugin_map):
        super().__init__(logger, kong_config_generator, policy_to_plugin_map)

    def map(self, policy_name: str, policy_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Map Apigee JavaCallout policy to a Kong plugin.
        This mapper will handle Java JARs.
        """
        self.logger.info(f"Mapping Apigee JavaCallout policy '{policy_name}' to Kong plugin.")

        # Resolve Apigee variables in the policy configuration
        resolved_policy_config = self._resolve_variables_in_config(policy_config)

        jar_resource_name = resolved_policy_config.get('ResourceURL')
        if not jar_resource_name:
            raise MappingError(f"No ResourceURL found for JavaCallout policy '{policy_name}'. Cannot determine JAR.", policy_name=policy_name, policy_type='JavaCallout')
        
        # Generate Kong plugin name based on convention: kong_<filename without extension>, hyphens replaced by underscores
        # Example: my-java-app.jar -> kong_my_java_app
        jar_file_name_without_ext = jar_resource_name.split('/')[-1].split('.')[0]
        kong_plugin_name = f"kong_{jar_file_name_without_ext.replace('-', '_')}"

        # Create Kong plugin configuration
        plugin_config = {
            'name': kong_plugin_name, # This would be a custom plugin in Kong that invokes the JAR
            'config': {
                'apigee_policy_name': policy_name,
                'apigee_java_callout_jar': jar_resource_name,
                # Any other relevant configuration from Apigee JavaCallout policy
            }
        }
        self.logger.info(f"Mapped Apigee JavaCallout policy '{policy_name}' to Kong plugin '{kong_plugin_name}'.")
        return [plugin_config]