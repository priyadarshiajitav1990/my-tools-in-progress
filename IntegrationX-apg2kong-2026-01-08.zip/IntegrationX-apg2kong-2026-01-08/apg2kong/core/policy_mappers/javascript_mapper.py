from .base_policy_mapper import BasePolicyMapper

class JavaScriptMapper(BasePolicyMapper):
    """
    Maps Apigee JavaScript policy to an existing Kong plugin if available, else to custom_javascript.
    """
    def map_to_plugins(self):
        # If a plugin with the same name as the JS file (without extension) exists in Kong, map to that
        plugin_name = self.policy_config.get('plugin_name') or "custom_javascript"
        return [{
            "name": plugin_name,
            "config": {
                # Map relevant config from self.policy_config
            }
        }]
