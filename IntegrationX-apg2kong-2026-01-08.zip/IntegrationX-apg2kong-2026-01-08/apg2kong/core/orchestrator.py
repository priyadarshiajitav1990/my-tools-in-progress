import logging
import os
import asyncio
import time
import yaml
from typing import Dict, Any
from core.apigee_bundle_parser import ApigeeBundleParser
from core.kong_config_generator import KongConfigGenerator
from core.cache import BundleCache
from core.config import Config
from core.metrics import MetricsCollector
from core.validation import InputValidator


async def _generate_summary_table(parsed_data: Dict[str, Any]) -> str:
    """Generates a summary table of parsed Apigee components and their statuses."""
    summary_lines = ["\n--- Apigee Bundle Parsing Summary ---"]

    # Proxy Endpoints
    summary_lines.append("\nProxy Endpoints:")
    if parsed_data.get('proxy_endpoints'):
        for ep in parsed_data['proxy_endpoints']:
            summary_lines.append(f"  - Name: {ep.get('name')}, Status: {ep.get('status', 'N/A')}")
    else:
        summary_lines.append("  No Proxy Endpoints found.")

    # Target Endpoints
    summary_lines.append("\nTarget Endpoints:")
    if parsed_data.get('target_endpoints'):
        for ep in parsed_data['target_endpoints']:
            summary_lines.append(f"  - Name: {ep.get('name')}, Status: {ep.get('status', 'N/A')}")
    else:
        summary_lines.append("  No Target Endpoints found.")

    # Policies
    summary_lines.append("\nPolicies:")
    if parsed_data.get('policies'):
        for name, policy in parsed_data['policies'].items():
            summary_lines.append(f"  - Name: {name} ({policy.get('type')}), Status: {policy.get('status', 'N/A')}")
    else:
        summary_lines.append("  No Policies found.")

    return "\n".join(summary_lines)

async def convert_bundle(input_path, output_dir, config: Config, validator: InputValidator, metrics: MetricsCollector, correlation_id=None):
    """
    Converts an Apigee bundle to a Kong configuration with comprehensive error handling and monitoring.
    This function is designed to be reusable by both CLI and web interfaces.
    """
    logger = logging.getLogger()
    start_time = time.time()

    # Increment active conversions metric
    metrics.increment_active_conversions()

    try:
        # Validate input
        is_valid, error_msg = validator.validate_file_path(input_path)
        if not is_valid:
            logger.error(f"Input validation failed: {error_msg}")
            metrics.increment_conversion_requests('error')
            raise ValueError(f"Input validation failed: {error_msg}")

        # Validate output directory
        is_valid, error_msg = validator.validate_directory_path(output_dir)
        if not is_valid:
            logger.error(f"Output directory validation failed: {error_msg}")
            metrics.increment_conversion_requests('error')
            raise ValueError(f"Output directory validation failed: {error_msg}")

        cache_dir = os.path.join(os.path.dirname(__file__), '..', config.get('CACHE_DIR', 'cache'))
        cache = BundleCache(cache_dir, logger)

        # Check cache first
        cached_data = cache.get(input_path)
        if cached_data:
            parsed_data = cached_data
            metrics.increment_cache_hit()
            logger.info("Using cached parsed data.")
        else:
            metrics.increment_cache_miss()
            parsing_start = time.time()
            parser = ApigeeBundleParser(input_path, logger)
            parsed_data = await parser.parse()
            parsing_duration = time.time() - parsing_start
            metrics.observe_parsing_duration(parsing_duration)

            if parsed_data:
                # Validate parsed data
                is_valid, error_msg = validator.validate_parsed_data(parsed_data)
                if not is_valid:
                    logger.error(f"Parsed data validation failed: {error_msg}")
                    metrics.increment_conversion_requests('error')
                    raise ValueError(f"Parsed data validation failed: {error_msg}")

                cache.set(input_path, parsed_data)
                logger.info("Parsed data cached.")
            else:
                logger.error("Failed to parse Apigee bundle.")
                metrics.increment_conversion_requests('error')
                raise ValueError("Failed to parse Apigee bundle")

        if parsed_data:
            generator = KongConfigGenerator(logger)
            kong_config = await generator.generate(parsed_data)
            
            # Convert kong_config dict to YAML string for deck validation
            kong_config_yaml_content = yaml.dump(kong_config, sort_keys=False)

            # Validate generated Kong config
            is_valid, error_msg = validator.validate_kong_config(kong_config_yaml_content)
            if not is_valid:
                logger.error(f"Kong config validation failed: {error_msg}")
                metrics.increment_conversion_requests('error')
                raise ValueError(f"Kong config validation failed: {error_msg}")

            proxy_name = os.path.splitext(os.path.basename(input_path))[0]
            output_file_name = f"{proxy_name}.yml"
            output_file_path = os.path.join(output_dir, output_file_name)

            with open(output_file_path, "w") as f:
                f.write(kong_config_yaml_content)

            conversion_duration = time.time() - start_time
            metrics.observe_conversion_duration(conversion_duration)
            metrics.increment_conversion_requests('success')

            # Generate and log summary table
            summary_table = await _generate_summary_table(parsed_data)
            logger.info(summary_table)

            logger.info(f"Successfully generated Kong configuration at: {output_file_path}")
            return output_file_name
        else:
            metrics.increment_conversion_requests('error')
            raise ValueError("No parsed data available for Kong config generation")

    except Exception as e:
        conversion_duration = time.time() - start_time
        metrics.observe_conversion_duration(conversion_duration)
        metrics.increment_conversion_requests('error')
        logger.error(f"Conversion failed: {str(e)}", exc_info=True)
        raise
    finally:
        metrics.decrement_active_conversions()
