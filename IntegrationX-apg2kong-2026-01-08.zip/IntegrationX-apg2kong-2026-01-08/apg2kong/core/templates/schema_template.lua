local typedefs = require "kong.db.schema.typedefs"

return {
  name = "{{plugin_name}}",
  fields = {
    { consumer = typedefs.no_consumer },
    { service = typedefs.no_service },
    { route = typedefs.no_route },
    { protocols = typedefs.protocols },
    { enabled = typedefs.enabled },
    { config = {
        type = "record",
        fields = {
          {{config_fields}}
        },
      },
    },
    { ordering = typedefs.plugin_ordering }, -- Add support for ordering
    { tags = typedefs.tags }, -- Add support for tags
  },
}