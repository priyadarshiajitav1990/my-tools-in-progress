local BasePlugin = require "kong.plugins.base_plugin"
local Access = require "kong.plugins.{{plugin_name}}.access"
local Logger = require "kong.plugins.{{plugin_name}}.logger"

local PLUGIN_NAME = "{{plugin_name}}"
local PLUGIN_PRIORITY = {{priority}}
local PLUGIN_VERSION = "{{version}}"

local CustomPlugin = BasePlugin:extend(PLUGIN_NAME)

function CustomPlugin:new()
  return BasePlugin.new(self, PLUGIN_NAME)
end

function CustomPlugin:access(conf)
  Access.execute(conf)
end

function CustomPlugin:log(conf)
  Logger.execute(conf)
end

CustomPlugin.PRIORITY = PLUGIN_PRIORITY
CustomPlugin.VERSION = PLUGIN_VERSION

return CustomPlugin
