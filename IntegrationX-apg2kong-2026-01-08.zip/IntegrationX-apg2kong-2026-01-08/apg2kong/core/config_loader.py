import json
import os
from typing import Dict, Any

class ConfigLoader:
    """
    Loads configuration from a JSON file.
    """
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.config = self._load_config()
        self.policy_mapping = self._load_policy_mapping()

    def _load_config(self) -> Dict[str, Any]:
        """
        Loads the main configuration from the specified path.
        """
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        
        with open(self.config_path, 'r') as f:
            return json.load(f)

    def _load_policy_mapping(self) -> Dict[str, Any]:
        """
        Loads the policy-to-plugin mapping from a JSON file.
        """
        # Assuming policy-to-plugin.json is in the same directory as config_path
        policy_mapping_path = os.path.join(os.path.dirname(self.config_path), 'policy-to-plugin.json')
        
        if not os.path.exists(policy_mapping_path):
            # If not found in the same directory, try apg2kong/configs
            project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
            policy_mapping_path = os.path.join(project_root, 'apg2kong', 'configs', 'policy-to-plugin.json')
            if not os.path.exists(policy_mapping_path):
                raise FileNotFoundError(f"Policy mapping file not found: {policy_mapping_path}")

        with open(policy_mapping_path, 'r') as f:
            return json.load(f)

    def get(self, key: str, default: Any = None) -> Any:
        """
        Gets a configuration value by key.
        """
        return self.config.get(key, default)

    def get_policy_mapping(self) -> Dict[str, Any]:
        """
        Returns the loaded policy-to-plugin mapping.
        """
        return self.policy_mapping
