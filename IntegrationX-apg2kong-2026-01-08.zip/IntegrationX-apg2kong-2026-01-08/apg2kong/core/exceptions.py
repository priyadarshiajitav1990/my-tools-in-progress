from typing import Optional

class MappingError(Exception):
    """
    Custom exception for errors encountered during Apigee to Kong mapping.
    """
    def __init__(self, message: str, policy_name: Optional[str] = None, policy_type: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.policy_name = policy_name
        self.policy_type = policy_type

    def __str__(self):
        details = ""
        if self.policy_name:
            details += f"Policy: {self.policy_name}."
        if self.policy_type:
            details += f" Type: {self.policy_type}."
        
        if details:
            return f"MappingError: {self.message} ({details.strip()})"
        return f"MappingError: {self.message}"

class InvalidConfigError(Exception):
    """
    Custom exception for invalid configuration issues.
    """
    pass