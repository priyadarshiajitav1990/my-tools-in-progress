"""
Generates a Kong Lua plugin from templates.
"""

import os

class CustomPluginGenerator:
    """
    This class is responsible for generating Kong custom Lua plugin files (handler.lua and schema.lua) from templates.
    """

    def __init__(self, handler_template_path, schema_template_path):
        self.handler_template_path = handler_template_path
        self.schema_template_path = schema_template_path

    def generate(self, output_dir, plugin_name, priority, version, access_logic, log_logic, schema_config_fields=""):
        """
        Generates handler.lua and schema.lua files for a custom Kong plugin.
        """
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Generate handler.lua
        with open(self.handler_template_path, "r") as f:
            handler_template = f.read()

        handler_content = handler_template.replace("{{plugin_name}}", plugin_name)
        handler_content = handler_content.replace("{{priority}}", str(priority))
        handler_content = handler_content.replace("{{version}}", version)
        handler_content = handler_content.replace("{{access_logic}}", access_logic)
        handler_content = handler_content.replace("{{log_logic}}", log_logic)

        handler_output_path = os.path.join(output_dir, "handler.lua")
        with open(handler_output_path, "w") as f:
            f.write(handler_content)

        # Generate schema.lua
        with open(self.schema_template_path, "r") as f:
            schema_template = f.read()
        
        schema_content = schema_template.replace("{{plugin_name}}", plugin_name)
        schema_content = schema_content.replace("{{config_fields}}", schema_config_fields)


        schema_output_path = os.path.join(output_dir, "schema.lua")
        with open(schema_output_path, "w") as f:
            f.write(schema_content)