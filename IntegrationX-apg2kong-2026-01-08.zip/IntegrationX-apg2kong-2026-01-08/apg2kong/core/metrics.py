from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from typing import Dict, Any
from logging import Logger
import time

class MetricsCollector:
    """
    Collects and exposes metrics for the Apg2Kong tool.
    """

    def __init__(self, logger: Logger):
        self.logger = logger

        # Counters
        self.conversion_requests_total = Counter(
            'apg2kong_conversion_requests_total',
            'Total number of conversion requests',
            ['status']  # success, error
        )

        self.cache_hits_total = Counter(
            'apg2kong_cache_hits_total',
            'Total number of cache hits'
        )

        self.cache_misses_total = Counter(
            'apg2kong_cache_misses_total',
            'Total number of cache misses'
        )

        # Histograms
        self.conversion_duration_seconds = Histogram(
            'apg2kong_conversion_duration_seconds',
            'Time spent processing conversion requests',
            buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0]
        )

        self.parsing_duration_seconds = Histogram(
            'apg2kong_parsing_duration_seconds',
            'Time spent parsing Apigee bundles',
            buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0]
        )

        # Gauges
        self.active_conversions = Gauge(
            'apg2kong_active_conversions',
            'Number of currently active conversion operations'
        )

        self.logger.info("Metrics collector initialized")

    def increment_conversion_requests(self, status: str = 'success'):
        """Increment conversion requests counter."""
        self.conversion_requests_total.labels(status=status).inc()

    def increment_cache_hit(self):
        """Increment cache hits counter."""
        self.cache_hits_total.inc()

    def increment_cache_miss(self):
        """Increment cache misses counter."""
        self.cache_misses_total.inc()

    def observe_conversion_duration(self, duration: float):
        """Observe conversion duration."""
        self.conversion_duration_seconds.observe(duration)

    def observe_parsing_duration(self, duration: float):
        """Observe parsing duration."""
        self.parsing_duration_seconds.observe(duration)

    def increment_active_conversions(self):
        """Increment active conversions gauge."""
        self.active_conversions.inc()

    def decrement_active_conversions(self):
        """Decrement active conversions gauge."""
        self.active_conversions.dec()

    def get_metrics(self) -> str:
        """Get metrics in Prometheus format."""
        return generate_latest().decode('utf-8')

class MetricsMiddleware:
    """
    Flask middleware for collecting HTTP request metrics.
    """

    def __init__(self, app, metrics_collector: MetricsCollector):
        self.app = app
        self.metrics = metrics_collector

        # HTTP request metrics
        self.http_requests_total = Counter(
            'apg2kong_http_requests_total',
            'Total number of HTTP requests',
            ['method', 'endpoint', 'status']
        )

        self.http_request_duration_seconds = Histogram(
            'apg2kong_http_request_duration_seconds',
            'HTTP request duration in seconds',
            ['method', 'endpoint'],
            buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
        )

        self.app.before_request(self.before_request)
        self.app.after_request(self.after_request)

    def before_request(self):
        """Called before each request."""
        self.start_time = time.time()

    def after_request(self, response):
        """Called after each request."""
        duration = time.time() - self.start_time

        # Get request info
        method = request.method
        endpoint = request.endpoint or 'unknown'
        status = response.status_code

        # Record metrics
        self.http_requests_total.labels(
            method=method,
            endpoint=endpoint,
            status=status
        ).inc()

        self.http_request_duration_seconds.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)

        return response
