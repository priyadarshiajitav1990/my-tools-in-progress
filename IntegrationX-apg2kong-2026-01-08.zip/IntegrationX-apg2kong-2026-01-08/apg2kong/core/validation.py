import os
import zipfile
import subprocess
import tempfile
from typing import Dict, Any, List, Optional, Tuple
from logging import Logger
import jsonschema
from jsonschema import ValidationError

class InputValidator:
    """
    Validates input files, paths, and configurations for the Apg2Kong tool.
    """

    def __init__(self, logger: Logger, config: 'Config'):
        self.logger = logger
        self.config = config

        # Define JSON schemas for validation
        self.bundle_schema = {
            "type": "object",
            "properties": {
                "proxy_endpoints": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "base_path": {"type": "string"},
                            "flows": {"type": "array"}
                        },
                        "required": ["name"]
                    }
                },
                "target_endpoints": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "url": {"type": "string"}
                        },
                        "required": ["name"]
                    }
                }
            }
        }

    def validate_file_path(self, file_path: str) -> Tuple[bool, Optional[str]]:
        """
        Validate that a file path exists and meets size requirements.
        Returns (is_valid, error_message)
        """
        try:
            if not file_path or not isinstance(file_path, str):
                return False, "File path must be a non-empty string"

            if not os.path.exists(file_path):
                return False, f"File does not exist: {file_path}"

            if not os.access(file_path, os.R_OK):
                return False, f"File is not readable: {file_path}"

            # Check file size
            file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
            max_size = self.config.get('MAX_FILE_SIZE_MB', 100)
            if file_size_mb > max_size:
                return False, f"File size ({file_size_mb:.2f} MB) exceeds maximum allowed size ({max_size} MB)"

            # Validate file extension for bundles
            if not self._is_valid_bundle_file(file_path):
                return False, f"Invalid file type. Expected .zip or directory for Apigee bundle"

            self.logger.debug(f"File path validation passed: {file_path}")
            return True, None

        except Exception as e:
            return False, f"File validation error: {str(e)}"

    def validate_directory_path(self, dir_path: str) -> Tuple[bool, Optional[str]]:
        """
        Validate that a directory path exists and is writable.
        Returns (is_valid, error_message)
        """
        try:
            if not dir_path or not isinstance(dir_path, str):
                return False, "Directory path must be a non-empty string"

            if not os.path.exists(dir_path):
                # Try to create the directory
                try:
                    os.makedirs(dir_path, exist_ok=True)
                    self.logger.info(f"Created output directory: {dir_path}")
                except OSError as e:
                    return False, f"Cannot create directory: {str(e)}"
            elif not os.path.isdir(dir_path):
                return False, f"Path exists but is not a directory: {dir_path}"

            if not os.access(dir_path, os.W_OK):
                return False, f"Directory is not writable: {dir_path}"

            self.logger.debug(f"Directory path validation passed: {dir_path}")
            return True, None

        except Exception as e:
            return False, f"Directory validation error: {str(e)}"

    def validate_parsed_data(self, parsed_data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """
        Validate the structure of parsed Apigee bundle data.
        Returns (is_valid, error_message)
        """
        try:
            if not isinstance(parsed_data, dict):
                return False, "Parsed data must be a dictionary"

            # Check for required top-level keys
            required_keys = ['proxy_endpoints', 'target_endpoints']
            for key in required_keys:
                if key not in parsed_data:
                    return False, f"Missing required key: {key}"

            # Validate against schema if enabled
            if self.config.get('VALIDATION_ENABLED', True):
                try:
                    jsonschema.validate(instance=parsed_data, schema=self.bundle_schema)
                except ValidationError as e:
                    return False, f"Data validation failed: {e.message}"

            # Additional business logic validation
            if not parsed_data.get('proxy_endpoints'):
                return False, "No proxy endpoints found in bundle"

            if not parsed_data.get('target_endpoints'):
                return False, "No target endpoints found in bundle"

            self.logger.debug("Parsed data validation passed")
            return True, None

        except Exception as e:
            return False, f"Data validation error: {str(e)}"

    def validate_kong_config(self, kong_config_yaml_content: str) -> Tuple[bool, Optional[str]]:
        """
        Validate generated Kong configuration using `deck gateway validate`.
        Returns (is_valid, error_message)
        """
        if not kong_config_yaml_content:
            return False, "Kong configuration content is empty."

        # Create a temporary file to write the Kong YAML content
        with tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.yml') as temp_kong_config_file:
            temp_kong_config_file.write(kong_config_yaml_content)
            temp_file_path = temp_kong_config_file.name

        self.logger.info(f"Running deck validation on temporary file: {temp_file_path}")
        
        try:
            # Execute `deck gateway validate` command
            # Using --no-color to prevent issues with capturing output
            # Assuming 'deck' is in the system's PATH
            result = subprocess.run(
                ["deck", "gateway", "validate", "-f", temp_file_path, "--no-color"],
                capture_output=True,
                text=True,
                check=False # Do not raise exception for non-zero exit codes
            )

            if result.returncode == 0:
                self.logger.info("Kong configuration validated successfully by deck.")
                return True, None
            else:
                error_message = f"Deck validation failed:\n{result.stderr}\n{result.stdout}"
                self.logger.error(error_message)
                return False, error_message
        except FileNotFoundError:
            error_message = "Deck (declarative config) command not found. Please ensure 'deck' is installed and available in your system's PATH."
            self.logger.error(error_message)
            return False, error_message
        except Exception as e:
            error_message = f"An unexpected error occurred during deck validation: {str(e)}"
            self.logger.error(error_message)
            return False, error_message
        finally:
            # Clean up the temporary file
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
                self.logger.debug(f"Removed temporary deck validation file: {temp_file_path}")


    def _is_valid_bundle_file(self, file_path: str) -> bool:
        """
        Check if the file is a valid Apigee bundle (zip or directory).
        """
        if os.path.isdir(file_path):
            return True

        if zipfile.is_zipfile(file_path):
            return True

        return False
