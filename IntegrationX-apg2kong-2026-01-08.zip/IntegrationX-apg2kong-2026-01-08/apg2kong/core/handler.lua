-- Generic handler for apg2kong custom plugins.
-- This template includes all available Kong plugin lifecycle phases.
-- Unused phases can be removed for production to avoid unnecessary overhead.

-- Load required Kong modules.
local BasePlugin = require "kong.plugins.base_plugin"

-- Define the plugin handler table.
local GenericHandler = BasePlugin:extend()

-- The constructor is called once per request.
-- It receives the plugin configuration.
function GenericHandler:new()
  GenericHandler.super.new(self, "kong_generic_plugin")
end

-- Executed for the first request on a worker.
-- Use for initializing worker-specific data.
function GenericHandler:init_worker()
  GenericHandler.super.init_worker(self)
  -- kong.log.info("Initializing worker...")
end

-- Executed during the SSL handshake.
-- Use for dynamic SSL certificate selection.
function GenericHandler:certificate(conf)
  GenericHandler.super.certificate(self, conf)
  -- kong.log.info("Certificate phase...")
end

-- Executed before Kong routes the request to the upstream service.
function GenericHandler:rewrite(conf)
  GenericHandler.super.rewrite(self, conf)
  -- kong.log.info("Rewrite phase...")
end

-- The most common phase for request validation and transformation.
function GenericHandler:access(conf)
  GenericHandler.super.access(self, conf)
  -- kong.log.info("Access phase...")
  -- Example: Accessing configuration
  -- local message = "Parameter value: " .. conf.example_parameter
  -- kong.response.set_header("X-Plugin-Message", message)
end

-- Executed for each response from the upstream service.
-- Use for modifying response headers.
function GenericHandler:header_filter(conf)
  GenericHandler.super.header_filter(self, conf)
  -- kong.log.info("Header filter phase...")
end

-- Executed just before sending the response to the client.
-- Use for modifying the response body.
function GenericHandler:body_filter(conf)
  GenericHandler.super.body_filter(self, conf)
  -- kong.log.info("Body filter phase...")
end

-- Executed after the response has been sent to the client.
-- Use for logging request/response data.
function GenericHandler:log(conf)
  GenericHandler.super.log(self, conf)
  -- kong.log.info("Log phase...")
end

return GenericHandler