"""
Module for transpiling custom Apigee logic (JS, Java, Python) to Lua.
"""

# This will act as a wrapper to call the jartolua, jstolua, and pytolua tools.