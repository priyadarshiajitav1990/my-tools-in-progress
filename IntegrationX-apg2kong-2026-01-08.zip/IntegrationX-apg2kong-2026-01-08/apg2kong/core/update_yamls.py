import os
import re

def get_config_block(schema_content):
    try:
        start_index = schema_content.find('config = {')
        if start_index == -1:
            return None

        content_after_start = schema_content[start_index:]
        brace_count = 0
        end_index = -1
        for i, char in enumerate(content_after_start):
            if char == '{':
                brace_count += 1
            elif char == '}':
                brace_count -= 1
            
            if brace_count == 0:
                end_index = i
                break
        
        if end_index == -1:
            return None

        return content_after_start[:end_index+1]

    except Exception:
        return None

def main():
    for dirpath, _, filenames in os.walk('custom-plugins'):
        for filename in filenames:
            if filename == 'schema.lua':
                schema_path = os.path.join(dirpath, filename)
                plugin_name = os.path.basename(dirpath)
                yml_path = os.path.join('custom_plugins_ymls', f'{plugin_name}.yml')

                if not os.path.exists(yml_path):
                    continue

                with open(schema_path, 'r', encoding='utf-8') as f:
                    schema_content = f.read()
                
                config_block = get_config_block(schema_content)

                if not config_block:
                    continue
                
                commented_config = "    # " + "\n    # ".join(config_block.splitlines())

                with open(yml_path, 'r', encoding='utf-8') as f:
                    yml_lines = f.readlines()

                new_yml_lines = []
                name_line_index = -1
                for i, line in enumerate(yml_lines):
                    if 'name:' in line:
                        name_line_index = i
                
                if name_line_index == -1:
                    continue
                
                # Keep lines up to and including the name line
                new_yml_lines.extend(yml_lines[:name_line_index+1])
                # Add the commented config block
                new_yml_lines.append(commented_config + "\n")

                with open(yml_path, 'w', encoding='utf-8') as f:
                    f.writelines(new_yml_lines)

if __name__ == '__main__':
    main()