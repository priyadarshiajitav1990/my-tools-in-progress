import os
import json
import yaml
import re # Import the 're' module
from typing import Dict, Any, List, Optional
from logging import Logger
from .exceptions import MappingError, InvalidConfigError
from .custom_plugin_generator import CustomPluginGenerator

class KongConfigGenerator:
    """
    Generates Kong configuration from parsed Apigee bundle data.
    Handles enterprise features like conditional flows, routing, and plugin ordering.
    """

    def __init__(self, logger: Logger):
        self.logger = logger
        self.plugin_compatibility = self._load_plugin_compatibility()
        
        policy_mapping_path = os.path.join(os.path.dirname(__file__), '..', 'configs', 'policy-to-plugin.json')
        try:
            with open(policy_mapping_path, 'r') as f:
                raw_policy_mapping = json.load(f)
            self.policy_to_plugin_mapping = raw_policy_mapping # Store original for reference if needed
            self.normalized_policy_to_plugin_mapping = {
                self._normalize_policy_type_name(k): v for k, v in raw_policy_mapping.items()
            }
            self.logger.debug("policy-to-plugin.json loaded and normalized successfully.")
        except FileNotFoundError:
            self.logger.error(f"policy-to-plugin.json not found at {policy_mapping_path}. Policy mapping will be empty.")
            self.policy_to_plugin_mapping = {}
            self.normalized_policy_to_plugin_mapping = {}
        except json.JSONDecodeError as e:
            self.logger.error(f"Error decoding policy-to-plugin.json: {e}. Policy mapping will be empty.")
            self.policy_to_plugin_mapping = {}
            self.normalized_policy_to_plugin_mapping = {}

        self.target_endpoint_upstream_map = {}
        self.unmapped_policies_summary = [] # New list to store unmapped policy details
        self.policy_mappers = {}

        handler_template_path = os.path.join(os.path.dirname(__file__), 'templates', 'handler_template.lua')
        schema_template_path = os.path.join(os.path.dirname(__file__), 'templates', 'schema_template.lua')
        self.custom_plugin_generator = CustomPluginGenerator(handler_template_path, schema_template_path)

    def _normalize_policy_type_name(self, policy_type_name: str) -> str:
        """
        Normalizes a policy type name by removing hyphens and ensuring PascalCase.
        Example: "Verify-API-Key" -> "VerifyAPIKey"
        """
        return policy_type_name.replace('-', '')

    async def generate(self, parsed_data: Dict[str, Any], apigee_proxy_name: str) -> str:
        """
        Generate Kong configuration YAML from parsed Apigee data.
        Handles custom flows, conditional flows, policy execution orders, and routing.
        """
        self.logger.info("Starting Kong configuration generation")

        # Input validation for parsed_data
        if not isinstance(parsed_data, dict):
            raise InvalidConfigError("Input 'parsed_data' must be a dictionary.")

        expected_top_level_keys = {
            'proxy_endpoints': list,
            'target_endpoints': list,
            'policies': dict
        }

        for key, expected_type in expected_top_level_keys.items():
            if key not in parsed_data:
                raise InvalidConfigError(f"Missing top-level key '{key}' in parsed_data.")
            if not isinstance(parsed_data[key], expected_type):
                raise InvalidConfigError(f"Expected '{key}' to be of type {expected_type.__name__}, but got {type(parsed_data[key]).__name__}.")

        kong_config = {
            '_format_version': '3.0',
            'services': [],
            'routes': [],
            'plugins': [],
            'upstreams': [],
            'certificates': [],
            'ca_certificates': [],
            'consumers': [],
            'custom_entities': {}
        }

        try:
            # Process target endpoints
            for target_endpoint in parsed_data.get('target_endpoints', []):
                upstream = self._process_target_endpoint(target_endpoint, apigee_proxy_name)
                if upstream:
                    cleaned_upstream = self._clean_entity_config(upstream, 'upstream')
                    kong_config['upstreams'].append(cleaned_upstream)

            # Process proxy endpoints
            for proxy_endpoint in parsed_data.get('proxy_endpoints', []):
                service, routes = await self._process_proxy_endpoint(proxy_endpoint, parsed_data, apigee_proxy_name)
                if service:
                    cleaned_service = self._clean_entity_config(service, 'service')
                    kong_config['services'].append(cleaned_service)
                cleaned_routes = [self._clean_entity_config(route, 'route') for route in routes]
                kong_config['routes'].extend(cleaned_routes)

            # Validate generated config
            await self._validate_generated_config(kong_config)

            # Convert to YAML
            yaml_config = yaml.dump(kong_config, default_flow_style=False, sort_keys=False)
            self.logger.info("Kong configuration generation completed successfully")
            return yaml_config

        except Exception as e:
            self.logger.error(f"Kong configuration generation failed: {str(e)}", exc_info=True)
            raise

    async def _process_proxy_endpoint(self, proxy_endpoint: Dict[str, Any], parsed_data: Dict[str, Any], apigee_proxy_name: str) -> tuple:
        """
        Process a proxy endpoint into Kong service and routes.
        Handles conditional flows, route rules, and plugin ordering.
        """
        proxy_endpoint_name = proxy_endpoint.get('name', 'default')
        self.logger.info(f"Processing proxy endpoint: {proxy_endpoint_name}")
        service_name = f"{apigee_proxy_name}-{proxy_endpoint_name}"
        base_path = proxy_endpoint.get('base_path', '/')
        virtual_hosts = proxy_endpoint.get('virtual_hosts', [])

        # Determine the target endpoint for the service
        service_target_endpoint_name = None
        route_rules = proxy_endpoint.get('route_rules', [])
        
        try:
            for rule in route_rules:
                if not rule.get('condition'): # Assuming the rule without a condition is the default
                    service_target_endpoint_name = rule.get('target_endpoint')
                    break
            
            if not service_target_endpoint_name and parsed_data.get('target_endpoints'):
                # Fallback: if no explicit default route rule, use the first target endpoint
                if parsed_data['target_endpoints']: # Ensure there's at least one target endpoint
                    service_target_endpoint_name = parsed_data['target_endpoints'][0].get('name')

            service_url = None
            if service_target_endpoint_name:
                service_url = self._get_target_endpoint_url(service_target_endpoint_name, parsed_data)

            if not service_url:
                self.logger.warning(f"Could not determine a target URL for service '{service_name}' from default route rules or first target endpoint. Using placeholder.")
                service_url = f'http://backend{service_name}' # Fallback placeholder

        except Exception as e:
            self.logger.error(f"Error determining service URL for proxy endpoint '{proxy_endpoint_name}': {e}", exc_info=True)
            service_url = f'http://backend{service_name}' # Ensure fallback


        # Create Kong service
        service = {
            'name': service_name,
            'plugins': []
        }

        # Prefer setting 'upstream' for the service if a default target endpoint was found
        if service_target_endpoint_name:
            default_upstream_name = self.target_endpoint_upstream_map.get(service_target_endpoint_name)
            if default_upstream_name:
                service['upstream'] = {'name': default_upstream_name}
                self.logger.debug(f"Service '{service_name}' configured to point to upstream '{default_upstream_name}'.")
            else:
                service['url'] = service_url # Fallback to URL if upstream not found (shouldn't happen if _process_target_endpoint ran first)
                self.logger.warning(f"Default upstream for target endpoint '{service_target_endpoint_name}' not found in map. Service '{service_name}' will use URL '{service_url}'.")
        else:
            service['url'] = service_url # Fallback to URL if no default target endpoint was determined
            self.logger.warning(f"No default target endpoint determined for service '{service_name}'. Service will use URL '{service_url}'.")

        routes = []

        # Process route rules for conditional routing
        route_rules = proxy_endpoint.get('route_rules', [])
        if route_rules:
            for rule in route_rules:
                route = self._create_route_from_rule(rule, service_name, base_path, virtual_hosts, apigee_proxy_name)
                if route:
                    routes.append(route)

        # If no route rules, create default route
        if not routes:
            route = {
                'name': f'{apigee_proxy_name}-{service_name}-default',
                'service': {'name': service_name},
                'paths': [base_path],
                'hosts': virtual_hosts if virtual_hosts else None,
                'plugins': []
            }
            routes.append(route)

        # Process flows and attach plugins in order
        await self._process_flows(proxy_endpoint, service, routes, parsed_data)
        self.logger.info(f"Finished processing proxy endpoint: {proxy_endpoint_name}")
        return service, routes

    async def _process_flows(self, proxy_endpoint: Dict[str, Any], service: Dict[str, Any], routes: List[Dict[str, Any]], parsed_data: Dict[str, Any]):
        """
        Process preflow, postflow, and conditional flows.
        Attach plugins to service/routes with proper ordering and conditions.
        """
        proxy_endpoint_name = proxy_endpoint.get('name', 'unknown')
        self.logger.info(f"Processing flows for proxy endpoint: {proxy_endpoint_name}")
        policies = parsed_data.get('policies', {})

        # Process preflow (request)
        preflow = proxy_endpoint.get('preflow', {})
        if preflow.get('request'):
            plugins = await self._process_flow_steps(preflow['request'], policies, 'request')
            service['plugins'].extend(plugins)

        # Process conditional flows
        flows = proxy_endpoint.get('flows', [])
        for flow in flows:
            condition = flow.get('condition')
            flow_plugins = []

            # Process request steps
            if flow.get('request'):
                request_plugins = await self._process_flow_steps(flow['request'], policies, 'request')
                flow_plugins.extend(request_plugins)

            # Process response steps
            if flow.get('response'):
                response_plugins = await self._process_flow_steps(flow['response'], policies, 'response')
                flow_plugins.extend(response_plugins)

            # Attach plugins with condition
            if flow_plugins:
                if condition:
                    # For conditional flows, create route with condition
                    conditional_route = {
                        'name': f"{proxy_endpoint['name']}-flow-{flow['name']}",
                        'service': {'name': service['name']},
                        'expression': self._convert_condition_to_kong_expression(condition),
                        'plugins': flow_plugins
                    }
                    routes.append(conditional_route)
                else:
                    # For unconditional flows, add to service
                    service['plugins'].extend(flow_plugins)

        # Process postflow (response)
        postflow = proxy_endpoint.get('postflow', {})
        if postflow.get('response'):
            plugins = await self._process_flow_steps(postflow['response'], policies, 'response')
            service['plugins'].extend(plugins)
        
        self.logger.info(f"Finished processing flows for proxy endpoint: {proxy_endpoint_name}")

    async def _process_flow_steps(self, steps: List[Dict[str, Any]], policies: Dict[str, Any], phase: str) -> List[Dict[str, Any]]:
        """
        Process flow steps into Kong plugins, maintaining order and conditions.
        """
        self.logger.info(f"Processing {len(steps)} flow steps for phase: {phase}")
        plugins = []

        for step in steps:
            policy_name = step.get('name')
            if not policy_name or policy_name not in policies:
                continue

            policy_data = policies[policy_name]
            condition = step.get('condition')

            # Map policy to Kong plugin
            mapped_plugins = await self._map_policy_to_plugin(policy_data)
            for plugin_config in mapped_plugins:
                # Add condition if present
                if condition:
                    plugin_config.setdefault('condition', self._convert_condition_to_kong_expression(condition))

                plugins.append(plugin_config)

        self.logger.info(f"Finished processing flow steps for phase: {phase}. Generated {len(plugins)} plugins.")
        return plugins

    async def _map_policy_to_plugin(self, policy_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Map Apigee policy to Kong plugin configuration.
        Returns a list of Kong plugin configurations.
        """
        policy_type = policy_data.get('type')
        policy_name = policy_data.get('name')
        policy_config = policy_data.get('config', {})

        # Import here to avoid circular imports
        from .policy_mappers.base_policy_mapper import BasePolicyMapper
        from .exceptions import MappingError # Import the custom exception

        mapper_class = self._get_policy_mapper_class(policy_type)
        if mapper_class:
            mapper = mapper_class(self.logger, self, self.normalized_policy_to_plugin_mapping)
            try:
                # Mappers should now return a list of plugin configurations
                mapped_plugins = mapper.map(policy_name, policy_config)
                
                if not isinstance(mapped_plugins, list):
                    mapped_plugins = [mapped_plugins] if mapped_plugins else []

                self.logger.debug(f"KongConfigGenerator._map_policy_to_plugin: mapped_plugins from mapper.map: {mapped_plugins}")

                valid_plugins = []
                for plugin_item in mapped_plugins:
                    self.logger.debug(f"KongConfigGenerator._map_policy_to_plugin: processing plugin_item: {plugin_item} (type: {type(plugin_item)})")
                    plugin_config = {}
                    if isinstance(plugin_item, str):
                        plugin_config = {'name': plugin_item, 'config': {}}
                    elif isinstance(plugin_item, dict):
                        plugin_config = plugin_item
                    else:
                        self.logger.warning(f"Invalid plugin configuration format for policy {policy_name}: {plugin_item}. Skipping.")
                        continue
                    
                    self.logger.debug(f"KongConfigGenerator._map_policy_to_plugin: plugin_config after conversion: {plugin_config} (type: {type(plugin_config)})")
                    if plugin_config and self.validate_plugin_config(plugin_config.get('name'), plugin_config.get('config', {})):
                        valid_plugins.append(plugin_config)
                    else:
                        self.logger.warning(f"Plugin config validation failed or returned None for one of the plugins mapped from policy {policy_name}")
                return valid_plugins
            except NotImplementedError:
                self.logger.error(f"The 'map' method has not been implemented for the '{mapper.__class__.__name__}' mapper, which is responsible for the '{policy_name}' policy of type '{policy_type}'.")
                raise MappingError(f"Mapper not implemented for policy '{policy_name}' (Type: {policy_type})", policy_name=policy_name, policy_type=policy_type)
            except MappingError: # Re-raise custom mapping errors
                raise
            except Exception as e:
                self.logger.error(f"Failed to map policy {policy_name}: {e}", exc_info=True)
                raise MappingError(f"Unhandled error during mapping of policy '{policy_name}' (Type: {policy_type}): {e}", policy_name=policy_name, policy_type=policy_type)

        return [] # Return empty list if no mapper class found or mapping fails

    def _get_policy_mapper_class(self, policy_type: str):
        """
        Get the appropriate policy mapper class for the policy type.
        """
        mappers = {
            'OAuthV2': 'core.policy_mappers.oauth2.OAuth2PolicyMapper',
            'CORS': 'core.policy_mappers.cors.CORSPolicyMapper',
            'Caching': 'core.policy_mappers.caching.CachingPolicyMapper',
            'ErrorHandling': 'core.policy_mappers.error_handling.ErrorHandlingPolicyMapper',
            'StatisticsCollector': 'core.policy_mappers.statistics_collector.StatisticsCollectorPolicyMapper',
            'LDAPAuthentication': 'core.policy_mappers.ldap.LDAPAuthenticationMapper',
            'SAMLAssertion': 'core.policy_mappers.saml.SAMLAssertionMapper',
            'ExtensionCallout': 'core.policy_mappers.extension.ExtensionCalloutMapper',
            'MessageLogging': 'core.policy_mappers.message_logging_mapper.MessageLoggingMapper',
            'RaiseFault': 'core.policy_mappers.raise_fault_mapper.RaiseFaultMapper',
            'ResponseCache': 'core.policy_mappers.response_cache_mapper.ResponseCacheMapper',
            'JSONThreatProtection': 'core.policy_mappers.json_threat_protection_mapper.JSONThreatProtectionMapper',
            'VerifyAPIKey': 'core.policy_mappers.verify_api_key_mapper.VerifyAPIKeyMapper',
            'Script': 'core.policy_mappers.script_mapper.ScriptPolicyMapper', # For custom Lua/JS/Python policies
            'Javascript': 'core.policy_mappers.script_mapper.ScriptPolicyMapper', # Alias for Javascript policies
            'JavaCallout': 'core.policy_mappers.java_callout_mapper.JavaCalloutMapper', # For Java JAR policies
            # Placeholder mappers for policies not yet fully implemented to avoid silent failures
            'Quota': 'core.policy_mappers.quota_mapper.QuotaMapper',
            'SpikeArrest': 'core.policy_mappers.spike_arrest_mapper.SpikeArrestMapper',
            'AccessControl': 'core.policy_mappers.access_control_mapper.AccessControlMapper',
            'ExtractVariables': 'core.policy_mappers.extract_variables_mapper.ExtractVariablesMapper',
            'AssignMessage': 'core.policy_mappers.assign_message_mapper.AssignMessageMapper',
            'ServiceCallout': 'core.policy_mappers.service_callout_mapper.ServiceCalloutMapper',
            'BasicAuthentication': 'core.policy_mappers.basic_authentication_mapper.BasicAuthenticationMapper',
            'PopulateCache': 'core.policy_mappers.populate_cache_mapper.PopulateCacheMapper',
            'LookupCache': 'core.policy_mappers.lookup_cache_mapper.LookupCacheMapper',
            'InvalidateCache': 'core.policy_mappers.invalidate_cache_mapper.InvalidateCacheMapper',
            'JSONToXML': 'core.policy_mappers.json_to_xml_mapper.JsonToXmlMapper',
            'XMLToJSON': 'core.policy_mappers.xml_to_json_mapper.XmlToJsonMapper',
            'JWT': 'core.policy_mappers.jwt_mapper.JwtMapper', # Generic JWT mapper
        }

        mapper_path = mappers.get(policy_type)
        if mapper_path:
            try:
                module_path, class_name = mapper_path.rsplit('.', 1)
                module = __import__(module_path, fromlist=[class_name])
                return getattr(module, class_name)
            except (ImportError, AttributeError):
                self.logger.warning(f"Could not import mapper for {policy_type}: {mapper_path}")

        return None

    def _create_route_from_rule(self, rule: Dict[str, Any], service_name: str, base_path: str, virtual_hosts: List[str], apigee_proxy_name: str) -> Optional[Dict[str, Any]]:
        """
        Create Kong route from Apigee route rule.
        Handles conditional routing.
        """
        rule_name = rule.get('name', 'unnamed-rule')
        self.logger.info(f"Processing route rule: {rule_name} for service {service_name}")
        route_name = f"{apigee_proxy_name}-{rule.get('name', f'{service_name}-route')}"
        target_endpoint = rule.get('target_endpoint')
        condition = rule.get('condition')

        route = {
            'name': route_name,
            'paths': [base_path] if base_path.endswith('/') else [base_path, f"{base_path}/"], # Handle trailing slash for consistency
            'hosts': virtual_hosts if virtual_hosts else None,
            'plugins': [],
            'strip_path': True # Explicitly set strip_path to true
        }

        if target_endpoint:
            upstream_name = self.target_endpoint_upstream_map.get(target_endpoint)
            if upstream_name:
                route['upstream'] = {'name': upstream_name}
                self.logger.debug(f"Route '{route_name}' configured to point to upstream '{upstream_name}'.")
            else:
                route['service'] = {'name': service_name}
                self.logger.warning(f"Target endpoint '{target_endpoint}' for route '{route_name}' not found in upstream map. Falling back to service '{service_name}'.")
        else:
            route['service'] = {'name': service_name}
            self.logger.debug(f"Route '{route_name}' configured to point to service '{service_name}' (no specific target endpoint).")

        # Add condition for conditional routing
        if condition:
            route['expression'] = self._convert_condition_to_kong_expression(condition)

        self.logger.info(f"Finished processing route rule: {rule_name}, created route: {route_name}")
        return route


    def _convert_condition_to_kong_expression(self, condition: str) -> str:
        """
        Convert Apigee condition to Kong expression for conditional routing/plugin execution.
        This enhancement aims for more robust conversion, mapping common Apigee variables
        and operators to Kong's expression language.
        """
        kong_expression = condition

        # Map Apigee variables to Kong equivalents
        kong_expression = kong_expression.replace('request.path', 'http.path')
        kong_expression = kong_expression.replace('request.method', 'http.method')
        kong_expression = kong_expression.replace('request.uri', 'http.uri')
        kong_expression = kong_expression.replace('request.querystring', 'http.query')
        kong_expression = kong_expression.replace('client.ip', 'client.ip')
        kong_expression = kong_expression.replace('proxy.pathsuffix', 'http.path')
        kong_expression = kong_expression.replace('response.status.code', 'response.status')
        kong_expression = kong_expression.replace('response.reason.phrase', 'response.reason')

        # Handle request headers: Apigee uses request.header.X-Header, Kong uses http.headers.x_header
        import re
        def replace_header_var(match):
            header_name = match.group(1)
            # Kong converts header names to lowercase and replaces hyphens with underscores
            kong_header_name = header_name.lower().replace('-', '_')
            return f'http.headers.{kong_header_name}'
        kong_expression = re.sub(r'request.header.(\w+(?:-\w+)*)', replace_header_var, kong_expression)

        # Handle query parameters: Apigee uses request.queryparam.paramName, Kong uses http.queries.paramName
        kong_expression = kong_expression.replace('request.queryparam.', 'http.queries.')
        
        # Handle form parameters: Apigee uses request.formparam.paramName, Kong uses http.forms.paramName
        kong_expression = kong_expression.replace('request.formparam.', 'http.forms.')

        # Map common operators and keywords (case-insensitive where applicable)
        kong_expression = re.sub(r'\bOR\b', '||', kong_expression, flags=re.IGNORECASE)
        kong_expression = re.sub(r'\bAND\b', '&&', kong_expression, flags=re.IGNORECASE)
        kong_expression = re.sub(r'\bNOT\b', '!', kong_expression, flags=re.IGNORECASE)
        kong_expression = kong_expression.replace('=', '==') # Apigee uses = for equality, Kong uses ==
        kong_expression = kong_expression.replace(' != ', ' ~= ') # Not equals
        kong_expression = kong_expression.replace(' <= ', ' <= ')
        kong_expression = kong_expression.replace(' >= ', ' >= ')
        kong_expression = kong_expression.replace(' < ', ' < ')
        kong_expression = kong_expression.replace(' > ', ' > ')
        kong_expression = kong_expression.replace(' ~ ', ' ~~ ') # Matches regex (Apigee ~ to Kong ~~ for string patterns)

        # Ensure that comparisons with '==' are not double-converted from '='
        kong_expression = kong_expression.replace('===', '==')

        # Remove extra spaces around operators
        kong_expression = re.sub(r'\s*([=><!~|&]+)\s*', r'\1', kong_expression)

        self.logger.debug(f"Converted Apigee condition '{condition}' to Kong expression '{kong_expression}'")
        return kong_expression

    def _process_target_endpoint(self, target_endpoint: Dict[str, Any], apigee_api_name: str) -> Optional[Dict[str, Any]]:
        """
        Process target endpoint into Kong upstream.
        """
        name = target_endpoint.get('name', 'default')
        self.logger.info(f"Processing target endpoint: {name} for API: {apigee_api_name}")
        url = target_endpoint.get('url')

        # Prefix the upstream name with apigee_api_name
        prefixed_name = f"{apigee_api_name}-{name}"

        if url:
            upstream = {
                'name': prefixed_name,
                'targets': [{'target': url}]
            }
            self.target_endpoint_upstream_map[name] = prefixed_name # Store mapping of original Apigee name to new Kong name
            self.logger.info(f"Finished processing target endpoint: {name}, created upstream: {prefixed_name}")
            return upstream

        self.logger.warning(f"Target endpoint '{name}' has no URL specified. Skipping upstream creation.")
        return None

    def _resolve_value(self, value: str) -> str:
        """
        Resolves Apigee variables within a string to their Kong equivalents.
        Uses Kong template strings {{...}} for direct replacement in plugin configurations.
        """
        if not isinstance(value, str):
            return value # Return non-string values as is

        # Regex to find Apigee variable patterns like {prefix.subprefix.VARIABLE_NAME}
        # This regex is more generic to capture various Apigee variable types
        # It also handles request.header and request.queryparam specifically
        # Pattern: { (group1: var_scope) . (group2: var_type) . (group3: var_name) }
        apigee_variable_pattern = re.compile(r'{([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)\.([a-zA-Z0-9_.-]+)}')
        
        def replace_apigee_var(match):
            scope = match.group(1)
            var_type = match.group(2)
            var_name = match.group(3)

            if scope == 'request':
                if var_type == 'header':
                    # Kong headers are lowercase with hyphens replaced by underscores
                    kong_header_name = var_name.lower().replace('-', '_')
                    return f'{{{{request.headers.{kong_header_name}}}}}'
                elif var_type == 'queryparam':
                    return f'{{{{request.queries.{var_name}}}}}'
                elif var_type == 'path': # Handles {request.path}
                    return f'{{{{request.path}}}}'
                elif var_type == 'method': # Handles {request.method} or {request.verb}
                    return f'{{{{request.method}}}}'
                elif var_type == 'uri': # Handles {request.uri}
                    return f'{{{{request.uri}}}}'
            elif scope == 'flow':
                # Generic flow variables. Kong usually uses kong.ctx.shared
                return f'{{{{kong.ctx.shared.{var_name}}}}}'
            elif scope == 'response':
                if var_type == 'status': # Handles {response.status.code}
                    return f'{{{{response.status}}}}'
                elif var_type == 'header':
                    kong_header_name = var_name.lower().replace('-', '_')
                    return f'{{{{response.headers.{kong_header_name}}}}}'

            self.logger.warning(f"Apigee variable pattern '{{{scope}.{var_type}.{var_name}}}' recognized but no direct Kong equivalent mapped. Using literal value.")
            return match.group(0) # Return original if no mapping found

        # Handle simple {request.path}, {request.method} patterns not covered by the generic regex
        resolved_value = value.replace('{request.path}', '{{request.path}}')
        resolved_value = resolved_value.replace('{request.method}', '{{request.method}}')
        resolved_value = resolved_value.replace('{request.uri}', '{{request.uri}}')
        resolved_value = resolved_value.replace('{request.verb}', '{{request.method}}') # Apigee verb is Kong method
        resolved_value = resolved_value.replace('{response.status.code}', '{{response.status}}')

        # Use regex for more complex patterns
        resolved_value = apigee_variable_pattern.sub(replace_apigee_var, resolved_value)
        
        if resolved_value != value:
            self.logger.debug(f"Resolved Apigee variables in '{value}' to '{resolved_value}'")
        return resolved_value

    def _get_target_endpoint_url(self, target_endpoint_name: str, parsed_data: Dict[str, Any]) -> Optional[str]:
        """
        Retrieves the URL for a given target endpoint name from parsed_data.
        """
        for te in parsed_data.get('target_endpoints', []):
            if te.get('name') == target_endpoint_name:
                return te.get('url')
        self.logger.warning(f"Target endpoint '{target_endpoint_name}' not found in parsed data.")
        return None

    def _load_plugin_compatibility(self) -> Dict[str, Any]:
        """
        Loads plugin compatibility information from plugin-compatibility.json.
        """
        compatibility_path = os.path.join(os.path.dirname(__file__), '..', 'configs', 'plugin-compatibility.json')
        try:
            with open(compatibility_path, 'r') as f:
                compatibility_data = json.load(f)
            self.logger.debug("plugin-compatibility.json loaded successfully.")
            return compatibility_data
        except FileNotFoundError:
            self.logger.warning(f"plugin-compatibility.json not found at {compatibility_path}. Using default compatibility.")
            return {"plugins": {}, "kong_enterprise_plugins": {}}
        except json.JSONDecodeError as e:
            self.logger.error(f"Error decoding plugin-compatibility.json: {e}. Using default compatibility.")
            return {"plugins": {}, "kong_enterprise_plugins": {}}

    def validate_plugin_config(self, plugin_name: str, plugin_config: Dict[str, Any]) -> bool:
        """
        Validates plugin configuration against compatibility requirements.
        """
        if plugin_name not in self.plugin_compatibility.get("plugins", {}):
            self.logger.warning(f"Plugin '{plugin_name}' not found in compatibility data. Skipping validation.")
            return True

        plugin_info = self.plugin_compatibility["plugins"][plugin_name]
        required_fields = plugin_info.get("required_fields", [])
        allowed_fields = plugin_info.get("allowed_fields")
        default_fields = plugin_info.get("default_fields", {})

        # Apply default values
        for field, default_value in default_fields.items():
            if field not in plugin_config:
                plugin_config[field] = default_value
                self.logger.debug(f"Applied default value for field '{field}' in plugin '{plugin_name}': {default_value}")

        # If allowed_fields are not explicitly defined, assume required_fields plus some common ones are allowed
        if allowed_fields is None:
            allowed_fields = set(required_fields)
            # Add some common Kong plugin config fields that are generally allowed
            allowed_fields.update(["name", "enabled", "tags", "protocols"])
            allowed_fields = list(allowed_fields)
        else:
            allowed_fields = set(allowed_fields) # Convert to set for efficient lookup

        # Remove unsupported fields from plugin_config
        fields_to_remove = []
        for field in list(plugin_config.keys()): # Iterate over a copy to allow modification
            if field not in allowed_fields:
                fields_to_remove.append(field)
                del plugin_config[field]
        
        if fields_to_remove:
            self.logger.warning(f"Removed unsupported fields {fields_to_remove} from plugin '{plugin_name}' configuration.")

        # Check required fields
        missing_fields = []
        for field in required_fields:
            if field not in plugin_config:
                missing_fields.append(field)

        if missing_fields:
            self.logger.error(f"Plugin '{plugin_name}' is missing required fields: {missing_fields}")
            return False

        self.logger.debug(f"Plugin '{plugin_name}' configuration validated successfully.")
        return True

    def check_plugin_compatibility(self, plugin_name: str, kong_version: str = "3.0.0") -> Dict[str, Any]:
        """
        Checks if a plugin is compatible with the current Kong version.
        Returns compatibility information.
        """
        compatibility_info = {
            "compatible": False,
            "min_version": None,
            "max_version": None,
            "warnings": []
        }

        if plugin_name not in self.plugin_compatibility.get("plugins", {}):
            compatibility_info["warnings"].append(f"Plugin '{plugin_name}' not found in compatibility database")
            return compatibility_info

        plugin_info = self.plugin_compatibility["plugins"][plugin_name]
        min_version = plugin_info.get("min_version")
        max_version = plugin_info.get("max_version")

        compatibility_info["min_version"] = min_version
        compatibility_info["max_version"] = max_version

        # Simple version comparison (could be enhanced with proper semver)
        try:
            kong_major = int(kong_version.split('.')[0])
            if min_version:
                min_major = int(min_version.split('.')[0])
                if kong_major < min_major:
                    compatibility_info["warnings"].append(f"Kong version {kong_version} is below minimum required {min_version}")
                    return compatibility_info

            if max_version and max_version != "3.x.x":
                max_major = int(max_version.split('.')[0])
                if kong_major > max_major:
                    compatibility_info["warnings"].append(f"Kong version {kong_version} exceeds maximum supported {max_version}")
                    return compatibility_info

            compatibility_info["compatible"] = True
        except (ValueError, IndexError):
            compatibility_info["warnings"].append("Could not parse version information")

        return compatibility_info

    def _get_allowed_fields_for_entity(self, entity_type: str) -> set:
        """
        Returns a set of allowed field names for a given Kong entity type.
        This list is based on Kong Gateway's declarative configuration schema.
        """
        if entity_type == 'service':
            return {
                'name', 'host', 'port', 'protocol', 'path', 'retries', 'connect_timeout',
                'write_timeout', 'read_timeout', 'tags', 'enabled', 'url', 'plugins', 'upstream'
            }
        elif entity_type == 'route':
            return {
                'name', 'protocols', 'methods', 'hosts', 'paths', 'headers', 'snis',
                'sources', 'destinations', 'tags', 'https_redirect_status_code',
                'regex_priority', 'strip_path', 'preserve_host', 'request_buffering',
                'response_buffering', 'service', 'upstream', 'expression', 'plugins'
            }
        elif entity_type == 'upstream':
            return {
                'name', 'slots', 'hash_on', 'hash_fallback', 'hash_on_header',
                'hash_fallback_header', 'hash_on_cookie', 'hash_on_cookie_path',
                'hash_on_query_arg', 'hash_fallback_query_arg', 'hash_on_uri',
                'hash_fallback_uri', 'tags', 'healthchecks', 'targets' # targets is a nested object
            }
        elif entity_type == 'target': # Nested within upstream
            return {
                'target', 'weight', 'tags'
            }
        else:
            return set()

    def _clean_entity_config(self, entity_config: Dict[str, Any], entity_type: str) -> Dict[str, Any]:
        """
        Removes unsupported parameters from a given entity's configuration.
        """
        allowed_fields = self._get_allowed_fields_for_entity(entity_type)
        cleaned_config = {}
        removed_fields = []

        for key, value in entity_config.items():
            if key in allowed_fields:
                if key == 'targets' and entity_type == 'upstream' and isinstance(value, list):
                    # Recursively clean targets within an upstream
                    cleaned_targets = []
                    for target in value:
                        cleaned_targets.append(self._clean_entity_config(target, 'target'))
                    cleaned_config[key] = cleaned_targets
                else:
                    cleaned_config[key] = value
            else:
                removed_fields.append(key)
        
        if removed_fields:
            self.logger.warning(f"Removed unsupported fields {removed_fields} from Kong {entity_type} configuration.")
        
        # Special handling for services: if 'upstream' is set, 'url' should not be present.
        if entity_type == 'service' and 'upstream' in cleaned_config and 'url' in cleaned_config:
            del cleaned_config['url']
            self.logger.debug(f"Removed redundant 'url' from service '{cleaned_config.get('name', 'unknown')}' because 'upstream' is defined.")
        
        return cleaned_config

    def generate_custom_plugin_template(self, plugin_name: str, plugin_type: str = "lua") -> str:
        """
        Generates a template for custom plugin development.
        """
        if plugin_type.lower() == "lua":
            template = f'''-- Custom Kong Plugin: {plugin_name}
-- Generated template for Apigee to Kong migration

local BasePlugin = require "kong.plugins.base_plugin"
local ngx = ngx
local cjson = require "cjson"

local _M = {{
    VERSION = "0.1.0",
    PRIORITY = 1000,
}}

function _M:new()
    local self = {{}}
    setmetatable(self, {{__index = _M}})
    return self
end

function _M:access(conf)
    -- Plugin logic goes here
    -- Access Apigee policy configuration via conf.apigee_policy_config
    -- Access policy name via conf.apigee_policy_name

    ngx.log(ngx.INFO, "[{plugin_name}] Processing request")
end

function _M:header_filter(conf)
    -- Optional: Modify response headers
end

function _M:body_filter(conf)
    -- Optional: Modify response body
end

function _M:log(conf)
    -- Optional: Log request/response information
end

return _M
'''
        else:
            template = f'''# Custom Kong Plugin: {plugin_name}
# Generated template for Apigee to Kong migration

class {plugin_name.title().replace('-', '')}Plugin:
    """
    Custom plugin for handling {plugin_name} functionality.
    """

    def __init__(self, config):
        self.config = config

    def access(self, kong):
        """
        Plugin access phase logic.
        """
        # Plugin logic goes here
        # Access Apigee policy configuration via self.config['apigee_policy_config']
        # Access policy name via self.config['apigee_policy_name']

        kong.log.info(f"[{plugin_name}] Processing request")
        pass

    def header_filter(self, kong):
        """
        Optional: Modify response headers.
        """
        pass

    def body_filter(self, kong):
        """
        Optional: Modify response body.
        """
        pass

    def log(self, kong):
        """
        Optional: Log request/response information.
        """
        pass
'''

        return template

    async def _validate_generated_config(self, kong_config: Dict[str, Any]) -> None:
        """
        Validates all plugins in the generated Kong configuration.
        """
        self.logger.info("Validating generated Kong configuration plugins.")

        validation_errors = []
        validation_warnings = []

        # Validate plugins in services
        for service in kong_config.get('services', []):
            if 'plugins' in service:
                for plugin in service['plugins']:
                    plugin_name = plugin.get('name')
                    plugin_config = plugin.get('config', {})

                    # Check compatibility
                    compatibility = self.check_plugin_compatibility(plugin_name)
                    if not compatibility['compatible']:
                        validation_warnings.extend(compatibility['warnings'])

                    # Validate configuration
                    if not self.validate_plugin_config(plugin_name, plugin_config):
                        validation_errors.append(f"Invalid configuration for plugin '{plugin_name}' in service '{service.get('name', 'unknown')}'")

        # Validate plugins in routes
        for route in kong_config.get('routes', []):
            if 'plugins' in route:
                for plugin in route['plugins']:
                    plugin_name = plugin.get('name')
                    plugin_config = plugin.get('config', {})

                    # Check compatibility
                    compatibility = self.check_plugin_compatibility(plugin_name)
                    if not compatibility['compatible']:
                        validation_warnings.extend(compatibility['warnings'])

                    # Validate configuration
                    if not self.validate_plugin_config(plugin_name, plugin_config):
                        validation_errors.append(f"Invalid configuration for plugin '{plugin_name}' in route '{route.get('name', 'unknown')}'")

        # Log validation results
        if validation_warnings:
            for warning in validation_warnings:
                self.logger.warning(f"Plugin validation warning: {warning}")

        if validation_errors:
            for error in validation_errors:
                self.logger.error(f"Plugin validation error: {error}")
            raise ValueError(f"Plugin validation failed with {len(validation_errors)} errors. Check logs for details.")

        self.logger.info("Plugin validation completed successfully.")
