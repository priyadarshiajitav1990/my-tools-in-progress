import os
from typing import Dict, Any, Optional
from dotenv import load_dotenv
import json
import yaml # Import yaml
from logging import Logger

class Config:
    """
    Configuration management for the Apg2Kong tool.
    Supports hierarchical loading: defaults < config.yaml < .env < environment variables.
    """

    def __init__(self, logger: Logger, config_file: str = 'configs/config.yaml'):
        self.logger = logger
        self.config_file = config_file
        self._config = {}
        self._load_config()

    def _load_from_yaml(self, file_path: str) -> Dict[str, Any]:
        """Loads configuration from a YAML file."""
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as f:
                    return yaml.safe_load(f) or {}
            except yaml.YAMLError as e:
                self.logger.error(f"Error loading YAML configuration from {file_path}: {e}")
            except Exception as e:
                self.logger.error(f"An unexpected error occurred while loading YAML from {file_path}: {e}")
        return {}

    def _load_config(self):
        """Load configuration from defaults, config.yaml, .env, and environment variables."""
        # 1. Define default configuration
        defaults = {
            'APP_NAME': 'apg2kong',
            'LOG_LEVEL': 'INFO',
            'LOG_FILE': 'logs/application.log',
            'CACHE_DIR': 'cache',
            'INPUT_DIR': 'input',
            'OUTPUT_DIR': 'output',
            'MAX_FILE_SIZE_MB': 100,
            'TIMEOUT_SECONDS': 300,
            'RETRY_ATTEMPTS': 3,
            'HEALTH_CHECK_PORT': 8080,
            'METRICS_ENABLED': True,
            'KONG_FORMAT_VERSION': '3.0',
            'VALIDATION_ENABLED': True,
        }
        self._config = defaults

        # 2. Load from config.yaml
        yaml_config = self._load_from_yaml(self.config_file)
        
        # Helper to merge dictionaries, handling nested structures
        def deep_merge(target, source):
            for k, v in source.items():
                if k in target and isinstance(target[k], dict) and isinstance(v, dict):
                    target[k] = deep_merge(target[k], v)
                else:
                    target[k] = v
            return target

        self._config = deep_merge(self._config, yaml_config)
        self.logger.info(f"Configuration loaded from {self.config_file}")

        # 3. Load from .env file (lowest precedence of env vars)
        load_dotenv()

        # 4. Load from environment variables (highest precedence)
        for key, default_value in defaults.items(): # Use defaults keys to iterate known configurations
            # Check for direct environment variable (e.g., APP_NAME)
            env_value = os.getenv(key)
            if env_value is not None:
                try: # Try to parse as JSON for complex types
                    self._config[key] = json.loads(env_value)
                except (json.JSONDecodeError, TypeError):
                    # If not JSON, use as string and try to convert types
                    if isinstance(self._config.get(key), bool): # Use current config type as hint
                        self._config[key] = env_value.lower() in ('true', '1', 'yes', 'on')
                    elif isinstance(self._config.get(key), int):
                        try: self._config[key] = int(env_value)
                        except ValueError: pass # Keep existing value if conversion fails
                    elif isinstance(self._config.get(key), float):
                        try: self._config[key] = float(env_value)
                        except ValueError: pass # Keep existing value if conversion fails
                    else:
                        self._config[key] = env_value
                self.logger.debug(f"Config '{key}' overridden by environment variable.")
            
            # Check for nested config keys in env vars (e.g., LOGGING_LEVEL for logging.level)
            # This is a simplistic approach and might need more sophistication for deep nesting
            if isinstance(self._config.get(key), dict): # If it's a nested dict
                for sub_key in self._config[key].keys():
                    nested_env_key = f"{key}_{sub_key}".upper() # e.g., LOGGING_LEVEL
                    nested_env_value = os.getenv(nested_env_key)
                    if nested_env_value is not None:
                        try:
                            self._config[key][sub_key] = json.loads(nested_env_value)
                        except (json.JSONDecodeError, TypeError):
                            if isinstance(self._config[key].get(sub_key), bool):
                                self._config[key][sub_key] = nested_env_value.lower() in ('true', '1', 'yes', 'on')
                            elif isinstance(self._config[key].get(sub_key), int):
                                try: self._config[key][sub_key] = int(nested_env_value)
                                except ValueError: pass
                            elif isinstance(self._config[key].get(sub_key), float):
                                try: self._config[key][sub_key] = float(nested_env_value)
                                except ValueError: pass
                            else:
                                self._config[key][sub_key] = nested_env_value
                        self.logger.debug(f"Nested config '{nested_env_key}' overridden by environment variable.")


        # Flatten nested config from YAML for easier access if not already handled
        # This part ensures that if a YAML key is 'logging.level', it can be accessed with get('LOG_LEVEL')
        # This logic needs to be careful not to overwrite direct env vars if they were already loaded.
        flattened_config = {}
        for k, v in self._config.items():
            if isinstance(v, dict):
                for sub_k, sub_v in v.items():
                    flattened_config[f"{k.upper()}_{sub_k.upper()}"] = sub_v # e.g., LOGGING_LEVEL
            flattened_config[k.upper()] = v # Always keep the top-level key as is

        self._config = flattened_config
        self.logger.info(f"Final configuration loaded with {len(self._config)} settings")

    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value."""
        # Try to retrieve by direct key or by flattened nested key
        val = self._config.get(key)
        if val is None:
            val = self._config.get(key.upper()) # Try uppercase direct key
        if val is None:
            # Try to resolve nested key from original structure (e.g., "logging.level")
            parts = key.split('.')
            if len(parts) > 1:
                nested_val = self._config
                found = True
                for part in parts:
                    if isinstance(nested_val, dict) and part in nested_val:
                        nested_val = nested_val[part]
                    else:
                        found = False
                        break
                if found:
                    val = nested_val
        
        return val if val is not None else default

    def set(self, key: str, value: Any):
        """Set a configuration value.
        Note: This bypasses hierarchical loading and sets directly.
        Use with caution in production if immutable config is desired.
        """
        self._config[key.upper()] = value # Always store as uppercase for consistency
        self.logger.debug(f"Configuration updated: {key.upper()} = {value}")

    def validate(self) -> bool:
        """Validate configuration values."""
        try:
            # Validate file paths (assuming they are strings)
            # Need to adapt to nested structure if paths are defined there
            
            # Example for LOG_FILE, now potentially under logging.file
            log_file_path = self.get('LOGGING_FILE') # Access flattened key
            if log_file_path and not isinstance(log_file_path, str):
                self.logger.error("Invalid LOGGING_FILE: must be a string")
                return False

            cache_dir_path = self.get('CONVERSION_CACHE_DIR')
            if cache_dir_path and not isinstance(cache_dir_path, str):
                self.logger.error("Invalid CONVERSION_CACHE_DIR: must be a string")
                return False
            
            input_dir_path = self.get('CONVERSION_INPUT_DIR')
            if input_dir_path and not isinstance(input_dir_path, str):
                self.logger.error("Invalid CONVERSION_INPUT_DIR: must be a string")
                return False

            output_dir_path = self.get('CONVERSION_OUTPUT_DIR')
            if output_dir_path and not isinstance(output_dir_path, str):
                self.logger.error("Invalid CONVERSION_OUTPUT_DIR: must be a string")
                return False

            # Validate numeric values
            max_file_size = self.get('CONVERSION_MAX_FILE_SIZE_MB')
            if not isinstance(max_file_size, (int, float)) or max_file_size <= 0:
                self.logger.error("Invalid CONVERSION_MAX_FILE_SIZE_MB: must be a positive number")
                return False

            timeout_seconds = self.get('CONVERSION_TIMEOUT_SECONDS')
            if not isinstance(timeout_seconds, (int, float)) or timeout_seconds <= 0:
                self.logger.error("Invalid CONVERSION_TIMEOUT_SECONDS: must be a positive number")
                return False

            retry_attempts = self.get('CONVERSION_RETRY_ATTEMPTS')
            if not isinstance(retry_attempts, int) or retry_attempts < 0:
                self.logger.error("Invalid CONVERSION_RETRY_ATTEMPTS: must be a non-negative integer")
                return False
            
            health_check_port = self.get('SERVER_HEALTH_CHECK_PORT')
            if not isinstance(health_check_port, int) or health_check_port <= 0 or health_check_port > 65535:
                self.logger.error("Invalid SERVER_HEALTH_CHECK_PORT: must be a valid port number")
                return False

            self.logger.info("Configuration validation passed")
            return True

        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            return False

    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values."""
        return self._config.copy()
