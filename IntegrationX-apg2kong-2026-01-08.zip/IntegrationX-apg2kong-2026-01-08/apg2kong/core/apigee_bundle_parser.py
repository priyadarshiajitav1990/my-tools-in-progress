import os
import zipfile
import xml.etree.ElementTree as ET
import asyncio
from typing import Dict, Any, Tuple, List, Optional
from logging import Logger

class ApigeeBundleParser:
    """
    Parses Apigee proxy bundles (zip/XML/JSON) and extracts proxy configuration.
    """
    def __init__(self, bundle_path: Optional[str], logger: Logger):
        self.bundle_path = bundle_path
        self.logger = logger
        self.parsed_data = {
            'proxy_endpoints': [],
            'target_endpoints': [],
            'policies': {}, # Store policies by name for easier lookup
            'resources': {} # Store resources like JSS
        }
        self.policy_parsers = {
            'Quota': self._parse_quota_policy,
            'SpikeArrest': self._parse_spikearrest_policy,
            'Javascript': self._parse_javascript_policy,
            'AssignMessage': self._parse_assign_message_policy,
            'ExtractVariables': self._parse_extract_variables_policy,
            'ServiceCallout': self._parse_service_callout_policy,
            'JavaCallout': self._parse_javacallout_policy,
            'CORS': self._parse_cors_policy,
            'MessageLogging': self._parse_message_logging_policy,
            'RaiseFault': self._parse_raise_fault_policy,
            'ResponseCache': self._parse_response_cache_policy,
            'JSONThreatProtection': self._parse_json_threat_protection_policy,
            'VerifyAPIKey': self._parse_verify_api_key_policy,
            'AccessControl': self._parse_access_control_policy,
            'AccessEntity': self._parse_access_entity_policy,
            'BasicAuthentication': self._parse_basic_authentication_policy,
            'FlowCallout': self._parse_flow_callout_policy,
            'GraphQL': self._parse_graphql_policy,
            'InvalidateCache': self._parse_invalidate_cache_policy,
            'JSONToXML': self._parse_json_to_xml_policy,
            'KeyValueMapOperations': self._parse_key_value_map_operations_policy,
        }
        self.logger.debug(f"ApigeeBundleParser initialized for path: {bundle_path}")

    async def _parse_xml_file_async(self, file_path: str):
        """Asynchronously parse a single XML file."""
        try:
            loop = asyncio.get_event_loop()
            tree = await loop.run_in_executor(None, ET.parse, file_path)
            root = tree.getroot()
            rel_path = os.path.relpath(file_path, self.bundle_path).replace('\\', '/')

            if 'apiproxy/' in rel_path: # Ensure we are in the apiproxy folder
                if 'proxies/' in rel_path and 'ProxyEndpoint' in root.tag:
                    self.logger.debug(f"Detected ProxyEndpoint file: {file_path}")
                    self._parse_proxy_endpoint(os.path.basename(file_path), root)
                elif 'targets/' in rel_path and 'TargetEndpoint' in root.tag:
                    self.logger.debug(f"Detected TargetEndpoint file: {file_path}")
                    self._parse_target_endpoint(os.path.basename(file_path), root)
                elif 'policies/' in rel_path:
                    self.logger.debug(f"Detected policy file: {file_path}")
                    self._parse_policy(os.path.basename(file_path), root)
                elif 'resources/jsc/' in rel_path:
                    self.logger.debug(f"Detected JavaScript resource: {file_path}")
                    content = await loop.run_in_executor(None, self._read_resource_file, file_path)
                    self.parsed_data['resources'][os.path.basename(file_path)] = {'type': 'javascript', 'content': content}
                else:
                    self.logger.debug(f"Storing other XML file content: {file_path}")
                    # Store other relevant XMLs for inspection if needed
                    self.parsed_data[rel_path] = ET.tostring(root, encoding='unicode')
            else:
                self.logger.debug(f"Skipping non-apiproxy XML file: {file_path}")
        except ET.ParseError as e:
            self.logger.error(f"Failed to parse XML file {file_path}: {e}")
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while parsing {file_path}: {e}", exc_info=True)

    async def parse_bundle(self, bundle_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse bundle data directly from JSON structure (for testing).
        """
        self.logger.info("Parsing bundle data from JSON structure")

        # Initialize parsed data
        self.parsed_data = {
            'proxy_endpoints': [],
            'target_endpoints': [],
            'policies': {},
            'resources': {}
        }

        # Process policies
        for policy in bundle_data.get('policies', []):
            policy_name = policy.get('name')
            policy_type = policy.get('type')
            policy_config = policy.get('config', {})

            parsed_policy = {
                'type': policy_type,
                'name': policy_name,
                'config': policy_config,
                'enabled': policy.get('enabled', True),
                'continue_on_error': policy.get('continueOnError', False)
            }
            self.parsed_data['policies'][policy_name] = parsed_policy

        # Process proxy endpoints
        for proxy_ep in bundle_data.get('proxy_endpoints', []):
            endpoint = {
                'type': 'ProxyEndpoint',
                'name': proxy_ep.get('name', 'default'),
                'flows': proxy_ep.get('flows', []),
                'preflow': proxy_ep.get('preflow', {}),
                'postflow': proxy_ep.get('postflow', {}),
                'route_rules': proxy_ep.get('route_rules', []),
                'virtual_hosts': proxy_ep.get('virtual_hosts', []),
                'base_path': proxy_ep.get('base_path', '/'),
                'fault_rules': []
            }
            self.parsed_data['proxy_endpoints'].append(endpoint)

        # Process target endpoints
        for target_ep in bundle_data.get('target_endpoints', []):
            endpoint = {
                'type': 'TargetEndpoint',
                'name': target_ep.get('name', 'default'),
                'url': target_ep.get('url'),
                'details': {},
                'fault_rules': []
            }
            self.parsed_data['target_endpoints'].append(endpoint)

        self.logger.info("Bundle data parsing completed")
        return self.parsed_data

    async def parse(self) -> Dict[str, Any]:
        """
        Parse the Apigee bundle from a directory or zip and extract endpoints, flows, and policies into structured data.
        """
        self.logger.info(f"Starting to parse Apigee bundle from {self.bundle_path}")

        # Validate bundle path
        if not self.bundle_path or not isinstance(self.bundle_path, str):
            raise ValueError("Bundle path must be a non-empty string")

        if not os.path.exists(self.bundle_path):
            raise FileNotFoundError(f"Bundle path does not exist: {self.bundle_path}")

        try:
            if os.path.isdir(self.bundle_path):
                self.logger.debug(f"Bundle is a directory: {self.bundle_path}")
                xml_files = []
                for root_dir, dirs, files in os.walk(self.bundle_path):
                    for file in files:
                        if file.endswith('.xml'):
                            file_path = os.path.join(root_dir, file)
                            xml_files.append(file_path)

                if not xml_files:
                    raise ValueError(f"No XML files found in directory: {self.bundle_path}")

                # Process XML files concurrently
                tasks = [self._parse_xml_file_async(file_path) for file_path in xml_files]
                await asyncio.gather(*tasks)

                # Handle JavaScript, Lua, and Python resources synchronously
                for root_dir, dirs, files in os.walk(self.bundle_path):
                    for file in files:
                        file_path = os.path.join(root_dir, file)
                        rel_path = os.path.relpath(file_path, self.bundle_path).replace('\\', '/')
                        
                        if file.endswith('.js') and 'resources/jsc/' in rel_path:
                            self.logger.debug(f"Detected JavaScript resource: {file_path}")
                            self.parsed_data['resources'][file] = {'type': 'javascript', 'content': self._read_resource_file(file_path)}
                        elif file.endswith('.lua') and 'resources/lua/' in rel_path:
                            self.logger.debug(f"Detected Lua resource: {file_path}")
                            self.parsed_data['resources'][file] = {'type': 'lua', 'content': self._read_resource_file(file_path)}
                        elif file.endswith('.py') and 'resources/py/' in rel_path:
                            self.logger.debug(f"Detected Python resource: {file_path}")
                            self.parsed_data['resources'][file] = {'type': 'python', 'content': self._read_resource_file(file_path)}

                self.logger.info(f"Finished parsing Apigee bundle directory: {self.bundle_path}")
                return self.parsed_data

            elif zipfile.is_zipfile(self.bundle_path):
                self.logger.debug(f"Bundle is a zip file: {self.bundle_path}")
                with zipfile.ZipFile(self.bundle_path, 'r') as zip_ref:
                    xml_files = [file_in_zip for file_in_zip in zip_ref.namelist() if file_in_zip.endswith('.xml') and 'apiproxy/' in file_in_zip]

                    if not xml_files:
                        raise ValueError(f"No XML files found in apiproxy directory of zip: {self.bundle_path}")

                    # Process XML files concurrently
                    async def parse_zip_xml(file_in_zip):
                        with zip_ref.open(file_in_zip) as f:
                            try:
                                loop = asyncio.get_event_loop()
                                tree = await loop.run_in_executor(None, ET.parse, f)
                                root = tree.getroot()
                                if 'proxies/' in file_in_zip and 'ProxyEndpoint' in root.tag:
                                    self.logger.debug(f"Detected ProxyEndpoint in zip: {file_in_zip}")
                                    self._parse_proxy_endpoint(file_in_zip, root)
                                elif 'targets/' in file_in_zip and 'TargetEndpoint' in root.tag:
                                    self.logger.debug(f"Detected TargetEndpoint in zip: {file_in_zip}")
                                    self._parse_target_endpoint(file_in_zip, root)
                                elif 'policies/' in file_in_zip:
                                    self.logger.debug(f"Detected policy in zip: {file_in_zip}")
                                    self._parse_policy(file_in_zip, root)
                                else:
                                    self.logger.debug(f"Storing other XML content from zip: {file_in_zip}")
                                    self.parsed_data[file_in_zip] = ET.tostring(root, encoding='unicode')
                            except ET.ParseError as e:
                                self.logger.error(f"Failed to parse XML file {file_in_zip} from zip: {e}")
                                raise
                            except Exception as e:
                                self.logger.error(f"An unexpected error occurred while parsing {file_in_zip} from zip: {e}", exc_info=True)
                                raise

                    tasks = [parse_zip_xml(file_in_zip) for file_in_zip in xml_files]
                    await asyncio.gather(*tasks)

                    # Handle JavaScript, Lua, and Python resources
                    for file_in_zip in zip_ref.namelist():
                        if 'resources/jsc/' in file_in_zip and file_in_zip.endswith('.js'):
                            self.logger.debug(f"Detected JavaScript resource in zip: {file_in_zip}")
                            with zip_ref.open(file_in_zip) as f:
                                self.parsed_data['resources'][os.path.basename(file_in_zip)] = {'type': 'javascript', 'content': f.read().decode('utf-8')}
                        elif 'resources/lua/' in file_in_zip and file_in_zip.endswith('.lua'):
                            self.logger.debug(f"Detected Lua resource in zip: {file_in_zip}")
                            with zip_ref.open(file_in_zip) as f:
                                self.parsed_data['resources'][os.path.basename(file_in_zip)] = {'type': 'lua', 'content': f.read().decode('utf-8')}
                        elif 'resources/py/' in file_in_zip and file_in_zip.endswith('.py'):
                            self.logger.debug(f"Detected Python resource in zip: {file_in_zip}")
                            with zip_ref.open(file_in_zip) as f:
                                self.parsed_data['resources'][os.path.basename(file_in_zip)] = {'type': 'python', 'content': f.read().decode('utf-8')}

                self.logger.info(f"Finished parsing Apigee bundle zip: {self.bundle_path}")
                return self.parsed_data
            else:
                raise ValueError(f"Unsupported bundle format. Provided path: {self.bundle_path}. Please provide a directory or zip file.")

        except Exception as e:
            self.logger.error(f"Error parsing Apigee bundle: {e}", exc_info=True)
            raise

    def _read_resource_file(self, file_path: str) -> str:
        """Reads content of a resource file (e.g., JavaScript)."""
        self.logger.debug(f"Reading resource file: {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                self.logger.debug(f"Successfully read resource file: {file_path}")
                return content
        except Exception as e:
            self.logger.error(f"Failed to read resource file {file_path}: {e}", exc_info=True)
            return ""

    def _get_element_text_and_ref(self, parent_element, tag_name: str) -> Tuple[str | None, str | None]:
        """Helper to extract text and 'ref' attribute from a child element."""
        elem = parent_element.find(tag_name)
        text = elem.text.strip() if elem is not None and elem.text else None
        ref = elem.attrib.get('ref') if elem is not None else None
        self.logger.debug(f"Extracted '{tag_name}': text='{text}', ref='{ref}'")
        return text, ref

    def _parse_proxy_endpoint(self, file, root):
        """Extract ProxyEndpoint details (flows, preflow, postflow, etc.)"""
        endpoint_name = root.attrib.get('name', os.path.splitext(file)[0])
        self.logger.debug(f"Parsing ProxyEndpoint '{endpoint_name}' from file '{file}'")
        endpoint = {'type': 'ProxyEndpoint', 'name': endpoint_name, 'flows': [], 'preflow': {}, 'postflow': {}, 'route_rules': [], 'virtual_hosts': [], 'base_path': '/', 'fault_rules': [], 'status': 'parsed'}
        
        # Extract BasePath and VirtualHosts
        http_connection = root.find('HTTPProxyConnection')
        if http_connection is not None:
            base_path_elem = http_connection.find('BasePath')
            if base_path_elem is not None and base_path_elem.text:
                endpoint['base_path'] = base_path_elem.text.strip()
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - BasePath: {endpoint['base_path']}")
            virtual_hosts_elems = http_connection.findall('VirtualHost') # Use findall for multiple virtual hosts
            if virtual_hosts_elems:
                endpoint['virtual_hosts'] = [vh.text.strip() for vh in virtual_hosts_elems if vh.text]
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - VirtualHosts: {endpoint['virtual_hosts']}")

        for child in root:
            if child.tag == 'PreFlow':
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing PreFlow")
                endpoint['preflow'] = self._parse_flow(child)
            elif child.tag == 'PostFlow':
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing PostFlow")
                endpoint['postflow'] = self._parse_flow(child)
            elif child.tag == 'Flows':
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing Conditional Flows")
                endpoint['flows'] = [self._parse_flow(flow) for flow in child.findall('Flow')]
            elif child.tag == 'RouteRules': # Handle the plural container tag
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing RouteRules")
                for route_rule_elem in child.findall('RouteRule'):
                    route_rule = {'name': route_rule_elem.attrib.get('name'), 'status': 'parsed'}
                    target_endpoint_elem = route_rule_elem.find('TargetEndpoint')
                    if target_endpoint_elem is not None:
                        route_rule['target_endpoint'] = target_endpoint_elem.text
                    condition = route_rule_elem.find('Condition')
                    if condition is not None and condition.text:
                        route_rule['condition'] = condition.text.strip()
                    endpoint['route_rules'].append(route_rule)
                    self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Added RouteRule: {route_rule.get('name')}")
            elif child.tag == 'RouteRule': # Also handle singular direct child for backward compatibility or simpler cases
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing single RouteRule")
                route_rule = {'name': child.attrib.get('name'), 'status': 'parsed'}
                target_endpoint_elem = child.find('TargetEndpoint')
                if target_endpoint_elem is not None:
                    route_rule['target_endpoint'] = target_endpoint_elem.text
                condition = child.find('Condition')
                if condition is not None and condition.text:
                    route_rule['condition'] = condition.text.strip()
                endpoint['route_rules'].append(route_rule)
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Added single RouteRule: {route_rule.get('name')}")
            elif child.tag == 'FaultRules':
                self.logger.debug(f"ProxyEndpoint '{endpoint_name}' - Parsing FaultRules")
                endpoint['fault_rules'] = self._parse_fault_rules(child)
        self.parsed_data['proxy_endpoints'].append(endpoint)
        self.logger.info(f"Successfully parsed ProxyEndpoint: {endpoint_name}")

    def _parse_target_endpoint(self, file, root):
        """Extract TargetEndpoint details (target servers, SSL, etc.)"""
        endpoint_name = root.attrib.get('name', os.path.splitext(file)[0])
        self.logger.debug(f"Parsing TargetEndpoint '{endpoint_name}' from file '{file}'")
        endpoint = {'type': 'TargetEndpoint', 'name': endpoint_name, 'url': None, 'details': {}, 'fault_rules': [], 'preflow': {}, 'postflow': {}, 'flows': [], 'status': 'parsed'}
        
        http_connection = root.find('HTTPTargetConnection')
        if http_connection is not None:
            self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Found HTTPTargetConnection")
            load_balancer = http_connection.find('LoadBalancer')
            if load_balancer is not None:
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Found LoadBalancer")
                endpoint['load_balancer_algorithm'] = load_balancer.find('Algorithm').text.strip() if load_balancer.find('Algorithm') is not None else 'ROUND_ROBIN' # Default to ROUND_ROBIN
                servers = []
                for server_elem in load_balancer.findall('Server'):
                    server_name = server_elem.attrib.get('name')
                    server_host_elem = server_elem.find('Host')
                    server_host = server_host_elem.text.strip() if server_host_elem is not None and server_host_elem.text else None
                    server_port_elem = server_elem.find('Port')
                    server_port = server_port_elem.text.strip() if server_port_elem is not None and server_port_elem.text else None
                    servers.append({'name': server_name, 'host': server_host, 'port': server_port})
                    self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Added Server: {server_name}")
                endpoint['servers'] = servers
            else:
                url_elem = http_connection.find('URL')
                if url_elem is not None and url_elem.text:
                    endpoint['url'] = url_elem.text.strip()
                    self.logger.debug(f"TargetEndpoint '{endpoint_name}' - URL: {endpoint['url']}")
            # Could parse other connection details like SSLInfo, etc.

        # Generic capture of other elements for now
        for child in root:
            if child.tag == 'HTTPTargetConnection': # Already handled above
                continue
            elif child.tag == 'PreFlow':
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Parsing PreFlow")
                endpoint['preflow'] = self._parse_flow(child)
            elif child.tag == 'PostFlow':
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Parsing PostFlow")
                endpoint['postflow'] = self._parse_flow(child)
            elif child.tag == 'Flows':
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Parsing Conditional Flows")
                endpoint['flows'] = [self._parse_flow(flow) for flow in child.findall('Flow')]
            elif child.tag == 'FaultRules':
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Parsing FaultRules")
                endpoint['fault_rules'] = self._parse_fault_rules(child)
            else:
                self.logger.debug(f"TargetEndpoint '{endpoint_name}' - Storing generic element: {child.tag}")
                endpoint['details'][child.tag] = ET.tostring(child, encoding='unicode')
        self.parsed_data['target_endpoints'].append(endpoint)
        self.logger.info(f"Successfully parsed TargetEndpoint: {endpoint_name}")

    def _parse_policy(self, file, root):
        """Extract policy details (type, name, config) and dispatch to specific parsers."""
        policy_type = root.tag
        policy_name = root.attrib.get('name', os.path.splitext(file)[0])
        self.logger.debug(f"Parsing policy '{policy_name}' of type '{policy_type}' from file '{file}'")
        
        parsed_config = {}
        if policy_type in self.policy_parsers:
            parsed_config = self.policy_parsers[policy_type](root)
            self.logger.debug(f"Parsed specific config for policy {policy_name} ({policy_type}): {parsed_config}")
        else:
            self.logger.warning(f"No specific parser found for policy type: {policy_type} (Policy: {policy_name}). Storing full XML.")
            parsed_config['raw_xml'] = ET.tostring(root, encoding='unicode')

        policy_data = {
            'type': policy_type,
            'name': policy_name,
            'config': parsed_config,
            'enabled': root.attrib.get('enabled', 'true').lower() == 'true',
            'continue_on_error': root.attrib.get('continueOnError', 'false').lower() == 'true',
            'status': 'parsed'
        }
        self.parsed_data['policies'][policy_name] = policy_data
        self.logger.info(f"Successfully parsed Policy: {policy_name} ({policy_type})")

    def _parse_quota_policy(self, root) -> Dict[str, Any]:
        """Parses Quota policy details."""
        self.logger.debug(f"Parsing Quota policy: {root.attrib.get('name')}")
        config = {}
        allow_elem = root.find('Allow')
        if allow_elem is not None:
            config['allow_count'] = allow_elem.text.strip() if allow_elem.text else None
            config['allow_ref'] = allow_elem.attrib.get('countRef')
            # Fallback to 'count' attribute if text is missing but attribute exists
            if config['allow_count'] is None and allow_elem.attrib.get('count'):
                config['allow_count'] = allow_elem.attrib.get('count')
        
        interval_text, interval_ref = self._get_element_text_and_ref(root, 'Interval')
        config['interval'], config['interval_ref'] = interval_text, interval_ref

        time_unit_text, time_unit_ref = self._get_element_text_and_ref(root, 'TimeUnit')
        config['time_unit'], config['time_unit_ref'] = time_unit_text, time_unit_ref
        
        config['type'] = root.attrib.get('type') # e.g., calendar, rollingwindow
        self.logger.debug(f"Quota policy config: {config}")
        return config

    def _parse_spikearrest_policy(self, root) -> Dict[str, Any]:
        """Parses SpikeArrest policy details."""
        self.logger.debug(f"Parsing SpikeArrest policy: {root.attrib.get('name')}")
        config = {}
        rate_elem = root.find('Rate')
        if rate_elem is not None and rate_elem.text:
            config['rate'] = rate_elem.text.strip()
        
        identifier_text, identifier_ref = self._get_element_text_and_ref(root, 'Identifier')
        config['identifier'], config['identifier_ref'] = identifier_text, identifier_ref
        
        message_weight_text, message_weight_ref = self._get_element_text_and_ref(root, 'MessageWeight')
        config['message_weight'], config['message_weight_ref'] = message_weight_text, message_weight_ref
        self.logger.debug(f"SpikeArrest policy config: {config}")
        return config

    def _parse_javascript_policy(self, root) -> Dict[str, Any]:
        """Parses Javascript policy details."""
        self.logger.debug(f"Parsing Javascript policy: {root.attrib.get('name')}")
        config = {}
        resource_url_elem = root.find('ResourceURL')
        if resource_url_elem is not None and resource_url_elem.text:
            config['ResourceURL'] = resource_url_elem.text.strip() # Changed key to 'ResourceURL'
        config['time_limit'] = root.attrib.get('timeLimit')
        self.logger.debug(f"Javascript policy config: {config}")
        return config
    
    def _parse_assign_message_policy(self, root) -> Dict[str, Any]:
        """Parses AssignMessage policy details."""
        self.logger.debug(f"Parsing AssignMessage policy: {root.attrib.get('name')}")
        config = {'set': {'headers': [], 'parameters': [], 'payload': None},
                  'add': {'headers': [], 'parameters': []},
                  'remove': {'headers': [], 'parameters': []},
                  'copy': {'headers': [], 'parameters': []},
                  'assign_variables': []}

        # Handle <Set>
        set_elem = root.find('Set')
        if set_elem is not None:
            self.logger.debug(f"AssignMessage '{root.attrib.get('name')}' - Parsing <Set> section")
            # Headers
            for header_elem in set_elem.findall('Headers/Header'):
                config['set']['headers'].append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
            # Parameters
            for param_elem in set_elem.findall('Parameters/Parameter'):
                config['set']['parameters'].append({'name': param_elem.attrib.get('name'), 'value': param_elem.text.strip() if param_elem.text else None})
            # Payload
            payload_elem = set_elem.find('Payload')
            if payload_elem is not None:
                config['set']['payload'] = {'content': payload_elem.text.strip() if payload_elem.text else None,
                                           'content_type': payload_elem.attrib.get('contentType'),
                                           'message_format': payload_elem.attrib.get('messageFormat')}

        # Handle <Add>
        add_elem = root.find('Add')
        if add_elem is not None:
            self.logger.debug(f"AssignMessage '{root.attrib.get('name')}' - Parsing <Add> section")
            for header_elem in add_elem.findall('Headers/Header'):
                config['add']['headers'].append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
            for param_elem in add_elem.findall('Parameters/Parameter'):
                config['add']['parameters'].append({'name': param_elem.attrib.get('name'), 'value': param_elem.text.strip() if param_elem.text else None})

        # Handle <Remove>
        remove_elem = root.find('Remove')
        if remove_elem is not None:
            self.logger.debug(f"AssignMessage '{root.attrib.get('name')}' - Parsing <Remove> section")
            for header_elem in remove_elem.findall('Headers/Header'):
                config['remove']['headers'].append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
            for param_elem in remove_elem.findall('Parameters/Parameter'):
                config['remove']['parameters'].append({'name': param_elem.attrib.get('name'), 'value': param_elem.text.strip() if param_elem.text else None})

        # Handle <Copy> (Simplified, only header copy from source to target is common)
        copy_elem = root.find('Copy')
        if copy_elem is not None:
            self.logger.debug(f"AssignMessage '{root.attrib.get('name')}' - Parsing <Copy> section")
            for header_elem in copy_elem.findall('Headers/Header'):
                config['copy']['headers'].append({'source': header_elem.attrib.get('source'), 'name': header_elem.attrib.get('name')})
            for param_elem in copy_elem.findall('Parameters/Parameter'):
                config['copy']['parameters'].append({'source': param_elem.attrib.get('source'), 'name': param_elem.attrib.get('name')})
        
        # Handle <AssignVariable>
        for assign_var_elem in root.findall('AssignVariable'):
            self.logger.debug(f"AssignMessage '{root.attrib.get('name')}' - Parsing <AssignVariable>")
            name_text, name_ref = self._get_element_text_and_ref(assign_var_elem, 'Name')
            value_text, _ = self._get_element_text_and_ref(assign_var_elem, 'Value') # Value does not have 'ref' attr
            ref_attr = assign_var_elem.attrib.get('ref')
            config['assign_variables'].append({'name': name_text, 'value': value_text, 'ref': name_ref or ref_attr})
        self.logger.debug(f"AssignMessage policy config: {config}")
        return config

    def _parse_extract_variables_policy(self, root) -> Dict[str, Any]:
        """Parses ExtractVariables policy details."""
        self.logger.debug(f"Parsing ExtractVariables policy: {root.attrib.get('name')}")
        config = {'source': None, 'variable_prefix': None, 'extract_variables': []}

        source_elem = root.find('Source')
        if source_elem is not None and source_elem.text:
            config['source'] = source_elem.text.strip()
        
        variable_prefix_elem = root.find('VariablePrefix')
        if variable_prefix_elem is not None and variable_prefix_elem.text:
            config['variable_prefix'] = variable_prefix_elem.text.strip()

        for ev_elem in root.findall('ExtractVariable'):
            extract_var = {'name': ev_elem.attrib.get('name'), 'type': ev_elem.attrib.get('type')}
            
            # Extract variable source (e.g., Header, QueryParam, URIPath, JSONPath, XPath)
            for child in ev_elem:
                if child.tag == 'Header':
                    extract_var['header'] = {'name': child.attrib.get('name'), 'pattern': child.text.strip() if child.text else None}
                elif child.tag == 'QueryParam':
                    extract_var['query_param'] = {'name': child.attrib.get('name'), 'pattern': child.text.strip() if child.text else None}
                elif child.tag == 'URIPath':
                    extract_var['uri_path'] = {'pattern': child.text.strip() if child.text else None}
                elif child.tag == 'JSONPath':
                    extract_var['json_path'] = {'pattern': child.text.strip() if child.text else None}
                elif child.tag == 'XPath':
                    extract_var['xpath'] = {'pattern': child.text.strip() if child.text else None}
                elif child.tag == 'FormParam':
                    extract_var['form_param'] = {'name': child.attrib.get('name'), 'pattern': child.text.strip() if child.text else None}
            
            config['extract_variables'].append(extract_var)
        self.logger.debug(f"ExtractVariables policy config: {config}")
        return config

    def _parse_service_callout_policy(self, root) -> Dict[str, Any]:
        """Parses ServiceCallout policy details."""
        self.logger.debug(f"Parsing ServiceCallout policy: {root.attrib.get('name')}")
        config = {}
        # TargetEndpoint (URL or Named TargetEndpoint)
        callout_target_elem = root.find('HTTPTargetConnection/URL') or root.find('TargetEndpoint')
        if callout_target_elem is not None:
            if callout_target_elem.tag == 'URL':
                config['target_url'] = callout_target_elem.text.strip() if callout_target_elem.text else None
            elif callout_target_elem.tag == 'TargetEndpoint':
                config['target_endpoint_name'] = callout_target_elem.text.strip() if callout_target_elem.text else None
        
        # Request details
        request_elem = root.find('Request')
        if request_elem is not None:
            config['method'] = request_elem.attrib.get('variable', 'GET').upper() # Default to GET if not specified
            
            # Headers
            headers = []
            for header_elem in request_elem.findall('Add/Headers/Header'):
                headers.append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
            for header_elem in request_elem.findall('Set/Headers/Header'):
                headers.append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
            config['headers'] = headers

            # Body
            payload_elem = request_elem.find('Payload')
            if payload_elem is not None:
                config['body'] = payload_elem.text.strip() if payload_elem.text else None

        # Timeout
        timeout_elem = root.find('Timeoutinmillis')
        if timeout_elem is not None and timeout_elem.text:
            config['timeout'] = timeout_elem.text.strip()

        # Variable prefix for results
        variable_prefix_elem = root.find('VariablePrefix')
        if variable_prefix_elem is not None and variable_prefix_elem.text:
            config['variable_prefix'] = variable_prefix_elem.text.strip()
        self.logger.debug(f"ServiceCallout policy config: {config}")
        return config

    def _parse_javacallout_policy(self, root) -> Dict[str, Any]:
        """Parses JavaCallout policy details."""
        self.logger.debug(f"Parsing JavaCallout policy: {root.attrib.get('name')}")
        config = {}

        class_name_elem = root.find('ClassName')
        if class_name_elem is not None and class_name_elem.text:
            config['class_name'] = class_name_elem.text.strip()
        
        resource_url_elem = root.find('ResourceURL')
        if resource_url_elem is not None and resource_url_elem.text:
            config['resource_url'] = resource_url_elem.text.strip() # e.g., java://my-java-callout.jar

        properties = []
        properties_elem = root.find('Properties')
        if properties_elem:
            for prop_elem in properties_elem.findall('Property'):
                prop_name = prop_elem.attrib.get('name')
                prop_value = prop_elem.text.strip() if prop_elem.text else None
                if prop_name:
                    properties.append({'name': prop_name, 'value': prop_value})
        config['properties'] = properties

        self.logger.debug(f"JavaCallout policy config: {config}")
        return config

    def _parse_cors_policy(self, root) -> Dict[str, Any]:
        """Parses CORS policy details."""
        self.logger.debug(f"Parsing CORS policy: {root.attrib.get('name')}")
        config = {}
        allow_origins = root.find('AllowOrigins')
        if allow_origins is not None and allow_origins.text:
            config['allow_origins'] = allow_origins.text.strip()
        allow_methods = root.find('AllowMethods')
        if allow_methods is not None and allow_methods.text:
            config['allow_methods'] = allow_methods.text.strip()
        allow_headers = root.find('AllowHeaders')
        if allow_headers is not None and allow_headers.text:
            config['allow_headers'] = allow_headers.text.strip()
        expose_headers = root.find('ExposeHeaders')
        if expose_headers is not None and expose_headers.text:
            config['expose_headers'] = expose_headers.text.strip()
        max_age = root.find('MaxAge')
        if max_age is not None and max_age.text:
            config['max_age'] = max_age.text.strip()
        allow_credentials = root.find('AllowCredentials')
        if allow_credentials is not None and allow_credentials.text:
            config['allow_credentials'] = allow_credentials.text.strip()
        return config

    def _parse_message_logging_policy(self, root) -> Dict[str, Any]:
        """Parses MessageLogging policy details."""
        self.logger.debug(f"Parsing MessageLogging policy: {root.attrib.get('name')}")
        config = {}
        syslog = root.find('Syslog')
        if syslog is not None:
            config['syslog'] = {}
            message = syslog.find('Message')
            if message is not None and message.text:
                config['syslog']['message'] = message.text.strip()
            host = syslog.find('Host')
            if host is not None and host.text:
                config['syslog']['host'] = host.text.strip()
            port = syslog.find('Port')
            if port is not None and port.text:
                config['syslog']['port'] = port.text.strip()
        return config

    def _parse_raise_fault_policy(self, root) -> Dict[str, Any]:
        """Parses RaiseFault policy details."""
        self.logger.debug(f"Parsing RaiseFault policy: {root.attrib.get('name')}")
        config = {}
        fault_response = root.find('FaultResponse')
        if fault_response is not None:
            config['fault_response'] = {}
            set_elem = fault_response.find('Set')
            if set_elem is not None:
                status_code = set_elem.find('StatusCode')
                if status_code is not None and status_code.text:
                    config['fault_response']['status_code'] = status_code.text.strip()
                reason_phrase = set_elem.find('ReasonPhrase')
                if reason_phrase is not None and reason_phrase.text:
                    config['fault_response']['reason_phrase'] = reason_phrase.text.strip()
                payload = set_elem.find('Payload')
                if payload is not None:
                    config['fault_response']['payload'] = {
                        'content': payload.text.strip() if payload.text else None,
                        'contentType': payload.attrib.get('contentType')
                    }
                headers = []
                for header_elem in set_elem.findall('Headers/Header'):
                    headers.append({
                        'name': header_elem.attrib.get('name'),
                        'value': header_elem.text.strip() if header_elem.text else None
                    })
                config['fault_response']['headers'] = headers
        return config

    def _parse_response_cache_policy(self, root) -> Dict[str, Any]:
        """Parses ResponseCache policy details."""
        self.logger.debug(f"Parsing ResponseCache policy: {root.attrib.get('name')}")
        config = {}
        cache_key = root.find('CacheKey')
        if cache_key is not None:
            config['cache_key'] = {}
            prefix = cache_key.find('Prefix')
            if prefix is not None and prefix.text:
                config['cache_key']['prefix'] = prefix.text.strip()
            key_fragment = cache_key.find('KeyFragment')
            if key_fragment is not None:
                config['cache_key']['key_fragment'] = {
                    'ref': key_fragment.attrib.get('ref'),
                    'type': key_fragment.attrib.get('type')
                }
        scope = root.find('Scope')
        if scope is not None and scope.text:
            config['scope'] = scope.text.strip()
        expiry_settings = root.find('ExpirySettings')
        if expiry_settings is not None:
            config['expiry_settings'] = {}
            timeout = expiry_settings.find('TimeoutInSeconds')
            if timeout is not None and timeout.text:
                config['expiry_settings']['timeout_in_seconds'] = timeout.text.strip()
        return config

    def _parse_json_threat_protection_policy(self, root) -> Dict[str, Any]:
        """Parses JSONThreatProtection policy details."""
        self.logger.debug(f"Parsing JSONThreatProtection policy: {root.attrib.get('name')}")
        config = {}
        array_element_count = root.find('ArrayElementCount')
        if array_element_count is not None and array_element_count.text:
            config['array_element_count'] = array_element_count.text.strip()
        container_depth = root.find('ContainerDepth')
        if container_depth is not None and container_depth.text:
            config['container_depth'] = container_depth.text.strip()
        object_entry_count = root.find('ObjectEntryCount')
        if object_entry_count is not None and object_entry_count.text:
            config['object_entry_count'] = object_entry_count.text.strip()
        object_entry_name_length = root.find('ObjectEntryNameLength')
        if object_entry_name_length is not None and object_entry_name_length.text:
            config['object_entry_name_length'] = object_entry_name_length.text.strip()
        source = root.find('Source')
        if source is not None and source.text:
            config['source'] = source.text.strip()
        string_value_length = root.find('StringValueLength')
        if string_value_length is not None and string_value_length.text:
            config['string_value_length'] = string_value_length.text.strip()
        return config

    def _parse_verify_api_key_policy(self, root) -> Dict[str, Any]:
        """Parses VerifyAPIKey policy details."""
        self.logger.debug(f"Parsing VerifyAPIKey policy: {root.attrib.get('name')}")
        config = {}
        api_key = root.find('APIKey')
        if api_key is not None:
            config['api_key_ref'] = api_key.attrib.get('ref')
        return config

    def _parse_access_control_policy(self, root) -> Dict[str, Any]:
        """Parses AccessControl policy details."""
        self.logger.debug(f"Parsing AccessControl policy: {root.attrib.get('name')}")
        config = {
            'ip_rules': [],
            'ignore_true_client_ip_header': False,
            'cidr_size': None,
            'ipv4_criteria': 'ALLOW', # Default as per Apigee docs
            'ipv6_criteria': 'ALLOW'  # Default as per Apigee docs
        }

        # Parse IPRules
        ip_rules_elem = root.find('IPRules')
        if ip_rules_elem is not None:
            for ip_rule_elem in ip_rules_elem.findall('IPRule'):
                rule = {
                    'action': ip_rule_elem.attrib.get('action'),
                    'mask': ip_rule_elem.attrib.get('mask'),
                    'source_address': ip_rule_elem.find('SourceAddress').text.strip() if ip_rule_elem.find('SourceAddress') is not None else None
                }
                config['ip_rules'].append(rule)
        
        # Parse optional elements
        ignore_ip_header_elem = root.find('IgnoreTrueClientIPHeader')
        if ignore_ip_header_elem is not None and ignore_ip_header_elem.text:
            config['ignore_true_client_ip_header'] = ignore_ip_header_elem.text.strip().lower() == 'true'

        cidr_size_elem = root.find('CidrSize')
        if cidr_size_elem is not None and cidr_size_elem.text:
            config['cidr_size'] = cidr_size_elem.text.strip()
        
        ipv4_criteria_elem = root.find('IPv4Criteria')
        if ipv4_criteria_elem is not None and ipv4_criteria_elem.text:
            config['ipv4_criteria'] = ipv4_criteria_elem.text.strip()

        ipv6_criteria_elem = root.find('IPv6Criteria')
        if ipv6_criteria_elem is not None and ipv6_criteria_elem.text:
            config['ipv6_criteria'] = ipv6_criteria_elem.text.strip()

        self.logger.debug(f"AccessControl policy config: {config}")
        return config

    def _parse_access_entity_policy(self, root) -> Dict[str, Any]:
        """Placeholder for AccessEntity policy details, as no standard Apigee XML structure was found."""
        policy_name = root.attrib.get('name', 'Unknown')
        self.logger.warning(f"No specific parser implemented for custom policy type 'AccessEntity' (Policy: {policy_name}). Storing full XML for manual review.")
        config = {'raw_xml': ET.tostring(root, encoding='unicode')}
        return config

    def _parse_basic_authentication_policy(self, root) -> Dict[str, Any]:
        """Parses BasicAuthentication policy details."""
        self.logger.debug(f"Parsing BasicAuthentication policy: {root.attrib.get('name')}")
        config = {}

        operation_elem = root.find('Operation')
        if operation_elem is not None and operation_elem.text:
            config['operation'] = operation_elem.text.strip()

        ignore_unresolved_elem = root.find('IgnoreUnresolvedVariables')
        if ignore_unresolved_elem is not None and ignore_unresolved_elem.text:
            config['ignore_unresolved_variables'] = ignore_unresolved_elem.text.strip().lower() == 'true'
        
        user_elem = root.find('User')
        if user_elem is not None and user_elem.text:
            config['user'] = user_elem.text.strip()

        password_elem = root.find('Password')
        if password_elem is not None and password_elem.text:
            config['password'] = password_elem.text.strip()

        source_elem = root.find('Source')
        if source_elem is not None and source_elem.text:
            config['source'] = source_elem.text.strip()

        scheme_elem = root.find('Scheme')
        if scheme_elem is not None and scheme_elem.text:
            config['scheme'] = scheme_elem.text.strip()
        
        # Output parsing (simplified for now, can be expanded if needed)
        output_elem = root.find('Output')
        if output_elem is not None:
            set_elem = output_elem.find('Set')
            if set_elem is not None:
                headers = []
                for header_elem in set_elem.findall('Headers/Header'):
                    headers.append({'name': header_elem.attrib.get('name'), 'value': header_elem.text.strip() if header_elem.text else None})
                if headers:
                    config['output_headers'] = headers

        self.logger.debug(f"BasicAuthentication policy config: {config}")
        return config

    def _parse_flow_callout_policy(self, root) -> Dict[str, Any]:
        """Parses FlowCallout policy details."""
        self.logger.debug(f"Parsing FlowCallout policy: {root.attrib.get('name')}")
        config = {}

        shared_flow_bundle_elem = root.find('SharedFlowBundle')
        if shared_flow_bundle_elem is not None and shared_flow_bundle_elem.text:
            config['shared_flow_bundle'] = shared_flow_bundle_elem.text.strip()
        
        parameters = []
        parameters_elem = root.find('Parameters')
        if parameters_elem:
            for param_elem in parameters_elem.findall('Parameter'):
                param_name = param_elem.attrib.get('name')
                param_value = param_elem.text.strip() if param_elem.text else None
                if param_name:
                    parameters.append({'name': param_name, 'value': param_value})
        config['parameters'] = parameters

        self.logger.debug(f"FlowCallout policy config: {config}")
        return config

    def _parse_graphql_policy(self, root) -> Dict[str, Any]:
        """Parses GraphQL policy details."""
        self.logger.debug(f"Parsing GraphQL policy: {root.attrib.get('name')}")
        config = {}

        operation_type_elem = root.find('OperationType')
        if operation_type_elem is not None and operation_type_elem.text:
            config['operation_type'] = operation_type_elem.text.strip()
        
        operation_name_elem = root.find('OperationName')
        if operation_name_elem is not None and operation_name_elem.text:
            config['operation_name'] = operation_name_elem.text.strip()

        schema_elem = root.find('Schema')
        if schema_elem is not None:
            resource_url_elem = schema_elem.find('ResourceURL')
            if resource_url_elem is not None and resource_url_elem.text:
                config['schema_resource_url'] = resource_url_elem.text.strip()

        variables_list = []
        variables_elem = root.find('Variables')
        if variables_elem:
            for var_elem in variables_elem.findall('Variable'):
                variable = {
                    'name': var_elem.attrib.get('name'),
                    'type': var_elem.attrib.get('type'),
                    'source': var_elem.find('Source').text.strip() if var_elem.find('Source') is not None else None
                }
                variables_list.append(variable)
        if variables_list:
            config['variables'] = variables_list
        
        action_elem = root.find('Action')
        if action_elem is not None:
            action_type_elem = action_elem.find('Type')
            if action_type_elem is not None and action_type_elem.text:
                config['action_type'] = action_type_elem.text.strip()

        source_elem = root.find('Source')
        if source_elem is not None and source_elem.text:
            config['source'] = source_elem.text.strip()
        
        self.logger.debug(f"GraphQL policy config: {config}")
        return config

    def _parse_invalidate_cache_policy(self, root) -> Dict[str, Any]:
        """Parses InvalidateCache policy details."""
        self.logger.debug(f"Parsing InvalidateCache policy: {root.attrib.get('name')}")
        config = {}

        # Parse Cache element
        cache_elem = root.find('Cache')
        if cache_elem is not None:
            config['cache'] = {
                'key_fragment_ref': cache_elem.attrib.get('keyFragmentRef'),
                'key_fragment_set': cache_elem.attrib.get('keyFragmentSet', 'false').lower() == 'true',
                'cache_resource': cache_elem.find('CacheResource').text.strip() if cache_elem.find('CacheResource') is not None else None
            }
        
        # Parse CacheKey element
        cache_key_elem = root.find('CacheKey')
        if cache_key_elem is not None:
            config['cache_key'] = {}
            prefix_elem = cache_key_elem.find('Prefix')
            if prefix_elem is not None and prefix_elem.text:
                config['cache_key']['prefix'] = prefix_elem.text.strip()
            
            key_fragments = []
            for kf_elem in cache_key_elem.findall('KeyFragment'):
                key_fragments.append({
                    'ref': kf_elem.attrib.get('ref'),
                    'value': kf_elem.text.strip() if kf_elem.text else None
                })
            if key_fragments:
                config['cache_key']['key_fragments'] = key_fragments
        
        # Parse SkipCache element
        skip_cache_elem = root.find('SkipCache')
        if skip_cache_elem is not None:
            config['skip_cache_lookup'] = skip_cache_elem.attrib.get('lookup')
        
        self.logger.debug(f"InvalidateCache policy config: {config}")
        return config

    def _parse_json_to_xml_policy(self, root) -> Dict[str, Any]:
        """Parses JSONToXML policy details."""
        self.logger.debug(f"Parsing JSONToXML policy: {root.attrib.get('name')}")
        config = {}

        output_variable_elem = root.find('OutputVariable')
        if output_variable_elem is not None and output_variable_elem.text:
            config['output_variable'] = output_variable_elem.text.strip()
        
        source_elem = root.find('Source')
        if source_elem is not None and source_elem.text:
            config['source'] = source_elem.text.strip()
        
        options_elem = root.find('Options')
        if options_elem is not None:
            options_config = {}
            omit_xml_declaration_elem = options_elem.find('OmitXmlDeclaration')
            if omit_xml_declaration_elem is not None and omit_xml_declaration_elem.text:
                options_config['omit_xml_declaration'] = omit_xml_declaration_elem.text.strip().lower() == 'true'
            
            omit_json_envelope_elem = options_elem.find('OmitJsonEnvelope')
            if omit_json_envelope_elem is not None and omit_json_envelope_elem.text:
                options_config['omit_json_envelope'] = omit_json_envelope_elem.text.strip().lower() == 'true'
            
            treat_unwrapped_as_map_elem = options_elem.find('TreatUnwrappedAsMap')
            if treat_unwrapped_as_map_elem is not None and treat_unwrapped_as_map_elem.text:
                options_config['treat_unwrapped_as_map'] = treat_unwrapped_as_map_elem.text.strip().lower() == 'true'
            
            xml_encoding_elem = options_elem.find('XmlEncoding')
            if xml_encoding_elem is not None and xml_encoding_elem.text:
                options_config['xml_encoding'] = xml_encoding_elem.text.strip()
            
            xml_namespace_elem = options_elem.find('XmlNamespace')
            if xml_namespace_elem is not None and xml_namespace_elem.text:
                options_config['xml_namespace'] = xml_namespace_elem.text.strip()
            
            pretty_print_elem = options_elem.find('prettyPrint')
            if pretty_print_elem is not None and pretty_print_elem.text:
                options_config['pretty_print'] = pretty_print_elem.text.strip().lower() == 'true'
            
            if options_config:
                config['options'] = options_config
        
        array_root_elem = root.find('ArrayRoot')
        if array_root_elem is not None and array_root_elem.text:
            config['array_root'] = array_root_elem.text.strip()
        
        array_element_elem = root.find('ArrayElement')
        if array_element_elem is not None and array_element_elem.text:
            config['array_element'] = array_element_elem.text.strip()

        self.logger.debug(f"JSONToXML policy config: {config}")
        return config

    def _parse_key_value_map_operations_policy(self, root) -> Dict[str, Any]:
        """Parses KeyValueMapOperations policy details."""
        self.logger.debug(f"Parsing KeyValueMapOperations policy: {root.attrib.get('name')}")
        config = {}

        exclusive_cache_elem = root.find('ExclusiveCache')
        if exclusive_cache_elem is not None and exclusive_cache_elem.text:
            config['exclusive_cache'] = exclusive_cache_elem.text.strip().lower() == 'true'
        
        expiry_time_elem = root.find('ExpiryTimeInSecs')
        if expiry_time_elem is not None and expiry_time_elem.text:
            config['expiry_time_in_secs'] = expiry_time_elem.text.strip()
        
        # Parse Get operation
        get_elem = root.find('Get')
        if get_elem is not None:
            get_config = {
                'assign_to': get_elem.attrib.get('assignTo'),
                'map_name': get_elem.find('MapName').text.strip() if get_elem.find('MapName') is not None else None
            }
            key_elem = get_elem.find('Key')
            if key_elem is not None:
                parameter_elem = key_elem.find('Parameter')
                if parameter_elem is not None:
                    get_config['key_parameter'] = {
                        'ref': parameter_elem.attrib.get('ref'),
                        'value': parameter_elem.text.strip() if parameter_elem.text else None
                    }
            config['get'] = get_config

        # Parse Put operation
        put_elem = root.find('Put')
        if put_elem is not None:
            put_config = {
                'map_name': put_elem.find('MapName').text.strip() if put_elem.find('MapName') is not None else None
            }
            key_elem = put_elem.find('Key')
            if key_elem is not None:
                parameter_elem = key_elem.find('Parameter')
                if parameter_elem is not None:
                    put_config['key_parameter'] = {
                        'ref': parameter_elem.attrib.get('ref'),
                        'value': parameter_elem.text.strip() if parameter_elem.text else None
                    }
            value_elem = put_elem.find('Value')
            if value_elem is not None:
                put_config['value'] = {
                    'ref': value_elem.attrib.get('ref'),
                    'value': value_elem.text.strip() if value_elem.text else None
                }
            
            entries = []
            for entry_elem in put_elem.findall('Entry'):
                entries.append({
                    'name': entry_elem.attrib.get('name'),
                    'value': entry_elem.find('Value').text.strip() if entry_elem.find('Value') is not None else None
                })
            if entries:
                put_config['entries'] = entries
            config['put'] = put_config
        
        scope_elem = root.find('Scope')
        if scope_elem is not None and scope_elem.text:
            config['scope'] = scope_elem.text.strip()

        self.logger.debug(f"KeyValueMapOperations policy config: {config}")
        return config

    def _parse_fault_rules(self, fault_rules_elem: ET.Element) -> List[Dict[str, Any]]:
        """Parses FaultRules section."""
        self.logger.debug("Parsing FaultRules")
        fault_rules = []
        for fault_rule_elem in fault_rules_elem.findall('FaultRule'):
            fault_rule_name = fault_rule_elem.attrib.get('name')
            self.logger.debug(f"Parsing FaultRule: {fault_rule_name}")
            fault_rule = {'name': fault_rule_name, 'steps': [], 'condition': None}
            condition_elem = fault_rule_elem.find('Condition')
            if condition_elem is not None and condition_elem.text:
                fault_rule['condition'] = condition_elem.text.strip()
                self.logger.debug(f"FaultRule '{fault_rule_name}' - Condition: {fault_rule['condition']}")
            
            for step_elem in fault_rule_elem.findall('Step'):
                step = {'name': None, 'condition': None, 'continue_on_error': None, 'enabled': None}
                name_elem = step_elem.find('Name')
                if name_elem is not None and name_elem.text:
                    step['name'] = name_elem.text.strip()
                step_condition_elem = step_elem.find('Condition')
                if step_condition_elem is not None and step_condition_elem.text:
                    step['condition'] = step_condition_elem.text.strip()
                step['continue_on_error'] = step_elem.attrib.get('continueOnError', 'false').lower() == 'true'
                step['enabled'] = step_elem.attrib.get('enabled', 'true').lower() == 'true'
                fault_rule['steps'].append(step)
                self.logger.debug(f"FaultRule '{fault_rule_name}' - Added Step: {step.get('name')}")
            fault_rules.append(fault_rule)
        self.logger.debug(f"Parsed {len(fault_rules)} FaultRules.")
        return fault_rules


    def _parse_flow(self, flow_elem):
        """Extract flow steps and conditions.
        At this stage, we only extract policy names, not full policy configs.
        The linkage to full policy configs will happen in the generator.
        """
        flow_name = flow_elem.attrib.get('name', 'UnnamedFlow')
        self.logger.debug(f"Parsing flow: {flow_name}")
        flow = {'name': flow_name, 'request': [], 'response': [], 'condition': '', 'status': 'parsed'}
        # Flow-level condition
        flow_condition_elem = flow_elem.find('Condition')
        if flow_condition_elem is not None and flow_condition_elem.text:
            flow['condition'] = flow_condition_elem.text.strip()
            self.logger.debug(f"Flow '{flow_name}' - Condition: {flow['condition']}")

        for child in flow_elem:
            if child.tag == 'Request':
                self.logger.debug(f"Flow '{flow_name}' - Parsing Request steps")
                # Find all 'Step' elements within 'Request' and then their 'Name' child
                for step_elem in child.findall('Step'):
                    step_data = {'name': None, 'condition': None, 'continue_on_error': None, 'enabled': None}
                    name_elem = step_elem.find('Name')
                    if name_elem is not None and name_elem.text:
                        step_data['name'] = name_elem.text.strip()
                    step_condition_elem = step_elem.find('Condition')
                    if step_condition_elem is not None and step_condition_elem.text:
                        step_data['condition'] = step_condition_elem.text.strip()
                    step_data['continue_on_error'] = step_elem.attrib.get('continueOnError', 'false').lower() == 'true'
                    step_data['enabled'] = step_elem.attrib.get('enabled', 'true').lower() == 'true'
                    flow['request'].append(step_data)
                    self.logger.debug(f"Flow '{flow_name}' - Added Request Step: {step_data.get('name')}")
            elif child.tag == 'Response':
                self.logger.debug(f"Flow '{flow_name}' - Parsing Response steps")
                # Find all 'Step' elements within 'Response' and then their 'Name' child
                for step_elem in child.findall('Step'):
                    step_data = {'name': None, 'condition': None, 'continue_on_error': None, 'enabled': None}
                    name_elem = step_elem.find('Name')
                    if name_elem is not None and name_elem.text:
                        step_data['name'] = name_elem.text.strip()
                    step_condition_elem = step_elem.find('Condition')
                    if step_condition_elem is not None and step_condition_elem.text:
                        step_data['condition'] = step_condition_elem.text.strip()
                    step_data['continue_on_error'] = step_elem.attrib.get('continueOnError', 'false').lower() == 'true'
                    step_data['enabled'] = step_elem.attrib.get('enabled', 'true').lower() == 'true'
                    flow['response'].append(step_data)
                    self.logger.debug(f"Flow '{flow_name}' - Added Response Step: {step_data.get('name')}")
        self.logger.debug(f"Finished parsing flow: {flow_name}")
        return flow
