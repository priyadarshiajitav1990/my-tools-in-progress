import hashlib
import json
import os
from typing import Dict, Any, Optional
from logging import Logger

class BundleCache:
    """
    Caches parsed Apigee bundle data based on file hash to avoid re-processing identical bundles.
    """
    def __init__(self, cache_dir: str, logger: Logger):
        self.cache_dir = cache_dir
        self.logger = logger
        os.makedirs(self.cache_dir, exist_ok=True)
        self.logger.debug(f"BundleCache initialized with cache directory: {cache_dir}")

    def _get_file_hash(self, bundle_path: str) -> str:
        """Generate a hash for the bundle file or directory."""
        if os.path.isfile(bundle_path):
            # For zip files, hash the file content
            with open(bundle_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        elif os.path.isdir(bundle_path):
            # For directories, hash all file contents
            hasher = hashlib.sha256()
            for root, dirs, files in os.walk(bundle_path):
                for file in sorted(files):
                    file_path = os.path.join(root, file)
                    with open(file_path, 'rb') as f:
                        hasher.update(f.read())
            return hasher.hexdigest()
        else:
            raise ValueError(f"Invalid bundle path: {bundle_path}")

    def get(self, bundle_path: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached parsed data if available."""
        try:
            if not bundle_path or not isinstance(bundle_path, str):
                self.logger.warning("Invalid bundle path provided to cache.get()")
                return None

            bundle_hash = self._get_file_hash(bundle_path)
            cache_file = os.path.join(self.cache_dir, f"{bundle_hash}.json")

            if os.path.exists(cache_file):
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                self.logger.info(f"Cache hit for bundle: {bundle_path}")
                return cached_data
            else:
                self.logger.debug(f"Cache miss for bundle: {bundle_path}")
                return None
        except json.JSONDecodeError as e:
            self.logger.warning(f"Corrupted cache file for {bundle_path}: {e}")
            # Remove corrupted cache file
            try:
                os.remove(cache_file)
            except OSError:
                pass
            return None
        except Exception as e:
            self.logger.warning(f"Error retrieving cache for {bundle_path}: {e}")
            return None

    def set(self, bundle_path: str, parsed_data: Dict[str, Any]) -> None:
        """Store parsed data in cache."""
        try:
            bundle_hash = self._get_file_hash(bundle_path)
            cache_file = os.path.join(self.cache_dir, f"{bundle_hash}.json")

            with open(cache_file, 'w') as f:
                json.dump(parsed_data, f, indent=2)
            self.logger.debug(f"Cached parsed data for bundle: {bundle_path}")
        except Exception as e:
            self.logger.warning(f"Error caching data for {bundle_path}: {e}")

    def clear(self) -> None:
        """Clear all cached data."""
        try:
            for file in os.listdir(self.cache_dir):
                if file.endswith('.json'):
                    os.remove(os.path.join(self.cache_dir, file))
            self.logger.info("Cache cleared")
        except Exception as e:
            self.logger.warning(f"Error clearing cache: {e}")
