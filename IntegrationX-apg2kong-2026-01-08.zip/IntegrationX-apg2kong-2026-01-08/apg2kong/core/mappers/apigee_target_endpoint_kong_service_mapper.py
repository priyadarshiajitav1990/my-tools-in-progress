from logging import Logger
from typing import Dict, Any

class ApigeeTargetEndpointKongServiceMapper:
    def __init__(self, logger: Logger, config_generator):
        self.logger = logger
        self.config_generator = config_generator

    def map(self, target_endpoint: Dict[str, Any]) -> Dict[str, Any]:
        service_name = f"{target_endpoint['name']}-service"
        
        url = None
        if target_endpoint.get('url'):
            url = target_endpoint['url']
        elif target_endpoint.get('servers'):
            # For simplicity, we'll just use the first server
            server = target_endpoint['servers'][0]
            protocol = "http" # Assuming http for now
            url = f"{protocol}://{server['host']}:{server['port']}"

        if not url:
            return None

        return {
            'name': service_name,
            'url': url
        }
