from logging import Logger
from typing import Dict, Any, List

class ApigeeProxyEndpointKongRouteMapper:
    def __init__(self, logger: Logger, config_generator):
        self.logger = logger
        self.config_generator = config_generator

    def map(self, proxy_endpoint: Dict[str, Any], parsed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        routes = []
        
        # Default route
        default_route = self._map_route(proxy_endpoint, parsed_data)
        routes.append(default_route)

        # Routes from RouteRules
        for route_rule in proxy_endpoint.get('route_rules', []):
            route = self._map_route(proxy_endpoint, parsed_data, route_rule)
            routes.append(route)

        return routes

    def _map_route(self, proxy_endpoint: Dict[str, Any], parsed_data: Dict[str, Any], route_rule: Dict[str, Any] = None) -> Dict[str, Any]:
        route_name = proxy_endpoint['name']
        if route_rule:
            route_name = f"{route_name}-{route_rule['name']}"

        route = {
            'name': route_name,
            'paths': [proxy_endpoint['base_path']],
            'plugins': []
        }

        # Determine the target service
        target_endpoint_name = None
        if route_rule:
            target_endpoint_name = route_rule.get('target_endpoint')
        
        if not target_endpoint_name:
            # Get default target endpoint
            target_endpoint_name = self._get_default_target_endpoint(parsed_data)

        if target_endpoint_name:
            route['service'] = {'name': self._get_service_name(target_endpoint_name)}

        # Map policies
        all_plugins = []
        # PreFlow
        preflow_plugins = self._map_policies_in_flow(proxy_endpoint.get('preflow', {}), parsed_data, 'request')
        all_plugins.extend(preflow_plugins)
        
        # Conditional Flows
        for flow in proxy_endpoint.get('flows', []):
            flow_request_plugins = self._map_policies_in_flow(flow, parsed_data, 'request')
            all_plugins.extend(flow_request_plugins)

        # Process response policies after all request policies
        all_plugins.extend(self._map_policies_in_flow(proxy_endpoint.get('preflow', {}), parsed_data, 'response'))
        for flow in proxy_endpoint.get('flows', []):
            flow_response_plugins = self._map_policies_in_flow(flow, parsed_data, 'response')
            all_plugins.extend(flow_response_plugins)

        # PostFlow
        postflow_plugins_request = self._map_policies_in_flow(proxy_endpoint.get('postflow', {}), parsed_data, 'request')
        all_plugins.extend(postflow_plugins_request)
        postflow_plugins_response = self._map_policies_in_flow(proxy_endpoint.get('postflow', {}), parsed_data, 'response')
        all_plugins.extend(postflow_plugins_response)

        route['plugins'] = all_plugins

        return route

    def _map_policies_in_flow(self, flow_data: Dict[str, Any], parsed_data: Dict[str, Any], flow_phase: str) -> List[Dict[str, Any]]:
        """
        Maps policies within a specific flow phase (request or response) to Kong plugins,
        including ordering.
        """
        plugins_in_phase = []
        
        # Keep track of previous plugin for ordering
        # This will be more complex when dealing with different Kong phases (access, header_filter, etc.)
        # For now, a simplified approach assuming all map to 'access' phase for sequential order.
        last_plugin_name = None 

        for step in flow_data.get(flow_phase, []):
            policy_name = step.get('name')
            if not policy_name:
                self.logger.warning(f"Flow step in phase '{flow_phase}' missing policy name. Skipping.")
                continue
            
            # Find the policy configuration from parsed_data
            policy_data = parsed_data['policies'].get(policy_name)
            if not policy_data:
                self.logger.error(f"Policy '{policy_name}' not found in parsed data. Skipping.")
                continue

            # Find the appropriate policy mapper
            mapped_plugins_for_policy = []
            for mapper in self.config_generator.policy_mappers:
                if mapper.can_map(policy_data['type']):
                    mapped_plugins_for_policy = mapper.map(policy_name, policy_data)
                    break
            
            if not mapped_plugins_for_policy:
                self.logger.warning(f"No mapper found for policy type '{policy_data['type']}' (Policy: {policy_name}). Skipping.")
                continue

            for plugin in mapped_plugins_for_policy:
                # Apply ordering logic
                if last_plugin_name:
                    plugin['ordering'] = {
                        'after': {
                            'access': [last_plugin_name] # Assuming 'access' for now, needs refinement
                        }
                    }
                plugins_in_phase.append(plugin)
                last_plugin_name = plugin['name'] # Update last plugin for next iteration
        
        return plugins_in_phase

    
    def _get_default_target_endpoint(self, parsed_data: Dict[str, Any]) -> str:
        if parsed_data.get('target_endpoints'):
            return parsed_data['target_endpoints'][0]['name']
        return None

    def _get_service_name(self, target_endpoint_name: str) -> str:
        # This should ideally be handled by the service mapper
        return f"{target_endpoint_name}-service"