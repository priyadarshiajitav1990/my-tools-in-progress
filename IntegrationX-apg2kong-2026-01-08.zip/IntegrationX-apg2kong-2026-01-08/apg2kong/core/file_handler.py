"""
Utility functions for file and directory operations.
"""

# Helper functions for reading, writing, and managing files will go here.