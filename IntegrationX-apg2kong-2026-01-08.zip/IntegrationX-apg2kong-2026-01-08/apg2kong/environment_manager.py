import os
import subprocess
import sys

def setup_venv():
    """
    Automates the creation and activation of a Python virtual environment
    and installs dependencies from requirements.txt.
    """
    venv_dir = "venv"
    requirements_file = "requirements.txt"

    print(f"Setting up Python virtual environment in '{venv_dir}'...")

    # 1. Create virtual environment if it doesn't exist
    if not os.path.exists(venv_dir):
        try:
            print(f"Creating virtual environment '{venv_dir}'...")
            subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
            print(f"Virtual environment '{venv_dir}' created successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error creating virtual environment: {e}")
            sys.exit(1)
    else:
        print(f"Virtual environment '{venv_dir}' already exists.")

    # Determine the correct Python executable within the venv
    if sys.platform == "win32":
        python_executable = os.path.join(venv_dir, "Scripts", "python.exe")
        pip_executable = os.path.join(venv_dir, "Scripts", "pip.exe")
    else:
        python_executable = os.path.join(venv_dir, "bin", "python")
        pip_executable = os.path.join(venv_dir, "bin", "pip")

    if not os.path.exists(python_executable):
        print(f"Error: Python executable not found in '{python_executable}'.")
        sys.exit(1)

    # 2. Install dependencies from requirements.txt
    if os.path.exists(requirements_file):
        print(f"Installing dependencies from '{requirements_file}' into '{venv_dir}'...")
        try:
            subprocess.run([pip_executable, "install", "-r", requirements_file], check=True)
            print("Dependencies installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error installing dependencies: {e}")
            sys.exit(1)

        # 3. Verify installed dependencies using pip check
        print("Verifying installed dependencies...")
        try:
            result = subprocess.run([pip_executable, "check"], capture_output=True, text=True)
            if result.returncode == 0:
                print("All installed dependencies are compatible.")
            else:
                print("Dependency check failed:")
                print(result.stdout)
                print(result.stderr)
                sys.exit(1)
        except Exception as e:
            print(f"Error during dependency check: {e}")
            sys.exit(1)
    else:
        print(f"Warning: '{requirements_file}' not found. Skipping dependency installation and check.")

    print("\nVirtual environment setup complete.")
    print(f"To activate the virtual environment, run:")
    if sys.platform == "win32":
        print(f".\\{venv_dir}\\Scripts\\activate")
    else:
        print(f"source ./{venv_dir}/bin/activate")

def check_venv_active():
    """
    Checks if the current Python environment is a virtual environment.
    Exits with an error message if not.
    """
    if not hasattr(sys, 'real_prefix') and not (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        print("\nERROR: Not running inside a virtual environment.")
        print("Please activate the virtual environment first.")
        print("To activate (Windows): .\\venv\\Scripts\\activate")
        print("To activate (Linux/macOS): source ./venv/bin/activate")
        sys.exit(1)
    print("Running inside a virtual environment.")

if __name__ == "__main__":
    setup_venv()
