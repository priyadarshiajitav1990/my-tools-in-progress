// Read the 'apikey' header from the request
var apiKey = context.getVariable("request.header.apikey");

// Log the API key value
console.log("Received API Key: " + apiKey);

// Set a custom variable based on the API key
if (apiKey && apiKey.length > 0) {
    context.setVariable("custom.apiKeyStatus", "present");
} else {
    context.setVariable("custom.apiKeyStatus", "missing");
}