# Apigee to Kong Mapping Conventions

This document details the conventions and logic used to map Apigee policies to Kong Gateway plugins within the `apg2kong` tool.

## Core Principles

1.  **Preservation of Functionality:** Every effort is made to ensure that all functionalities of an Apigee policy are replicated in the corresponding Kong plugin(s).
2.  **Idiomatic Kong:** Mappings aim to leverage Kong's native features and plugin architecture wherever possible.
3.  **Modularity vs. Smart Plugins:**
    *   For simple Apigee policies with direct Kong equivalents, native Kong plugins are used.
    *   For complex Apigee policies (e.g., `AssignMessage`) that involve multiple, interwoven functionalities or dynamic logic not easily covered by separate Kong plugins, a single "smart" custom Lua plugin is created. This plugin encapsulates the full Apigee policy logic.
4.  **Extensibility:** The mapping is driven by `policy-to-plugin.json` and dynamically loaded policy mappers, allowing for easy expansion.

## Mapping Logic

The mapping from an Apigee policy to Kong plugin(s) is defined in `configs/policy-to-plugin.json`.

### `policy-to-plugin.json` Structure

```json
{
    "ApigeePolicyName": ["kong-built-in-plugin-1", "kong_custom_plugin_name"],
    "AnotherApigeePolicy": ["another-kong-built-in-plugin"]
}
```

*   **`ApigeePolicyName`**: The exact name of the Apigee policy XML tag (e.g., `AssignMessage`, `VerifyAPIKey`, `Quota`).
*   **`[array of plugin names]`**: A list of one or more Kong plugin names. These can be:
    *   **Built-in Kong Plugins**: Standard plugins like `rate-limiting`, `key-auth`, `cors`, `request-transformer`, etc.
    *   **Custom Lua Plugins**: Plugins developed specifically for `apg2kong` (e.g., `kong_assign_message_plugin`).

### Custom Lua Plugin Conventions

Custom Lua plugins generated or managed by this tool adhere to the following conventions:

*   **Naming:** Custom plugin names follow the pattern `kong_<apigee_policy_name>_plugin`. For example, `AssignMessage` maps to `kong_assign_message_plugin`.
*   **Location:** Custom plugins reside in the `custom-plugins/` directory, with each plugin in its own subdirectory (e.g., `custom-plugins/kong_assign_message_plugin/`).
*   **Structure:** Each custom plugin directory contains:
    *   `handler.lua`: Contains the main Lua logic for the plugin, implementing Kong's plugin lifecycle phases (e.g., `access`, `response`).
    *   `schema.lua`: Defines the configuration schema for the plugin, allowing it to accept user-defined parameters like built-in Kong plugins.
*   **Kong Compatibility:** All custom plugins are developed with compatibility for Kong Gateway v3.12 and Lua 5.1.5 (specifically LuaJIT, as used by Kong).
*   **Configuration:** The `schema.lua` for custom plugins exposes a `config` field, allowing parameters to be passed to the plugin's `handler.lua`. The internal structure of this `config` is designed to directly mirror the parsed Apigee policy XML structure where feasible, simplifying translation.
*   **`ordering` and `tags` Support:** All custom plugins implicitly support Kong's `ordering` and `tags` fields in their `schema.lua`, enabling precise control over plugin execution order and organization.

### Apigee Variable Resolution

Apigee policies frequently use variables (e.g., `{request.header.apikey}`). Custom Lua plugins (like `kong_assign_message_plugin`) include a `resolve_variable` utility function to translate these Apigee-style variables into values from Kong's context (`kong.request`, `kong.response`, `kong.ctx.shared`).

### Plugin Ordering

Apigee policies execute in a defined sequence within flows (PreFlow, Conditional Flows, PostFlow, Request, Response). The `apg2kong` tool translates this order into Kong's `ordering` field in the generated YAML configuration.

*   For policies appearing sequentially in an Apigee flow, the generated Kong plugins will have `ordering.after.<phase>` fields.
*   `ordering.after.<phase>`: This field is used to ensure that a plugin executes *after* a preceding plugin in the same Kong phase (e.g., `access`).
*   The current implementation assumes most general policies primarily operate within the `access` phase for ordering purposes, but this is extensible to other phases as specific plugin needs arise.

### Example: AssignMessage Policy

*   **Apigee Policy:** `AssignMessage`
*   **Mapping in `policy-to-plugin.json`**: `"AssignMessage": ["kong_assign_message_plugin"]`
*   **Rationale:** The `AssignMessage` policy is highly versatile, combining message creation, modification (headers, query params, payload, verb, URL, status code), copying, and variable assignment. A single "smart" custom Lua plugin (`kong_assign_message_plugin`) is used to encapsulate all these functionalities, providing a direct translation of the Apigee XML configuration into the Kong plugin's runtime configuration (`conf`).
*   **`kong_assign_message_plugin` handler logic:** Processes the `conf` object, applying `set`, `add`, `remove`, `copy`, and `assign_variables` actions to `kong.request` or `kong.response` objects based on the plugin's phase (`access` or `response`).

---
