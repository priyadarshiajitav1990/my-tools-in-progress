# Apigee to Kong Policy Mapping

This document outlines the mapping of Apigee policies to Kong plugins.

| Apigee Policy | Kong Plugin | Notes |
|---|---|---|
| Access-Control | [CORS](https://docs.konghq.com/hub/kong-inc/cors/) | Supports standard CORS headers. |
| Access-Entity | Custom Plugin | Requires a custom plugin to extract specific information (e.g., from a JWT) and place it in a header. |
| Assign-Message | [Request Transformer](https://docs.konghq.com/hub/kong-inc/request-transformer/) / [Response Transformer](https://docs.konghq.com/hub/kong-inc/response-transformer/) | Can be mapped to Kong's Request Transformer and Response Transformer plugins. |
| Basic-Authentication | [Basic Authentication](https://docs.konghq.com/hub/kong-inc/basic-auth/) | Can be mapped to Kong's Basic Authentication plugin. |
| Extract-Variables | [Request Transformer](https://docs.konghq.com/hub/kong-inc/request-transformer/) / Custom Plugin | Complex policy. Can be partially mapped to Kong's Request Transformer, but often requires a custom plugin for advanced cases (e.g., JSON/XML payloads). |
| Flow-Callout | Custom Plugin | Requires a custom plugin to execute another shared flow. |
| GraphQL | [GraphQL Rate Limiting](https://docs.konghq.com/hub/kong-inc/graphql-rate-limiting-advanced/) | Can be mapped to Kong's GraphQL Rate Limiting plugin, but not a direct equivalent. |
| Invalidate-Cache | Custom Plugin | Can be mapped to a custom plugin that invalidates cache entries. |
| JSON-Threat-Protection | [Request Size Limiting](https://docs.konghq.com/hub/kong-inc/request-size-limiting/) / [Request Validator](https://docs.konghq.com/hub/kong-inc/request-validator/) | Can be partially mapped to Kong's Request Size Limiting and Request Validator plugins. |
| JSON-to-XML | Custom Plugin | Can be mapped to a custom JSON-to-XML transformation plugin. |
| Java-Callout | Custom Plugin | Requires a custom plugin to execute Java code. |
| JavaScript | Custom Plugin | Requires a custom plugin to execute JavaScript code. A sub-tool for this is in development. |
| KeyValueMap-Operations | Custom Plugin | Can be mapped to a custom plugin that interacts with a key-value store. |
| Lookup-Cache | [Proxy Cache](https://docs.konghq.com/hub/kong-inc/proxy-cache/) | Can be mapped to Kong's Proxy Cache plugin. |
| Message-Logging | [Logging Plugins](https://docs.konghq.com/hub/) | Can be mapped to Kong's logging plugins (e.g., file-log, http-log). |
| OAuth-v2 | [OAuth2 Authentication](https://docs.konghq.com/hub/kong-inc/oauth2/) | Can be mapped to Kong's OAuth2 Authentication plugin. |
| Populate-Cache | [Proxy Cache](https://docs.konghq.com/hub/kong-inc/proxy-cache/) | Can be mapped to Kong's Proxy Cache plugin. |
| Python-Script | Custom Plugin | Requires a custom plugin to execute Python code. |
| Quota | [Rate Limiting](https://docs.konghq.com/hub/kong-inc/rate-limiting/) | Can be mapped to Kong's Rate Limiting plugin. |
| Raise-Fault | [Response Transformer](https://docs.konghq.com/hub/kong-inc/response-transformer/) / Custom Plugin | Can be mapped to Kong's Response Transformer or a custom plugin to generate fault responses. |
| Regular-Expression-Protection | Custom Plugin | Can be mapped to a custom plugin that performs regex matching on request content. |
| Reset-Quota | Custom Plugin | Requires a custom plugin to reset quota counters. |
| Response-Cache | [Proxy Cache](https://docs.konghq.com/hub/kong-inc/proxy-cache/) | Can be mapped to Kong's Proxy Cache plugin. |
| SAML-Assertion | Custom Plugin | Requires a custom plugin for SAML assertion validation. |
| Service-Callout | Custom Plugin | Can be mapped to a custom plugin to make external service calls. |
| SOAP-Message-Validation | Custom Plugin | Requires a custom plugin for SOAP message validation. |
| Spike-Arrest | [Rate Limiting](https://docs.konghq.com/hub/kong-inc/rate-limiting/) | Can be mapped to Kong's Rate Limiting plugin (specifically, the `rate-limiting-advanced` variant). |
| Statistics-Collector | [Prometheus](https://docs.konghq.com/hub/kong-inc/prometheus/) | Can be mapped to Kong's Prometheus or other metrics plugins. |
| Verify-API-Key | [Key Authentication](https://docs.konghq.com/hub/kong-inc/key-auth/) | Can be mapped to Kong's Key Authentication plugin. |
| XML-Threat-Protection | [Request Size Limiting](https://docs.konghq.com/hub/kong-inc/request-size-limiting/) | Can be partially mapped to Kong's Request Size Limiting plugin. |
| XML-to-JSON | Custom Plugin | Can be mapped to a custom XML-to-JSON transformation plugin. |
| XSL-Transform | Custom Plugin | Requires a custom plugin to perform XSL transformations. |
| JWS-Generate | Custom Plugin | Requires a custom plugin for JWS generation. |
| JWS-Verify | Custom Plugin | Requires a custom plugin for JWS verification. |
| JWS-Decode | Custom Plugin | Requires a custom plugin for JWS decoding. |
| Data-Capture | [Logging Plugins](https://docs.konghq.com/hub/) | Can be mapped to Kong's logging plugins. |
| Integration-Callout | Custom Plugin | Requires a custom plugin for integration callouts. |
| Set-Integration-Request | Custom Plugin | Requires a custom plugin for setting integration requests. |
