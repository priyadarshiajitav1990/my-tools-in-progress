import asyncio
import os
import tempfile
import shutil
import time
from core.apigee_bundle_parser import ApigeeBundleParser
from core.kong_config_generator import KongConfigGenerator
from core.cache import BundleCache
from core.logger import setup_logging
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_async_parsing():
    """Test async parsing functionality"""
    print("Testing async parsing...")

    # Create a temporary directory with mock XML files
    with tempfile.TemporaryDirectory() as temp_dir:
        apiproxy_dir = os.path.join(temp_dir, 'apiproxy')
        proxies_dir = os.path.join(apiproxy_dir, 'proxies')
        targets_dir = os.path.join(apiproxy_dir, 'targets')
        policies_dir = os.path.join(apiproxy_dir, 'policies')

        os.makedirs(proxies_dir)
        os.makedirs(targets_dir)
        os.makedirs(policies_dir)

        # Create mock proxy endpoint XML
        proxy_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<ProxyEndpoint name="default">
    <HTTPProxyConnection>
        <BasePath>/test</BasePath>
        <VirtualHost>default</VirtualHost>
    </HTTPProxyConnection>
    <RouteRule name="default">
        <TargetEndpoint>default</TargetEndpoint>
    </RouteRule>
</ProxyEndpoint>'''
        with open(os.path.join(proxies_dir, 'default.xml'), 'w') as f:
            f.write(proxy_xml)

        # Create mock target endpoint XML
        target_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<TargetEndpoint name="default">
    <HTTPTargetConnection>
        <URL>http://example.com</URL>
    </HTTPTargetConnection>
</TargetEndpoint>'''
        with open(os.path.join(targets_dir, 'default.xml'), 'w') as f:
            f.write(target_xml)

        # Create mock policy XML
        policy_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<SpikeArrest name="Spike-Arrest-1">
    <Rate>30ps</Rate>
</SpikeArrest>'''
        with open(os.path.join(policies_dir, 'Spike-Arrest-1.xml'), 'w') as f:
            f.write(policy_xml)

        # Test parsing
        start_time = time.time()
        parser = ApigeeBundleParser(temp_dir, logger)
        parsed_data = await parser.parse()
        end_time = time.time()

        print(".2f")
        print(f"Parsed data keys: {list(parsed_data.keys())}")

        # Verify parsed data structure
        assert 'proxy_endpoints' in parsed_data
        assert 'target_endpoints' in parsed_data
        assert 'policies' in parsed_data
        assert len(parsed_data['proxy_endpoints']) > 0
        assert len(parsed_data['target_endpoints']) > 0
        assert len(parsed_data['policies']) > 0

        print("✓ Async parsing test passed")

async def test_async_generation():
    """Test async generation functionality"""
    print("Testing async generation...")

    # Mock parsed data
    parsed_data = {
        'proxy_endpoints': [{
            'name': 'default',
            'base_path': '/test',
            'virtual_hosts': ['default'],
            'route_rules': [{'target_endpoint': 'default'}]
        }],
        'target_endpoints': [{
            'name': 'default',
            'url': 'http://example.com'
        }]
    }

    # Test generation
    start_time = time.time()
    generator = KongConfigGenerator(logger)
    kong_config = await generator.generate(parsed_data)
    end_time = time.time()

    print(".2f")
    print("Generated Kong config (first 200 chars):")
    print(kong_config[:200] + "...")

    # Verify config structure
    assert '_format_version' in kong_config
    assert 'services' in kong_config
    assert 'routes' in kong_config
    assert len(kong_config['services']) > 0
    assert len(kong_config['routes']) > 0

    print("✓ Async generation test passed")

async def test_caching():
    """Test caching functionality"""
    print("Testing caching functionality...")

    with tempfile.TemporaryDirectory() as temp_dir:
        cache_dir = os.path.join(temp_dir, 'cache')
        cache = BundleCache(cache_dir, logger)

        # Create a test bundle
        bundle_dir = os.path.join(temp_dir, 'bundle')
        os.makedirs(bundle_dir)
        test_file = os.path.join(bundle_dir, 'test.txt')
        with open(test_file, 'w') as f:
            f.write('test content')

        # First cache operation (should miss)
        print("First cache operation (should miss)...")
        start_time = time.time()
        result1 = cache.get(bundle_dir)
        end_time = time.time()
        print(".4f")
        assert result1 is None, "Expected cache miss"

        # Set cache
        test_data = {'test': 'data'}
        cache.set(bundle_dir, test_data)

        # Second cache operation (should hit)
        print("Second cache operation (should hit)...")
        start_time = time.time()
        result2 = cache.get(bundle_dir)
        end_time = time.time()
        print(".4f")
        assert result2 == test_data, "Expected cache hit with correct data"

        print("✓ Caching test passed")

async def test_full_pipeline():
    """Test the full async pipeline with caching"""
    print("Testing full async pipeline with caching...")

    with tempfile.TemporaryDirectory() as temp_dir:
        # Create mock bundle
        bundle_dir = os.path.join(temp_dir, 'bundle')
        apiproxy_dir = os.path.join(bundle_dir, 'apiproxy')
        proxies_dir = os.path.join(apiproxy_dir, 'proxies')
        targets_dir = os.path.join(apiproxy_dir, 'targets')

        os.makedirs(proxies_dir)
        os.makedirs(targets_dir)

        # Create minimal proxy and target XMLs
        proxy_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<ProxyEndpoint name="default">
    <HTTPProxyConnection>
        <BasePath>/api</BasePath>
        <VirtualHost>default</VirtualHost>
    </HTTPProxyConnection>
    <RouteRule name="default">
        <TargetEndpoint>default</TargetEndpoint>
    </RouteRule>
</ProxyEndpoint>'''
        with open(os.path.join(proxies_dir, 'default.xml'), 'w') as f:
            f.write(proxy_xml)

        target_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<TargetEndpoint name="default">
    <HTTPTargetConnection>
        <URL>http://api.example.com</URL>
    </HTTPTargetConnection>
</TargetEndpoint>'''
        with open(os.path.join(targets_dir, 'default.xml'), 'w') as f:
            f.write(target_xml)

        # First run (should parse and cache)
        print("First run (parsing and caching)...")
        start_time = time.time()
        parser = ApigeeBundleParser(bundle_dir, logger)
        parsed_data = await parser.parse()
        generator = KongConfigGenerator(logger)
        kong_config = await generator.generate(parsed_data)
        first_run_time = time.time() - start_time
        print(".2f")

        # Second run (should use cache)
        print("Second run (using cache)...")
        start_time = time.time()
        parser2 = ApigeeBundleParser(bundle_dir, logger)
        parsed_data2 = await parser2.parse()
        generator2 = KongConfigGenerator(logger)
        kong_config2 = await generator2.generate(parsed_data2)
        second_run_time = time.time() - start_time
        print(".2f")

        # Verify results are identical
        assert parsed_data == parsed_data2, "Parsed data should be identical"
        assert kong_config == kong_config2, "Generated configs should be identical"

        print(".2f")
        print("✓ Full pipeline test passed")

async def main():
    """Run all tests"""
    print("Starting async and caching tests...\n")

    try:
        await test_async_parsing()
        print()

        await test_async_generation()
        print()

        await test_caching()
        print()

        await test_full_pipeline()
        print()

        print("🎉 All tests passed successfully!")

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
