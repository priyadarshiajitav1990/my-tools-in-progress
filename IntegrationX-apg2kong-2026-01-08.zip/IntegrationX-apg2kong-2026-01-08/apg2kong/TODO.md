# Apigee to Kong Migration Tool - TODO

## Phase 2: Enterprise Policies ✅ COMPLETED
- [x] Update policy-to-plugin.json with enterprise policy mappings
- [x] Create LDAPAuthenticationMapper using Kong's ldap-auth plugin
- [x] Create StatisticsCollectorMapper using Kong's statsd plugin
- [x] Update SAMLAssertionMapper (placeholder exists)
- [x] Rename ExternalCalloutMapper to ExtensionCalloutMapper
- [x] Update TODO.md

## Phase 3: Dynamic Plugin Adoption ✅ COMPLETED
- [x] Add plugin version compatibility checking in KongConfigGenerator
- [x] Create plugin configuration validation
- [x] Support custom plugin development (already partially there)
- [x] Update TODO.md

## Testing & Validation ✅ COMPLETED
- [x] Create test Apigee bundles with various policy combinations
- [x] Validate Kong configuration generation
- [x] Performance testing and optimization
- [x] Update TODO.md

## Phase 4: Enterprise Production Readiness
- [x] Enhance KongConfigGenerator.generate() to process flows and attach plugins in order with conditions
- [x] Add support for conditional routing by creating routes with conditions
- [x] Implement dynamic routing using Kong expressions
- [x] Ensure plugin order matches Apigee policy order
- [x] Add tests for custom flows, conditional flows, conditional policy executions, orders of policy executions, route rules, conditional routing, dynamic routing
- [x] Update TODO.md

## Phase 5: Tool Enhancement and Automation
### Task: Enhance Tool and Make `main.py` Entry Point
- [✅] Update `main.py` to orchestrate the entire process.

### Task: Process Apigee Proxy Zip
- [✅] Unzip the Apigee proxy zip from `input/` into `apigee_api/`.

### Task: Transpile Custom Logic to Lua Plugins
- [✅] Search `apigee_api/` for `.js`, `.jar`, and `.py` files.
- [✅] For each `.js` file, use `tools/our-tools/jstolua_tool.py` to create a custom Lua plugin.
- [✅] For each `.jar` file, use `tools/our-tools/jartolua_tool.py` to create a custom Lua plugin.
- [✅] For each `.py` file, use `tools/our-tools/pytolua_tool.py` to create a custom Lua plugin.
- [✅] Store generated Lua plugins in `custom_plugins/` or a similar designated directory.

### Task: Deploy Custom Lua Plugins to Kong Gateway
- [✅] Integrate `configs/deploy.py` to deploy generated Lua plugins.
- [✅] Ensure deployed plugins are enabled and configured on the remote Kong Gateway.

### Task: Generate Kong API Configuration YAML
- [✅] Read `configs/policy-to-plugin.json` for plugin mappings.
- [✅] Use appropriate mappers (Apigee to Kong) to create Kong API configuration.
- [✅] Generate Kong API Configuration YAML under `output/`.
- [✅] Add tags (Apigee API name) to each element in the YAML.

### Task: Validate and Deploy Kong API Configuration
- [✅] Validate the generated YAML using `deck gateway validate`.
- [✅] Deploy the API configuration using `deck gateway deploy` (only affecting the specific API).

### Error Resolution: `main.py` SyntaxError
- [✅] Fix `SyntaxError: expected 'except' or 'finally' block` in `main.py` by correctly placing `add_tags_to_kong_config`, `validate_kong_config`, and `deploy_kong_config` as top-level functions.

### Error Resolution: `main.py` NameError
- [✅] Fix `NameError: name 'generate_custom_plugins_if_missing' is not defined` by re-adding the function definition as a top-level function.

### Error Resolution: `main.py` ImportError
- [✅] Fix `ImportError` related to `cli` module by replacing `try-except` import for `cli` with direct import of `apg2kong_cli`.

### Task: Run `main.py` and fix any encountered issues.
- [✅] Run `main.py`.
- [ ] Fix any new issues.

### Error Resolution: `ModuleNotFoundError: No module named 'yaml'` (Environment Issue)
- [✅] Install `PyYAML` library.

### Task: Create and set up a virtual environment.
- [✅] Create virtual environment.
- [✅] Activate virtual environment.
- [✅] Install dependencies (`pyyaml` and any others).
- [🟡] Run `main.py` within the virtual environment.