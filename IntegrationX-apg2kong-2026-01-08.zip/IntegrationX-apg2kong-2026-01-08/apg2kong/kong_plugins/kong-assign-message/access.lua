local cjson = require "cjson"

local Access = {}

function Access.execute(conf)
  local ngx = ngx
  local req = ngx.req
  local res = ngx.resp
  local var = ngx.ctx.var

  -- Helper to resolve Apigee-style variables (very basic implementation)
  local function resolve_variable(value_str)
    if not value_str or type(value_str) ~= "string" then
      return value_str
    end
    -- Very basic variable resolution - needs to be more robust for production
    -- Example: {request.header.some_header} -> ngx.req.get_headers()["some_header"]
    -- This is a simplified example and would need a full Apigee-to-Kong variable mapping implementation.
    return value_str:gsub("{(%w+%.?%w*%.?%w*)}", function(var_name)
      if var_name:match("^request%.header%.") then
        local header_name = var_name:gsub("^request%.header%.", "")
        return req.get_headers()[header_name] or ""
      elseif var_name:match("^request%.queryparam%.") then
        local param_name = var_name:gsub("^request%.queryparam%.", "")
        return req.get_args()[param_name] or ""
      -- Add more variable types as needed
      end
      return "" -- Fallback for unresolved variables
    end)
  end

  -- SET operations
  if conf.set then
    if conf.set.headers then
      for _, header_data in ipairs(conf.set.headers) do
        local value = resolve_variable(header_data.value)
        req.set_header(header_data.name, value)
      end
    end
    if conf.set.parameters then
      -- Modifying query parameters requires more complex logic
      -- For simplicity, this example assumes setting request body parameters
      -- A real implementation would need to parse request body or handle specific parameter types
      -- Not directly supported in Kong 'access' phase for query params without full body parsing
    end
    if conf.set.payload then
      -- Setting payload in access phase is complex and typically done in body_filter
      -- This example will just log the intent
      ngx.log(ngx.INFO, "AssignMessage: Set payload logic not fully implemented in access phase.")
      -- For request body modification, a body_filter phase or a custom proxy-rewrite phase would be better.
      -- To set the *response* body, the header_filter or body_filter phase would be needed.
    end
  end

  -- ADD operations
  if conf.add then
    if conf.add.headers then
      for _, header_data in ipairs(conf.add.headers) do
        local value = resolve_variable(header_data.value)
        req.add_header(header_data.name, value)
      end
    end
    if conf.add.parameters then
      -- Similar to SET parameters, direct ADD to query params is complex in access phase
      ngx.log(ngx.INFO, "AssignMessage: Add parameters logic not fully implemented in access phase.")
    end
  end

  -- REMOVE operations
  if conf.remove then
    if conf.remove.headers then
      for _, header_data in ipairs(conf.remove.headers) do
        req.clear_header(header_data.name)
      end
    end
    if conf.remove.parameters then
      ngx.log(ngx.INFO, "AssignMessage: Remove parameters logic not fully implemented in access phase.")
    end
  end

  -- COPY operations
  if conf.copy then
    if conf.copy.headers then
      for _, header_data in ipairs(conf.copy.headers) do
        local source_value = req.get_headers()[header_data.source]
        if source_value then
          req.set_header(header_data.name, source_value)
        end
      end
    end
    if conf.copy.parameters then
      ngx.log(ngx.INFO, "AssignMessage: Copy parameters logic not fully implemented in access phase.")
    end
  end

  -- ASSIGN_VARIABLES
  if conf.assign_variables then
    for _, var_data in ipairs(conf.assign_variables) do
      local value = resolve_variable(var_data.value)
      -- Assign to ngx.ctx.var (Kong context variables)
      -- Note: These variables are local to the request context.
      -- For global or persistent variables, other Kong mechanisms (e.g., KV store) would be needed.
      var[var_data.name] = value
      ngx.log(ngx.INFO, "AssignMessage: Assigned variable: " .. var_data.name .. " = " .. value)
    end
  end

  -- Handle continue_on_error (currently no error conditions explicitly handled in this access logic)
  if not conf.continue_on_error then
    -- If there was an error in logic above, and continue_on_error is false,
    -- a typical Apigee behavior would be to raise a fault.
    -- For now, this is a placeholder. Real errors would need to be caught and ngx.exit() called.
  end
end

return Access
