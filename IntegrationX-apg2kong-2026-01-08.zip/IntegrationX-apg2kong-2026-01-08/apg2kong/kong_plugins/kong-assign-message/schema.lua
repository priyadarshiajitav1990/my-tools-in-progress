local typedefs = require "kong.db.schema.typedefs"

return {
  name = "kong-assign-message",
  fields = {
    { consumer = typedefs.no_consumer },
    { service = typedefs.no_service },
    { route = typedefs.no_route },
    { protocols = typedefs.protocols },
    { enabled = typedefs.enabled },
    { config = {
        type = "record",
        fields = {
          {set = {
            type = "record",
            fields = {
              {headers = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
              {parameters = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
              {payload = {
                type = "record",
                fields = {
                  {content = { type = "string" }},
                  {content_type = { type = "string" }},
                  {message_format = { type = "string" }},
                }
              }},
            }
          }},
          {add = {
            type = "record",
            fields = {
              {headers = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
              {parameters = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
            }
          }},
          {remove = {
            type = "record",
            fields = {
              {headers = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
              {parameters = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {name = { type = "string" }},
                    {value = { type = "string", default = "" }},
                  }
                }
              }},
            }
          }},
          {copy = {
            type = "record",
            fields = {
              {headers = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {source = { type = "string" }},
                    {name = { type = "string" }},
                  }
                }
              }},
              {parameters = {
                type = "array",
                elements = {
                  type = "record",
                  fields = {
                    {source = { type = "string" }},
                    {name = { type = "string" }},
                  }
                }
              }},
            }
          }},
          {assign_variables = {
            type = "array",
            elements = {
              type = "record",
              fields = {
                {name = { type = "string" }},
                {value = { type = "string" }},
                {ref = { type = "string", default = "" }},
              }
            }
          }},
          {continue_on_error = { type = "boolean", default = false }},
        },
      },
    },
    { ordering = typedefs.plugin_ordering },
    { tags = typedefs.tags },
  },
}
