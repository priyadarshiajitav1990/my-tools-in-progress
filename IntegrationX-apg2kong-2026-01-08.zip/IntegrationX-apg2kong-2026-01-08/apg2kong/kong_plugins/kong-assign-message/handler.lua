local BasePlugin = require "kong.plugins.base_plugin"
local Access = require "kong.plugins.kong-assign-message.access"
local Logger = require "kong.plugins.kong-assign-message.logger"

local PLUGIN_NAME = "kong-assign-message"
local PLUGIN_PRIORITY = 1000 -- Assign a suitable priority
local PLUGIN_VERSION = "0.1.0"

local CustomPlugin = BasePlugin:extend(PLUGIN_NAME)

function CustomPlugin:new()
  return BasePlugin.new(self, PLUGIN_NAME)
end

function CustomPlugin:access(conf)
  Access.execute(conf)
end

function CustomPlugin:log(conf)
  Logger.execute(conf)
end

CustomPlugin.PRIORITY = PLUGIN_PRIORITY
CustomPlugin.VERSION = PLUGIN_VERSION

return CustomPlugin
