// apg2kong/tools/js_to_ast.js
const acorn = require("acorn");
const fs = require("fs");

let jsCode = '';

process.stdin.on('data', (chunk) => {
    jsCode += chunk;
});

process.stdin.on('end', () => {
    try {
        const ast = acorn.parse(jsCode, {
            ecmaVersion: 2020, // Support modern JavaScript features
            sourceType: "module", // or "script" depending on the input
        });
        console.log(JSON.stringify(ast, null, 2));
    } catch (error) {
        console.error(JSON.stringify({ error: error.message, stack: error.stack }, null, 2));
        process.exit(1);
    }
});
