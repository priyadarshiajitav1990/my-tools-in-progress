export enum DefaultTeamNames {
  ORGANIZATION_ADMIN = 'organization-admin',
  ORGANIZATION_ADMIN_READONLY = 'organization-admin-readonly',
  PORTAL_ADMIN = 'portal-admin',
  RUNTIME_ADMIN = 'runtime-admin',
  SERVICE_ADMIN = 'service-admin',
  SERVICE_DEVELOPER = 'service-developer',
  ANALYTICS_ADMIN = 'analytics-admin',
  ANALYTICS_VIEWER = 'analytics-viewer',
}