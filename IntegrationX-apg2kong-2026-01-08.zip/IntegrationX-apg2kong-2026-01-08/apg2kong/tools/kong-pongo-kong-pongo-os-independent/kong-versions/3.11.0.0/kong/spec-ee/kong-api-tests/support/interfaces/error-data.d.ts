export interface ErrorData {
  errors: Array<{ status: string; title: string }>;
}
