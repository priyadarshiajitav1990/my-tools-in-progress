export interface Consumer {
  username: string;
  custom_id?: string;
  id?: string;
  tags?: string[];
  username_lower?: string;
}