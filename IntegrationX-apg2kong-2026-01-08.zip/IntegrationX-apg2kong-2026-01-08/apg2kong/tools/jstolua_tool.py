
import subprocess
import json
import os
import logging
import sys
from datetime import datetime

logger = logging.getLogger(__name__)

JS_TO_AST_SCRIPT_PATH = os.path.join(os.path.dirname(__file__), "js_to_ast.js")

# --- JavaScript AST Visitor ---
class JavaScriptASTVisitor:
    """
    A basic visitor pattern for Acorn-generated JavaScript AST nodes (represented as Python dicts/lists).
    """
    def __init__(self):
        self.extracted_info = {
            "functions": [],
            "variables": [],
            "classes": [] # JavaScript classes (ES6)
        }

    def visit(self, node):
        if isinstance(node, dict) and 'type' in node:
            node_type = node['type']
            method_name = 'visit_' + node_type
            visitor = getattr(self, method_name, self.generic_visit)
            return visitor(node)
        elif isinstance(node, list):
            for item in node:
                self.visit(item)
        # Primitives or other non-AST structures are ignored by generic_visit

    def generic_visit(self, node):
        """Called if no explicit visit function exists for a node type."""
        logger.debug(f"Visiting generic JS node: {node.get('type', 'N/A')}")
        if isinstance(node, dict):
            for key, value in node.items():
                # Avoid infinite recursion on 'loc', 'range' etc. and 'type'
                if key not in ['type', 'loc', 'range', 'start', 'end', 'raw']:
                    self.visit(value)
        elif isinstance(node, list):
            for item in node:
                self.visit(item)

    # Example visitor methods for common types (add more as needed)
    def visit_Program(self, node):
        logger.debug("Visiting Program node (root of AST)")
        self.generic_visit(node)

    def visit_FunctionDeclaration(self, node):
        function_name = node['id']['name'] if node['id'] else 'anonymous'
        params = [p['name'] for p in node['params']]
        self.extracted_info['functions'].append({'name': function_name, 'params': params, 'type': 'declaration'})
        logger.debug(f"  Found FunctionDeclaration: {function_name}({', '.join(params)})")
        self.generic_visit(node)

    def visit_FunctionExpression(self, node):
        function_name = node['id']['name'] if node['id'] else 'anonymous_expression'
        params = [p['name'] for p in node['params']]
        self.extracted_info['functions'].append({'name': function_name, 'params': params, 'type': 'expression'})
        logger.debug(f"  Found FunctionExpression: {function_name}({', '.join(params)})")
        self.generic_visit(node)
    
    def visit_VariableDeclarator(self, node):
        var_name = node['id']['name']
        self.extracted_info['variables'].append({'name': var_name, 'type': 'declarator'})
        logger.debug(f"  Found VariableDeclarator: {var_name}")
        self.generic_visit(node)

    def visit_ClassDeclaration(self, node):
        class_name = node['id']['name']
        super_class = node['superClass']['name'] if node['superClass'] else None
        self.extracted_info['classes'].append({'name': class_name, 'superClass': super_class})
        logger.debug(f"  Found ClassDeclaration: {class_name} extends {super_class}")
        self.generic_visit(node)

# --- JavaScript to Lua Transpiler ---
class JavaScriptToLuaTranspiler:
    def __init__(self):
        self.indent_level = 0
        self.output_lines = []

    def _indent(self, code):
        if not code.strip():
            return code
        return "  " * self.indent_level + code

    def _add_line(self, line):
        self.output_lines.append(self._indent(line))

    def transpile(self, node):
        if isinstance(node, dict) and 'type' in node:
            node_type = node['type']
            method_name = 'transpile_' + node_type
            transpiler_method = getattr(self, method_name, self.generic_transpile)
            return transpiler_method(node)
        elif isinstance(node, list):
            return "\n".join(filter(None, [self.transpile(item) for item in node]))
        return ""

    def generic_transpile(self, node):
        logger.warning(f"No specific transpilation rule for node type: {node.get('type', 'N/A')}. Attempting generic traversal.")
        generated_code_parts = []
        if isinstance(node, dict):
            for key, value in node.items():
                if key not in ['type', 'loc', 'range', 'start', 'end', 'raw']:
                    transpiled_part = self.transpile(value)
                    if transpiled_part:
                        generated_code_parts.append(transpiled_part)
        elif isinstance(node, list):
            for item in node:
                transpiled_part = self.transpile(item)
                if transpiled_part:
                    generated_code_parts.append(transpiled_part)
        return "\n".join(filter(None, generated_code_parts))
    
    def transpile_Program(self, node):
        self.indent_level = 0
        self.output_lines = []

        for body_node in node['body']:
            self._add_line(self.transpile(body_node))
        return "\n".join(self.output_lines)

    def transpile_ExpressionStatement(self, node):
        return self.transpile(node['expression'])

    def transpile_CallExpression(self, node):
        callee = self.transpile(node['callee'])
        args = [self.transpile(arg) for arg in node['arguments']]
        return f"{callee}({', '.join(args)})"
    
    def transpile_MemberExpression(self, node):
        obj = self.transpile(node['object'])
        prop = node['property']['name'] if node['property']['type'] == 'Identifier' else self.transpile(node['property'])
        return f"{obj}.{prop}"

    def transpile_Identifier(self, node):
        return node['name']
    
    def transpile_Literal(self, node):
        if isinstance(node['value'], str):
            return f'"{node["value"]}"'
        elif isinstance(node['value'], bool):
            return str(node['value']).lower()
        elif node['value'] is None:
            return "nil"
        return str(node['value'])

    def transpile_VariableDeclaration(self, node):
        declarations = []
        for declarator in node['declarations']:
            var_name = declarator['id']['name']
            init_value = self.transpile(declarator['init']) if declarator['init'] else "nil"
            declarations.append(f"local {var_name} = {init_value}")
        return "\n".join(declarations)


def parse_js_to_ast(js_code):
    """
    Parses JavaScript code into an AST using the Node.js 'js_to_ast.js' script
    and returns the AST as a Python dictionary.
    """
    if not os.path.exists(JS_TO_AST_SCRIPT_PATH):
        logger.error(f"Node.js AST parsing script not found at '{JS_TO_AST_SCRIPT_PATH}'.")
        return None

    try:
        # Execute the Node.js script, passing JavaScript code via stdin
        process = subprocess.run(
            ["node", JS_TO_AST_SCRIPT_PATH],
            input=js_code,
            capture_output=True,
            text=True,
            check=True
        )
        
        ast_json = process.stdout
        ast_data = json.loads(ast_json)
        logger.info("Successfully parsed JavaScript to AST using Node.js.")
        return ast_data
    except subprocess.CalledProcessError as e:
        logger.error(f"Node.js script failed with exit code {e.returncode}.")
        logger.error(f"STDOUT: {e.stdout}")
        logger.error(f"STDERR: {e.stderr}")
        try:
            error_details = json.loads(e.stderr)
            if error_details.get('error'):
                logger.error(f"JavaScript parsing error: {error_details['error']}")
        except json.JSONDecodeError:
            pass # Not a JSON error from script
        return None
    except json.JSONDecodeError as e:
        logger.error(f"Failed to decode JSON AST from Node.js script output: {e}")
        logger.error(f"Node.js STDOUT (partial): {process.stdout[:500]}...")
        return None
    except FileNotFoundError:
        logger.error(" 'node' command not found. Please ensure Node.js is installed and in your PATH.")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during JavaScript AST parsing: {e}")
        return None

def convert_js_to_lua_plugin(js_code, output_base_dir, plugin_name):
    """
    Converts JavaScript code into a Kong Lua custom plugin.
    This involves:
    1. Parsing JavaScript code into an AST.
    2. Analyzing the JavaScript AST and transpiling to Lua.
    3. Generating Kong custom plugin structure (handler.lua, schema.lua).
    """
    logger.info(f"Starting conversion of JavaScript to Kong Lua plugin '{plugin_name}'...")

    # --- Step 1: Parse JavaScript code into an AST ---
    js_ast = parse_js_to_ast(js_code)
    if not js_ast:
        logger.error("Failed to parse JavaScript code to AST. Aborting Lua plugin conversion.")
        return False
    
    logger.debug(f"JavaScript AST: {json.dumps(js_ast, indent=2)}")

    # --- Step 2: Analyze JavaScript AST and transpiling to Lua ---
    logger.info("Starting JavaScript AST traversal for analysis...")
    visitor = JavaScriptASTVisitor()
    visitor.visit(js_ast) # Start traversal from the root 'Program' node
    logger.info("Finished JavaScript AST traversal.")

    logger.info(f"Extracted Functions: {len(visitor.extracted_info['functions'])}")
    for func_info in visitor.extracted_info['functions']:
        logger.debug(f"  Function: {func_info['name']}({', '.join(func_info['params'])})")
    
    logger.info(f"Extracted Variables: {len(visitor.extracted_info['variables'])}")
    for var_info in visitor.extracted_info['variables']:
        logger.debug(f"  Variable: {var_info['name']}")
        
    logger.info(f"Extracted Classes: {len(visitor.extracted_info['classes'])}")
    for cls_info in visitor.extracted_info['classes']:
        logger.debug(f"  Class: {cls_info['name']} (Super: {cls_info['superClass']})")


    logger.info("Starting JavaScript to Lua transpilation...")
    transpiler = JavaScriptToLuaTranspiler()
    final_lua_output = transpiler.transpile(js_ast) # Transpile the entire AST
    
    if final_lua_output:
        logger.info("Aggregated transpiled Lua code generated.")
        logger.debug(final_lua_output)
    else:
        logger.warning("No Lua code was transpiled.")


    # --- Step 3: Generating Kong custom plugin structure (handler.lua, schema.lua) ---
    lua_plugin_dir = os.path.join(output_base_dir, f"kong_{plugin_name}_plugin")
    os.makedirs(lua_plugin_dir, exist_ok=True)

    handler_lua_content = f"""
-- This file contains the transpiled Lua logic from the Apigee JavaScript.
-- It should be placed in Kong's plugins directory.

local BasePlugin = require "kong.plugins.base_plugin"
local PLUGIN_NAME = "{plugin_name}"

{final_lua_output}

-- Main handler for the plugin
local {plugin_name}Handler = BasePlugin:extend(PLUGIN_NAME)

function {plugin_name}Handler:new()
  {plugin_name}Handler.super.new(self, PLUGIN_NAME)
end

function {plugin_name}Handler:access(conf)
  {plugin_name}Handler.super.access(self)
  kong.log.inspect("Executing {plugin_name} access phase with configuration:", conf)
  -- Here you would call the entry point of your transpiled JavaScript logic.
  kong.log.notice("Transpiled JavaScript logic for {plugin_name} executed successfully.")
end

-- Add other lifecycle phases as needed (init_worker, rewrite, certificate, header_filter, response, log)

return {plugin_name}Handler
"""
    schema_fields = []
    for func_info in visitor.extracted_info['functions']:
        schema_fields.append(f"        {{ {func_info['name'].lower()} = {{ type = \"string\", default = \"default_value\", description = \"Config for JS function: {func_info['name']}.\" }} }}")
    
    for var_info in visitor.extracted_info['variables']:
        schema_fields.append(f"        {{ {var_info['name'].lower()} = {{ type = \"string\", default = \"default_value\", description = \"Config for JS variable: {var_info['name']}.\" }} }}")

    for cls_info in visitor.extracted_info['classes']:
        schema_fields.append(f"        {{ {cls_info['name'].lower()} = {{ type = \"string\", default = \"default_value\", description = \"Config for JS class: {cls_info['name']}.\" }} }}")
    
    if not schema_fields:
        schema_fields.append(f"        {{ some_js_param = {{ type = \"string\", default = \"default_value\", description = \"Placeholder for a parameter from JavaScript.\" }} }}")


    schema_lua_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
  name = "{plugin_name}",
  fields = {{
    {{ consumer = typedefs.no_consumer }},
    {{ service = typedefs.no_service }},
    {{ route = typedefs.no_route }},
    {{ protocols = typedefs.protocols }},
    {{ config = {{
      type = "record",
      fields = {{
{',\n'.join(schema_fields)}
      }},
    }} }},
  }},
}}
"""
    with open(os.path.join(lua_plugin_dir, "handler.lua"), "w") as f:
        f.write(handler_lua_content)
    with open(os.path.join(lua_plugin_dir, "schema.lua"), "w") as f:
        f.write(schema_lua_content)

    logger.info(f"Generated placeholder Kong Lua plugin structure for '{plugin_name}' in '{lua_plugin_dir}'")

    logger.info(f"Conversion of JavaScript to Kong Lua plugin '{plugin_name}' completed (with placeholder transpilation).")
    return True

if __name__ == "__main__":
    log_dir = 'logs'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_filename = datetime.now().strftime(f"{log_dir}/jstolua_tool_%Y-%m-%d.log")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    logger = logging.getLogger(__name__)


    if len(sys.argv) != 4:
        logger.info("Usage: python jstolua_tool.py <js_file_path> <output_base_directory> <plugin_name>")
        logger.info("Example: python jstolua_tool.py myjs.js ./output myjsplugin")
        sys.exit(1)

    input_js_file_path = sys.argv[1]
    output_base_dir = sys.argv[2]
    plugin_name = sys.argv[3]

    if not os.path.exists(input_js_file_path):
        logger.error(f"Input JavaScript file not found at '{input_js_file_path}'.")
        sys.exit(1)

    with open(input_js_file_path, 'r', encoding='utf-8') as f:
        js_code_to_transpile = f.read()

    convert_js_to_lua_plugin(js_code_to_transpile, output_base_dir, plugin_name)