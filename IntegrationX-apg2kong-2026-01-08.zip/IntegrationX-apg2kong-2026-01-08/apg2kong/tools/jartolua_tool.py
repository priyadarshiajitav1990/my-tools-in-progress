import zipfile
import os
import shutil
import subprocess
import sys
import logging
import javalang
import javalang.tree
from datetime import datetime

# --- Constants ---
CFR_DECOMPILER_FILENAME = "cfr-0.152.jar"
CFR_DECOMPILER_PATH = os.environ.get("CFR_DECOMPILER_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), CFR_DECOMPILER_FILENAME))

logger = logging.getLogger(__name__)

# --- Java AST Visitor ---
class JavaASTVisitor:
    """
    A basic visitor pattern for javalang AST nodes to extract class, method, and field information.
    """
    def __init__(self):
        self.extracted_info = {
            "classes": [],
            "methods": [],
            "fields": []
        }
        self.current_class = None

    def visit(self, node):
        method_name = 'visit_' + type(node).__name__
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        for child in node.children:
            if isinstance(child, javalang.tree.Node):
                self.visit(child)
            elif isinstance(child, list):
                for item in child:
                    if isinstance(item, javalang.tree.Node):
                        self.visit(item)

    def visit_CompilationUnit(self, node):
        self.generic_visit(node)

    def visit_ClassDeclaration(self, node):
        class_info = {
            "name": node.name,
            "modifiers": [str(m) for m in node.modifiers],
            "implements": [impl.name for impl in node.implements] if node.implements else [],
            "extends": node.extends.name if node.extends else None,
            "position": node.position
        }
        self.extracted_info["classes"].append(class_info)
        logger.debug(f"Identified Class: {node.name}")

        original_current_class = self.current_class
        self.current_class = node.name
        self.generic_visit(node)
        self.current_class = original_current_class

    def visit_MethodDeclaration(self, node):
        method_info = {
            "name": node.name,
            "return_type": node.return_type.name if node.return_type else "void",
            "modifiers": [str(m) for m in node.modifiers],
            "parameters": [{"name": param.name, "type": param.type.name} for param in node.parameters],
            "parent_class": self.current_class,
            "position": node.position
        }
        self.extracted_info["methods"].append(method_info)
        logger.debug(f"  Identified Method: {self.current_class}.{node.name}")
        self.generic_visit(node)

    def visit_FieldDeclaration(self, node):
        for declarator in node.declarators:
            field_info = {
                "name": declarator.name,
                "type": node.type.name,
                "modifiers": [str(m) for m in node.modifiers],
                "parent_class": self.current_class,
                "init_value": declarator.initializer.value if declarator.initializer and hasattr(declarator.initializer, 'value') else None,
                "position": node.position
            }
            self.extracted_info["fields"].append(field_info)
            logger.debug(f"  Identified Field: {self.current_class}.{declarator.name} (Type: {node.type.name})")
        self.generic_visit(node)

# --- Type Mapping Function ---
def map_java_type_to_lua(java_type):
    """
    Maps a Java data type string to its equivalent Lua data type.
    """
    type_map = {
        "byte": "number", "short": "number", "int": "number", "long": "number",
        "float": "number", "double": "number", "char": "string",
        "boolean": "boolean", "String": "string", "Object": "table", "void": "nil",
    }
    return type_map.get(java_type, "table")

# --- Lua Transpiler ---
class LuaTranspiler:
    def __init__(self):
        self.indent_level = 0
        self.current_class = None
        self.output_lines = []

    def _indent(self, code):
        if not code.strip():
            return code
        return "  " * self.indent_level + code

    def _add_line(self, line):
        self.output_lines.append(self._indent(line))

    def transpile(self, node):
        method_name = 'transpile_' + type(node).__name__
        transpiler_method = getattr(self, method_name, self.generic_transpile)
        return transpiler_method(node)

    def generic_transpile(self, node):
        generated_code_parts = []
        for child in node.children:
            if isinstance(child, javalang.tree.Node):
                transpiled_child = self.transpile(child)
                if transpiled_child:
                    generated_code_parts.append(transpiled_child)
            elif isinstance(child, list):
                for item in child:
                    if isinstance(item, javalang.tree.Node):
                        transpiled_item = self.transpile(item)
                        if transpiled_item:
                            generated_code_parts.append(transpiled_item)
        return "\n".join(generated_code_parts)

    def transpile_CompilationUnit(self, node):
        for type_decl in node.types:
            if isinstance(type_decl, javalang.tree.ClassDeclaration):
                self.transpile_ClassDeclaration(type_decl)
        return "\n".join(self.output_lines)

    def transpile_ClassDeclaration(self, node):
        class_name = node.name
        super_class_name = node.extends.name if node.extends else None

        self._add_line(f"local {class_name} = {{}}")
        self._add_line(f"{class_name}.__index = {class_name}")

        if super_class_name:
            self._add_line(f"setmetatable({class_name}, {{ __index = {super_class_name} }})")
        
        self._add_line(f"function {class_name}:new(...) ")
        self.indent_level += 1
        self._add_line("local instance = setmetatable({}, { __index = self })")
        if super_class_name:
            self._add_line(f"self.super:new(instance, ...) -- Call superclass constructor")
        
        java_constructor_found = False
        for member in node.body:
            if isinstance(member, javalang.tree.MethodDeclaration) and member.name == class_name and member.return_type is None:
                java_constructor_found = True
                break
        
        if java_constructor_found:
            self._add_line(f"instance:{class_name}_init(...) -- Call transpiled Java constructor")
        
        self._add_line("return instance")
        self.indent_level -= 1
        self._add_line("end")

        original_current_class = self.current_class
        self.current_class = class_name

        for member in node.body:
            if isinstance(member, javalang.tree.MethodDeclaration):
                self.transpile_MethodDeclaration(member, is_class_member=True)
            elif isinstance(member, javalang.tree.FieldDeclaration):
                self.transpile_FieldDeclaration(member, is_class_member=True)

        self.current_class = original_current_class

    def transpile_MethodDeclaration(self, node, is_class_member=False):
        function_name = node.name
        parameters = [param.name for param in node.parameters]
        
        is_java_constructor = (node.name == self.current_class) and (node.return_type is None)

        if is_class_member and not any(m == 'static' for m in node.modifiers):
            parameters.insert(0, "self")
        
        param_str = ", ".join(parameters)

        method_definition_start = ""
        if is_class_member:
            if is_java_constructor:
                method_definition_start = f"function {self.current_class}:{self.current_class}_init({param_str})"
            elif any(m == 'static' for m in node.modifiers):
                method_definition_start = f"function {self.current_class}.{function_name}({param_str})"
            else:
                method_definition_start = f"function {self.current_class}:{function_name}({param_str})"
        else:
            method_definition_start = f"function {function_name}({param_str})"
        
        self._add_line(method_definition_start)
        self.indent_level += 1
        method_body_lua = self.transpile(node.body) if node.body else ""
        if method_body_lua:
            for line in method_body_lua.splitlines():
                self._add_line(line)
        self.indent_level -= 1
        self._add_line("end")


    def transpile_FieldDeclaration(self, node, is_class_member=False):
        for declarator in node.declarators:
            var_name = declarator.name
            init_value_lua = self.transpile(declarator.initializer) if declarator.initializer else "nil"
            
            if is_class_member:
                if any(m == 'static' for m in node.modifiers):
                    self._add_line(f"{self.current_class}.{var_name} = {init_value_lua}")
                else:
                    self._add_line(f"-- instance.{var_name} = {init_value_lua} (Java instance field)")
            else:
                self._add_line(f"{var_name} = {init_value_lua}")

    def transpile_MethodInvocation(self, node):
        args_lua = [self.transpile(arg) for arg in node.arguments]
        args_str = ", ".join(args_lua)

        if node.qualifier and node.qualifier == "System" and node.member == "out" and node.selector and node.selector.member == "println":
            return f"kong.log.notice({args_str})"
        elif node.qualifier and node.qualifier == "System" and node.member == "out" and node.selector and node.selector.member == "print":
            return f"kong.log.debug({args_str})"

        target_lua = ""
        if node.qualifier:
            target_lua = self.transpile(node.qualifier)
        
        if target_lua:
            if target_lua == "self":
                 return f"{target_lua}:{node.member}({args_str})"
            else:
                 return f"{target_lua}.{node.member}({args_str})"
        
        function_name = node.member
        if self.current_class:
            function_name = f"self:{function_name}"

        return f"{function_name}({args_str})"

    def transpile_IfStatement(self, node):
        condition_lua = self.transpile(node.condition)
        
        lua_if_statement_parts = [f"if {condition_lua} then"]
        self.indent_level += 1
        lua_if_statement_parts.append(self.transpile(node.then_statement))
        self.indent_level -= 1

        if node.else_statement:
            lua_if_statement_parts.append("else")
            self.indent_level += 1
            lua_if_statement_parts.append(self.transpile(node.else_statement))
            self.indent_level -= 1
        
        lua_if_statement_parts.append("end")
        return "\n".join(filter(None, lua_if_statement_parts))

    def transpile_Literal(self, node):
        if isinstance(node.value, str):
            return f'"{node.value}"'
        if node.value in ['true', 'false']:
            return node.value.lower()
        if node.value is None:
            return 'nil'
        return str(node.value)

    def transpile_BlockStatement(self, node):
        generated_code = []
        for statement in node.statements:
            transpiled_statement = self.transpile(statement)
            if transpiled_statement:
                generated_code.append(transpiled_statement)
        return "\n".join(generated_code)

    def transpile_StatementExpression(self, node):
        return self.transpile(node.expression)

    def transpile_LocalVariableDeclaration(self, node):
        declarators_code = []
        for declarator in node.declarators:
            var_name = declarator.name
            init_value_lua = self.transpile(declarator.initializer) if declarator.initializer else ""
            
            if not init_value_lua.strip():
                 init_value_lua = "nil"

            declarators_code.append(f"local {var_name} = {init_value_lua}")
        return "\n".join(declarators_code)
    
    def transpile_BinaryOperation(self, node):
        left = self.transpile(node.operandl)
        right = self.transpile(node.operandr)
        operator_map = {
            "==": "==", "!=": "~=",
            "&&": "and", "||": "or",
            "&": "&", "|": "|", "^": "~",
            "instanceof": " --[[ instanceof (not direct Lua equivalent) ]] ",
            "+": "+", "-": "-", "*": "*", "/": "/", "%": "%",
            ">": ">", "<": "<", ">=": ">=", "<=": "<=",
        }
        op = operator_map.get(node.operator, node.operator)
        return f"({left} {op} {right})"
    
    def transpile_MemberReference(self, node):
        if node.qualifier:
            return f"{self.transpile(node.qualifier)}.{node.member}"
        return node.member
    
    def transpile_Assignment(self, node):
        target = self.transpile(node.value)
        value = self.transpile(node.expression)
        return f"{target} = {value}"

    def transpile_UnaryOperator(self, node):
        operand = self.transpile(node.operand)
        operator_map = {
            "++": "{0} = {0} + 1".format(operand),
            "--": "{0} = {0} - 1".format(operand),
            "!": "not {0}".format(operand),
            "-": "-{0}".format(operand),
            "+": "{0}".format(operand),
        }
        return operator_map.get(node.operator, f"--[[ UNHANDLED UNARY OPERATOR: {node.operator} {operand} ]]--")

    def transpile_Cast(self, node):
        cast_type = node.type.name
        value = self.transpile(node.expression)
        return f" --[[ ({cast_type}){value} (Java cast ignored in Lua) ]]-- {value}"

    def transpile_BasicType(self, node):
        return map_java_type_to_lua(node.name)

    def transpile_TryStatement(self, node):
        lua_try_block_lines = []
        self.indent_level += 1
        lua_try_block_lines.append(self.transpile(node.block))
        self.indent_level -= 1
        try_block_content = "\n".join(filter(None, lua_try_block_lines))

        lua_catch_blocks = []
        for catch_clause in node.catches:
            exception_type = catch_clause.parameter.type.name
            exception_name = catch_clause.parameter.name
            
            catch_block_lines = []
            self.indent_level += 1
            catch_block_lines.append(self.transpile(catch_clause.block))
            self.indent_level -= 1
            catch_block_content = "\n".join(filter(None, catch_block_lines))
            
            lua_catch_blocks.append(f"  -- Catch block for {exception_type} as {exception_name}\n{catch_block_content}")

        lua_finally_block = ""
        if node.finally_block:
            finally_block_lines = []
            self.indent_level += 1
            finally_block_lines.append(self.transpile(node.finally_block))
            self.indent_level -= 1
            lua_finally_block = "\n  -- Finally block\n" + "\n".join(filter(None, finally_block_lines))


        lua_code = []
        lua_code.append(self._indent(f"local success, err = pcall(function()") )
        self.indent_level += 1
        lua_code.append(try_block_content)
        self.indent_level -= 1
        lua_code.append(self._indent(f"end)"))

        lua_code.append(self._indent(f"if not success then"))
        self.indent_level += 1
        lua_code.append(self._indent(f"kong.log.err('Error in transpiled Java try block: ' .. tostring(err))"))
        for catch_block in lua_catch_blocks:
            lua_code.append(self._indent(catch_block))
        self.indent_level -= 1
        lua_code.append(self._indent(f"end"))

        if lua_finally_block:
            lua_code.append(self._indent(lua_finally_block))

        return "\n".join(lua_code)



# --- Core Functions ---
def extract_jar(jar_path, output_dir):
    """
    Extracts the contents of a JAR file to a specified output directory.
    """
    if not os.path.exists(jar_path):
        logger.error(f"JAR file not found at '{jar_path}'")
        return False

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    logger.info(f"Extracting '{jar_path}' to '{output_dir}'...")
    try:
        with zipfile.ZipFile(jar_path, 'r') as zip_ref:
            zip_ref.extractall(output_dir)
        logger.info(f"Successfully extracted.")
        return True
    except zipfile.BadZipFile:
        logger.error(f"'{jar_path}' is not a valid JAR/ZIP file.")
        return False
    except Exception as e:
        logger.error(f"An unexpected error occurred during extraction: {e}")
        return False

def find_class_files(directory):
    """
    Finds all .class files within a given directory and its subdirectories.
    Returns a list of absolute paths to the class files.
    """
    class_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.class'):
                class_files.append(os.path.join(root, file))
    logger.info(f"Found {len(class_files)} .class files in '{directory}'")
    return class_files

def decompile_class_file(class_file_path, cfr_path, output_dir):
    """
    Decompiles a single .class file using CFR.
    The output .java file will be placed in a structure relative to output_dir
    mimicking the package structure of the class file.
    """
    if not os.path.exists(cfr_path):
        logger.error(f"CFR decompiler not found at '{cfr_path}'.")
        logger.error(f"Please download '{CFR_DECOMPILER_FILENAME}' from https://www.benf.org/other/cfr/ and place it in the same directory as this script, or update CFR_DECOMPILER_PATH environment variable.")
        return False

    command = [
        "java",
        "-jar",
        cfr_path,
        class_file_path,
        "--outputdir",
        output_dir
    ]

    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return True
    except FileNotFoundError:
        logger.error(" 'java' command not found. Please ensure Java JRE/JDK is installed and in your PATH.")
        return False
    except subprocess.CalledProcessError as e:
        logger.error(f"Error decompiling '{class_file_path}' using CFR.")
        logger.error(f"CFR STDOUT:\n{e.stdout}")
        logger.error(f"CFR STDERR:\n{e.stderr}")
        return False
    except Exception as e:
        logger.error(f"An unexpected error occurred during decompilation of '{class_file_path}': {e}")
        return False

def parse_java_file(java_file_path):
    """
    Parses a Java source file and returns its Abstract Syntax Tree (AST).
    """
    if not os.path.exists(java_file_path):
        logger.error(f"Java file not found at '{java_file_path}' for parsing.")
        return None

    try:
        with open(java_file_path, 'r', encoding='utf-8') as f:
            java_code = f.read()
        tree = javalang.parse.parse(java_code)
        logger.info(f"Successfully parsed Java file: '{java_file_path}'")
        return tree
    except javalang.tokenizer.LexerError as e:
        logger.error(f"Lexer error while parsing '{java_file_path}': {e}")
        return None
    except javalang.parser.JavaSyntaxError as e:
        logger.error(f"Syntax error while parsing '{java_file_path}': {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during parsing '{java_file_path}': {e}")
        return None


def convert_jar_to_lua_plugin(jar_file_path, output_base_dir, plugin_name):
    """
    Converts a Java JAR file (representing an Apigee Java callout) into a Kong Lua custom plugin.
    This involves:
    1. Decompiling the JAR to Java source code.
    2. Analyzing Java source code and transpiling to Lua.
    3. Generating Kong custom plugin structure (handler.lua, schema.lua).
    """
    logger.info(f"Starting conversion of JAR '{jar_file_path}' to Kong Lua plugin '{plugin_name}'...")

    # --- Step 1: Decompile JAR to Java source code ---
    temp_extract_dir = os.path.join(output_base_dir, f"{plugin_name}_temp_extracted")
    java_source_output_dir = os.path.join(output_base_dir, f"{plugin_name}_java_source")

    if os.path.exists(temp_extract_dir):
        shutil.rmtree(temp_extract_dir)
    if os.path.exists(java_source_output_dir):
        shutil.rmtree(java_source_output_dir)

    os.makedirs(java_source_output_dir, exist_ok=True)

    if not extract_jar(jar_file_path, temp_extract_dir):
        logger.error("JAR extraction failed. Aborting Lua plugin conversion.")
        return False

    class_files = find_class_files(temp_extract_dir)

    if not class_files:
        logger.warning("No .class files found in the JAR. Cannot proceed with decompilation for Lua plugin conversion.")
        shutil.rmtree(temp_extract_dir)
        return False

    decompiled_count = 0
    for i, class_file in enumerate(class_files):
        logger.debug(f"Decompiling: '{os.path.relpath(class_file, temp_extract_dir)}'")
        if decompile_class_file(class_file, CFR_DECOMPILER_PATH, java_source_output_dir):
            decompiled_count += 1
        else:
            logger.warning(f"Failed to decompile '{os.path.relpath(class_file, temp_extract_dir)}'")

    logger.info(f"Decomposition complete. Successfully decompiled {decompiled_count} out of {len(class_files)} .class files.")
    logger.info(f"Decompiled Java source code is located in: '{java_source_output_dir}'")

    # Clean up the temporary extracted files
    shutil.rmtree(temp_extract_dir)
    logger.info("Temporary extraction files cleaned up.")

    # --- Step 2: Analyze Java source code and transpiling to Lua ---
    java_asts = {}
    visitor = JavaASTVisitor() # Initialize visitor outside the loop to collect global info
    if decompiled_count > 0:
        logger.info("Starting Java source code parsing...")
        for root, _, files in os.walk(java_source_output_dir):
            for file in files:
                if file.endswith('.java'):
                    java_file_path = os.path.join(root, file)
                    ast = parse_java_file(java_file_path)
                    if ast:
                        java_asts[java_file_path] = ast
        logger.info(f"Parsed {len(java_asts)} Java files into ASTs.")
        
        # --- Java AST Traversal and Analysis ---
        logger.info("Starting Java AST traversal for analysis...")
        for java_file_path, ast_tree in java_asts.items():
            logger.info(f"Traversing AST for {java_file_path}")
            visitor.visit(ast_tree)
        logger.info("Finished Java AST traversal.")
        
        logger.info(f"Extracted Classes: {len(visitor.extracted_info['classes'])}")
        for cls in visitor.extracted_info['classes']:
            logger.debug(f"  Class: {cls['name']}, Modifiers: {cls['modifiers']}, Extends: {cls['extends']}, Implements: {cls['implements']}")
        
        logger.info(f"Extracted Methods: {len(visitor.extracted_info['methods'])}")
        for method in visitor.extracted_info['methods']:
            logger.debug(f"  Method: {method['parent_class']}.{method['name']}, ReturnType: {method['return_type']}, Modifiers: {method['modifiers']}, Parameters: {method['parameters']}")
            
        logger.info(f"Extracted Fields: {len(visitor.extracted_info['fields'])}")
        for field in visitor.extracted_info['fields']:
            logger.debug(f"  Field: {field['parent_class']}.{field['name']}, Type: {field['type']}, Modifiers: {field['modifiers']}, InitValue: {field['init_value']}")

        # --- Lua Transpilation ---
        logger.info("Starting Lua transpilation...")
        transpiler = LuaTranspiler()
        all_transpiled_lua_code_parts = []
        for java_file_path, ast_tree in java_asts.items():
            transpiler.output_lines = [] # Clear for each new file
            transpiler.current_class = None # Reset class context
            transpiled_lua_code = transpiler.transpile(ast_tree)
            
            if transpiled_lua_code:
                all_transpiled_lua_code_parts.append(f"-- Transpiled code from: {os.path.basename(java_file_path)}\n{transpiled_lua_code}\n")
        
        final_lua_output = "\n".join(all_transpiled_lua_code_parts)
        if final_lua_output:
            logger.info("Aggregated transpiled Lua code generated.")
            logger.debug(final_lua_output)
        else:
            logger.warning("No Lua code was transpiled.")

    else:
        logger.warning("No Java source files to parse after decompilation.")
        final_lua_output = ""


    # --- Step 3: Generating Kong custom plugin structure (handler.lua, schema.lua) ---
    lua_plugin_dir = os.path.join(output_base_dir, f"kong_{plugin_name}_plugin")
    os.makedirs(lua_plugin_dir, exist_ok=True)

    handler_lua_content = f"""
-- This file contains the transpiled Lua logic from the Apigee Java JAR.
-- It should be placed in Kong's plugins directory.

local BasePlugin = require "kong.plugins.base_plugin"
local PLUGIN_NAME = "{plugin_name}"

-- Insert transpiled Java to Lua code here
{final_lua_output}

-- Main handler for the plugin
local {plugin_name}Handler = BasePlugin:extend(PLUGIN_NAME)

function {plugin_name}Handler:new()
  {plugin_name}Handler.super.new(self, PLUGIN_NAME)
end

function {plugin_name}Handler:access(conf)
  {plugin_name}Handler.super.access(self)
  kong.log.inspect("Executing {plugin_name} access phase with configuration:", conf)
  -- Here you would call the entry point of your transpiled Java logic.
  -- For example, if your Java Callout had a public execute method in a class named 'MyCallout':
  -- local my_callout_instance = MyCallout:new()
  -- my_callout_instance:execute(kong_message_context, kong_execution_context)

  kong.log.notice("Transpiled Java logic for {plugin_name} executed successfully.")
end

-- Add other lifecycle phases as needed (init_worker, rewrite, certificate, header_filter, response, log)

return {plugin_name}Handler
"""
    # Generate schema.lua based on extracted fields
    schema_fields = []
    for cls in visitor.extracted_info.get('classes', []):
        for field in visitor.extracted_info.get('fields', []):
            if field['parent_class'] == cls['name'] and 'static' in field['modifiers'] and 'public' in field['modifiers'] and 'final' in field['modifiers']:
                # Example: Map public static final fields to plugin configuration
                # Simple mapping for now, assuming string type for all
                lua_type = map_java_type_to_lua(field['type'])
                schema_fields.append(f"        {{ {field['name'].lower()} = {{ type = \"{lua_type}\", default = \"{field['init_value'] if field['init_value'] is not None else ''}\", description = \"Config for Java static final field: {field['name']}.\" }} }}")
    
    if not schema_fields:
        # Add a default config field if no suitable fields are found
        schema_fields.append(f"        {{ some_java_param = {{ type = \"string\", default = \"default_value\", description = \"Placeholder for a parameter from Java.\" }} }}")


    schema_lua_content = f"""
local typedefs = require "kong.db.schema.typedefs"

return {{
  name = "{plugin_name}",
  fields = {{
    {{ consumer = typedefs.no_consumer }},
    {{ service = typedefs.no_service }},
    {{ route = typedefs.no_route }},
    {{ protocols = typedefs.protocols }},
    {{ config = {{
      type = "record",
      fields = {{
{',\n'.join(schema_fields)}
      }},
    }} }},
  }},
}}
"""
    with open(os.path.join(lua_plugin_dir, "handler.lua"), "w") as f:
        f.write(handler_lua_content)
    with open(os.path.join(lua_plugin_dir, "schema.lua"), "w") as f:
        f.write(schema_lua_content)

    logger.info(f"Generated Kong Lua plugin structure for '{plugin_name}' in '{lua_plugin_dir}'")

    logger.info(f"Conversion of JAR '{jar_file_path}' to Kong Lua plugin '{plugin_name}' completed.")
    return True

if __name__ == "__main__":
    # Configure logging for standalone execution
    log_dir = 'logs'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_filename = datetime.now().strftime(f"{log_dir}/jartolua_tool_%Y-%m-%d.log")
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    # Set logger for this module after basicConfig
    logger = logging.getLogger(__name__)


    if len(sys.argv) != 4:
        logger.info("Usage: python jartolua_tool.py <jar_file_path> <output_base_directory> <plugin_name>")
        logger.info("Example: python jartolua_tool.py myjava.jar ./output myjavaplugin")
        logger.info(f"Please ensure '{CFR_DECOMPILER_FILENAME}' is accessible (either in script dir or via CFR_DECOMPILER_PATH env var).")
        sys.exit(1)

    input_jar_path = sys.argv[1]
    output_base_dir = sys.argv[2]
    plugin_name = sys.argv[3]

    convert_jar_to_lua_plugin(input_jar_path, output_base_dir, plugin_name)
