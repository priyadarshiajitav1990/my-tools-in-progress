import argparse
import os
import sys


import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.apigee_bundle_parser import ApigeeBundleParser
from core.kong_config_generator import KongConfigGenerator
# from app_logging.enterprise_logger import EnterpriseLogger  # Commented out if not present

# Import the tools
from tools.pytolua_tool import transpile_python_to_lua
from tools.verify_custom_lua_plugin import run_luacheck, verify_plugin_schema


def convert_command(args):
    logger = EnterpriseLogger(__name__, verbose=args.verbose).get_logger()

    if not os.path.exists(args.input):
        logger.error(f"Input path not found: {args.input}")
        sys.exit(1)

    try:
        parser = ApigeeBundleParser(args.input, logger)
        parsed_data = parser.parse()

        generator = KongConfigGenerator(logger)
        kong_config = generator.generate(parsed_data)

        # Ensure the output directory exists
        output_dir = os.path.dirname(args.output)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        with open(args.output, 'w') as f:
            f.write(kong_config)

        logger.info(f"Successfully converted Apigee proxy bundle to Kong configuration: {args.output}")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)
        sys.exit(1)

        logger.info(f"Successfully converted Apigee proxy bundle to Kong configuration: {args.output}")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)
        sys.exit(1)

def transpile_python_command(args):
    logger = EnterpriseLogger(__name__, verbose=args.verbose).get_logger()

    if not os.path.exists(args.input_file):
        logger.error(f"Python input file not found: {args.input_file}")
        sys.exit(1)

    try:
        with open(args.input_file, "r") as f:
            python_code = f.read()

        lua_output = transpile_python_to_lua(python_code)
        
        output_dir = args.output_dir if args.output_dir else "pytolua_output"
        os.makedirs(output_dir, exist_ok=True)

        handler_file_path = os.path.join(output_dir, args.plugin_name + "_handler.lua")
        with open(handler_file_path, "w") as f:
            f.write(f"""
local BasePlugin = require "kong.plugins.base_plugin"

local {args.plugin_name} = BasePlugin:extend("{args.plugin_name}")

function {args.plugin_name}:new()
  return BasePlugin.new(self, "{args.plugin_name}", 1.0)
end

function {args.plugin_name}:access(conf)
  BasePlugin.access(self)
  -- Your transpiled Python code goes here
{lua_output}
end

return {args.plugin_name}
""")
        logger.info(f"Generated handler.lua at {handler_file_path}")

        schema_file_path = os.path.join(output_dir, args.plugin_name + "_schema.lua")
        with open(schema_file_path, "w") as f:
            f.write("""
local typedefs = require "kong.db.schema.typedefs"

return {
  name = "pytolua-plugin",
  fields = {
    { consumer = typedefs.no_consumer },
    { protocols = typedefs.protocols },
    { config = {
        type = "record",
        fields = {
          -- Add configurable fields here based on Python code analysis
          -- For example:
          -- { message = { type = "string", default = "Hello from pytolua!" } },
        },
      },
    },
  },
}
""")
        logger.info(f"Generated schema.lua at {schema_file_path}")

        logger.info(f"Successfully transpiled Python to Lua for {args.input_file}")

    except Exception as e:
        logger.error(f"An error occurred during Python transpilation: {e}", exc_info=True)
        sys.exit(1)

def verify_lua_plugin_command(args):
    logger = EnterpriseLogger(__name__, verbose=args.verbose).get_logger()

    if not os.path.exists(args.handler_file):
        logger.error(f"Handler Lua file not found: {args.handler_file}")
        sys.exit(1)
    if not os.path.exists(args.schema_file):
        logger.error(f"Schema Lua file not found: {args.schema_file}")
        sys.exit(1)

    handler_ok = run_luacheck(args.handler_file)
    schema_ok = verify_plugin_schema(args.schema_file)

    if handler_ok and schema_ok:
        logger.info("\nCustom Lua plugin verification successful!")
    else:
        logger.error("\nCustom Lua plugin verification failed.")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description='Apg2Kong CLI for Apigee to Kong migration and toolchain.')
    parser.add_argument('-v', '--verbose', help='Enable verbose logging.', action='store_true') # Global verbose argument

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Convert command
    convert_parser = subparsers.add_parser('convert', help='Convert Apigee proxy bundle to Kong configuration.')
    convert_parser.add_argument('input', help='Path to the Apigee proxy bundle (zip file or directory).')
    convert_parser.add_argument('-o', '--output', help='Path to the output Kong configuration file (default: kong.yml).', default='kong.yml')
    convert_parser.set_defaults(func=convert_command)

    # Transpile Python command
    transpile_python_parser = subparsers.add_parser('transpile-python', help='Transpile Python code to Kong Lua plugin files.')
    transpile_python_parser.add_argument('input_file', help='Path to the Python input file.')
    transpile_python_parser.add_argument('-o', '--output_dir', help='Output directory for generated Lua files (default: pytolua_output).')
    transpile_python_parser.add_argument('-n', '--plugin_name', help='Name of the Kong plugin to be generated (e.g., my_python_plugin).', required=True)
    transpile_python_parser.set_defaults(func=transpile_python_command)

    # Verify Lua Plugin command
    verify_lua_parser = subparsers.add_parser('verify-lua-plugin', help='Verify a custom Kong Lua plugin (handler.lua and schema.lua).')
    verify_lua_parser.add_argument('handler_file', help='Path to the handler.lua file.')
    verify_lua_parser.add_argument('schema_file', help='Path to the schema.lua file.')
    verify_lua_parser.set_defaults(func=verify_lua_plugin_command)

    args = parser.parse_args()

    if 'func' in args:
        args.func(args)
    else:
        parser.print_help()

