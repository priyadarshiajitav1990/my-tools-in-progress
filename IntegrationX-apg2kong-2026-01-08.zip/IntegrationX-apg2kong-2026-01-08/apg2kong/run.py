import asyncio
import sys
import os

# Add the 'src' directory to the Python path
# This allows importing modules from 'src/apg2kong' directly
# when running from the project root.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "src")))

from apg2kong.main import main as apg2kong_main

if __name__ == "__main__":
    # Run the main asynchronous function
    asyncio.run(apg2kong_main())
