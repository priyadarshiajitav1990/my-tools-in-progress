
-- kong/plugins/custom_decode_jws/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local jwt = require "resty.jwt"
local cjson = require "cjson"

local CustomDecodeJwsHandler = BasePlugin:extend()

CustomDecodeJwsHandler.PRIORITY = 940
CustomDecodeJwsHandler.VERSION = "0.1.0"

function CustomDecodeJwsHandler:new()
  CustomDecodeJwsHandler.super.new(self, "custom_decode_jws")
end

function CustomDecodeJwsHandler:access(conf)
  CustomDecodeJwsHandler.super.access(self)

  local token
  if conf.token_source == "header" then
    token = kong.request.get_header(conf.token_source_name)
  elseif conf.token_source == "query_param" then
    token = kong.request.get_query_arg(conf.token_source_name)
  end

  if not token then
    return kong.response.exit(401, { message = "JWS token not found" })
  end

  local jwt_obj = jwt:verify(token, conf.secret)

  if not jwt_obj.verified then
    return kong.response.exit(401, { message = "Invalid JWS token signature" })
  end
  
  -- Add the decoded payload to a request header
  kong.service.request.set_header("x-decoded-jws-payload", cjson.encode(jwt_obj.payload))

end

return CustomDecodeJwsHandler
