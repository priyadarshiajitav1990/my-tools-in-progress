
local typedefs = require "kong.db.schema.typedefs"

return {
	name = "custom_soap_message_validation",
	fields = {
		{ consumer = typedefs.no_consumer },
		{
			config = {
				type = "record",
				fields = {
					{ wsdl_url = { type = "string", required = true } },
					{ validation_service_url = { type = "string", required = true } },
					{ verify_ssl = { type = "boolean", required = false, default = true } }
				}
			}
		}
	}
}


