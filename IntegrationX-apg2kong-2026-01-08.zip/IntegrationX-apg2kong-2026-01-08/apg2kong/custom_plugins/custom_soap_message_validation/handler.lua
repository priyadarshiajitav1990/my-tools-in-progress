local http = require "resty.http"
local cjson = require "cjson"

local CustomSoapMessageValidationHandler = {
  VERSION = "1.0.0",
  PRIORITY = 10,
}

function CustomSoapMessageValidationHandler:access(conf)
  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return kong.response.exit(400, { message = "SOAP message body is empty" })
  end

  local httpc = http.new()
  local payload = cjson.encode({
    wsdl_url = conf.wsdl_url,
    soap_message = body,
  })

  local res, err = httpc:request_uri(conf.validation_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("External SOAP validation failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "External SOAP validation failed" })
  end

  if res.status ~= 200 then
    kong.log.err("External SOAP validation service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "SOAP message validation failed", details = res.body })
  end

  -- Assuming a 200 OK from the validation service means the message is valid
  -- If the external service returns a specific response body for validation status,
  -- that can be parsed and acted upon here.
end

return CustomSoapMessageValidationHandler
