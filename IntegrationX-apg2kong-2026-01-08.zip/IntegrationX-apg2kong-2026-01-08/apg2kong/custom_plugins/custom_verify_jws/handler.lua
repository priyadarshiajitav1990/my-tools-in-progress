
-- kong/plugins/custom_verify_jws/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local jwt = require "resty.jwt"
local cjson = require "cjson"

local CustomVerifyJwsHandler = BasePlugin:extend()

CustomVerifyJwsHandler.PRIORITY = 630
CustomVerifyJwsHandler.VERSION = "0.1.0"

function CustomVerifyJwsHandler:new()
  CustomVerifyJwsHandler.super.new(self, "custom_verify_jws")
end

function CustomVerifyJwsHandler:access(conf)
  CustomVerifyJwsHandler.super.access(self)

  local token
  if conf.token_source == "header" then
    token = kong.request.get_header(conf.token_source_name)
  elseif conf.token_source == "query_param" then
    token = kong.request.get_query_arg(conf.token_source_name)
  end

  if not token then
    return kong.response.exit(401, { message = "JWS token not found" })
  end

  local jwt_obj = jwt:verify(token, conf.secret)

  if not jwt_obj.verified then
    return kong.response.exit(401, { message = "Invalid JWS token signature" })
  end
  
  -- Add the decoded payload to a request header
  kong.service.request.set_header("x-verified-jws-payload", cjson.encode(jwt_obj.payload))

end

return CustomVerifyJwsHandler
