
-- kong/plugins/custom_json_threat_protection/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"
-- jsonschema is a community library for validating JSON schemas.
-- You need to make sure it is available in your environment.
local jsonschema = require "jsonschema"

local CustomJsonThreatProtectionHandler = BasePlugin:extend()

CustomJsonThreatProtectionHandler.PRIORITY = 830
CustomJsonThreatProtectionHandler.VERSION = "0.1.0"

function CustomJsonThreatProtectionHandler:new()
  CustomJsonThreatProtectionHandler.super.new(self, "custom_json_threat_protection")
end

function CustomJsonThreatProtectionHandler:access(conf)
  CustomJsonThreatProtectionHandler.super.access(self)

  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return
  end

  local parsed_body, err = cjson.decode(body)
  if err then
    return kong.response.exit(400, { message = "Invalid JSON body" })
  end

  local schema, err = cjson.decode(conf.json_schema)
  if err then
    return kong.response.exit(500, { message = "Invalid JSON schema in plugin configuration" })
  end

  local valid, errors = jsonschema.validate(parsed_body, schema)

  if not valid then
    return kong.response.exit(400, { message = "JSON body does not match schema", errors = errors })
  end

end

return CustomJsonThreatProtectionHandler
