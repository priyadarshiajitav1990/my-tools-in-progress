
-- kong/plugins/custom_revoke_oauthv2/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomRevokeOauth2Handler = BasePlugin:extend()

CustomRevokeOauth2Handler.PRIORITY = 720
CustomRevokeOauth2Handler.VERSION = "0.1.0"

function CustomRevokeOauth2Handler:new()
  CustomRevokeOauth2Handler.super.new(self, "custom_revoke_oauthv2")
end

function CustomRevokeOauth2Handler:access(conf)
  CustomRevokeOauth2Handler.super.access(self)

  local token
  if conf.token_source == "header" then
    token = kong.request.get_header(conf.token_source_name)
  elseif conf.token_source == "query_param" then
    token = kong.request.get_query_arg(conf.token_source_name)
  end

  if not token then
    return kong.response.exit(400, { message = "Token not found in request" })
  end

  local oauth2_token, err = kong.db.oauth2_tokens:select_by_field("access_token", token)
  if err then
    return kong.response.exit(500, { message = "Error finding token: " .. err })
  end

  if not oauth2_token then
    return kong.response.exit(404, { message = "Token not found" })
  end

  _, err = kong.db.oauth2_tokens:delete(oauth2_token)
  if err then
    return kong.response.exit(500, { message = "Error revoking token: " .. err })
  end

  return kong.response.exit(200, { message = "Token revoked successfully" })
end

return CustomRevokeOauth2Handler
