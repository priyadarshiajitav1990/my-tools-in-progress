
-- kong/plugins/custom_set_oauthv2_info/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomSetOauth2InfoHandler = BasePlugin:extend()

CustomSetOauth2InfoHandler.PRIORITY = 670
CustomSetOauth2InfoHandler.VERSION = "0.1.0"

function CustomSetOauth2InfoHandler:new()
  CustomSetOauth2InfoHandler.super.new(self, "custom_set_oauthv2_info")
end

function CustomSetOauth2InfoHandler:access(conf)
  CustomSetOauth2InfoHandler.super.access(self)

  local oauth2_token, err = kong.db.oauth2_tokens:select_by_field("access_token", conf.access_token)
  if err then
    return kong.response.exit(500, { message = "Error finding token: " .. err })
  end

  if oauth2_token then
    -- Update existing token
    local _, err = kong.db.oauth2_tokens:update(oauth2_token, {
      consumer_id = conf.consumer_id,
      scope = conf.scope,
      token_type = conf.token_type,
      expires_in = conf.expires_in,
    })
    if err then
      return kong.response.exit(500, { message = "Error updating token: " .. err })
    end
    return kong.response.exit(200, { message = "Token updated successfully" })
  else
    -- Create new token
    local _, err = kong.db.oauth2_tokens:insert({
      access_token = conf.access_token,
      consumer_id = conf.consumer_id,
      scope = conf.scope,
      token_type = conf.token_type,
      expires_in = conf.expires_in,
    })
    if err then
      return kong.response.exit(500, { message = "Error creating token: " .. err })
    end
    return kong.response.exit(201, { message = "Token created successfully" })
  end

end

return CustomSetOauth2InfoHandler
