
-- kong/plugins/custom_regex_protection/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomRegexProtectionHandler = BasePlugin:extend()

CustomRegexProtectionHandler.PRIORITY = 740
CustomRegexProtectionHandler.VERSION = "0.1.0"

function CustomRegexProtectionHandler:new()
  CustomRegexProtectionHandler.super.new(self, "custom_regex_protection")
end

local function get_source_value(conf)
    if conf.source == "header" then
        return kong.request.get_header(conf.source_name)
    elseif conf.source == "query_param" then
        return kong.request.get_query_arg(conf.source_name)
    elseif conf.source == "body_field" then
        local body, err = kong.request.get_body()
        if err then
            return nil, err
        end
        if body and body[conf.source_name] then
            return body[conf.source_name]
        end
    end
    return nil
end

function CustomRegexProtectionHandler:access(conf)
  CustomRegexProtectionHandler.super.access(self)

  local value, err = get_source_value(conf)
  if err then
    return kong.response.exit(500, { message = "Error getting source value: " .. err })
  end

  if value then
    local match = ngx.re.match(value, conf.regex)
    if not match then
      return kong.response.exit(conf.error_code, { message = conf.error_message })
    end
  end

end

return CustomRegexProtectionHandler
