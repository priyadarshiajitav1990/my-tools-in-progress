
-- kong/plugins/custom_generate_jws/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local jwt = require "resty.jwt"
local cjson = require "cjson"

local CustomGenerateJwsHandler = BasePlugin:extend()

CustomGenerateJwsHandler.PRIORITY = 880
CustomGenerateJwsHandler.VERSION = "0.1.0"

function CustomGenerateJwsHandler:new()
  CustomGenerateJwsHandler.super.new(self, "custom_generate_jws")
end

function CustomGenerateJwsHandler:access(conf)
  CustomGenerateJwsHandler.super.access(self)

  local payload_table, err = cjson.decode(conf.payload)
  if err then
    return kong.response.exit(400, { message = "Invalid JSON payload" })
  end

  local jwt_obj = jwt:sign(payload_table, {
    algorithm = "HS256",
    secret = conf.secret
  })

  if not jwt_obj then
    return kong.response.exit(500, { message = "Failed to generate JWS token" })
  end

  kong.service.request.set_header(conf.header_name, jwt_obj)

end

return CustomGenerateJwsHandler
