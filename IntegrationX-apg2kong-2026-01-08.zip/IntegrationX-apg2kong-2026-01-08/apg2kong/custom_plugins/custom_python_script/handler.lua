
-- kong/plugins/custom_python_script/handler.lua  local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomPythonScriptHandler = BasePlugin:extend()

CustomPythonScriptHandler.PRIORITY = 845
CustomPythonScriptHandler.VERSION = "0.1.0"

function CustomPythonScriptHandler:new()
  CustomPythonScriptHandler.super.new(self, "custom_python_script")
end

function CustomPythonScriptHandler:access(conf)
  CustomPythonScriptHandler.super.access(self)

  local httpc = http.new()
  local payload = cjson.encode({
    script_path = conf.script_path,
    -- Optionally pass current request details
    request_method = kong.request.get_method(),
    request_uri = kong.request.get_uri(),
    request_headers = kong.request.get_headers(),
    request_body = kong.request.get_raw_body(),
  })

  local res, err = httpc:request_uri(conf.python_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("External Python script execution failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "External Python script execution failed" })
  end

  if res.status ~= 200 then
    kong.log.err("External Python service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "External Python service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end
end

return CustomPythonScriptHandler
