local http = require "resty.http"
local cjson = require "cjson"

-- A modern handler is a simple Lua table with functions for the phases it implements.
local CustomJavaCalloutHandler = {
  PRIORITY = 850,
  VERSION = "0.1.0",
}

function CustomJavaCalloutHandler:access(conf)
  local httpc = http.new()
  local payload = cjson.encode({
    jar_path = conf.jar_path,
    class_name = conf.class_name,
    -- Optionally pass current request details
    request_method = kong.request.get_method(),
    request_uri = kong.request.get_uri(),
    request_headers = kong.request.get_headers(),
    request_body = kong.request.get_raw_body(),
  })

  local res, err = httpc:request_uri(conf.java_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("External Java callout failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "External Java callout failed" })
  end

  if res.status ~= 200 then
    kong.log.err("External Java service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "External Java service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end
end

return CustomJavaCalloutHandler
