
-- kong/plugins/custom_external_callout/handler.lua

local http = require "resty.http"
local cjson = require "cjson"

local CustomExternalCalloutHandler = {
  VERSION = "1.0.0",
  PRIORITY = 10,
}

function CustomExternalCalloutHandler:access(conf)
  local httpc = http.new()
  local res, err = httpc:request_uri(conf.url, {
    method = conf.method,
    headers = conf.headers,
    body = conf.body,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("External callout failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "External callout failed" })
  end

  if res.status < 200 or res.status >= 300 then
    kong.log.err("External service returned non-2xx status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "External service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end
end

return CustomExternalCalloutHandler
