
local typedefs = require "kong.db.schema.typedefs"

return {
	name = "custom_external_callout",
	fields = {
		{ consumer = typedefs.no_consumer },
		{
			config = {
				type = "record",
				fields = {
					{ url = { type = "string", required = true } },
					{ method = { type = "string", required = true } },
					{ headers = { type = "map", keys = { type = "string" }, values = { type = "string" }, required = false } },
					{ body = { type = "string", required = false } },
					{ verify_ssl = { type = "boolean", required = false, default = true } },
					{ response_header_name = { type = "string", required = false } }
				}
			}
		}
	}
}


