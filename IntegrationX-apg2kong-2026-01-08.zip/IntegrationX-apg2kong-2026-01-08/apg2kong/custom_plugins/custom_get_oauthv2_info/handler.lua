
-- kong/plugins/custom_get_oauthv2_info/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"

local CustomGetOauth2InfoHandler = BasePlugin:extend()

CustomGetOauth2InfoHandler.PRIORITY = 925
CustomGetOauth2InfoHandler.VERSION = "0.1.0"

function CustomGetOauth2InfoHandler:new()
  CustomGetOauth2InfoHandler.super.new(self, "custom_get_oauthv2_info")
end

function CustomGetOauth2InfoHandler:access(conf)
  CustomGetOauth2InfoHandler.super.access(self)

  local token
  if conf.token_source == "header" then
    token = kong.request.get_header(conf.token_source_name)
  elseif conf.token_source == "query_param" then
    token = kong.request.get_query_arg(conf.token_source_name)
  end

  if not token then
    return kong.response.exit(400, { message = "Token not found in request" })
  end

  local oauth2_token, err = kong.db.oauth2_tokens:select_by_field("access_token", token)
  if err then
    return kong.response.exit(500, { message = "Error finding token: " .. err })
  end

  if not oauth2_token then
    return kong.response.exit(404, { message = "Token not found" })
  end

  return kong.response.exit(200, cjson.encode(oauth2_token))
end

return CustomGetOauth2InfoHandler
