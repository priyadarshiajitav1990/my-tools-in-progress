
-- kong/plugins/custom_assert_condition/schema.lua

return {
  name = "custom_assert_condition",
  fields = {
    { consumer = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { route = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { service = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { tags = {
        type = "array",
        elements = { type = "string" },
        description = "An optional list of strings associated with the Plugin for grouping and filtering.",
      },
    },
    { ordering = {
        type = "record",
        fields = {
          { before = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          },
          { after = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          }
        }
      }
    },
    { config = {
        type = "record",
        fields = {
          { source = {
              type = "string",
              enum = { "header", "query_param", "body" },
              default = "header",
              required = true,
            },
          },
          { source_name = {
              type = "string",
              required = true,
            },
          },
          { operator = {
              type = "string",
              enum = { "eq", "ne", "gt", "lt", "ge", "le", "is_present", "is_not_present" },
              default = "eq",
              required = true,
            },
          },
          { value = {
              type = "string",
            },
          },
          { error_code = {
              type = "number",
              default = 400,
            },
          },
          { error_message = {
              type = "string",
              default = "Condition not met",
            },
          },

        },
      },
    },
  },
}
