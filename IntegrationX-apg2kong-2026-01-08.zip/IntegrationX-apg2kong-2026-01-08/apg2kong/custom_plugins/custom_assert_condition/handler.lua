
-- kong/plugins/custom_assert_condition/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomAssertConditionHandler = BasePlugin:extend()

CustomAssertConditionHandler.PRIORITY = 1001
CustomAssertConditionHandler.VERSION = "0.1.0"

function CustomAssertConditionHandler:new()
  CustomAssertConditionHandler.super.new(self, "custom_assert_condition")
end

local function get_source_value(conf)
  if conf.source == "header" then
    return kong.request.get_header(conf.source_name)
  elseif conf.source == "query_param" then
    return kong.request.get_query_arg(conf.source_name)
  elseif conf.source == "body" then
    local body, err = kong.request.get_body()
    if err then
      return nil, err
    end
    if body and body[conf.source_name] then
      return body[conf.source_name]
    end
  end
  return nil
end

local function to_number(val)
    if type(val) == "string" then
        local num = tonumber(val)
        if num ~= nil then
            return num
        end
    end
    return val
end

function CustomAssertConditionHandler:access(conf)
  CustomAssertConditionHandler.super.access(self)

  local source_value, err = get_source_value(conf)
  if err then
    return kong.response.exit(500, { message = "Error getting source value: " .. err })
  end
  
  local condition_met = false

  if conf.operator == "is_present" then
    condition_met = source_value ~= nil
  elseif conf.operator == "is_not_present" then
    condition_met = source_value == nil
  else
    if source_value == nil then
        return kong.response.exit(conf.error_code, { message = conf.error_message })
    end
    
    local num_source_value = to_number(source_value)
    local num_conf_value = to_number(conf.value)
    
    if conf.operator == "eq" then
      condition_met = num_source_value == num_conf_value
    elseif conf.operator == "ne" then
      condition_met = num_source_value ~= num_conf_value
    elseif conf.operator == "gt" then
      condition_met = num_source_value > num_conf_value
    elseif conf.operator == "lt" then
      condition_met = num_source_value < num_conf_value
    elseif conf.operator == "ge" then
      condition_met = num_source_value >= num_conf_value
    elseif conf.operator == "le" then
      condition_met = num_source_value <= num_conf_value
    end
  end

  if not condition_met then
    return kong.response.exit(conf.error_code, { message = conf.error_message })
  end
end

return CustomAssertConditionHandler
