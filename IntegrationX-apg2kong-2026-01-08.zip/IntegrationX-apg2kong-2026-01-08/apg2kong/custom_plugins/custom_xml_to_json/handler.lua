
-- kong/plugins/custom_xml_to_json/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"
-- xml2lua is a community library for parsing XML.
-- You need to make sure it is available in your environment.
local xml2lua = require "xml2lua"
local xml = xml2lua.parser()

local CustomXmlToJsonHandler = BasePlugin:extend()

CustomXmlToJsonHandler.PRIORITY = 610
CustomXmlToJsonHandler.VERSION = "0.1.0"

function CustomXmlToJsonHandler:new()
  CustomXmlToJsonHandler.super.new(self, "custom_xml_to_json")
end

function CustomXmlToJsonHandler:access(conf)
  CustomXmlToJsonHandler.super.access(self)

  local body, err = kong.request.get_raw_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return
  end

  
  -- For production use, you might want to use a more robust and performant XML parser.
  local parsed_body, err = xml:parse(body)
  
  if err or not parsed_body then
    return kong.response.exit(400, { message = "Invalid XML body: " .. (err or "") })
  end

  local json_body = cjson.encode(parsed_body)

  kong.service.request.set_raw_body(json_body)
  kong.service.request.set_header("Content-Type", "application/json")

end

return CustomXmlToJsonHandler
