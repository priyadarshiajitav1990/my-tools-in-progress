
-- kong/plugins/custom_integration_callout/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomIntegrationCalloutHandler = BasePlugin:extend()

CustomIntegrationCalloutHandler.PRIORITY = 860
CustomIntegrationCalloutHandler.VERSION = "0.1.0"

function CustomIntegrationCalloutHandler:new()
  CustomIntegrationCalloutHandler.super.new(self, "custom_integration_callout")
end

function CustomIntegrationCalloutHandler:access(conf)
  CustomIntegrationCalloutHandler.super.access(self)

  local httpc = http.new()
  local res, err = httpc:request_uri(conf.url, {
    method = conf.method,
    headers = conf.headers,
    body = conf.body,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("Integration callout failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "Integration callout failed" })
  end

  -- Enhanced error handling for non-2xx responses from the external service
  if res.status < 200 or res.status >= 300 then
    kong.log.err("Integration service returned non-2xx status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "Integration service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end

end

return CustomIntegrationCalloutHandler
