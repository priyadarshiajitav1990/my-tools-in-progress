
-- kong/plugins/custom_json_to_xml/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local dkjson = require "dkjson"

-- Function to convert a Lua table to an XML string
-- This function converts a Lua table to an XML string.
-- It's a basic implementation and might not cover all edge cases.
-- For production use, you might want to use a more robust library.
local function to_xml(t, root)
    local s = ""
    local function to_xml_inner(t, name, indent)
        indent = indent or ""
        if type(t) == "table" then
            s = s .. indent .. "<" .. name .. ">\n"
            for k, v in pairs(t) do
                if tonumber(k) then -- array
                    to_xml_inner(v, "item", indent .. "  ")
                else -- map
                    to_xml_inner(v, k, indent .. "  ")
                end
            end
            s = s .. indent .. "</" .. name .. ">\n"
        elseif type(t) == "boolean" then
            s = s .. indent .. "<" .. name .. ">" .. tostring(t) .. "</" .. name .. ">\n"
        else
            s = s .. indent .. "<" .. name .. ">" .. ngx.escape_uri(tostring(t)) .. "</" .. name .. ">\n"
        end
    end

    to_xml_inner(t, root or "root")
    return s
end


local CustomJsonToXmlHandler = BasePlugin:extend()

CustomJsonToXmlHandler.PRIORITY = 820
CustomJsonToXmlHandler.VERSION = "0.1.0"

function CustomJsonToXmlHandler:new()
  CustomJsonToXmlHandler.super.new(self, "custom_json_to_xml")
end

function CustomJsonToXmlHandler:access(conf)
  CustomJsonToXmlHandler.super.access(self)

  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return
  end

  local parsed_body, pos, err = dkjson.decode(body, 1, nil)
  if err then
    return kong.response.exit(400, { message = "Invalid JSON body" })
  end
  
  local xml_body = to_xml(parsed_body)

  kong.service.request.set_raw_body(xml_body)
  kong.service.request.set_header("Content-Type", "application/xml")

end

return CustomJsonToXmlHandler
