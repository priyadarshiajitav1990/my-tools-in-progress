
-- kong/plugins/custom_delete_oauthv2_info/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomDeleteOauth2InfoHandler = BasePlugin:extend()

CustomDeleteOauth2InfoHandler.PRIORITY = 930
CustomDeleteOauth2InfoHandler.VERSION = "0.1.0"

function CustomDeleteOauth2InfoHandler:new()
  CustomDeleteOauth2InfoHandler.super.new(self, "custom_delete_oauthv2_info")
end

function CustomDeleteOauth2InfoHandler:access(conf)
  CustomDeleteOauth2InfoHandler.super.access(self)

  local token
  if conf.token_source == "header" then
    token = kong.request.get_header(conf.token_source_name)
  elseif conf.token_source == "query_param" then
    token = kong.request.get_query_arg(conf.token_source_name)
  end

  if not token then
    return kong.response.exit(400, { message = "Token not found in request" })
  end

  local oauth2_token, err = kong.db.oauth2_tokens:select_by_field("access_token", token)
  if err then
    return kong.response.exit(500, { message = "Error finding token: " .. err })
  end

  if not oauth2_token then
    return kong.response.exit(404, { message = "Token not found" })
  end

  _, err = kong.db.oauth2_tokens:delete(oauth2_token)
  if err then
    return kong.response.exit(500, { message = "Error deleting token: " .. err })
  end

  return kong.response.exit(200, { message = "Token deleted successfully" })
end

return CustomDeleteOauth2InfoHandler
