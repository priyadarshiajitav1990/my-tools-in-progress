
-- kong/plugins/custom_delete_oauthv2_info/schema.lua

return {
  name = "custom_delete_oauthv2_info",
  fields = {
    { consumer = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { route = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { service = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { tags = {
        type = "array",
        elements = { type = "string" },
        description = "An optional list of strings associated with the Plugin for grouping and filtering.",
      },
    },
    { ordering = {
        type = "record",
        fields = {
          { before = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          },
          { after = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          }
        }
      }
    },
    { config = {
        type = "record",
        fields = {
          { token_source = {
              type = "string",
              enum = { "header", "query_param" },
              default = "header",
              required = true,
            },
          },
          { token_source_name = {
              type = "string",
              required = true,
            },
          },

        },
      },
    },
  },
}
