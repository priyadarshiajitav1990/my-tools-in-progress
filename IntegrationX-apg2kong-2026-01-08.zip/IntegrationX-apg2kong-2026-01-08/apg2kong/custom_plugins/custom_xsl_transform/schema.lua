

return {
  name = "custom_xsl_transform",
  fields = {
    {
      config = {
        type = "record",
        fields = {
          { xslt_stylesheet_url = { type = "string", required = true } },
        },
      }
    }
  }
}
