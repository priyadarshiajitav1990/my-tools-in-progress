



local http = require "resty.http"

local CustomXslTransformHandler = {
  VERSION = "1.0.0",
  PRIORITY = 10,
}

function CustomXslTransformHandler:access(conf)
  local body, err = kong.request.get_raw_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  if not body then
    return
  end

  local httpc = http.new()
  local res, err = httpc:request_uri(conf.xslt_stylesheet_url)
  if not res then
    return kong.response.exit(500, { message = "Failed to fetch XSLT stylesheet: " .. err })
  end
  local stylesheet = res.body

  -- Placeholder: just pass through for now
  kong.service.request.set_raw_body(body)
end

return CustomXslTransformHandler
