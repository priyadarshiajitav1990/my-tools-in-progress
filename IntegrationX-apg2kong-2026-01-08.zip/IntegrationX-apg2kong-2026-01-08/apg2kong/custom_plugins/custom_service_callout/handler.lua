
-- kong/plugins/custom_service_callout/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomServiceCalloutHandler = BasePlugin:extend()

CustomServiceCalloutHandler.PRIORITY = 700
CustomServiceCalloutHandler.VERSION = "0.1.0"

function CustomServiceCalloutHandler:new()
  CustomServiceCalloutHandler.super.new(self, "custom_service_callout")
end

function CustomServiceCalloutHandler:access(conf)
  CustomServiceCalloutHandler.super.access(self)

  local httpc = http.new()
  local res, err = httpc:request_uri(conf.url, {
    method = conf.method,
    headers = conf.headers,
    body = conf.body,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("Service callout failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "Service callout failed" })
  end

  -- Enhanced error handling for non-2xx responses from the external service
  if res.status < 200 or res.status >= 300 then
    kong.log.err("External service returned non-2xx status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "External service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end

end

return CustomServiceCalloutHandler
