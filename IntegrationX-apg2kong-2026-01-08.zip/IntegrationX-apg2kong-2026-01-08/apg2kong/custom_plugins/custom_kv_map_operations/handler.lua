
-- kong/plugins/custom_kv_map_operations/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomKvMapOperationsHandler = BasePlugin:extend()

CustomKvMapOperationsHandler.PRIORITY = 810
CustomKvMapOperationsHandler.VERSION = "0.1.0"

function CustomKvMapOperationsHandler:new()
  CustomKvMapOperationsHandler.super.new(self, "custom_kv_map_operations")
end

local function get_value(conf)
    if conf.value_source == "header" then
        return kong.request.get_header(conf.value_source_name)
    elseif conf.value_source == "query_param" then
        return kong.request.get_query_arg(conf.value_source_name)
    elseif conf.value_source == "body_field" then
        local body, err = kong.request.get_body()
        if err then
            return nil, err
        end
        if body and body[conf.value_source_name] then
            return body[conf.value_source_name]
        end
    elseif conf.value_source == "static" then
        return conf.static_value
    end
    return nil
end

function CustomKvMapOperationsHandler:access(conf)
  CustomKvMapOperationsHandler.super.access(self)

  if conf.operation == "write" then
    local value, err = get_value(conf)
    if err then
        return kong.response.exit(500, { message = "Error getting value: " .. err })
    end
    
    if value then
        kong.shared.dict:set(conf.key, value)
    else
        return kong.response.exit(400, { message = "Value not found for write operation" })
    end
  elseif conf.operation == "read" then
    local value = kong.shared.dict:get(conf.key)
    if value and conf.destination_header then
      kong.service.request.set_header(conf.destination_header, value)
    end
  end

end

return CustomKvMapOperationsHandler
