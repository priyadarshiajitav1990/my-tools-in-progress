
-- kong/plugins/custom_lookup_cache/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomLookupCacheHandler = BasePlugin:extend()

CustomLookupCacheHandler.PRIORITY = 800
CustomLookupCacheHandler.VERSION = "0.1.0"

function CustomLookupCacheHandler:new()
  CustomLookupCacheHandler.super.new(self, "custom_lookup_cache")
end

function CustomLookupCacheHandler:access(conf)
  CustomLookupCacheHandler.super.access(self)

  local value, err = kong.cache:get(conf.cache_key)
  if err then
    return kong.response.exit(500, { message = "Failed to lookup cache: " .. err })
  end

  if value then
    kong.service.request.set_header(conf.destination_header, value)
  end

end

return CustomLookupCacheHandler
