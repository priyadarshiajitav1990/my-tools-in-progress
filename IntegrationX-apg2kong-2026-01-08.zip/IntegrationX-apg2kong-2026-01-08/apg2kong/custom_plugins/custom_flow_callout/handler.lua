
-- kong/plugins/custom_flow_callout/handler.lua  local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomFlowCalloutHandler = BasePlugin:extend()

CustomFlowCalloutHandler.PRIORITY = 890
CustomFlowCalloutHandler.VERSION = "0.1.0"

function CustomFlowCalloutHandler:new()
  CustomFlowCalloutHandler.super.new(self, "custom_flow_callout")
end

function CustomFlowCalloutHandler:access(conf)
  CustomFlowCalloutHandler.super.access(self)

  local httpc = http.new()
  local payload = cjson.encode({
    flow_name = conf.flow_name,
    -- Optionally pass current request details
    request_method = kong.request.get_method(),
    request_uri = kong.request.get_uri(),
    request_headers = kong.request.get_headers(),
    request_body = kong.request.get_raw_body(),
  })

  local res, err = httpc:request_uri(conf.flow_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("External flow callout failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "External flow callout failed" })
  end

  if res.status ~= 200 then
    kong.log.err("External flow service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "External flow service error", details = res.body })
  end

  if conf.response_header_name then
    kong.service.request.set_header(conf.response_header_name, res.body)
  end
end

return CustomFlowCalloutHandler
