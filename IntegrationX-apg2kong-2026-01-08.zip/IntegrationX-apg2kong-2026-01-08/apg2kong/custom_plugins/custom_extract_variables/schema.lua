-- kong/plugins/custom_extract_variables/schema.lua

return {

  name = "custom_extract_variables",

  fields = {

    { consumer = {

        type = "record",

        fields = {

          { "id" },

        },

      },

    },

    { route = {

        type = "record",

        fields = {

          { "id" },

        },

      },

    },

    { service = {

        type = "record",

        fields = {

          { "id" },

        },

      },

    },

    { tags = {

        type = "array",

        elements = { type = "string" },

        description = "An optional list of strings associated with the Plugin for grouping and filtering.",

      },

    },

    { ordering = {
        type = "record",
        fields = {
          { before = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          },
          { after = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          }
        }
      }
    },

    { config = {

        type = "record",

        fields = {

          { source = {

              type = "string",

              enum = { "body" },

              default = "body",

            },

          },

          { payload_type = {

              type = "string",

              enum = { "json", "xml" },

              default = "json",

            },

          },

          { variables = {

              type = "array",

              elements = {

                type = "record",

                fields = {



                  { path = { type = "string", required = true } },

                  { destination = {

                      type = "string",

                      enum = { "header", "context" },

                      default = "header",

                    },

                  },

                  { destination_name = { type = "string", required = true } },

                },

              },

            },

          },



        },

      },

    },

  },

}