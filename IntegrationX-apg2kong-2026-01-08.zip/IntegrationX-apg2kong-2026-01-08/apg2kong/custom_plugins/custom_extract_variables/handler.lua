
-- kong/plugins/custom_extract_variables/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"
-- xml2lua is a community library for parsing XML.
-- You need to make sure it is available in your environment.
local xml2lua = require "xml2lua"
local xml = xml2lua.parser()

local CustomExtractVariablesHandler = BasePlugin:extend()

CustomExtractVariablesHandler.PRIORITY = 900
CustomExtractVariablesHandler.VERSION = "0.1.0"

function CustomExtractVariablesHandler:new()
  CustomExtractVariablesHandler.super.new(self, "custom_extract_variables")
end

local function get_value_from_path(data, path)
    if not data or not path then
        return nil
    end

    local current = data
    for key in string.gmatch(path, "[^%.]+") do
        if type(current) ~= "table" then
            return nil
        end
        current = current[key]
        if current == nil then
            return nil
        end
    end
    return current
end

function CustomExtractVariablesHandler:access(conf)
  CustomExtractVariablesHandler.super.access(self)

  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return
  end

  local parsed_body
  if conf.payload_type == "json" then
    parsed_body, err = cjson.decode(body)
    if err then
      return kong.response.exit(400, { message = "Invalid JSON body" })
    end
  elseif conf.payload_type == "xml" then
    parsed_body, err = xml:parse(body)
    if err then
      return kong.response.exit(400, { message = "Invalid XML body: " .. err })
    end
  end
  
  for _, var in ipairs(conf.variables) do
    local value = get_value_from_path(parsed_body, var.path)
    if value then
        if var.destination == "header" then
            kong.service.request.set_header(var.destination_name, tostring(value))
        elseif var.destination == "context" then
            -- Setting context variables is not directly supported in the same way as headers.

            kong.ctx.shared[var.destination_name] = value
        end
    end
  end

end

return CustomExtractVariablesHandler
