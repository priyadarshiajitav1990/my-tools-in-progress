

local BasePlugin = require "kong.plugins.base_plugin"
local redis = require "resty.redis"
local jwt = require "resty.jwt"

local CustomResetQuotaHandler = BasePlugin:extend()

CustomResetQuotaHandler.PRIORITY = 730
CustomResetQuotaHandler.VERSION = "0.1.0"

function CustomResetQuotaHandler:new()
  CustomResetQuotaHandler.super.new(self, "custom_reset_quota")
end

local function get_consumer_id(conf)
    if conf.consumer_id_source == "header" then
        return kong.request.get_header(conf.consumer_id_source_name)
    elseif conf.consumer_id_source == "query_param" then
        return kong.request.get_query_arg(conf.consumer_id_source_name)
    elseif conf.consumer_id_source == "jwt_claim" then
        local auth_header = kong.request.get_header("authorization")
        if auth_header and string.starts_with(auth_header, "Bearer ") then
            local token = string.sub(auth_header, 8)
            local jwt_obj = jwt:verify(token, conf.jwt_secret)
            if jwt_obj and jwt_obj.payload[conf.consumer_id_source_name] then
                return jwt_obj.payload[conf.consumer_id_source_name]
            end
        end
    end
    return nil
end

function CustomResetQuotaHandler:access(conf)
  CustomResetQuotaHandler.super.access(self)

  local consumer_id = get_consumer_id(conf)

  if not consumer_id then
    return kong.response.exit(400, { message = "Consumer ID not found" })
  end
  
  local red = redis:new()
  red:set_timeout(1000) -- 1 sec

  local ok, err = red:connect(conf.redis_host, conf.redis_port)
  if not ok then
    return kong.response.exit(500, { message = "failed to connect to redis: " .. err })
  end

  if conf.redis_password then
    local ok, err = red:auth(conf.redis_password)
    if not ok then
      return kong.response.exit(500, { message = "failed to authenticate to redis: " .. err })
    end
  end

  local route_id = kong.router.get_route().id
  local key_prefix = "kong_rate_limiting:" .. route_id .. ":" .. consumer_id
  
  -- Find all keys for the consumer
  local keys, err = red:keys(key_prefix .. "*")
  if err then
      return kong.response.exit(500, { message = "failed to get keys from redis: " .. err })
  end

  for _, key in ipairs(keys) do
      red:del(key)
  end

  return kong.response.exit(200, { message = "Quota reset successfully for consumer " .. consumer_id })
end

return CustomResetQuotaHandler