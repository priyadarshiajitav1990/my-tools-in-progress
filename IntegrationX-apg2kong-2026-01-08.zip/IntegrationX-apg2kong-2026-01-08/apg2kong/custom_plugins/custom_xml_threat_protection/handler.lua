
local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomXmlThreatProtectionHandler = BasePlugin:extend()

CustomXmlThreatProtectionHandler.PRIORITY = 620
CustomXmlThreatProtectionHandler.VERSION = "0.1.0"

function CustomXmlThreatProtectionHandler:new()
  CustomXmlThreatProtectionHandler.super.new(self, "custom_xml_threat_protection")
end

function CustomXmlThreatProtectionHandler:access(conf)
  CustomXmlThreatProtectionHandler.super.access(self)

  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return kong.response.exit(400, { message = "XML body is empty" })
  end

  local httpc = http.new()
  local payload = cjson.encode({
    xml_body = body,
  })

  local res, err = httpc:request_uri(conf.xml_threat_protection_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("XML threat protection failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "XML threat protection failed" })
  end

  if res.status ~= 200 then
    kong.log.err("XML threat protection service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "XML threat protection failed", details = res.body })
  end

  -- Assuming a 200 OK from the validation service means no threats detected
  -- If the external service returns a specific response body for threat status,
  -- that can be parsed and acted upon here.
end

return CustomXmlThreatProtectionHandler
