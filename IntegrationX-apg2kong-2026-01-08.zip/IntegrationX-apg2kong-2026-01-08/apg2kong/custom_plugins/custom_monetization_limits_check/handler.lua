
-- kong/plugins/custom_monetization_limits_check/handler.lua  local BasePlugin = require "kong.plugins.base_plugin"
local jwt = require "resty.jwt"
local http = require "resty.http"
local cjson = require "cjson"

local CustomMonetizationLimitsCheckHandler = BasePlugin:extend()

CustomMonetizationLimitsCheckHandler.PRIORITY = 790
CustomMonetizationLimitsCheckHandler.VERSION = "0.1.0"

function CustomMonetizationLimitsCheckHandler:new()
  CustomMonetizationLimitsCheckHandler.super.new(self, "custom_monetization_limits_check")
end

local function get_consumer_id(conf)
    if conf.consumer_id_source == "header" then
        return kong.request.get_header(conf.consumer_id_source_name)
    elseif conf.consumer_id_source == "query_param" then
        return kong.request.get_query_arg(conf.consumer_id_source_name)
    elseif conf.consumer_id_source == "jwt_claim" then
        local auth_header = kong.request.get_header("authorization")
        if auth_header and string.starts_with(auth_header, "Bearer ") then
            local token = string.sub(auth_header, 8)
            local jwt_obj = jwt:verify(token, conf.jwt_secret) -- Use configurable secret
            if jwt_obj and jwt_obj.payload[conf.consumer_id_source_name] then
                return jwt_obj.payload[conf.consumer_id_source_name]
            end
        end
    end
    return nil
end

function CustomMonetizationLimitsCheckHandler:access(conf)
  CustomMonetizationLimitsCheckHandler.super.access(self)

  local consumer_id = get_consumer_id(conf)

  if not consumer_id then
    return kong.response.exit(400, { message = "Consumer ID not found" })
  end
  
  local httpc = http.new()
  local payload = cjson.encode({
    consumer_id = consumer_id,
    -- Optionally pass other relevant info for monetization check
    route_id = kong.router.get_route().id,
    service_id = kong.router.get_service().id,
  })

  local res, err = httpc:request_uri(conf.monetization_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("Monetization check failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "Monetization check failed" })
  end

  if res.status ~= 200 then
    kong.log.err("Monetization service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "Monetization check failed", details = res.body })
  end

  -- Assuming the monetization service returns a success status or relevant headers
  -- if no specific response is needed, just proceed.
end

return CustomMonetizationLimitsCheckHandler
