
-- kong/plugins/custom_parse_dialogflow_request/handler.lua local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"

local CustomParseDialogflowRequestHandler = BasePlugin:extend()

CustomParseDialogflowRequestHandler.PRIORITY = 780
CustomParseDialogflowRequestHandler.VERSION = "0.1.0"

function CustomParseDialogflowRequestHandler:new()
  CustomParseDialogflowRequestHandler.super.new(self, "custom_parse_dialogflow_request")
end

local function get_value_from_path(data, path)
    if not data or not path then
        return nil
    end

    local current = data
    for key in string.gmatch(path, "[^%.]+") do
        if type(current) ~= "table" then
            return nil
        end
        current = current[key]
        if current == nil then
            return nil
        end
    end
    return current
end

function CustomParseDialogflowRequestHandler:access(conf)
  CustomParseDialogflowRequestHandler.super.access(self)

  local body, err = kong.request.get_body()
  if err then
    return kong.response.exit(500, { message = "Error getting request body: " .. err })
  end
  
  if not body then
    return
  end

  local parsed_body, json_err = cjson.decode(body)
  if json_err then
    return kong.response.exit(400, { message = "Invalid JSON body: " .. json_err })
  end

  for _, rule in ipairs(conf.extract_rules) do
    local value = get_value_from_path(parsed_body, rule.path)
    if value then
        if rule.destination == "header" then
            kong.service.request.set_header(rule.destination_name, tostring(value))
        elseif rule.destination == "context" then
            kong.ctx.shared[rule.destination_name] = value
        end
    end
  end
end

return CustomParseDialogflowRequestHandler
