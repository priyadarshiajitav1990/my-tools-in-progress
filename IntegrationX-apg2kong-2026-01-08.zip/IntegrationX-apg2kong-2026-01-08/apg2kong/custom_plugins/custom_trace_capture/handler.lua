
-- kong/plugins/custom_trace_capture/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"
local cjson = require "cjson"

local CustomTraceCaptureHandler = BasePlugin:extend()

CustomTraceCaptureHandler.PRIORITY = 650
CustomTraceCaptureHandler.VERSION = "0.1.0"

function CustomTraceCaptureHandler:new()
  CustomTraceCaptureHandler.super.new(self, "custom_trace_capture")
end

function CustomTraceCaptureHandler:log(conf)
  CustomTraceCaptureHandler.super.log(self)

  local log_message = {
    request = {
      method = kong.request.get_method(),
      uri = kong.request.get_uri(),
      headers = conf.log_headers and kong.request.get_headers() or nil,
      body = conf.log_body and kong.request.get_raw_body() or nil,
    },
    response = {
      status = kong.response.get_status(),
      headers = conf.log_headers and kong.response.get_headers() or nil,
      body = conf.log_body and kong.response.get_raw_body() or nil,
    },
  }

  kong.log[conf.log_level](cjson.encode(log_message))

end

return CustomTraceCaptureHandler
