
-- kong/plugins/custom_invalidate_cache/schema.lua

return {
  name = "custom_invalidate_cache",
  fields = {
    { consumer = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { route = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { service = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { tags = {
        type = "array",
        elements = { type = "string" },
        description = "An optional list of strings associated with the Plugin for grouping and filtering.",
      },
    },
    { ordering = {
        type = "record",
        fields = {
          { before = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          },
          { after = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          }
        }
      }
    },
    { config = {
        type = "record",
        fields = {
          { cache_key = {
              type = "string",
              required = true,
            },
          },

        },
      },
    },
  },
}
