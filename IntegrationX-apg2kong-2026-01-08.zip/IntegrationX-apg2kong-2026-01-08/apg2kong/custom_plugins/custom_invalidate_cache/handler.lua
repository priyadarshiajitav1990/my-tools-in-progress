
-- kong/plugins/custom_invalidate_cache/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomInvalidateCacheHandler = BasePlugin:extend()

CustomInvalidateCacheHandler.PRIORITY = 870
CustomInvalidateCacheHandler.VERSION = "0.1.0"

function CustomInvalidateCacheHandler:new()
  CustomInvalidateCacheHandler.super.new(self, "custom_invalidate_cache")
end

function CustomInvalidateCacheHandler:access(conf)
  CustomInvalidateCacheHandler.super.access(self)

  local ok, err = kong.cache:invalidate(conf.cache_key)
  if not ok then
    return kong.response.exit(500, { message = "Failed to invalidate cache: " .. err })
  end

  return kong.response.exit(200, { message = "Cache invalidated successfully" })
end

return CustomInvalidateCacheHandler
