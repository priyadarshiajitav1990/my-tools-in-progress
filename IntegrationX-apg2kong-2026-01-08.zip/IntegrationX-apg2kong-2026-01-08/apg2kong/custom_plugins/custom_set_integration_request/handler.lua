
-- kong/plugins/custom_set_integration_request/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomSetIntegrationRequestHandler = BasePlugin:extend()

CustomSetIntegrationRequestHandler.PRIORITY = 680
CustomSetIntegrationRequestHandler.VERSION = "0.1.0"

function CustomSetIntegrationRequestHandler:new()
  CustomSetIntegrationRequestHandler.super.new(self, "custom_set_integration_request")
end

function CustomSetIntegrationRequestHandler:access(conf)
  CustomSetIntegrationRequestHandler.super.access(self)

  if conf.headers then
    for key, value in pairs(conf.headers) do
      kong.service.request.set_header(key, value)
    end
  end

  if conf.body then
    kong.service.request.set_raw_body(conf.body)
  end

end

return CustomSetIntegrationRequestHandler
