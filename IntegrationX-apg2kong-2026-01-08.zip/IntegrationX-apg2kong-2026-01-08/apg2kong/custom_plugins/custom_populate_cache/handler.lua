
-- kong/plugins/custom_populate_cache/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomPopulateCacheHandler = BasePlugin:extend()

CustomPopulateCacheHandler.PRIORITY = 770
CustomPopulateCacheHandler.VERSION = "0.1.0"

function CustomPopulateCacheHandler:new()
  CustomPopulateCacheHandler.super.new(self, "custom_populate_cache")
end

local function get_value(conf)
    if conf.value_source == "header" then
        return kong.request.get_header(conf.value_source_name)
    elseif conf.value_source == "query_param" then
        return kong.request.get_query_arg(conf.value_source_name)
    elseif conf.value_source == "body_field" then
        local body, err = kong.request.get_body()
        if err then
            return nil, err
        end
        if body and body[conf.value_source_name] then
            return body[conf.value_source_name]
        end
    elseif conf.value_source == "static" then
        return conf.static_value
    end
    return nil
end

function CustomPopulateCacheHandler:access(conf)
  CustomPopulateCacheHandler.super.access(self)

  local value, err = get_value(conf)
  if err then
    return kong.response.exit(500, { message = "Error getting value: " .. err })
  end
  
  if value then
    local ok, err = kong.cache:set(conf.cache_key, value, conf.ttl)
    if not ok then
        return kong.response.exit(500, { message = "Failed to populate cache: " .. err })
    end
  else
    return kong.response.exit(400, { message = "Value not found for cache population" })
  end

end

return CustomPopulateCacheHandler
