
-- kong/plugins/custom_access_entity/handler.lua
kong.log.err("[DEBUG] custom_access_entity handler.lua version: no-base-plugin, 2025-12-21")
local jwt = require "resty.jwt"

local plugin = {
  PRIORITY = 1000,
  VERSION = "0.1.0",
}

function plugin:access(conf)
  local entity_value

  if conf.source == "jwt" then
    local auth_header = kong.request.get_header("authorization")
    if auth_header and auth_header:sub(1, 7):lower() == "bearer " then
      local token = auth_header:sub(8)
      local jwt_obj = jwt:verify(token, nil) -- In a real scenario, you would verify the token with a secret
      if jwt_obj and jwt_obj.payload and jwt_obj.payload[conf.source_name] then
        entity_value = jwt_obj.payload[conf.source_name]
      else
        return kong.response.exit(401, { message = "Invalid or missing JWT token" })
      end
    else
      return kong.response.exit(401, { message = "Missing Authorization header" })
    end
  elseif conf.source == "header" then
    entity_value = kong.request.get_header(conf.source_name)
  elseif conf.source == "query_param" then
    entity_value = kong.request.get_query_arg(conf.source_name)
  end

  if entity_value then
    kong.service.request.set_header(conf.header_name, entity_value)
  else
    return kong.response.exit(400, { message = "Could not extract entity information" })
  end
end

return plugin
