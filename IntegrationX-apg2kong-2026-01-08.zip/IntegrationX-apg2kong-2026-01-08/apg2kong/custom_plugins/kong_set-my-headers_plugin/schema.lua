
local typedefs = require "kong.db.schema.typedefs"

return {
  name = "set-my-headers",
  fields = {
    { consumer = typedefs.no_consumer },
    { service = typedefs.no_service },
    { route = typedefs.no_route },
    { protocols = typedefs.protocols },
    { config = {
      type = "record",
      fields = {
        { apikey = { type = "string", default = "default_value", description = "Config for JS variable: apiKey." } }
      },
    } },
  },
}
