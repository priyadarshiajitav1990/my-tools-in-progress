
-- kong/plugins/custom_publish_message/handler.lualocal BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"
local kafka = require "resty.kafka.producer"

local CustomPublishMessageHandler = BasePlugin:extend()  CustomPublishMessageHandler.PRIORITY = 760 CustomPublishMessageHandler.VERSION = "0.1.0"  function CustomPublishMessageHandler:new()   CustomPublishMessageHandler.super.new(self, "custom_publish_message") end  local function get_message(conf)     if conf.message_source == "header" then         return kong.request.get_header(conf.message_source_name)     elseif conf.message_source == "query_param" then         return kong.request.get_query_arg(conf.message_source_name)     elseif conf.message_source == "body_field" then         local body, err = kong.request.get_body()         if err then             return nil, err         end         if body and body[conf.message_source_name] then             return body[conf.message_source_name]         end     elseif conf.message_source == "static" then         return conf.static_message     end     return nil end function CustomPublishMessageHandler:log(conf)
  CustomPublishMessageHandler.super.log(self)

  local message, err = get_message(conf)
  if err then
    kong.log.err("Error getting message: " .. err)
    return
  end
    
  if not message then
    kong.log.warn("Message not found for publishing")
    return
  end

  if conf.broker_type == "kafka" then
    if not conf.kafka_brokers or #conf.kafka_brokers == 0 then
      kong.log.err("Kafka brokers not configured")
      return
    end

    local bp = kafka:new({
      brokers = conf.kafka_brokers
    })

    local producer, err = bp:get_producer()
    if not producer then
      kong.log.err("Failed to create Kafka producer: " .. err)
      return
    end

    local offset, err = producer:send(conf.topic, nil, message)
    if err then
      kong.log.err("Failed to send message to Kafka: " .. err)
    else
      kong.log.info("Message sent to Kafka topic '" .. conf.topic .. "', offset: " .. offset)
    end
    producer:close()

  elseif conf.broker_type == "pubsub" then
    if not conf.pubsub_project_id then
      kong.log.err("PubSub project ID not configured")
      return
    end

    local pubsub_url = "https://pubsub.googleapis.com/v1/projects/" .. conf.pubsub_project_id .. "/topics/" .. conf.topic .. ":publish"
    local httpc = http.new()

    local payload = cjson.encode({
      messages = {{ 
        data = ngx.encode_base64(message) -- PubSub requires message data to be base64 encoded
      }}
    })

    -- In a real scenario, you would need to handle authentication (e.g., Google Cloud service account).

    local res, err = httpc:request_uri(pubsub_url, {
      method = "POST",
      headers = {
        ["Content-Type"] = "application/json",
        -- Add Authorization header here if needed, e.g., Bearer <token>
      },
      body = payload,
      ssl_verify = conf.verify_ssl
    })

    if not res then
      kong.log.err("PubSub message publishing failed: " .. (err or "unknown error"))
      return
    end

    if res.status >= 200 and res.status < 300 then
      kong.log.info("Message published to PubSub topic '" .. conf.topic .. "' in project '" .. conf.pubsub_project_id .. "'")
    else
      kong.log.err("PubSub service returned non-2xx status: " .. res.status .. ", body: " .. (res.body or ""))
    end
  end
end

return CustomPublishMessageHandler
