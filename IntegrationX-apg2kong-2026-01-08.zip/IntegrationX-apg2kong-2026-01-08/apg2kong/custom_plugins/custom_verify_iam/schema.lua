
-- kong/plugins/custom_verify_iam/schema.lua

return {
  name = "custom_verify_iam",
  fields = {
    { consumer = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { route = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { service = {
        type = "record",
        fields = {
          { "id" },
        },
      },
    },
    { tags = {
        type = "array",
        elements = { type = "string" },
        description = "An optional list of strings associated with the Plugin for grouping and filtering.",
      },
    },
    { ordering = {
        type = "record",
        fields = {
          { before = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          },
          { after = {
              type = "record",
              fields = {
                { access = { type = "array", elements = { type = "string" } } },
                { rewrite = { type = "array", elements = { type = "string" } } },
                { access_phase = { type = "array", elements = { type = "string" } } },
                { certificate = { type = "array", elements = { type = "string" } } },
                { ssl = { type = "array", elements = { type = "string" } } },
                { preread = { type = "array", elements = { type = "string" } } },
                { balancer = { type = "array", elements = { type = "string" } } },
                { log = { type = "array", elements = { type = "string" } } },
                { exit = { type = "array", elements = { type = "string" } } },
              }
            }
          }
        }
      }
    },
    { config = {
        type = "record",
        fields = {
          { iam_provider = {
              type = "string",
              enum = { "aws", "gcp" },
              required = true,
            },
          },
          { credential_source = {
              type = "string",
              enum = { "header", "query_param" },
              required = true,
            },
          },
          { credential_source_name = {
              type = "string",
              required = true,
            },
          },
          { iam_verification_service_url = {
              type = "string",
              required = true,
            },
          },
          { verify_ssl = {
              type = "boolean",
              default = true,
              description = "Whether to verify SSL certificates of the external service. Set to 'false' only if absolutely necessary and you understand the security implications.",
            },
          },

        },
      },
    },
  },
}
