
local BasePlugin = require "kong.plugins.base_plugin"
local http = require "resty.http"
local cjson = require "cjson"

local CustomVerifyIamHandler = BasePlugin:extend()

CustomVerifyIamHandler.PRIORITY = 640
CustomVerifyIamHandler.VERSION = "0.1.0"

function CustomVerifyIamHandler:new()
  CustomVerifyIamHandler.super.new(self, "custom_verify_iam")
end

local function get_credential(conf)
    if conf.credential_source == "header" then
        return kong.request.get_header(conf.credential_source_name)
    elseif conf.credential_source == "query_param" then
        return kong.request.get_query_arg(conf.credential_source_name)
    end
    return nil
end

function CustomVerifyIamHandler:access(conf)
  CustomVerifyIamHandler.super.access(self)

  local credential = get_credential(conf)

  if not credential then
    return kong.response.exit(401, { message = "IAM credential not found" })
  end

  local httpc = http.new()
  local payload = cjson.encode({
    iam_provider = conf.iam_provider,
    credential = credential,
    -- Optionally pass other relevant info for verification
    route_id = kong.router.get_route().id,
    service_id = kong.router.get_service().id,
  })

  local res, err = httpc:request_uri(conf.iam_verification_service_url, {
    method = "POST",
    headers = {
      ["Content-Type"] = "application/json",
    },
    body = payload,
    ssl_verify = conf.verify_ssl,
  })

  if not res then
    kong.log.err("IAM verification failed: " .. (err or "unknown error"))
    return kong.response.exit(500, { message = "IAM verification failed" })
  end

  if res.status ~= 200 then
    kong.log.err("IAM verification service returned non-200 status: " .. res.status .. ", body: " .. (res.body or ""))
    return kong.response.exit(res.status, { message = "IAM verification failed", details = res.body })
  end

  -- Assuming a 200 OK from the verification service means the credential is valid
  -- If the external service returns a specific response body for verification status,
  -- that can be parsed and acted upon here.
end

return CustomVerifyIamHandler
