
-- kong/plugins/custom_read_property_set/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

local CustomReadPropertySetHandler = BasePlugin:extend()

CustomReadPropertySetHandler.PRIORITY = 750
CustomReadPropertySetHandler.VERSION = "0.1.0"

function CustomReadPropertySetHandler:new()
  CustomReadPropertySetHandler.super.new(self, "custom_read_property_set")
end

function CustomReadPropertySetHandler:access(conf)
  CustomReadPropertySetHandler.super.access(self)

  if conf.properties then
    for key, value in pairs(conf.properties) do
      kong.service.request.set_header("x-property-" .. key, value)
    end
  end

end

return CustomReadPropertySetHandler
