function hello() {
    var x = 1;
    return x;
}