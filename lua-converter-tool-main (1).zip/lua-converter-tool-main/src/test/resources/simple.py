def hello():
    x = 1
    return x
