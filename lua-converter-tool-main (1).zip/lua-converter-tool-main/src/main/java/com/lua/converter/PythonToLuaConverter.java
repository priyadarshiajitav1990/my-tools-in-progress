// Python-to-Lua conversion removed
