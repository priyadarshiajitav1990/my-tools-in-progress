local typedefs = require "kong.db.schema.typedefs"

return {
  name = "__PLUGIN_NAME__",
  fields = {
    { consumer = typedefs.no_consumer },
    { protocols = typedefs.protocols_http },
    { tags = typedefs.tags },
    { config = {
      type = "record",
      fields = {
        { script_name = { type = "string" } },
        { dependency_name = { type = "string", required = false } },
        { condition = { type = "string", required = false } },
        { flow = { type = "string", required = false, default = "both", one_of = { "request", "response", "both" } } },
        { kv_pairs = { type = "map", keys = { type = "string" }, values = { type = "string" }, required = false } },
      },
    }, },
  },
}
