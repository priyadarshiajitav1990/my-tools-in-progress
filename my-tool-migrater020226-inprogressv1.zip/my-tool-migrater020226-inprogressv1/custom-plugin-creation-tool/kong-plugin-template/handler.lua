local BasePlugin = require "kong.plugins.base_plugin"
local TestPlugin = BasePlugin:extend()

function TestPlugin:new()
  TestPlugin.super.new(self, "testplugin")
end

function TestPlugin:access(conf)
  kong.log("TestPlugin access phase")
end

return TestPlugin
