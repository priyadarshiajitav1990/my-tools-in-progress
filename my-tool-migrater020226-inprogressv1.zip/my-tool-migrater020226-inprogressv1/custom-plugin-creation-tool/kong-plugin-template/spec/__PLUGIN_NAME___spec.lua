local helpers = require "spec.helpers"

describe("__PLUGIN_NAME__ plugin (integration)", function()
  local client

  lazy_setup(function()
    local bp = helpers.get_db_utils(nil, {
      "routes",
      "services",
      "plugins",
    }, { "__PLUGIN_NAME__" })

    local service = bp.services:insert {
      name = "test-service",
      url = "http://httpbin.org/get"
    }
    local route = bp.routes:insert {
      service = service,
      hosts = { "test.com" },
    }
    bp.plugins:insert {
      name = "__PLUGIN_NAME__",
      route = { id = route.id },
      config = {
        script_name = "main_policy.lua",
        dependency_name = "helper.lua",
        condition = "true",
        flow = "request",
        kv_pairs = { user_role = "admin", max_limit = "100" }
      }
    }
    assert(helpers.start_kong({
      plugins = "bundled,__PLUGIN_NAME__"
    }))
    client = helpers.proxy_client()
  end)

  lazy_teardown(function()
    if client then client:close() end
    helpers.stop_kong()
  end)

  it("executes main and dependency script with kv", function()
    local res = assert(client:send {
      method = "GET",
      path = "/",
      headers = {
        host = "test.com"
      }
    })
    assert.res_status(200, res)
  end)
end)
