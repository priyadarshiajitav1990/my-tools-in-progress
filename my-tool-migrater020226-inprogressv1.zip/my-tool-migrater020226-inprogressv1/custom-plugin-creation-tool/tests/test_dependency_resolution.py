import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/..'))
import unittest
from custom_plugin_develop import resolve_dependencies, create_plugin_from_template, load_config

class TestDependencyResolution(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.plugin_dir = create_plugin_from_template(self.config)

    def test_resolve_dependencies(self):
        try:
            resolve_dependencies(self.plugin_dir)
        except SystemExit:
            self.fail("Dependency resolution failed unexpectedly.")

    def tearDown(self):
        import shutil
        if self.plugin_dir and os.path.exists(self.plugin_dir):
            shutil.rmtree(self.plugin_dir)

if __name__ == "__main__":
    unittest.main()
