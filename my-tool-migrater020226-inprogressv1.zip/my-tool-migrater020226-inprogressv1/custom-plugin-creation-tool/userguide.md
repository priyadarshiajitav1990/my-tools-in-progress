# Custom Plugin Creation Tool - User Guide

## Requirements
- Python 3.7+
- LuaRocks (installed and in PATH)
- Docker (for Kong and Pongo validation)
- Kong-pongo (included in this repo)

## Directory Structure
- `custom_plugin_develop.py` : Main CLI tool
- `config.json` : Configuration file for plugin creation
- `kong-plugin-template/` : Template files for new plugins
- `luafiles/` : Place your Lua scripts here (main and helper files)
- `outputs/` : Generated plugin packages will appear here

## Setup Steps
1. **Clone the repository** and navigate to the `custom-plugin-creation-tool` directory.

2. **Edit `config.json`**
   - Set `plugin_name` to your desired plugin name.
   - Add `main_script` and `dependency_script` keys with your Lua filenames (if not present, add them):
     ```json
     {
       "plugin_name": "myplugin",
       "main_script": "handler.lua",
       "dependency_script": "helper.lua"
       // ...other config fields
     }
     ```

3. **Add your Lua files**
   - Place your main and helper Lua files in the `luafiles/` directory.

4. **Run the tool**
   ```bash
   cd /workspaces/my-tool-migrater020226/custom-plugin-creation-tool
   python3 custom_plugin_develop.py
   ```

5. **Check the output**
   - The generated plugin package will be in `outputs/<plugin_name>-standalone/`.
   - All required files (handler.lua, .rockspec, etc.) will be present.

6. **(Optional) Validate with Kong-Pongo**
   - The tool will automatically run Pongo tests if configured.

## Example
```json
{
  "plugin_name": "testplugin",
  "main_script": "handler.lua",
  "dependency_script": "test_helper.lua"
}
```

## Plugin Deployment

After generating your plugin package, you can deploy it to a Kong instance using the deployment script:

### Requirements
- Kong must be installed and the `kong` command available in your PATH (or specify the full path in config/arguments).
- Sufficient permissions to write to the Kong plugins directory (may require `sudo`).

### Steps
1. **Deploy the plugin locally:**
    ```bash
    sudo python3 plugin_deployment_scripts/deploy_plugin.py \
       --input_directory outputs/<plugin_name>-standalone \
       --plugin_name <plugin_name>
    ```
    - You can override config.json values with command-line arguments as shown above.
    - The script will:
       - Copy plugin files to the Kong plugins directory
       - Attempt to enable the plugin (placeholder logic)
       - Restart Kong and check health
       - Roll back changes if Kong fails to start

2. **Remote deployment:**
    - The script is ready for extension to support remote deployment (e.g., via SSH/SCP). See comments in `deploy_plugin.py`.

### Troubleshooting
- If you see `Permission denied`, run the script with `sudo` or adjust the plugin directory permissions.
- If you see `/bin/sh: 1: kong: not found`, ensure Kong is installed and in your PATH, or update the config to use the full path to the Kong binary.
- Check `plugin-deploy.log` or terminal output for error details.
- After rollback, verify Kong is running healthy.

---
For advanced usage or automation, see comments in `custom_plugin_develop.py` and `plugin_deployment_scripts/deploy_plugin.py`.
