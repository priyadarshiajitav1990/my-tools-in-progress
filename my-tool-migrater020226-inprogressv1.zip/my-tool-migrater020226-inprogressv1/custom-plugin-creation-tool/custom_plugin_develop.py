
import os
import json
import shutil
import subprocess
import sys
import logging


CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "kong-plugin-template")
LUAFILES_PATH = os.path.join(os.path.dirname(__file__), "luafiles")
OUTPUTS_PATH = os.path.join(os.path.dirname(__file__), "outputs")

KONG_VERSION = "3.13.0.0"

# Setup logging
LOG_PATH = os.path.join(os.path.dirname(__file__), "plugin-develop.log")
logging.basicConfig(
    filename=LOG_PATH,
    filemode="a",
    format="%(asctime)s %(levelname)s: %(message)s",
    level=logging.INFO
)


def load_config():
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        logging.info("Loaded config.json successfully.")
        return config
    except Exception as e:
        logging.error(f"Failed to load config.json: {e}")
        print("Error loading config.json. See log for details.")
        sys.exit(1)


def create_plugin_from_template(config):
    plugin_dir = os.path.join(os.path.dirname(__file__), config["plugin_name"])
    try:
        if os.path.exists(plugin_dir):
            shutil.rmtree(plugin_dir)
        shutil.copytree(TEMPLATE_PATH, plugin_dir)
        logging.info(f"Plugin template copied to {plugin_dir}")
        print(f"Plugin template copied to {plugin_dir}")
        # Place main and dependency scripts
        for script_key in ["main_script", "dependency_script"]:
            script_name = config.get(script_key)
            if script_name:
                src = os.path.join(LUAFILES_PATH, script_name)
                if os.path.isfile(src):
                    shutil.copy(src, plugin_dir)
                    logging.info(f"Placed {script_name} in plugin directory.")
                    print(f"Placed {script_name} in plugin directory.")
                else:
                    logging.error(f"Script {script_name} not found in luafiles.")
                    print(f"Script {script_name} not found in luafiles.")
        return plugin_dir
    except Exception as e:
        logging.error(f"Error creating plugin from template: {e}")
        print("Error creating plugin. See log for details.")
        sys.exit(1)


def resolve_dependencies(plugin_dir):
    print("Resolving dependencies with luarocks...")
    try:
        subprocess.run(["luarocks", "--local", "make"], cwd=plugin_dir, check=True)
        logging.info("Dependencies resolved successfully with luarocks --local.")
    except Exception as e:
        logging.error(f"Dependency resolution failed: {e}")
        print(f"Dependency resolution failed: {e}")
        sys.exit(1)


def package_plugin(plugin_dir):
    package_name = os.path.basename(plugin_dir) + "-standalone"
    package_path = os.path.join(OUTPUTS_PATH, package_name)
    try:
        if os.path.exists(package_path):
            shutil.rmtree(package_path)
        shutil.copytree(plugin_dir, package_path)
        logging.info(f"Packaged plugin at {package_path}")
        print(f"Packaged plugin at {package_path}")
        return package_path
    except Exception as e:
        logging.error(f"Error packaging plugin: {e}")
        print("Error packaging plugin. See log for details.")
        sys.exit(1)


def validate_with_pongo(package_path):
    print(f"Validating plugin with kong-pongo (Kong {KONG_VERSION})...")
    pongo_path = os.path.join(os.path.dirname(__file__), "kong-pongo", "pongo.sh")
    try:
        # Always set Kong version 3.13.0.0 before validation and testing
        subprocess.run([pongo_path, "down"], cwd=package_path, check=True)
        subprocess.run([pongo_path, "up", KONG_VERSION], cwd=package_path, check=True)
        subprocess.run([pongo_path, "run"], cwd=package_path, check=True)
        logging.info("Validation and testing successful with kong-pongo.")
        print("Validation and testing successful.")
    except Exception as e:
        logging.error(f"Validation failed: {e}")
        print(f"Validation failed: {e}")
        sys.exit(1)


def main():
    logging.info("Starting custom plugin development tool.")
    config = load_config()
    print("Loaded configuration:", config)
    plugin_dir = create_plugin_from_template(config)
    resolve_dependencies(plugin_dir)
    package_path = package_plugin(plugin_dir)
    validate_with_pongo(package_path)
    logging.info("Custom plugin development and validation complete.")
    print("Custom plugin development and validation complete.")
    print("Packaged plugin is available at:", package_path)

if __name__ == "__main__":
    main()
