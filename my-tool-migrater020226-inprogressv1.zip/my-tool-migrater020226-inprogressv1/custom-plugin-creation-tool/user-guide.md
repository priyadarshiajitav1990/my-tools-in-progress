# Custom Plugin Creation Tool - User Guide

This guide describes how to use the custom-plugin-creation-tool to develop, package, and validate custom Lua plugins for Kong (enterprise standards).

## Workflow Steps

1. **Configure Plugin**
   - Edit `custom-plugin-creation-tool/config.json` to specify:
     - `plugin_name`: Name of your plugin
     - `main_script`: Main Lua script filename (must be in `luafiles`)
     - `dependency_script`: Dependency Lua script filename (optional, must be in `luafiles`)
     - `author`, `version`, `description`, `kong_version`

2. **Prepare Lua Scripts**
   - Place your main and dependency Lua scripts in `custom-plugin-creation-tool/luafiles/`.

3. **Develop Plugin**
   - Run `custom-plugin-creation-tool/custom-plugin-develop.py`.
   - The tool will:
     - Copy the template from `kong-plugin-template`.
     - Place your Lua scripts in the plugin directory.
     - Resolve dependencies using `luarocks`.
     - Package the plugin as a standalone directory in `outputs/`.
     - Validate and test the plugin using Kong Pongo (Kong 3.13.0.0).

4. **Validation and Testing**
   - The tool uses Kong Pongo to validate and test the plugin.
   - If validation fails, review errors and retry after fixing issues.

5. **Production-Ready Output**
   - On success, your plugin and all dependencies are packaged in `custom-plugin-creation-tool/outputs/`.
   - This package is ready for deployment in enterprise environments.

## Notes
- Ensure all Lua scripts and dependencies are correct before running the tool.
- The tool automates all steps for plugin creation, packaging, and validation.
- For advanced customization, modify the template or add extra dependencies as needed.

## Troubleshooting
- If dependency resolution or validation fails, check your Lua scripts and luarocks configuration.
- For Kong Pongo issues, ensure Docker is running and Kong 3.13.0.0 is available.

## Support
- For further help, consult the README in `kong-plugin-template` or contact your platform administrator.
