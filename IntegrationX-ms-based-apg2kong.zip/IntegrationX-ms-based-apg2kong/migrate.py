#!/usr/bin/env python3
"""
Apigee to Kong Migration Tool - Simple Entry Point
==================================================

Configuration-driven migration tool that reads all settings from config/config.env
No command-line arguments needed - just run: python migrate.py

Features:
- Automatic file detection from INPUT_FILE in config
- Single output file per API (overwrites existing)
- Built-in deck validation
- Optional deployment to Kong Gateway
- All settings from config/config.env
"""

import sys
import os
from pathlib import Path

# Add src directory to Python path
current_dir = Path(__file__).parent
src_dir = current_dir / 'src'
sys.path.insert(0, str(src_dir))

from migration_tool import ApigeeMigrationTool
from core.exceptions import MigrationToolError


def main() -> int:
    """Main entry point - configuration-driven execution."""
    
    print("=" * 60)
    print("Apigee to Kong Migration Tool")
    print("=" * 60)
    print()
    
    try:
        # Initialize migration tool (reads config/config.env)
        tool = ApigeeMigrationTool()
        
        # Get configuration
        input_file = tool.config_manager.get('INPUT_FILE')
        
        # If INPUT_FILE not set, auto-detect from INPUT_DIR
        if not input_file:
            input_dir = tool.config_manager.get_path('INPUT_DIR')
            zip_files = list(input_dir.glob('*.zip'))
            if zip_files:
                input_file = str(zip_files[0])
                print(f"Auto-detected input file: {input_file}")
            else:
                print("ERROR: No ZIP files found in input directory")
                print(f"Please place your Apigee proxy bundle in: {input_dir}")
                return 1
        
        validate_deck = tool.config_manager.get('VALIDATE_WITH_DECK', True)
        deploy = tool.config_manager.get('DEPLOY_TO_KONG', False)
        
        # Check if input file exists
        input_path = Path(input_file)
        if not input_path.exists():
            print(f"ERROR: Input file not found: {input_file}")
            print(f"Please place your Apigee proxy bundle at: {input_file}")
            return 1
        
        print(f"Input File: {input_file}")
        print(f"Validate with deck: {validate_deck}")
        print(f"Deploy to Kong: {deploy}")
        print()
        print("-" * 60)
        print()
        
        # Run migration
        result = tool.migrate_single_bundle(
            input_file,
            output_name=None,  # Auto-generate from API name
            validate_with_deck=validate_deck,
            deploy_with_deck=deploy
        )
        
        # Display results
        print()
        print("=" * 60)
        if result['success']:
            print("SUCCESS: Migration completed!")
            print("=" * 60)
            print(f"  API Name: {result['proxy_name']}")
            print(f"  Output File: {result['output_file']}")
            print(f"  Migration Time: {result['migration_time']:.2f} seconds")
            
            if validate_deck:
                if result.get('deck_validation_passed'):
                    print(f"  deck Validation: PASSED")
                else:
                    print(f"  deck Validation: FAILED")
                    if result.get('errors'):
                        print(f"  Errors:")
                        for error in result['errors'][:3]:  # Show first 3 errors
                            print(f"    - {error}")
            
            if deploy:
                status = result.get('deck_deployment_status', 'unknown')
                if status == 'deployed':
                    print(f"  Deployment: SUCCESS")
                    print(f"  Note: Only '{result['proxy_name']}' was deployed")
                    print(f"        Other APIs in Kong Gateway were NOT affected")
                else:
                    print(f"  Deployment: {status}")
            
            if result.get('warnings'):
                print(f"  Warnings: {len(result['warnings'])}")
                for warning in result['warnings'][:3]:
                    print(f"    - {warning}")
            
            print()
            print("Next Steps:")
            if not validate_deck:
                print("  1. Validate: deck file validate " + result['output_file'])
            if not deploy:
                print("  2. Deploy: Set DEPLOY_TO_KONG=true in config/config.env")
            print()
            
            return 0
        else:
            print("FAILED: Migration failed!")
            print("=" * 60)
            for error in result['errors']:
                print(f"  ERROR: {error}")
            print()
            print("Check logs/migration.log for details")
            return 1
            
    except MigrationToolError as e:
        print(f"ERROR: {str(e)}")
        return 1
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        return 1
    except Exception as e:
        print(f"UNEXPECTED ERROR: {str(e)}")
        print("Check logs/migration.log for details")
        return 1


if __name__ == '__main__':
    sys.exit(main())
