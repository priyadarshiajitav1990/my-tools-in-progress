import json
from pathlib import Path

# Find the output file
output_dir = Path('C:/Users/Priyadarshi.Jena/Videos/kiro Developments/8-1-2026/apg2kong/output')
output_file = output_dir / 'migration-test-api.json'

if not output_file.exists():
    print(f"File not found: {output_file}")
    exit(1)

with open(output_file, 'r') as f:
    data = json.load(f)

plugins = [p for p in data['plugins'] if p['name'] == 'rate-limiting']
print(f"Rate-limiting plugins: {len(plugins)}")
for i, p in enumerate(plugins[:3]):
    plugin_id = p.get('id', 'NO ID')
    tags = p.get('tags', [])
    print(f"  {i+1}. ID: {plugin_id[:40] if plugin_id != 'NO ID' else 'NO ID'}...")
    print(f"     Tags: {tags[:2]}")
