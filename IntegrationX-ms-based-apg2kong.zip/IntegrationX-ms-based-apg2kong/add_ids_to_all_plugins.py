import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Find all plugin creation patterns where we have:
# plugin = {
#     'name': 'plugin-type',
#     'service': service_name,

# Pattern to match plugin dictionaries
pattern = r"(plugin = \{)\s*\n\s*('name': '[^']+',)\s*\n\s*('service': service_name,)"
replacement = r"\1\n            'id': self._generate_plugin_id(\2.split(': ')[1].strip(\"',\"), service_name, policy.get('name', 'unknown')),\n            \2\n            \3"

# This is complex, let's do it differently - add id after 'name' field
lines = content.split('\n')
new_lines = []
i = 0

while i < len(lines):
    line = lines[i]
    new_lines.append(line)
    
    # If we find a plugin dict with 'name': 'something',
    if "'name':" in line and i + 1 < len(lines) and "'service': service_name" in lines[i + 1]:
        # Extract plugin name
        match = re.search(r"'name':\s*'([^']+)'", line)
        if match:
            plugin_name = match.group(1)
            # Add ID line before service line
            indent = len(lines[i + 1]) - len(lines[i + 1].lstrip())
            id_line = " " * indent + f"'id': self._generate_plugin_id('{plugin_name}', service_name, policy.get('name', 'unknown')),"
            new_lines.append(id_line)
    
    i += 1

content = '\n'.join(new_lines)

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Added IDs to all plugins")
