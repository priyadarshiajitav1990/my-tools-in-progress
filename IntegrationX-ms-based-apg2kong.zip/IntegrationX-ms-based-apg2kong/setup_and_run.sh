#!/bin/bash
# ============================================================================
# Apigee to Kong Migration Tool - Setup and Run Script
# ============================================================================
# This script will:
# 1. Create a virtual environment (if not exists)
# 2. Activate the virtual environment
# 3. Install dependencies
# 4. Run the migration tool
# ============================================================================

set -e

echo ""
echo "========================================"
echo "Apigee to Kong Migration Tool"
echo "========================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed"
    echo "Please install Python 3.8+ and try again"
    exit 1
fi

echo "[INFO] Python found:"
python3 --version
echo ""

# Check if venv exists
if [ -d "venv" ]; then
    echo "[INFO] Virtual environment already exists"
else
    echo "[INFO] Creating virtual environment..."
    python3 -m venv venv
    echo "[SUCCESS] Virtual environment created"
fi
echo ""

# Activate virtual environment
echo "[INFO] Activating virtual environment..."
source venv/bin/activate
echo "[SUCCESS] Virtual environment activated"
echo ""

# Install/upgrade pip
echo "[INFO] Upgrading pip..."
python -m pip install --upgrade pip --quiet
echo ""

# Install dependencies
echo "[INFO] Installing dependencies..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt --quiet
    echo "[SUCCESS] Dependencies installed"
else
    echo "[WARNING] requirements.txt not found, skipping dependency installation"
fi
echo ""

# Menu function
show_menu() {
    echo "========================================"
    echo "Migration Tool Menu"
    echo "========================================"
    echo "1. Migrate single proxy"
    echo "2. Batch migrate all proxies"
    echo "3. Show tool info"
    echo "4. Generate migration plan"
    echo "5. Validate Kong config"
    echo "6. Exit"
    echo "========================================"
    echo ""
}

# Main loop
while true; do
    show_menu
    read -p "Enter your choice (1-6): " choice
    
    case $choice in
        1)
            echo ""
            echo "========================================"
            echo "Single Proxy Migration"
            echo "========================================"
            echo ""
            read -p "Enter path to Apigee proxy ZIP file (or press Enter for default): " input_file
            
            if [ -z "$input_file" ]; then
                # Use default file from input directory
                input_file=$(ls input/*.zip 2>/dev/null | head -n 1)
                if [ -z "$input_file" ]; then
                    echo "[ERROR] No ZIP files found in input directory"
                    echo ""
                    continue
                fi
                echo "[INFO] Using default file: $input_file"
            fi
            
            echo ""
            echo "[INFO] Starting migration..."
            python main.py migrate --input "$input_file"
            echo ""
            echo "[INFO] Migration complete!"
            echo "[INFO] Check the output directory for results"
            echo ""
            read -p "Press Enter to continue..."
            ;;
        2)
            echo ""
            echo "========================================"
            echo "Batch Migration"
            echo "========================================"
            echo ""
            echo "[INFO] Starting batch migration of all proxies in input directory..."
            python main.py batch --input-dir input
            echo ""
            echo "[INFO] Batch migration complete!"
            echo "[INFO] Check the output directory for results"
            echo ""
            read -p "Press Enter to continue..."
            ;;
        3)
            echo ""
            echo "========================================"
            echo "Tool Information"
            echo "========================================"
            echo ""
            python main.py info
            echo ""
            read -p "Press Enter to continue..."
            ;;
        4)
            echo ""
            echo "========================================"
            echo "Generate Migration Plan"
            echo "========================================"
            echo ""
            read -p "Enter path to Apigee proxy ZIP file: " input_file
            
            if [ -z "$input_file" ]; then
                echo "[ERROR] Input file is required"
                echo ""
                continue
            fi
            
            echo ""
            echo "[INFO] Generating migration plan..."
            python main.py plan --input "$input_file"
            echo ""
            echo "[INFO] Plan generation complete!"
            echo ""
            read -p "Press Enter to continue..."
            ;;
        5)
            echo ""
            echo "========================================"
            echo "Validate Kong Configuration"
            echo "========================================"
            echo ""
            read -p "Enter path to Kong config JSON file: " config_file
            
            if [ -z "$config_file" ]; then
                echo "[ERROR] Config file is required"
                echo ""
                continue
            fi
            
            echo ""
            echo "[INFO] Validating configuration..."
            python main.py validate --config-file "$config_file"
            echo ""
            read -p "Press Enter to continue..."
            ;;
        6)
            echo ""
            echo "[INFO] Deactivating virtual environment..."
            deactivate
            echo ""
            echo "========================================"
            echo "Thank you for using the Migration Tool!"
            echo "========================================"
            echo ""
            exit 0
            ;;
        *)
            echo "[ERROR] Invalid choice. Please try again."
            echo ""
            ;;
    esac
done
