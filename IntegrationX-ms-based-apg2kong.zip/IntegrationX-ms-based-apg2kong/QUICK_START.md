# Quick Start Guide

## 🚀 Get Started in 5 Minutes

This guide will get you up and running with the Apigee to Kong migration solution quickly.

## Prerequisites

- Docker and Docker Compose installed
- Python 3.11+ (for migration tool)
- Apigee proxy exports (ZIP files)

## Step 1: Analyze Your Apigee Proxies (2 minutes)

```bash
# Clone or navigate to the project
cd apg2kong

# Install Python dependencies
pip install -r requirements.txt

# Place your Apigee proxy exports in the input directory
cp /path/to/your/users-api_rev1.zip input/

# Run the migration analysis tool
python main.py

# Open the generated report
open APIGEE_KONG_MAPPING_REPORT.html
```

**What you'll see:**
- ✅ Policies that map directly to Kong
- ⚠️ Policies that need the microservice
- 📊 Migration complexity score
- 📋 Recommended approach

## Step 2: Extract and Organize Resources (1 minute)

```bash
# Extract your Apigee proxy
unzip input/users-api_rev1.zip -d temp/

# Create API-scoped resource directory
mkdir -p microservice/resources/users-api/{scripts,lib,transforms,wsdl}

# Copy JavaScript files
cp temp/apiproxy/resources/jsc/*.js \
   microservice/resources/users-api/scripts/

# Copy JAR files (if any)
cp temp/apiproxy/resources/java/*.jar \
   microservice/resources/users-api/lib/ 2>/dev/null || true

# Copy XSLT files (if any)
cp temp/apiproxy/resources/xsl/*.xsl \
   microservice/resources/users-api/transforms/ 2>/dev/null || true

# Verify structure
tree microservice/resources/
```

**Result:**
```
microservice/resources/
└── users-api/
    ├── scripts/
    │   ├── validate-user.js
    │   └── enrich-user.js
    ├── lib/
    │   └── user-validator.jar
    └── transforms/
        └── user-transform.xsl
```

## Step 3: Deploy the Microservice (1 minute)

```bash
# Navigate to microservice directory
cd microservice

# Copy environment configuration
cp .env.example .env

# (Optional) Edit configuration
# nano .env

# Start all services with Docker Compose
docker-compose up -d

# Wait for services to start (about 30 seconds)
sleep 30

# Verify microservice is running
curl http://localhost:8080/health
```

**Expected response:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "handlers_loaded": 20,
  "available_policies": [
    "javascript",
    "java_callout",
    "service_callout",
    "kvm_operations",
    "..."
  ]
}
```

## Step 4: Test a Policy (1 minute)

```bash
# Test JavaScript policy execution
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "api_name": "users-api",
    "policy_name": "ValidateUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/validate-user.js"
    },
    "flow_variables": {
      "request.content": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}"
    }
  }'
```

**Expected response:**
```json
{
  "success": true,
  "message": "Script executed successfully",
  "variables": {
    "validation_passed": true,
    "user_email": "john@example.com",
    "user_name": "John Doe"
  },
  "execution_time_ms": 23.5
}
```

## Step 5: Configure Kong (Optional - if you have Kong)

```bash
# Create Kong service
curl -X POST http://localhost:8001/services \
  --data "name=users-api" \
  --data "url=http://backend:8080/users"

# Create route
curl -X POST http://localhost:8001/services/users-api/routes \
  --data "paths[]=/api/users"

# Add Apigee policy plugin
curl -X POST http://localhost:8001/services/users-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "microservice_url": "http://apigee-policy-service:8080",
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ValidateUser",
            "script_file": "scripts/validate-user.js"
          }
        }
      ]
    }
  }'

# Test through Kong
curl -X POST http://localhost:8000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "John Doe", "email": "john@example.com"}'
```

## 🎯 What's Next?

### **For Development**
1. Review the generated migration report
2. Test all your policies
3. Add more APIs to the resources directory
4. Customize policy configurations

### **For Production**
1. Read `COMPLETE_MIGRATION_GUIDE.md`
2. Review `DEPLOYMENT.md` for production setup
3. Set up monitoring and logging
4. Configure security settings
5. Perform load testing

## 📚 Key Documentation

| Document | Purpose |
|----------|---------|
| `COMPLETE_MIGRATION_GUIDE.md` | End-to-end migration process |
| `FINAL_IMPLEMENTATION_SUMMARY.md` | Complete solution overview |
| `microservice/README.md` | Microservice documentation |
| `microservice/API_EXAMPLES.md` | API usage examples |
| `microservice/APIGEE_VARIABLES_GUIDE.md` | Variable handling |
| `microservice/API_SCOPED_RESOURCES.md` | Resource organization |
| `microservice/DEPLOYMENT.md` | Production deployment |

## 🔧 Common Commands

### **Microservice Management**
```bash
# Start services
docker-compose up -d

# Stop services
docker-compose down

# View logs
docker-compose logs -f apigee-policy-service

# Restart microservice
docker-compose restart apigee-policy-service

# Check health
curl http://localhost:8080/health

# View metrics
curl http://localhost:8080/metrics
```

### **Resource Management**
```bash
# List API resources
ls -la microservice/resources/users-api/scripts/

# Add new script
cp new-script.js microservice/resources/users-api/scripts/

# Restart to reload (if needed)
docker-compose restart apigee-policy-service
```

### **Testing**
```bash
# Run tests
cd microservice
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Validate structure
python validate_structure.py
```

## 🐛 Troubleshooting

### **Microservice won't start**
```bash
# Check logs
docker-compose logs apigee-policy-service

# Verify Python dependencies
docker-compose exec apigee-policy-service pip list

# Check configuration
docker-compose exec apigee-policy-service cat .env
```

### **Policy execution fails**
```bash
# Check if resource file exists
docker-compose exec apigee-policy-service ls -la /app/resources/users-api/scripts/

# Check microservice logs
docker-compose logs -f apigee-policy-service

# Test policy directly
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{"api_name": "users-api", "policy_config": {"script_file": "scripts/validate-user.js"}, ...}'
```

### **Redis connection issues**
```bash
# Check Redis is running
docker-compose ps redis

# Test Redis connection
docker-compose exec redis redis-cli ping

# Check Redis logs
docker-compose logs redis
```

## 💡 Tips

1. **Start Small**: Migrate one API at a time
2. **Test Thoroughly**: Test each policy individually before chaining
3. **Use API Scoping**: Organize resources by API name for clarity
4. **Monitor Performance**: Check metrics regularly
5. **Read Documentation**: Comprehensive docs available for all features

## 🎉 Success!

You now have:
- ✅ Microservice running and healthy
- ✅ Resources organized by API
- ✅ Policies executing correctly
- ✅ Ready for Kong integration

**Next**: Read `COMPLETE_MIGRATION_GUIDE.md` for the full migration process!

## 📞 Need Help?

1. Check the troubleshooting section above
2. Review the comprehensive documentation
3. Check microservice logs for errors
4. Verify resource file paths and permissions

**Happy migrating!** 🚀