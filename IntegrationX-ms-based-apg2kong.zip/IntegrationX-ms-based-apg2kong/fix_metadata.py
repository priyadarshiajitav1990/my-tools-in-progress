import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix metadata references
content = content.replace("self.kong_config['_apigee_metadata']", "self.apigee_metadata")

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed metadata references")
