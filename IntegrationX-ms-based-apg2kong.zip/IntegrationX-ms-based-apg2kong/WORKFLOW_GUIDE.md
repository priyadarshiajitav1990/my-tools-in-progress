# Complete Workflow Guide: Input to Output

## 🎯 Overview

This guide walks you through the complete workflow from Apigee proxy input to Kong configuration output using the migration tool.

## 📋 Prerequisites

- Python 3.8 or higher installed
- Apigee proxy bundle(s) exported as ZIP files
- Windows, Linux, or macOS operating system

## 🚀 Quick Start (Automated)

### Windows

```bash
# Double-click or run:
setup_and_run.bat
```

### Linux/Mac

```bash
# Make executable and run:
chmod +x setup_and_run.sh
./setup_and_run.sh
```

The automated script will:
1. ✅ Create virtual environment (if not exists)
2. ✅ Activate virtual environment
3. ✅ Install dependencies
4. ✅ Present interactive menu
5. ✅ Run selected migration operation

## 📁 Directory Structure

```
apg2kong/
├── input/                          # Place your Apigee proxy ZIP files here
│   └── your-api_rev1.zip          # Example: migration-test-api_rev1.zip
├── output/                         # Kong configurations will be generated here
│   └── your-api_kong_config.json  # Generated Kong configuration
├── backup/                         # Automatic backups of existing files
│   └── your-api_backup_*.json     # Timestamped backups
├── logs/                           # Migration logs
│   └── migration.log              # Detailed execution logs
├── venv/                           # Virtual environment (auto-created)
├── main.py                         # Migration tool entry point
├── setup_and_run.bat              # Windows automated setup
├── setup_and_run.sh               # Linux/Mac automated setup
└── requirements.txt                # Python dependencies
```

## 🔄 Complete Workflow

### Step 1: Prepare Input Files

1. **Export Apigee Proxy**
   ```bash
   # Using apigeetool
   apigeetool getapi -u $APIGEE_USER -p $APIGEE_PASS \
     -o $APIGEE_ORG -n your-api -r 1 -f your-api_rev1.zip
   ```

2. **Place in Input Directory**
   ```bash
   # Copy to input directory
   cp your-api_rev1.zip input/
   ```

### Step 2: Run Automated Setup

**Option A: Interactive Menu (Recommended)**

```bash
# Windows
setup_and_run.bat

# Linux/Mac
./setup_and_run.sh
```

**Option B: Manual Setup**

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run migration
python main.py migrate --input input/your-api_rev1.zip
```

### Step 3: Review Output

1. **Kong Configuration**
   - Location: `output/your-api_kong_config.json`
   - Format: Kong declarative configuration (JSON)
   - Contains: Services, routes, plugins

2. **Migration Log**
   - Location: `logs/migration.log`
   - Contains: Detailed execution information
   - Includes: Warnings, errors, conversion details

3. **Backup Files**
   - Location: `backup/`
   - Created: Automatically if output file exists
   - Format: Timestamped backups

### Step 4: Validate Output

```bash
# Validate the generated Kong configuration
python main.py validate --config-file output/your-api_kong_config.json
```

## 📊 Migration Operations

### 1. Single Proxy Migration

**Purpose**: Migrate one Apigee proxy to Kong configuration

**Command**:
```bash
python main.py migrate --input input/your-api_rev1.zip
```

**Output**:
- `output/your-api_kong_config.json` - Kong configuration
- `logs/migration.log` - Detailed log
- `backup/your-api_backup_*.json` - Backup (if file existed)

**What It Does**:
1. Parses Apigee proxy bundle (ZIP)
2. Extracts policies, flows, endpoints
3. Converts to Kong services, routes, plugins
4. Validates output configuration
5. Creates backup if file exists
6. Writes Kong configuration JSON

### 2. Batch Migration

**Purpose**: Migrate all proxies in input directory

**Command**:
```bash
python main.py batch --input-dir input
```

**Output**:
- Multiple Kong configuration files in `output/`
- Consolidated log in `logs/migration.log`
- Summary report with success/failure counts

**What It Does**:
1. Scans input directory for ZIP files
2. Migrates each proxy sequentially
3. Generates individual Kong configurations
4. Provides summary statistics

### 3. Migration Plan

**Purpose**: Analyze proxy without performing migration

**Command**:
```bash
python main.py plan --input input/your-api_rev1.zip
```

**Output**:
- `output/your-api_migration_plan.json` - Migration plan
- Analysis of policies and complexity
- Manual tasks required
- Estimated effort

**What It Includes**:
- Proxy information
- Policy conversion plan
- Complexity assessment
- Manual tasks required
- Kong configuration preview

### 4. Validation

**Purpose**: Validate existing Kong configuration

**Command**:
```bash
python main.py validate --config-file output/your-api_kong_config.json
```

**Output**:
- Validation results (pass/fail)
- List of errors (if any)
- Warnings and recommendations

### 5. Tool Information

**Purpose**: Display tool and system information

**Command**:
```bash
python main.py info
```

**Output**:
- Tool version
- System information
- Configuration paths
- Migration statistics

## 🎨 Interactive Menu Options

When you run `setup_and_run.bat` or `setup_and_run.sh`, you'll see:

```
========================================
Migration Tool Menu
========================================
1. Migrate single proxy
2. Batch migrate all proxies
3. Show tool info
4. Generate migration plan
5. Validate Kong config
6. Exit
========================================
```

### Option 1: Migrate Single Proxy
- Prompts for input file path
- Uses default from input/ if none specified
- Performs complete migration
- Shows results and output location

### Option 2: Batch Migrate
- Automatically finds all ZIP files in input/
- Migrates each one
- Shows summary statistics

### Option 3: Show Tool Info
- Displays tool version
- Shows system information
- Lists configuration paths

### Option 4: Generate Migration Plan
- Prompts for input file
- Analyzes without migrating
- Creates detailed plan

### Option 5: Validate Kong Config
- Prompts for config file path
- Validates schema and structure
- Reports errors and warnings

### Option 6: Exit
- Deactivates virtual environment
- Exits cleanly

## 📝 Example Workflow

### Complete Example: Migrating "users-api"

```bash
# 1. Export from Apigee
apigeetool getapi -u admin@example.com -p password \
  -o my-org -n users-api -r 1 -f users-api_rev1.zip

# 2. Place in input directory
cp users-api_rev1.zip input/

# 3. Run automated setup (Windows)
setup_and_run.bat

# 4. Select option 1 (Migrate single proxy)
# Press Enter to use default file

# 5. Review output
# - output/users-api_kong_config.json
# - logs/migration.log

# 6. Validate output
# Select option 5 (Validate Kong config)
# Enter: output/users-api_kong_config.json

# 7. Deploy to Kong
deck sync -s output/users-api_kong_config.json
```

## 🔍 Understanding the Output

### Kong Configuration Structure

```json
{
  "_format_version": "3.0",
  "_transform": true,
  "services": [
    {
      "name": "users-api",
      "protocol": "https",
      "host": "api.example.com",
      "port": 443,
      "path": "/v1/users"
    }
  ],
  "routes": [
    {
      "name": "users-api-route",
      "service": {"name": "users-api"},
      "paths": ["/api/users"],
      "methods": ["GET", "POST", "PUT", "DELETE"]
    }
  ],
  "plugins": [
    {
      "name": "rate-limiting",
      "service": {"name": "users-api"},
      "config": {
        "minute": 100,
        "policy": "local"
      }
    }
  ]
}
```

### Key Sections

1. **Services**: Backend API endpoints
2. **Routes**: URL paths and methods
3. **Plugins**: Policies converted to Kong plugins

## 🛠️ Troubleshooting

### Issue: Virtual environment creation fails

**Solution**:
```bash
# Ensure Python is in PATH
python --version

# Install venv module (if missing)
# Ubuntu/Debian:
sudo apt-get install python3-venv

# Windows: Reinstall Python with "pip" option checked
```

### Issue: No ZIP files found

**Solution**:
```bash
# Check input directory
ls input/

# Ensure files have .zip extension
# Ensure files are valid Apigee proxy bundles
```

### Issue: Migration fails with errors

**Solution**:
```bash
# Check logs for details
cat logs/migration.log

# Run with verbose logging
python main.py migrate --input input/your-api.zip --verbose

# Validate input file
unzip -t input/your-api.zip
```

### Issue: Dependencies installation fails

**Solution**:
```bash
# Upgrade pip
python -m pip install --upgrade pip

# Install dependencies manually
pip install -r requirements.txt --verbose

# Check for proxy/firewall issues
pip install -r requirements.txt --proxy http://proxy:port
```

## 📊 Migration Statistics

After migration, check:

1. **Console Output**:
   - Success/failure status
   - Migration time
   - Output file location
   - Warning count

2. **Log File** (`logs/migration.log`):
   - Detailed parsing information
   - Policy conversion details
   - Warnings and errors
   - Validation results

3. **Output File**:
   - Number of services created
   - Number of routes created
   - Number of plugins configured

## 🎯 Best Practices

### Before Migration

1. ✅ Export all Apigee proxies
2. ✅ Review proxy configurations
3. ✅ Identify custom policies
4. ✅ Plan resource organization
5. ✅ Set up test environment

### During Migration

1. ✅ Start with simple proxies
2. ✅ Review migration plans first
3. ✅ Check logs for warnings
4. ✅ Validate each output
5. ✅ Keep backups

### After Migration

1. ✅ Test Kong configurations
2. ✅ Verify policy behavior
3. ✅ Check performance
4. ✅ Update documentation
5. ✅ Train team members

## 🚀 Next Steps

After successful migration:

1. **Deploy Microservice** (for unsupported policies)
   ```bash
   cd microservice
   docker-compose up -d
   ```

2. **Configure Kong**
   ```bash
   deck sync -s output/your-api_kong_config.json
   ```

3. **Test APIs**
   ```bash
   curl http://kong:8000/api/users
   ```

4. **Monitor**
   - Check Kong logs
   - Monitor microservice health
   - Review metrics

## 📚 Additional Resources

- `README.md` - Main project documentation
- `QUICK_START.md` - 5-minute setup guide
- `COMPLETE_MIGRATION_GUIDE.md` - Detailed migration process
- `TOOL_READINESS_REPORT.md` - Tool status and testing
- `microservice/README.md` - Microservice documentation

## 💡 Tips

1. **Use batch migration** for multiple proxies
2. **Generate plans first** to assess complexity
3. **Check logs** for detailed information
4. **Validate output** before deploying
5. **Keep backups** of original configurations
6. **Test incrementally** - one API at a time

---

**Ready to migrate?** Run `setup_and_run.bat` (Windows) or `./setup_and_run.sh` (Linux/Mac) to get started!
