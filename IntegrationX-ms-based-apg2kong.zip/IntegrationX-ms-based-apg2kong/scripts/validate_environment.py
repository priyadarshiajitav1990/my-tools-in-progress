#!/usr/bin/env python3
"""
Environment Validation Script
============================

Validates the environment setup and configuration for the migration tool.
"""

import os
import sys
import json
import platform
from pathlib import Path
from typing import Dict, List, Any


def validate_python_environment() -> Dict[str, Any]:
    """Validate Python environment."""
    result = {
        'status': 'pass',
        'issues': [],
        'info': {}
    }
    
    # Check Python version
    version = sys.version_info
    result['info']['python_version'] = f"{version.major}.{version.minor}.{version.micro}"
    
    if version < (3, 7):
        result['status'] = 'fail'
        result['issues'].append(f"Python 3.7+ required, found {version.major}.{version.minor}")
    
    # Check required modules
    required_modules = [
        'json', 'xml.etree.ElementTree', 'zipfile', 'pathlib',
        'logging', 'argparse', 'urllib.parse', 're'
    ]
    
    missing_modules = []
    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            missing_modules.append(module)
    
    if missing_modules:
        result['status'] = 'fail'
        result['issues'].extend([f"Missing module: {mod}" for mod in missing_modules])
    
    # Check optional modules
    optional_modules = ['colorama', 'jsonschema']
    available_optional = []
    
    for module in optional_modules:
        try:
            __import__(module)
            available_optional.append(module)
        except ImportError:
            pass
    
    result['info']['optional_modules'] = available_optional
    
    return result


def validate_file_system() -> Dict[str, Any]:
    """Validate file system setup."""
    result = {
        'status': 'pass',
        'issues': [],
        'info': {}
    }
    
    base_path = Path(__file__).parent.parent
    
    # Check required directories
    required_dirs = ['input', 'output', 'backup', 'logs', 'config', 'src']
    
    for dir_name in required_dirs:
        dir_path = base_path / dir_name
        if not dir_path.exists():
            result['issues'].append(f"Missing directory: {dir_name}")
            result['status'] = 'warn'
        elif not os.access(dir_path, os.R_OK | os.W_OK):
            result['issues'].append(f"No read/write access to: {dir_name}")
            result['status'] = 'fail'
    
    # Check required files
    required_files = [
        'main.py',
        'requirements.txt',
        'config/config.env',
        'src/migration_tool.py'
    ]
    
    for file_name in required_files:
        file_path = base_path / file_name
        if not file_path.exists():
            result['issues'].append(f"Missing file: {file_name}")
            result['status'] = 'fail'
        elif not os.access(file_path, os.R_OK):
            result['issues'].append(f"No read access to: {file_name}")
            result['status'] = 'fail'
    
    # Check disk space
    try:
        stat = os.statvfs(base_path)
        free_space = stat.f_bavail * stat.f_frsize
        result['info']['free_space_mb'] = free_space // (1024 * 1024)
        
        if free_space < 100 * 1024 * 1024:  # 100MB
            result['issues'].append("Low disk space (< 100MB)")
            result['status'] = 'warn'
            
    except (AttributeError, OSError):
        # Windows doesn't have statvfs
        result['info']['free_space_mb'] = 'unknown'
    
    return result


def validate_configuration() -> Dict[str, Any]:
    """Validate configuration files."""
    result = {
        'status': 'pass',
        'issues': [],
        'info': {}
    }
    
    base_path = Path(__file__).parent.parent
    config_file = base_path / 'config' / 'config.env'
    
    if not config_file.exists():
        result['status'] = 'fail'
        result['issues'].append("Configuration file not found")
        return result
    
    try:
        # Read configuration
        config = {}
        with open(config_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    config[key.strip()] = value.strip()
        
        # Check required configuration keys
        required_keys = [
            'LOG_LEVEL', 'INPUT_DIR', 'OUTPUT_DIR', 'BACKUP_DIR'
        ]
        
        for key in required_keys:
            if key not in config:
                result['issues'].append(f"Missing configuration: {key}")
                result['status'] = 'warn'
        
        # Validate log level
        if 'LOG_LEVEL' in config:
            valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
            if config['LOG_LEVEL'] not in valid_levels:
                result['issues'].append(f"Invalid log level: {config['LOG_LEVEL']}")
                result['status'] = 'warn'
        
        result['info']['config_keys'] = len(config)
        
    except Exception as e:
        result['status'] = 'fail'
        result['issues'].append(f"Failed to read configuration: {str(e)}")
    
    return result


def validate_dependencies() -> Dict[str, Any]:
    """Validate installed dependencies."""
    result = {
        'status': 'pass',
        'issues': [],
        'info': {}
    }
    
    base_path = Path(__file__).parent.parent
    requirements_file = base_path / 'requirements.txt'
    
    if not requirements_file.exists():
        result['status'] = 'fail'
        result['issues'].append("requirements.txt not found")
        return result
    
    try:
        # Read requirements
        with open(requirements_file, 'r') as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        
        # Check each requirement
        installed = []
        missing = []
        
        for req in requirements:
            # Extract package name (before >= or ==)
            package_name = req.split('>=')[0].split('==')[0].strip()
            
            try:
                __import__(package_name.replace('-', '_'))
                installed.append(package_name)
            except ImportError:
                missing.append(package_name)
        
        if missing:
            result['status'] = 'fail'
            result['issues'].extend([f"Missing dependency: {pkg}" for pkg in missing])
        
        result['info']['installed'] = installed
        result['info']['missing'] = missing
        
    except Exception as e:
        result['status'] = 'fail'
        result['issues'].append(f"Failed to check dependencies: {str(e)}")
    
    return result


def validate_tool_functionality() -> Dict[str, Any]:
    """Validate basic tool functionality."""
    result = {
        'status': 'pass',
        'issues': [],
        'info': {}
    }
    
    try:
        # Add src to path
        base_path = Path(__file__).parent.parent
        sys.path.insert(0, str(base_path / 'src'))
        
        # Try to import main components
        from src.core.config_manager import ConfigManager
        from src.core.logger import LoggerManager
        from src.migration_tool import ApigeeMigrationTool
        
        # Test basic initialization
        config_manager = ConfigManager()
        logger_manager = LoggerManager(config_manager)
        
        result['info']['components_loaded'] = True
        
    except ImportError as e:
        result['status'] = 'fail'
        result['issues'].append(f"Failed to import components: {str(e)}")
    except Exception as e:
        result['status'] = 'fail'
        result['issues'].append(f"Failed to initialize components: {str(e)}")
    
    return result


def generate_report(results: Dict[str, Dict[str, Any]]) -> None:
    """Generate validation report."""
    print("🔍 Environment Validation Report")
    print("=" * 50)
    
    overall_status = 'pass'
    total_issues = 0
    
    for category, result in results.items():
        status_icon = {
            'pass': '✅',
            'warn': '⚠️',
            'fail': '❌'
        }.get(result['status'], '❓')
        
        print(f"\n{status_icon} {category.replace('_', ' ').title()}")
        
        if result['issues']:
            for issue in result['issues']:
                print(f"   • {issue}")
            total_issues += len(result['issues'])
        
        if result['info']:
            for key, value in result['info'].items():
                if isinstance(value, list):
                    if value:
                        print(f"   ℹ️  {key}: {', '.join(map(str, value))}")
                else:
                    print(f"   ℹ️  {key}: {value}")
        
        if result['status'] == 'fail':
            overall_status = 'fail'
        elif result['status'] == 'warn' and overall_status != 'fail':
            overall_status = 'warn'
    
    print("\n" + "=" * 50)
    
    if overall_status == 'pass':
        print("🎉 Environment validation passed!")
        print("The migration tool is ready to use.")
    elif overall_status == 'warn':
        print("⚠️  Environment validation completed with warnings.")
        print(f"Found {total_issues} issues that should be addressed.")
    else:
        print("❌ Environment validation failed!")
        print(f"Found {total_issues} critical issues that must be fixed.")
    
    print("\nSystem Information:")
    print(f"   OS: {platform.system()} {platform.release()}")
    print(f"   Python: {platform.python_version()}")
    print(f"   Architecture: {platform.machine()}")


def main():
    """Main validation function."""
    print("🔍 Validating environment for Apigee to Kong Migration Tool...")
    print()
    
    # Run all validations
    results = {
        'python_environment': validate_python_environment(),
        'file_system': validate_file_system(),
        'configuration': validate_configuration(),
        'dependencies': validate_dependencies(),
        'tool_functionality': validate_tool_functionality()
    }
    
    # Generate report
    generate_report(results)
    
    # Return appropriate exit code
    if any(r['status'] == 'fail' for r in results.values()):
        return 1
    elif any(r['status'] == 'warn' for r in results.values()):
        return 2
    else:
        return 0


if __name__ == "__main__":
    sys.exit(main())