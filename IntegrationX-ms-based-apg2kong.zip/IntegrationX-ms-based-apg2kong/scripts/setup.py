#!/usr/bin/env python3
"""
Setup Script for Apigee to Kong Migration Tool
==============================================

Handles initial setup, dependency installation, and environment preparation.
"""

import os
import sys
import subprocess
import platform
from pathlib import Path


def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True


def install_dependencies():
    """Install required dependencies."""
    print("📦 Installing dependencies...")
    
    requirements_file = Path(__file__).parent.parent / "requirements.txt"
    
    if not requirements_file.exists():
        print("❌ requirements.txt not found")
        return False
    
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", str(requirements_file)
        ])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False


def create_directories():
    """Create required directories."""
    print("📁 Creating directories...")
    
    base_path = Path(__file__).parent.parent
    directories = [
        base_path / "input",
        base_path / "output", 
        base_path / "backup",
        base_path / "logs"
    ]
    
    for directory in directories:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            print(f"✅ Created directory: {directory}")
        except Exception as e:
            print(f"❌ Failed to create directory {directory}: {e}")
            return False
    
    return True


def verify_installation():
    """Verify the installation by running the tool."""
    print("🔍 Verifying installation...")
    
    try:
        main_script = Path(__file__).parent.parent / "main.py"
        result = subprocess.run([
            sys.executable, str(main_script), "info"
        ], capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ Installation verification successful")
            return True
        else:
            print(f"❌ Installation verification failed: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("❌ Installation verification timed out")
        return False
    except Exception as e:
        print(f"❌ Installation verification failed: {e}")
        return False


def show_system_info():
    """Display system information."""
    print("🖥️  System Information:")
    print(f"   OS: {platform.system()} {platform.release()}")
    print(f"   Architecture: {platform.machine()}")
    print(f"   Python: {platform.python_version()}")
    print(f"   Platform: {platform.platform()}")


def main():
    """Main setup function."""
    print("🚀 Apigee to Kong Migration Tool Setup")
    print("=" * 50)
    
    # Show system information
    show_system_info()
    print()
    
    # Check Python version
    if not check_python_version():
        return 1
    
    # Install dependencies
    if not install_dependencies():
        return 1
    
    # Create directories
    if not create_directories():
        return 1
    
    # Verify installation
    if not verify_installation():
        return 1
    
    print()
    print("🎉 Setup completed successfully!")
    print()
    print("Next steps:")
    print("1. Place your Apigee proxy bundles in the 'input' directory")
    print("2. Run: python main.py batch")
    print("3. Check the 'output' directory for Kong configurations")
    print()
    print("For help: python main.py --help")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())