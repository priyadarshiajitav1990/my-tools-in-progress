import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Routes need service as object: {'name': service_name}
# But we need to be careful not to change plugin references

# Find and replace only in route creation sections
lines = content.split('\n')
new_lines = []
in_route_section = False

for line in lines:
    # Detect if we're in a route creation section
    if "'name': route_name," in line or "route = {" in line:
        in_route_section = True
    elif in_route_section and "'service': service_name," in line:
        # Change back to object format for routes
        line = line.replace("'service': service_name,", "'service': {'name': service_name},")
        in_route_section = False
    elif in_route_section and line.strip() == '}':
        in_route_section = False
    
    new_lines.append(line)

content = '\n'.join(new_lines)

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed format: routes use objects, plugins use strings")
