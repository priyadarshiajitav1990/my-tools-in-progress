# Apigee to Kong Migration Tool

A comprehensive, enterprise-grade tool for migrating Apigee proxy bundles to Kong Gateway configurations with **complete support for all Apigee flow elements** including RouteRules, FaultRules, Conditions, Conditional Flows, PreFlow, and PostFlow. Built with Python and designed for production readiness, cross-platform compatibility, and enterprise standards.

## ✨ Key Features

- **deck Integration**: ✅ Automated validation and deployment with Kong's deck CLI
- **Selective Deployment**: ✅ Deploy individual APIs without affecting others
- **Clean Output Naming**: ✅ Files named by API (e.g., `my-api.json`)
- **Complete Flow Support**: ✅ RouteRules, FaultRules, Conditions, Conditional Flows, PreFlow, PostFlow
- **Complete Migration**: Converts Apigee proxy bundles (ZIP) to Kong Gateway JSON configurations
- **Condition Evaluation**: Full support for Apigee condition syntax with all operators
- **Production-Ready Microservice**: 20+ policy handlers with API-scoped resource organization
- **Enterprise Ready**: Production-grade error handling, logging, and validation
- **Cross-Platform**: OS-independent design works on Windows, Linux, and macOS
- **Modular Architecture**: Clean OOP design with separate modules for each functionality
- **Comprehensive Validation**: Validates both input bundles and output configurations
- **Batch Processing**: Migrate multiple proxy bundles in one operation
- **Detailed Logging**: Configurable logging with file rotation and console output

## Architecture

```
src/
├── core/                   # Core functionality
│   ├── config_manager.py   # Configuration management
│   ├── logger.py          # Logging system
│   └── exceptions.py      # Custom exceptions
├── parsers/               # Input parsing
│   └── apigee_parser.py   # Apigee bundle parser
├── converters/            # Format conversion
│   └── kong_converter.py  # Kong configuration generator
├── utils/                 # Utilities
│   ├── file_manager.py    # File operations
│   └── validator.py       # Configuration validation
└── migration_tool.py      # Main orchestrator
```

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd apigee-kong-migration-tool
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify installation**:
   ```bash
   python main.py info
   ```

## Quick Start

### Basic Migration

```bash
# Migrate a single Apigee proxy bundle
python main.py migrate --input input/my-api.zip
# Output: output/my-api.json
```

### Migration with deck Validation

```bash
# Migrate and validate with deck
python main.py migrate --input input/my-api.zip --validate-deck
```

### Migration with Deployment

```bash
# Migrate, validate, and deploy to Kong Gateway
python main.py migrate --input input/my-api.zip --deploy
# Uses selective sync - other APIs remain untouched
```

### Batch Migration

```bash
# Migrate all proxy bundles in the input directory
python main.py batch --input-dir ./input
```

### Interactive Menu

```bash
# Run the interactive menu (Windows)
run_migration.bat

# Options include:
# 1. Migrate single proxy
# 2. Migrate with custom file
# 3. Migrate + Validate with deck
# 4. Migrate + Deploy to Kong Gateway
# 5. Batch migrate
```

## Configuration

The tool uses a configuration file at `config/config.env`. Key settings include:

```env
# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=logs/migration.log

# Input/Output Directories
INPUT_DIR=input
OUTPUT_DIR=output
BACKUP_DIR=backup

# Kong Gateway Configuration
KONG_ADMIN_URL=http://localhost:8001
KONG_WORKSPACE=

# Migration Settings
VALIDATE_OUTPUT=true
CREATE_BACKUP=true
OVERWRITE_EXISTING=false
```

### deck CLI (Optional)

For validation and deployment features, install Kong's deck CLI:

```bash
# macOS
brew install deck

# Linux
curl -sL https://github.com/Kong/deck/releases/download/v1.28.2/deck_1.28.2_linux_amd64.tar.gz -o deck.tar.gz
tar -xf deck.tar.gz
sudo mv deck /usr/local/bin/

# Verify
deck version
```

See [DECK_INTEGRATION_GUIDE.md](DECK_INTEGRATION_GUIDE.md) for complete deck setup and usage.

## Usage Examples

### Command Line Interface

```bash
# Show help
python main.py --help

# Migrate with custom configuration
python main.py migrate --input proxy.zip --config custom.env

# Batch migrate with verbose logging
python main.py batch --input-dir ./bundles --verbose

# Validate Kong configuration
python main.py validate --config-file output/my_service.json

# Show system information
python main.py info
```

### Programmatic Usage

```python
from src.migration_tool import ApigeeMigrationTool

# Initialize tool
with ApigeeMigrationTool() as tool:
    # Migrate single bundle
    result = tool.migrate_single_bundle('proxy.zip')
    
    if result['success']:
        print(f"Migration successful: {result['output_file']}")
    else:
        print(f"Migration failed: {result['errors']}")
    
    # Batch migrate
    results = tool.migrate_multiple_bundles('./input')
    
    # Get statistics
    stats = tool.get_migration_statistics()
    print(f"Success rate: {stats['success_rate']:.1f}%")
```

## Supported Apigee Features

### Policies Converted to Kong Plugins

| Apigee Policy | Kong Plugin | Notes |
|---------------|-------------|-------|
| Rate Limiting | rate-limiting | Supports per-minute/hour/day limits |
| CORS | cors | Full CORS configuration support |
| API Key | key-auth | Multiple key name support |
| Basic Auth | basic-auth | Direct conversion |
| JWT | jwt | Claims verification support |
| OAuth | oauth2 | Scope-based authorization |
| Request/Response Transformation | request-transformer | Basic transformations |
| Security Policies | bot-detection | Pattern-based security |

### Proxy Components

- **Proxy Endpoints**: Converted to Kong routes with path matching
- **Target Endpoints**: Converted to Kong services with upstream configuration
- **Flows**: Mapped to Kong plugin execution order
- **Resources**: Logged for manual review (JavaScript, Java, etc.)

## Output Format

The tool generates Kong Gateway configuration in declarative format:

```json
{
  "_format_version": "3.0",
  "_transform": true,
  "services": [
    {
      "name": "my-service",
      "protocol": "https",
      "host": "api.example.com",
      "port": 443,
      "path": "/v1"
    }
  ],
  "routes": [
    {
      "name": "my-service-route",
      "service": {"name": "my-service"},
      "paths": ["/api/v1"],
      "methods": ["GET", "POST"]
    }
  ],
  "plugins": [
    {
      "name": "rate-limiting",
      "service": {"name": "my-service"},
      "config": {
        "minute": 100,
        "policy": "local"
      }
    }
  ]
}
```

## Error Handling

The tool provides comprehensive error handling:

- **Input Validation**: Validates Apigee bundle structure and accessibility
- **Parsing Errors**: Detailed XML/JSON parsing error messages
- **Conversion Errors**: Specific policy conversion failure details
- **Output Validation**: Kong configuration schema validation
- **File Operations**: OS-independent file operation error handling

## Logging

Multi-level logging with file rotation:

```
2024-01-08 10:30:15 - apigee_kong_migration - INFO - Starting migration of bundle: proxy.zip
2024-01-08 10:30:16 - apigee_kong_migration - INFO - Parsing Apigee proxy bundle...
2024-01-08 10:30:17 - apigee_kong_migration - INFO - Converting to Kong configuration...
2024-01-08 10:30:18 - apigee_kong_migration - INFO - Validating Kong configuration...
2024-01-08 10:30:19 - apigee_kong_migration - INFO - Successfully migrated proxy.zip to output/my_service_kong_config.json
```

## Validation

The tool performs multiple validation steps:

1. **Input Validation**: Apigee bundle structure and file integrity
2. **Parsing Validation**: XML schema and content validation
3. **Conversion Validation**: Policy mapping completeness
4. **Output Validation**: Kong configuration schema compliance
5. **Cross-Reference Validation**: Entity relationship consistency

## Backup and Recovery

Automatic backup system:

- Creates timestamped backups before overwriting files
- Configurable backup retention
- OS-independent backup location management
- Backup verification and integrity checks

## Performance

Optimized for enterprise workloads:

- Streaming ZIP file processing for large bundles
- Configurable concurrent processing limits
- Memory-efficient XML parsing
- Chunked file operations for large outputs

## Troubleshooting

### Common Issues

1. **"No ZIP files found"**: Ensure input directory contains .zip files
2. **"Invalid ZIP file"**: Verify Apigee bundle is properly exported
3. **"Validation failed"**: Check Kong configuration requirements
4. **"Permission denied"**: Ensure write access to output directory

### Debug Mode

Enable verbose logging for detailed troubleshooting:

```bash
python main.py migrate --input proxy.zip --verbose
```

### Log Analysis

Check the log file for detailed error information:

```bash
# View recent logs
tail -f logs/migration.log

# Search for errors
grep ERROR logs/migration.log
```

## Contributing

1. Follow the existing code structure and naming conventions
2. Add comprehensive error handling and logging
3. Include unit tests for new functionality
4. Update documentation for new features
5. Ensure cross-platform compatibility

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues and questions:

1. Check the troubleshooting section
2. Review log files for detailed error information
3. Create an issue with reproduction steps and log output