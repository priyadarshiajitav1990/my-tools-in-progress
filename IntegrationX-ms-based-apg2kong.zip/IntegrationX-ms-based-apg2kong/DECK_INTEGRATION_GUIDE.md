# deck Integration Guide

## Overview

The migration tool now integrates with Kong's `deck` CLI for validation and deployment. This ensures:
- ✅ Configuration files are validated before deployment
- ✅ Selective deployment without affecting other APIs
- ✅ Safe, isolated updates to Kong Gateway

## What Changed

### 1. Output File Naming
**Before:** `migration-test-api_kong_config_1_2_3.json`  
**After:** `migration-test-api.json`

Output files now use the **Apigee API name** directly, making them easier to identify and manage.

### 2. API-Specific Tags
All Kong resources (services, routes, plugins) now include the tag:
```
apigee-api:<api-name>
```

This enables selective deployment using deck's `--select-tag` option.

### 3. deck Integration
Three levels of migration:
1. **Basic Migration** - Generate Kong config only
2. **Migration + Validation** - Generate + validate with deck
3. **Migration + Deployment** - Generate + validate + deploy to Kong

## Prerequisites

### Install deck CLI

**macOS (Homebrew):**
```bash
brew install deck
```

**Linux:**
```bash
curl -sL https://github.com/Kong/deck/releases/download/v1.28.2/deck_1.28.2_linux_amd64.tar.gz -o deck.tar.gz
tar -xf deck.tar.gz -C /tmp
sudo cp /tmp/deck /usr/local/bin/
```

**Windows:**
Download from: https://github.com/Kong/deck/releases

Verify installation:
```bash
deck version
```

### Configure Kong Admin URL

Edit `config/config.env`:
```env
KONG_ADMIN_URL=http://localhost:8001
KONG_WORKSPACE=
```

For Kong Enterprise with workspaces:
```env
KONG_ADMIN_URL=http://localhost:8001
KONG_WORKSPACE=my-workspace
```

## Usage

### Command Line

#### 1. Basic Migration (No deck)
```bash
python main.py migrate --input input/my-api.zip
```
**Output:** `output/my-api.json`

#### 2. Migration + deck Validation
```bash
python main.py migrate --input input/my-api.zip --validate-deck
```
**Runs:**
- Migration
- `deck file validate output/my-api.json`

#### 3. Migration + deck Deployment
```bash
python main.py migrate --input input/my-api.zip --deploy
```
**Runs:**
- Migration
- `deck file validate output/my-api.json`
- `deck gateway validate output/my-api.json`
- `deck gateway sync output/my-api.json --select-tag apigee-api:my-api`

### Interactive Menu

Run the batch script:
```bash
run_migration.bat
```

**New Menu Options:**
- **Option 3:** Migrate + Validate with deck
- **Option 4:** Migrate + Deploy to Kong Gateway

## How Selective Deployment Works

### The Problem
Traditional deck sync replaces ALL Kong configuration, which can:
- ❌ Delete other APIs
- ❌ Affect unrelated services
- ❌ Cause downtime

### The Solution
Using `--select-tag` for isolated deployment:

```bash
deck gateway sync my-api.json --select-tag apigee-api:my-api
```

**What happens:**
1. ✅ Only resources with tag `apigee-api:my-api` are synced
2. ✅ Other APIs remain untouched
3. ✅ Safe, isolated updates

### Example Scenario

**Kong Gateway has:**
- `users-api` (existing)
- `orders-api` (existing)
- `payments-api` (existing)

**You deploy:**
```bash
python main.py migrate --input products-api.zip --deploy
```

**Result:**
- ✅ `products-api` is deployed
- ✅ `users-api` unchanged
- ✅ `orders-api` unchanged
- ✅ `payments-api` unchanged

## deck Commands Explained

### 1. deck file validate
**Purpose:** Validate configuration file syntax and structure

```bash
deck file validate output/my-api.json
```

**Checks:**
- JSON syntax
- Kong schema compliance
- Required fields
- Data types

**Does NOT check:**
- Kong Gateway connectivity
- Existing resources
- Conflicts

### 2. deck gateway validate
**Purpose:** Validate against running Kong Gateway

```bash
deck gateway validate output/my-api.json --kong-addr http://localhost:8001
```

**Checks:**
- Everything from `file validate`
- Kong Gateway connectivity
- Plugin compatibility
- Resource conflicts
- Schema versions

### 3. deck gateway sync
**Purpose:** Deploy configuration to Kong Gateway

```bash
deck gateway sync output/my-api.json \
  --kong-addr http://localhost:8001 \
  --select-tag apigee-api:my-api \
  --skip-consumers
```

**Options:**
- `--kong-addr`: Kong Admin API URL
- `--select-tag`: Only sync resources with this tag
- `--skip-consumers`: Don't sync consumers (safer)
- `--workspace`: Kong Enterprise workspace
- `--dry-run`: Preview changes without applying

## Migration Result Output

### Success Example
```
✓ Migration successful!
  Output file: output/my-api.json
  Proxy name: my-api
  Migration time: 0.05 seconds
  ✓ deck validation: PASSED
  ✓ deck deployment: SUCCESS
  API 'my-api' deployed to Kong Gateway
  Other APIs in gateway were NOT affected (selective sync)
```

### Validation Failure Example
```
✓ Migration successful!
  Output file: output/my-api.json
  Proxy name: my-api
  Migration time: 0.05 seconds
  ✗ deck validation: FAILED
  Error: deck file validate failed: invalid plugin configuration
```

### Deployment Failure Example
```
✓ Migration successful!
  Output file: output/my-api.json
  Proxy name: my-api
  Migration time: 0.05 seconds
  ✓ deck validation: PASSED
  ✗ deck deployment: deployment_failed
  Error: deck gateway sync failed: connection refused
```

## Troubleshooting

### deck not found
**Error:** `deck CLI not found`

**Solution:**
```bash
# Install deck
brew install deck  # macOS
# or download from GitHub releases

# Verify
deck version
```

### Connection refused
**Error:** `connection refused`

**Solution:**
1. Check Kong Gateway is running:
   ```bash
   curl http://localhost:8001
   ```

2. Verify `KONG_ADMIN_URL` in `config/config.env`

3. Check firewall/network settings

### Validation failed
**Error:** `deck file validate failed`

**Solution:**
1. Check the generated JSON file
2. Review error messages
3. Check logs: `logs/migration.log`
4. Validate manually:
   ```bash
   deck file validate output/my-api.json
   ```

### Plugin not available
**Error:** `plugin 'xyz' not available`

**Solution:**
1. Install required Kong plugins
2. Check Kong Gateway version compatibility
3. Use `--skip-plugins` flag (not recommended)

## Best Practices

### 1. Always Validate Before Deploy
```bash
# Good
python main.py migrate --input api.zip --validate-deck
# Review output
python main.py migrate --input api.zip --deploy

# Better (single command with validation)
python main.py migrate --input api.zip --deploy
```

### 2. Use Dry Run for Testing
```bash
# Generate config
python main.py migrate --input api.zip

# Test deployment (no changes)
deck gateway sync output/my-api.json \
  --select-tag apigee-api:my-api \
  --dry-run
```

### 3. Backup Before Deployment
```bash
# Backup current Kong state
deck gateway dump --output-file backup-$(date +%Y%m%d).json

# Deploy new API
python main.py migrate --input api.zip --deploy
```

### 4. Monitor Deployment
```bash
# Check service status
curl http://localhost:8001/services/my-api

# Check routes
curl http://localhost:8001/services/my-api/routes

# Test API
curl http://localhost:8000/my-api/health
```

## Advanced Usage

### Deploy to Multiple Environments

**Development:**
```bash
export KONG_ADMIN_URL=http://dev-kong:8001
python main.py migrate --input api.zip --deploy
```

**Staging:**
```bash
export KONG_ADMIN_URL=http://staging-kong:8001
python main.py migrate --input api.zip --deploy
```

**Production:**
```bash
export KONG_ADMIN_URL=http://prod-kong:8001
python main.py migrate --input api.zip --deploy
```

### Workspace Deployment (Kong Enterprise)

```bash
# Set workspace in config
echo "KONG_WORKSPACE=team-a" >> config/config.env

# Deploy
python main.py migrate --input api.zip --deploy
```

### Batch Deployment

```bash
# Migrate all APIs
for zip in input/*.zip; do
  python main.py migrate --input "$zip" --deploy
done
```

### Rollback

```bash
# Restore previous state
deck gateway sync backup-20260108.json --kong-addr http://localhost:8001
```

## Configuration Reference

### config/config.env

**For Kong Konnect (Cloud):**
```env
# Kong Konnect Configuration
KONNECT_ADMIN_API=https://in.api.konghq.com/v2/control-planes/YOUR_CONTROL_PLANE_ID
KONNECT_TOKEN=kpat_YOUR_TOKEN_HERE
KONNECT_CONTROL_PLANE_ID=YOUR_CONTROL_PLANE_ID

# Migration Settings
VALIDATE_OUTPUT=true
CREATE_BACKUP=true
```

**For Self-Hosted Kong Gateway:**
```env
# Kong Gateway Configuration
KONG_ADMIN_URL=http://localhost:8001
KONG_WORKSPACE=

# Migration Settings
VALIDATE_OUTPUT=true
CREATE_BACKUP=true
```

### Getting Konnect Credentials

1. **Login to Kong Konnect:** https://cloud.konghq.com/
2. **Create Personal Access Token:**
   - Go to Settings → Personal Access Tokens
   - Click "Generate Token"
   - Copy the token (starts with `kpat_`)
3. **Get Control Plane ID:**
   - Go to Gateway Manager
   - Select your Control Plane
   - Copy the ID from the URL or settings page

### Environment Variables
Override config file settings:

**For Konnect:**
```bash
export KONNECT_TOKEN=kpat_YOUR_TOKEN_HERE
export KONNECT_ADMIN_API=https://in.api.konghq.com/v2/control-planes/YOUR_CP_ID
python main.py migrate --input api.zip --deploy
```

**For Self-Hosted Kong:**
```bash
export KONG_ADMIN_URL=http://custom-kong:8001
export KONG_WORKSPACE=my-workspace
python main.py migrate --input api.zip --deploy
```

## Security Considerations

### 1. Kong Konnect Token Security
- **Never commit tokens to version control**
- Store tokens in environment variables or secure vaults
- Rotate tokens regularly
- Use least-privilege access
- Monitor token usage

### 2. Kong Admin API Access (Self-Hosted)
- Use HTTPS in production
- Implement authentication (Kong RBAC)
- Restrict network access
- Use API keys or tokens

### 2. Selective Sync Benefits
- Prevents accidental deletion
- Isolates API changes
- Reduces blast radius
- Enables safe CI/CD

### 3. Validation Steps
- Always validate before deploy
- Use dry-run for testing
- Review changes carefully
- Maintain backups

## CI/CD Integration

### GitHub Actions Example
```yaml
name: Deploy to Kong

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Install deck
        run: |
          curl -sL https://github.com/Kong/deck/releases/download/v1.28.2/deck_1.28.2_linux_amd64.tar.gz -o deck.tar.gz
          tar -xf deck.tar.gz
          sudo mv deck /usr/local/bin/
      
      - name: Migrate and Deploy
        env:
          KONG_ADMIN_URL: ${{ secrets.KONG_ADMIN_URL }}
        run: |
          python main.py migrate --input input/my-api.zip --deploy
```

### GitLab CI Example
```yaml
deploy:
  stage: deploy
  image: python:3.9
  before_script:
    - pip install -r requirements.txt
    - curl -sL https://github.com/Kong/deck/releases/download/v1.28.2/deck_1.28.2_linux_amd64.tar.gz -o deck.tar.gz
    - tar -xf deck.tar.gz && mv deck /usr/local/bin/
  script:
    - python main.py migrate --input input/my-api.zip --deploy
  only:
    - main
```

## Summary

The deck integration provides:
- ✅ **Automated validation** - Catch errors before deployment
- ✅ **Selective deployment** - Update only specific APIs
- ✅ **Safe operations** - Other APIs remain untouched
- ✅ **Production-ready** - Enterprise-grade deployment workflow
- ✅ **CI/CD friendly** - Easy automation

**Key Command:**
```bash
python main.py migrate --input my-api.zip --deploy
```

This single command:
1. Migrates Apigee proxy to Kong config
2. Validates with deck
3. Deploys to Kong Gateway
4. Uses selective sync for safety

**Output file:** `output/my-api.json` (clean, API-name based)
