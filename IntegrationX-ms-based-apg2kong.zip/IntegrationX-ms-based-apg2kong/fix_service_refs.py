import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix service references in plugins (already done)
content = re.sub(r"'service':\s*\{'name':\s*service_name\}", "'service': service_name", content)

# Fix service references in routes
content = re.sub(r"'service':\s*\{'name':\s*service_name\}", "'service': service_name", content)

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed all service references")
