import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# In conditional flows, replace policy.get('name', 'unknown') with flow.get('name', 'unknown')
content = re.sub(
    r"(_convert_conditional_flows.*?)'id': self\._generate_plugin_id\('pre-function', service_name, policy\.get\('name', 'unknown'\)\)",
    r"\1'id': self._generate_plugin_id('pre-function', service_name, flow.get('name', 'unknown'))",
    content,
    flags=re.DOTALL
)

# In fault rules, replace policy.get('name', 'unknown') with rule.get('name', 'unknown')
content = re.sub(
    r"(_convert_fault_rules.*?)'id': self\._generate_plugin_id\('pre-function', service_name, policy\.get\('name', 'unknown'\)\)",
    r"\1'id': self._generate_plugin_id('pre-function', service_name, rule.get('name', 'unknown'))",
    content,
    flags=re.DOTALL
)

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed policy undefined errors")
