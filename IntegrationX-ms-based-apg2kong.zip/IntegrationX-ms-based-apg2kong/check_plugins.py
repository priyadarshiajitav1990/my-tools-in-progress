import json

with open('output/migration-test-api_1_2_3.json', 'r') as f:
    data = json.load(f)

plugins = data.get('plugins', [])
print(f"Total plugins: {len(plugins)}")

# Group by plugin name
from collections import defaultdict
by_name = defaultdict(list)
for p in plugins:
    by_name[p['name']].append(p)

for name, instances in by_name.items():
    print(f"\n{name}: {len(instances)} instances")
    for i, p in enumerate(instances[:3]):
        tags = p.get('tags', [])
        source_tag = [t for t in tags if 'source-policy' in t]
        print(f"  {i+1}. {source_tag}")
