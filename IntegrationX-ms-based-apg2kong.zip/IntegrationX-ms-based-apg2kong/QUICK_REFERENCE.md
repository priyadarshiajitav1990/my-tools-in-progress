# Quick Reference Card

## Common Commands

### Migration

```bash
# Basic migration
python main.py migrate --input input/my-api.zip

# With validation
python main.py migrate --input input/my-api.zip --validate-deck

# With deployment
python main.py migrate --input input/my-api.zip --deploy

# Batch migration
python main.py batch --input-dir input/
```

### Output Files

```
input/my-api.zip  →  output/my-api.json
```

### deck Commands

```bash
# Validate file
deck file validate output/my-api.json

# Validate against Kong
deck gateway validate output/my-api.json --kong-addr http://localhost:8001

# Deploy (selective sync)
deck gateway sync output/my-api.json \
  --kong-addr http://localhost:8001 \
  --select-tag apigee-api:my-api

# Dry run
deck gateway sync output/my-api.json \
  --kong-addr http://localhost:8001 \
  --select-tag apigee-api:my-api \
  --dry-run
```

## Configuration

### config/config.env
```env
KONG_ADMIN_URL=http://localhost:8001
KONG_WORKSPACE=
VALIDATE_OUTPUT=true
CREATE_BACKUP=true
```

### Environment Variables
```bash
export KONG_ADMIN_URL=http://custom-kong:8001
export KONG_WORKSPACE=my-workspace
```

## File Structure

```
apg2kong/
├── input/              # Place Apigee ZIP files here
├── output/             # Kong configs generated here
│   └── my-api.json    # Clean naming: {api-name}.json
├── backup/             # Automatic backups
├── logs/               # Migration logs
│   └── migration.log
└── config/
    └── config.env     # Configuration file
```

## Interactive Menu

```bash
run_migration.bat      # Windows
./setup_and_run.sh     # Linux/Mac
```

**Menu Options:**
1. Migrate single proxy (default file)
2. Migrate single proxy (specify file)
3. Migrate + Validate with deck
4. Migrate + Deploy to Kong Gateway
5. Batch migrate all proxies
6. Show tool info
7. Generate migration plan
8. Validate Kong config
9. Exit

## Selective Deployment

**Key Feature:** Deploy one API without affecting others

```bash
# Deploy api-1 (api-2 and api-3 remain untouched)
python main.py migrate --input input/api-1.zip --deploy

# Deploy api-2 (api-1 and api-3 remain untouched)
python main.py migrate --input input/api-2.zip --deploy
```

**How it works:**
- All resources tagged with `apigee-api:{api-name}`
- deck uses `--select-tag` for selective sync
- Only matching resources are updated

## Troubleshooting

### deck not found
```bash
# Install deck
brew install deck  # macOS
# or download from GitHub releases

# Verify
deck version
```

### Connection refused
```bash
# Check Kong is running
curl http://localhost:8001

# Update config
echo "KONG_ADMIN_URL=http://your-kong:8001" >> config/config.env
```

### Validation failed
```bash
# Check logs
cat logs/migration.log

# Validate manually
deck file validate output/my-api.json
```

## Success Indicators

### Migration Success
```
✓ Migration successful!
  Output file: output/my-api.json
  Proxy name: my-api
  Migration time: 0.05 seconds
```

### Validation Success
```
  ✓ deck validation: PASSED
```

### Deployment Success
```
  ✓ deck deployment: SUCCESS
  API 'my-api' deployed to Kong Gateway
  Other APIs in gateway were NOT affected (selective sync)
```

## Documentation

- **DECK_INTEGRATION_GUIDE.md** - Complete deck integration guide
- **ENHANCEMENT_DECK_INTEGRATION.md** - Enhancement summary
- **WORKFLOW_GUIDE.md** - Complete workflow documentation
- **QUICK_START.md** - 5-minute setup guide
- **README.md** - Main documentation

## Support

### Check Tool Status
```bash
python main.py info
```

### View Logs
```bash
cat logs/migration.log
```

### Generate Migration Plan
```bash
python main.py plan --input input/my-api.zip
```

## Best Practices

1. **Always validate before deploy**
   ```bash
   python main.py migrate --input api.zip --validate-deck
   # Review output
   python main.py migrate --input api.zip --deploy
   ```

2. **Use dry-run for testing**
   ```bash
   deck gateway sync output/my-api.json --dry-run
   ```

3. **Backup before deployment**
   ```bash
   deck gateway dump --output-file backup-$(date +%Y%m%d).json
   ```

4. **Monitor deployment**
   ```bash
   curl http://localhost:8001/services/my-api
   curl http://localhost:8000/my-api/health
   ```

## Quick Examples

### Example 1: First-time deployment
```bash
# Step 1: Migrate
python main.py migrate --input input/users-api.zip

# Step 2: Review
cat output/users-api.json

# Step 3: Deploy
python main.py migrate --input input/users-api.zip --deploy
```

### Example 2: Update existing API
```bash
# Update users-api without affecting orders-api
python main.py migrate --input input/users-api-v2.zip --deploy
```

### Example 3: Multiple environments
```bash
# Dev
export KONG_ADMIN_URL=http://dev-kong:8001
python main.py migrate --input input/my-api.zip --deploy

# Prod
export KONG_ADMIN_URL=http://prod-kong:8001
python main.py migrate --input input/my-api.zip --deploy
```

## Key Concepts

### Selective Sync
- Uses `--select-tag apigee-api:{api-name}`
- Only updates resources with matching tag
- Other APIs remain completely untouched
- Safe for production deployments

### Output Naming
- Format: `{api-name}.json`
- No version numbers
- Clean and predictable
- Easy to identify

### API Tags
Every resource includes:
- `apigee-migration` - General migration tag
- `apigee-api:{api-name}` - API-specific tag for selective sync
- `source:{api-name}` - Source API identifier

## Exit Codes

- `0` - Success
- `1` - Failure

Use in scripts:
```bash
if python main.py migrate --input api.zip --deploy; then
  echo "Deployment successful"
else
  echo "Deployment failed"
  exit 1
fi
```
