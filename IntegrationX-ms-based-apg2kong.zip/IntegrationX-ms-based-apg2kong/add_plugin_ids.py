import json
import uuid

# Read the file
with open('output/migration-test-api_1_2_3.json', 'r') as f:
    data = json.load(f)

# Add unique IDs to all plugins
for plugin in data.get('plugins', []):
    if 'id' not in plugin:
        # Generate UUID based on plugin name, service, and tags for consistency
        source_tag = [t for t in plugin.get('tags', []) if 'source-policy' in t]
        unique_str = f"{plugin['name']}-{plugin.get('service', '')}-{source_tag}"
        plugin['id'] = str(uuid.uuid5(uuid.NAMESPACE_DNS, unique_str))

# Write back
with open('output/migration-test-api_1_2_3.json', 'w') as f:
    json.dump(data, f, indent=2)

print(f"Added IDs to {len(data.get('plugins', []))} plugins")
