import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Find all plugin creation patterns and add instance_name based on source policy
# Pattern: plugin = { 'name': 'plugin-type', 'service': service_name,

# Add instance_name field after tags in all plugins
# This makes each plugin instance unique

pattern = r"('tags':\s*\[\s*'apigee-migration',\s*f\"source-policy:\{policy\.get\('name', 'unknown'\)\}\"[^\]]*\])"
replacement = r"\1,\n            'instance_name': f\"{policy.get('name', 'unknown')}-{service_name}\""

content = re.sub(pattern, replacement, content)

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Added instance_name to plugins for uniqueness")
