#!/usr/bin/env python3
"""
Apigee to Kong Migration Tool
============================

Main entry point for the Apigee to Kong Gateway migration tool.
Provides command-line interface for migrating proxy bundles.

Usage:
    python main.py --help
    python main.py migrate --input proxy.zip
    python main.py batch --input-dir ./input
    python main.py validate --config kong_config.json
"""

import sys
import os
import argparse
from pathlib import Path
import logging

# Add src directory to Python path
current_dir = Path(__file__).parent
src_dir = current_dir / 'src'
sys.path.insert(0, str(src_dir))

from migration_tool import ApigeeMigrationTool
from core.exceptions import MigrationToolError


def setup_argument_parser() -> argparse.ArgumentParser:
    """Setup command-line argument parser."""
    parser = argparse.ArgumentParser(
        description='Apigee to Kong Gateway Migration Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Migrate single proxy bundle
  python main.py migrate --input proxy.zip --output kong_config.json
  
  # Batch migrate all bundles in directory
  python main.py batch --input-dir ./input
  
  # Validate existing Kong configuration
  python main.py validate --config kong_config.json
  
  # Use custom configuration file
  python main.py migrate --input proxy.zip --config custom_config.env
        '''
    )
    
    # Global arguments
    parser.add_argument(
        '--config', '-c',
        type=str,
        help='Path to configuration file (default: config/config.env)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )
    
    parser.add_argument(
        '--quiet', '-q',
        action='store_true',
        help='Suppress non-error output'
    )
    
    # Subcommands
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Migrate command
    migrate_parser = subparsers.add_parser(
        'migrate',
        help='Migrate single Apigee proxy bundle'
    )
    migrate_parser.add_argument(
        '--input', '-i',
        type=str,
        required=True,
        help='Path to Apigee proxy bundle ZIP file'
    )
    migrate_parser.add_argument(
        '--output', '-o',
        type=str,
        help='Output filename for Kong configuration (optional)'
    )
    migrate_parser.add_argument(
        '--validate-deck',
        action='store_true',
        help='Run deck validation after migration'
    )
    migrate_parser.add_argument(
        '--deploy',
        action='store_true',
        help='Deploy to Kong Gateway using deck (implies --validate-deck)'
    )
    
    # Batch command
    batch_parser = subparsers.add_parser(
        'batch',
        help='Batch migrate multiple proxy bundles'
    )
    batch_parser.add_argument(
        '--input-dir', '-d',
        type=str,
        help='Directory containing proxy bundle ZIP files (default: input/)'
    )
    
    # Validate command
    validate_parser = subparsers.add_parser(
        'validate',
        help='Validate Kong configuration file'
    )
    validate_parser.add_argument(
        '--config-file',
        type=str,
        required=True,
        help='Path to Kong configuration JSON file'
    )
    
    # Plan command
    plan_parser = subparsers.add_parser(
        'plan',
        help='Generate migration plan without performing actual migration'
    )
    plan_parser.add_argument(
        '--input', '-i',
        type=str,
        required=True,
        help='Path to Apigee proxy bundle ZIP file'
    )
    plan_parser.add_argument(
        '--output', '-o',
        type=str,
        help='Output filename for migration plan (optional)'
    )
    
    # Info command
    info_parser = subparsers.add_parser(
        'info',
        help='Show tool information and system details'
    )
    
    return parser


def handle_migrate_command(args, tool: ApigeeMigrationTool) -> int:
    """Handle single migration command."""
    try:
        print(f"Migrating Apigee proxy bundle: {args.input}")
        
        # If deploy is requested, validation is implied
        validate_deck = args.validate_deck or args.deploy
        
        result = tool.migrate_single_bundle(
            args.input, 
            args.output,
            validate_with_deck=validate_deck,
            deploy_with_deck=args.deploy
        )
        
        if result['success']:
            print(f"✓ Migration successful!")
            print(f"  Output file: {result['output_file']}")
            print(f"  Proxy name: {result['proxy_name']}")
            print(f"  Migration time: {result['migration_time']:.2f} seconds")
            
            if validate_deck:
                if result['deck_validation_passed']:
                    print(f"  ✓ deck validation: PASSED")
                else:
                    print(f"  ✗ deck validation: FAILED")
            
            if args.deploy:
                if result['deck_deployment_status'] == 'deployed':
                    print(f"  ✓ deck deployment: SUCCESS")
                    print(f"  API '{result['proxy_name']}' deployed to Kong Gateway")
                    print(f"  Other APIs in gateway were NOT affected (selective sync)")
                else:
                    print(f"  ✗ deck deployment: {result['deck_deployment_status']}")
            
            if result['warnings']:
                print(f"  Warnings: {len(result['warnings'])}")
                for warning in result['warnings']:
                    print(f"    - {warning}")
            
            return 0
        else:
            print(f"✗ Migration failed!")
            for error in result['errors']:
                print(f"  Error: {error}")
            return 1
            
    except Exception as e:
        print(f"X Migration failed: {str(e)}")
        return 1


def handle_batch_command(args, tool: ApigeeMigrationTool) -> int:
    """Handle batch migration command."""
    try:
        print("Starting batch migration...")
        
        results = tool.migrate_multiple_bundles(args.input_dir)
        
        if not results:
            print("No proxy bundles found to migrate.")
            return 1
        
        successful = sum(1 for r in results if r['success'])
        failed = len(results) - successful
        
        print(f"\nBatch migration completed:")
        print(f"  Total: {len(results)}")
        print(f"  Successful: {successful}")
        print(f"  Failed: {failed}")
        
        if failed > 0:
            print("\nFailed migrations:")
            for result in results:
                if not result['success']:
                    print(f"  - {Path(result['input_file']).name}")
        
        return 0 if failed == 0 else 1
        
    except Exception as e:
        print(f"✗ Batch migration failed: {str(e)}")
        return 1


def handle_validate_command(args, tool: ApigeeMigrationTool) -> int:
    """Handle validation command."""
    try:
        print(f"Validating Kong configuration: {args.config_file}")
        
        result = tool.validate_existing_kong_config(args.config_file)
        
        if result['is_valid']:
            print("✓ Validation passed!")
            print(f"  Services: {result['services_count']}")
            print(f"  Routes: {result['routes_count']}")
            print(f"  Plugins: {result['plugins_count']}")
            
            if result['warnings']:
                print(f"  Warnings: {len(result['warnings'])}")
                for warning in result['warnings']:
                    print(f"    - {warning}")
            
            return 0
        else:
            print("✗ Validation failed!")
            for error in result['errors']:
                print(f"  Error: {error}")
            return 1
            
    except Exception as e:
        print(f"✗ Validation failed: {str(e)}")
        return 1


def handle_plan_command(args, tool: ApigeeMigrationTool) -> int:
    """Handle migration plan command."""
    try:
        print(f"Generating migration plan for: {args.input}")
        
        # Parse the Apigee bundle to analyze what needs to be migrated
        apigee_data = tool.apigee_parser.parse_proxy_bundle(args.input)
        
        # Generate migration plan
        plan = {
            'proxy_information': {
                'name': apigee_data.get('name', 'unknown'),
                'display_name': apigee_data.get('display_name', ''),
                'description': apigee_data.get('description', ''),
                'base_path': apigee_data.get('base_path', '/'),
                'target_url': tool.kong_converter._extract_target_url(apigee_data)
            },
            'migration_analysis': {
                'total_policies': len(apigee_data.get('policies', [])),
                'total_proxy_endpoints': len(apigee_data.get('proxy_endpoints', [])),
                'total_target_endpoints': len(apigee_data.get('target_endpoints', [])),
                'total_resources': len(apigee_data.get('resources', []))
            },
            'policy_conversion_plan': [],
            'estimated_complexity': 'medium',
            'manual_tasks_required': [],
            'kong_configuration_preview': {
                'services_to_create': 1,
                'routes_to_create': len(apigee_data.get('proxy_endpoints', [])) or 1,
                'plugins_to_configure': 0
            }
        }
        
        # Analyze each policy
        supported_count = 0
        partial_count = 0
        manual_count = 0
        
        for policy in apigee_data.get('policies', []):
            policy_type = policy.get('type', '').lower()
            policy_name = policy.get('name', '')
            
            conversion_info = {
                'policy_name': policy_name,
                'policy_type': policy_type,
                'conversion_status': 'unknown',
                'kong_plugin': 'unknown',
                'notes': ''
            }
            
            # Determine conversion status
            if any(supported_type in policy_type for supported_type in 
                   ['ratelimit', 'quota', 'cors', 'oauth', 'apikey', 'basicauth', 'jwt']):
                conversion_info['conversion_status'] = 'fully_supported'
                conversion_info['kong_plugin'] = 'native_plugin'
                conversion_info['notes'] = 'Direct conversion available'
                supported_count += 1
            elif any(partial_type in policy_type for partial_type in 
                     ['spikearrest', 'accesscontrol', 'responsecache', 'messagevalidation']):
                conversion_info['conversion_status'] = 'partially_supported'
                conversion_info['kong_plugin'] = 'equivalent_plugin'
                conversion_info['notes'] = 'Equivalent Kong plugin available with configuration adjustments'
                partial_count += 1
            else:
                conversion_info['conversion_status'] = 'requires_manual_implementation'
                conversion_info['kong_plugin'] = 'custom_implementation'
                conversion_info['notes'] = 'Requires custom Lua script or plugin development'
                manual_count += 1
                
                plan['manual_tasks_required'].append({
                    'task': f'Implement {policy_name} ({policy_type})',
                    'complexity': 'high' if policy_type in ['script', 'javacallout'] else 'medium',
                    'estimated_effort_hours': 8 if policy_type in ['script', 'javacallout'] else 4
                })
            
            plan['policy_conversion_plan'].append(conversion_info)
        
        # Update plugin count
        plan['kong_configuration_preview']['plugins_to_configure'] = supported_count + partial_count
        
        # Determine overall complexity
        if manual_count > 3 or any(p.get('type', '').lower() in ['script', 'javacallout'] 
                                  for p in apigee_data.get('policies', [])):
            plan['estimated_complexity'] = 'high'
        elif manual_count > 0 or partial_count > 2:
            plan['estimated_complexity'] = 'medium'
        else:
            plan['estimated_complexity'] = 'low'
        
        # Add summary statistics
        plan['conversion_summary'] = {
            'fully_supported_policies': supported_count,
            'partially_supported_policies': partial_count,
            'manual_implementation_required': manual_count,
            'conversion_coverage_percentage': round((supported_count + partial_count) / 
                                                  len(apigee_data.get('policies', [])) * 100) if apigee_data.get('policies') else 100
        }
        
        # Save plan
        output_name = args.output or f"{apigee_data.get('name', 'unknown')}_migration_plan.json"
        output_path = tool.config_manager.get_path('OUTPUT_DIR') / output_name
        
        tool.file_manager.write_json_file(plan, str(output_path), create_backup=False)
        
        print("✓ Migration plan generated successfully!")
        print(f"  Plan file: {output_path}")
        print(f"  Proxy: {plan['proxy_information']['name']}")
        print(f"  Complexity: {plan['estimated_complexity']}")
        print(f"  Policies: {plan['migration_analysis']['total_policies']}")
        print(f"  Conversion coverage: {plan['conversion_summary']['conversion_coverage_percentage']}%")
        print(f"  Manual tasks: {len(plan['manual_tasks_required'])}")
        
        return 0
        
    except Exception as e:
        print(f"✗ Plan generation failed: {str(e)}")
        return 1


def handle_info_command(args, tool: ApigeeMigrationTool) -> int:
    """Handle info command."""
    try:
        print("Apigee to Kong Migration Tool")
        print("=" * 40)
        
        # Tool information
        try:
            import __init__ as src_init
            print(f"Version: {src_init.__version__}")
            print(f"Author: {src_init.__author__}")
            print(f"Description: {src_init.__description__}")
        except ImportError:
            print("Version: 1.0.0")
            print("Author: Migration Tool Team")
            print("Description: Apigee to Kong Migration Tool")
        print()
        
        # System information
        os_info = tool.config_manager.get_os_info()
        print("System Information:")
        print(f"  OS: {os_info['system']} {os_info['release']}")
        print(f"  Machine: {os_info['machine']}")
        print(f"  Python: {os_info['python_version']}")
        print()
        
        # Configuration
        print("Configuration:")
        print(f"  Input Directory: {tool.config_manager.get_path('INPUT_DIR')}")
        print(f"  Output Directory: {tool.config_manager.get_path('OUTPUT_DIR')}")
        print(f"  Backup Directory: {tool.config_manager.get_path('BACKUP_DIR')}")
        print(f"  Log Level: {tool.config_manager.get('LOG_LEVEL')}")
        print(f"  Validation Enabled: {tool.config_manager.get('VALIDATE_OUTPUT')}")
        print()
        
        # Migration statistics
        stats = tool.get_migration_statistics()
        if stats['total'] > 0:
            print("Migration Statistics:")
            print(f"  Total Migrations: {stats['total']}")
            print(f"  Successful: {stats['successful']}")
            print(f"  Failed: {stats['failed']}")
            print(f"  Success Rate: {stats['success_rate']:.1f}%")
        
        return 0
        
    except Exception as e:
        print(f"✗ Failed to show info: {str(e)}")
        return 1


def main() -> int:
    """Main entry point."""
    parser = setup_argument_parser()
    args = parser.parse_args()
    
    # Handle case where no command is provided
    if not args.command:
        parser.print_help()
        return 1
    
    try:
        # Initialize migration tool
        tool = ApigeeMigrationTool(args.config)
        
        # Adjust logging level based on arguments
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        elif args.quiet:
            logging.getLogger().setLevel(logging.ERROR)
        
        # Execute command
        if args.command == 'migrate':
            return handle_migrate_command(args, tool)
        elif args.command == 'batch':
            return handle_batch_command(args, tool)
        elif args.command == 'validate':
            return handle_validate_command(args, tool)
        elif args.command == 'plan':
            return handle_plan_command(args, tool)
        elif args.command == 'info':
            return handle_info_command(args, tool)
        else:
            print(f"Unknown command: {args.command}")
            return 1
            
    except MigrationToolError as e:
        print(f"✗ Migration tool error: {str(e)}")
        return 1
    except KeyboardInterrupt:
        print("\n✗ Operation cancelled by user")
        return 1
    except Exception as e:
        print(f"X Unexpected error: {str(e)}")
        return 1


if __name__ == '__main__':
    sys.exit(main())