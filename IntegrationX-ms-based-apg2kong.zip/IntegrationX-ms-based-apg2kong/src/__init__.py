"""
Apigee to Kong Migration Tool
============================

A comprehensive tool for migrating Apigee proxy bundles to Kong Gateway configurations.
Designed with enterprise standards, production readiness, and cross-platform compatibility.

Author: Migration Tool Team
Version: 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Migration Tool Team"
__description__ = "Apigee to Kong Migration Tool"