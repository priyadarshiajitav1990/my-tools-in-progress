"""
Validation Utilities
===================

Provides validation functions for Kong configurations, 
Apigee proxy bundles, and migration results.
"""

import json
import re
from typing import Dict, Any, List, Optional, Tuple
import logging
from urllib.parse import urlparse
from core.exceptions import ValidationError


class ConfigurationValidator:
    """Validates configurations and migration results."""
    
    def __init__(self, logger: logging.Logger):
        """
        Initialize configuration validator.
        
        Args:
            logger: Logger instance
        """
        self.logger = logger
        self.validation_errors: List[str] = []
        self.validation_warnings: List[str] = []
    
    def validate_kong_configuration(self, kong_config: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
        """
        Validate Kong configuration for correctness and completeness.
        
        Args:
            kong_config: Kong configuration dictionary
            
        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        self.validation_errors.clear()
        self.validation_warnings.clear()
        
        self.logger.info("Starting Kong configuration validation")
        
        try:
            # Validate format version
            self._validate_format_version(kong_config)
            
            # Validate services
            self._validate_services(kong_config.get('services', []))
            
            # Validate routes
            self._validate_routes(kong_config.get('routes', []))
            
            # Validate plugins
            self._validate_plugins(kong_config.get('plugins', []))
            
            # Validate upstreams
            self._validate_upstreams(kong_config.get('upstreams', []))
            
            # Validate consumers
            self._validate_consumers(kong_config.get('consumers', []))
            
            # Cross-reference validation
            self._validate_cross_references(kong_config)
            
            is_valid = len(self.validation_errors) == 0
            
            if is_valid:
                self.logger.info("Kong configuration validation passed")
            else:
                self.logger.error(f"Kong configuration validation failed with {len(self.validation_errors)} errors")
            
            return is_valid, self.validation_errors.copy(), self.validation_warnings.copy()
            
        except Exception as e:
            self.validation_errors.append(f"Validation process failed: {str(e)}")
            return False, self.validation_errors.copy(), self.validation_warnings.copy()
    
    def _validate_format_version(self, config: Dict[str, Any]) -> None:
        """Validate Kong configuration format version."""
        format_version = config.get('_format_version')
        
        if not format_version:
            self.validation_warnings.append("Missing _format_version field")
        elif format_version not in ['1.1', '2.1', '3.0']:
            self.validation_warnings.append(f"Unsupported format version: {format_version}")
    
    def _validate_services(self, services: List[Dict[str, Any]]) -> None:
        """Validate Kong services configuration."""
        if not services:
            self.validation_warnings.append("No services defined")
            return
        
        service_names = set()
        
        for i, service in enumerate(services):
            service_context = f"Service {i}"
            
            # Validate required fields
            name = service.get('name')
            if not name:
                self.validation_errors.append(f"{service_context}: Missing required field 'name'")
            elif not self._is_valid_name(name):
                self.validation_errors.append(f"{service_context}: Invalid name format '{name}'")
            elif name in service_names:
                self.validation_errors.append(f"{service_context}: Duplicate service name '{name}'")
            else:
                service_names.add(name)
                service_context = f"Service '{name}'"
            
            # Validate host
            host = service.get('host')
            if not host:
                self.validation_errors.append(f"{service_context}: Missing required field 'host'")
            elif not self._is_valid_host(host):
                self.validation_errors.append(f"{service_context}: Invalid host format '{host}'")
            
            # Validate protocol
            protocol = service.get('protocol', 'http')
            if protocol not in ['http', 'https', 'grpc', 'grpcs', 'tcp', 'udp']:
                self.validation_errors.append(f"{service_context}: Invalid protocol '{protocol}'")
            
            # Validate port
            port = service.get('port')
            if port is not None:
                if not isinstance(port, int) or port < 1 or port > 65535:
                    self.validation_errors.append(f"{service_context}: Invalid port '{port}'")
            
            # Validate path
            path = service.get('path')
            if path is not None and not path.startswith('/'):
                self.validation_errors.append(f"{service_context}: Path must start with '/' - got '{path}'")
            
            # Validate timeout values
            for timeout_field in ['connect_timeout', 'write_timeout', 'read_timeout']:
                timeout = service.get(timeout_field)
                if timeout is not None:
                    if not isinstance(timeout, int) or timeout < 1:
                        self.validation_errors.append(f"{service_context}: Invalid {timeout_field} '{timeout}'")
    
    def _validate_routes(self, routes: List[Dict[str, Any]]) -> None:
        """Validate Kong routes configuration."""
        if not routes:
            self.validation_warnings.append("No routes defined")
            return
        
        route_names = set()
        
        for i, route in enumerate(routes):
            route_context = f"Route {i}"
            
            # Validate required fields
            name = route.get('name')
            if not name:
                self.validation_errors.append(f"{route_context}: Missing required field 'name'")
            elif not self._is_valid_name(name):
                self.validation_errors.append(f"{route_context}: Invalid name format '{name}'")
            elif name in route_names:
                self.validation_errors.append(f"{route_context}: Duplicate route name '{name}'")
            else:
                route_names.add(name)
                route_context = f"Route '{name}'"
            
            # Validate service reference
            service = route.get('service')
            if not service:
                self.validation_errors.append(f"{route_context}: Missing required field 'service'")
            elif isinstance(service, dict):
                if 'name' not in service and 'id' not in service:
                    self.validation_errors.append(f"{route_context}: Service reference must have 'name' or 'id'")
            
            # Validate at least one matching criteria
            has_criteria = any(route.get(field) for field in ['paths', 'hosts', 'methods', 'headers'])
            if not has_criteria:
                self.validation_errors.append(f"{route_context}: Must have at least one matching criteria (paths, hosts, methods, headers)")
            
            # Validate paths
            paths = route.get('paths', [])
            if paths:
                for path in paths:
                    if not isinstance(path, str) or not path.startswith('/'):
                        self.validation_errors.append(f"{route_context}: Invalid path '{path}' - must start with '/'")
            
            # Validate methods
            methods = route.get('methods', [])
            if methods:
                valid_methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS', 'CONNECT', 'TRACE']
                for method in methods:
                    if method not in valid_methods:
                        self.validation_errors.append(f"{route_context}: Invalid HTTP method '{method}'")
            
            # Validate hosts
            hosts = route.get('hosts', [])
            if hosts:
                for host in hosts:
                    if not self._is_valid_host_pattern(host):
                        self.validation_errors.append(f"{route_context}: Invalid host pattern '{host}'")
    
    def _validate_plugins(self, plugins: List[Dict[str, Any]]) -> None:
        """Validate Kong plugins configuration."""
        for i, plugin in enumerate(plugins):
            plugin_context = f"Plugin {i}"
            
            # Validate required fields
            name = plugin.get('name')
            if not name:
                self.validation_errors.append(f"{plugin_context}: Missing required field 'name'")
            else:
                plugin_context = f"Plugin '{name}'"
                
                # Validate plugin name format
                if not self._is_valid_plugin_name(name):
                    self.validation_errors.append(f"{plugin_context}: Invalid plugin name format")
            
            # Validate entity reference (service, route, or consumer)
            entity_refs = ['service', 'route', 'consumer']
            entity_count = sum(1 for ref in entity_refs if plugin.get(ref))
            
            if entity_count == 0:
                self.validation_warnings.append(f"{plugin_context}: No entity reference (global plugin)")
            elif entity_count > 1:
                self.validation_errors.append(f"{plugin_context}: Multiple entity references not allowed")
            
            # Validate config if present
            config = plugin.get('config', {})
            if config and not isinstance(config, dict):
                self.validation_errors.append(f"{plugin_context}: Config must be an object")
    
    def _validate_upstreams(self, upstreams: List[Dict[str, Any]]) -> None:
        """Validate Kong upstreams configuration."""
        upstream_names = set()
        
        for i, upstream in enumerate(upstreams):
            upstream_context = f"Upstream {i}"
            
            # Validate required fields
            name = upstream.get('name')
            if not name:
                self.validation_errors.append(f"{upstream_context}: Missing required field 'name'")
            elif not self._is_valid_name(name):
                self.validation_errors.append(f"{upstream_context}: Invalid name format '{name}'")
            elif name in upstream_names:
                self.validation_errors.append(f"{upstream_context}: Duplicate upstream name '{name}'")
            else:
                upstream_names.add(name)
                upstream_context = f"Upstream '{name}'"
            
            # Validate algorithm
            algorithm = upstream.get('algorithm', 'round-robin')
            valid_algorithms = ['round-robin', 'consistent-hashing', 'least-connections']
            if algorithm not in valid_algorithms:
                self.validation_errors.append(f"{upstream_context}: Invalid algorithm '{algorithm}'")
    
    def _validate_consumers(self, consumers: List[Dict[str, Any]]) -> None:
        """Validate Kong consumers configuration."""
        consumer_usernames = set()
        consumer_ids = set()
        
        for i, consumer in enumerate(consumers):
            consumer_context = f"Consumer {i}"
            
            # Validate required fields (username or custom_id)
            username = consumer.get('username')
            custom_id = consumer.get('custom_id')
            
            if not username and not custom_id:
                self.validation_errors.append(f"{consumer_context}: Must have either 'username' or 'custom_id'")
            
            if username:
                if not self._is_valid_name(username):
                    self.validation_errors.append(f"{consumer_context}: Invalid username format '{username}'")
                elif username in consumer_usernames:
                    self.validation_errors.append(f"{consumer_context}: Duplicate username '{username}'")
                else:
                    consumer_usernames.add(username)
            
            if custom_id:
                if custom_id in consumer_ids:
                    self.validation_errors.append(f"{consumer_context}: Duplicate custom_id '{custom_id}'")
                else:
                    consumer_ids.add(custom_id)
    
    def _validate_cross_references(self, config: Dict[str, Any]) -> None:
        """Validate cross-references between entities."""
        # Collect service names
        service_names = {service.get('name') for service in config.get('services', []) if service.get('name')}
        
        # Collect route names
        route_names = {route.get('name') for route in config.get('routes', []) if route.get('name')}
        
        # Collect consumer usernames
        consumer_names = {consumer.get('username') for consumer in config.get('consumers', []) if consumer.get('username')}
        
        # Validate route service references
        for route in config.get('routes', []):
            service_ref = route.get('service', {})
            if isinstance(service_ref, dict) and 'name' in service_ref:
                service_name = service_ref['name']
                if service_name not in service_names:
                    self.validation_errors.append(f"Route '{route.get('name', 'unknown')}' references non-existent service '{service_name}'")
        
        # Validate plugin entity references
        for plugin in config.get('plugins', []):
            # Check service reference
            service_ref = plugin.get('service', {})
            if isinstance(service_ref, dict) and 'name' in service_ref:
                service_name = service_ref['name']
                if service_name not in service_names:
                    self.validation_errors.append(f"Plugin '{plugin.get('name', 'unknown')}' references non-existent service '{service_name}'")
            
            # Check route reference
            route_ref = plugin.get('route', {})
            if isinstance(route_ref, dict) and 'name' in route_ref:
                route_name = route_ref['name']
                if route_name not in route_names:
                    self.validation_errors.append(f"Plugin '{plugin.get('name', 'unknown')}' references non-existent route '{route_name}'")
            
            # Check consumer reference
            consumer_ref = plugin.get('consumer', {})
            if isinstance(consumer_ref, dict) and 'username' in consumer_ref:
                consumer_name = consumer_ref['username']
                if consumer_name not in consumer_names:
                    self.validation_errors.append(f"Plugin '{plugin.get('name', 'unknown')}' references non-existent consumer '{consumer_name}'")
    
    def _is_valid_name(self, name: str) -> bool:
        """Validate Kong entity name format."""
        if not isinstance(name, str) or not name:
            return False
        
        # Kong names should match: ^[a-zA-Z0-9._~-]+$
        pattern = r'^[a-zA-Z0-9._~-]+$'
        return bool(re.match(pattern, name))
    
    def _is_valid_host(self, host: str) -> bool:
        """Validate host format."""
        if not isinstance(host, str) or not host:
            return False
        
        # Basic hostname validation
        if host == 'localhost':
            return True
        
        # IP address pattern
        ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if re.match(ip_pattern, host):
            return True
        
        # Domain name pattern
        domain_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$'
        return bool(re.match(domain_pattern, host))
    
    def _is_valid_host_pattern(self, host: str) -> bool:
        """Validate host pattern (can include wildcards)."""
        if not isinstance(host, str) or not host:
            return False
        
        # Allow wildcards in host patterns
        if '*' in host:
            # Simple wildcard validation
            return host.count('*') == 1 and (host.startswith('*.') or host == '*')
        
        return self._is_valid_host(host)
    
    def _is_valid_plugin_name(self, name: str) -> bool:
        """Validate plugin name format."""
        if not isinstance(name, str) or not name:
            return False
        
        # Plugin names should be lowercase with hyphens
        pattern = r'^[a-z0-9-]+$'
        return bool(re.match(pattern, name))
    
    def validate_apigee_bundle_structure(self, bundle_files: List[str]) -> Tuple[bool, List[str], List[str]]:
        """
        Validate Apigee proxy bundle structure.
        
        Args:
            bundle_files: List of files in the bundle
            
        Returns:
            Tuple of (is_valid, errors, warnings)
        """
        self.validation_errors.clear()
        self.validation_warnings.clear()
        
        # Required files/directories
        required_patterns = [
            r'.*\.xml$',  # At least one XML file
            r'apiproxy/.*\.xml$'  # Proxy configuration
        ]
        
        # Check for required patterns
        for pattern in required_patterns:
            if not any(re.match(pattern, f) for f in bundle_files):
                self.validation_errors.append(f"Missing required file pattern: {pattern}")
        
        # Check for common directories
        expected_dirs = ['apiproxy', 'apiproxy/proxies', 'apiproxy/targets', 'apiproxy/policies']
        for expected_dir in expected_dirs:
            if not any(f.startswith(expected_dir + '/') for f in bundle_files):
                self.validation_warnings.append(f"Missing expected directory: {expected_dir}")
        
        is_valid = len(self.validation_errors) == 0
        return is_valid, self.validation_errors.copy(), self.validation_warnings.copy()