"""
File Management Utilities
=========================

Provides OS-independent file operations, backup management, 
and validation utilities for the migration tool.
"""

import os
import shutil
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging
from core.exceptions import FileProcessingError, BackupError, ValidationError


class FileManager:
    """Manages file operations with OS-independent path handling."""
    
    def __init__(self, logger: logging.Logger, config_manager):
        """
        Initialize file manager.
        
        Args:
            logger: Logger instance
            config_manager: Configuration manager instance
        """
        self.logger = logger
        self.config_manager = config_manager
    
    def ensure_directory_exists(self, directory_path: str) -> Path:
        """
        Ensure directory exists, create if it doesn't.
        
        Args:
            directory_path: Path to directory
            
        Returns:
            Path object for the directory
            
        Raises:
            FileProcessingError: If directory creation fails
        """
        try:
            path = Path(directory_path)
            path.mkdir(parents=True, exist_ok=True)
            self.logger.debug(f"Ensured directory exists: {path}")
            return path
        except Exception as e:
            raise FileProcessingError(f"Failed to create directory {directory_path}: {str(e)}")
    
    def validate_input_file(self, file_path: str) -> bool:
        """
        Validate input file exists and is accessible.
        
        Args:
            file_path: Path to input file
            
        Returns:
            True if file is valid
            
        Raises:
            FileProcessingError: If file validation fails
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileProcessingError(f"Input file does not exist: {file_path}")
        
        if not path.is_file():
            raise FileProcessingError(f"Path is not a file: {file_path}")
        
        if not os.access(path, os.R_OK):
            raise FileProcessingError(f"File is not readable: {file_path}")
        
        # Check file size (prevent processing extremely large files)
        file_size = path.stat().st_size
        max_size = 100 * 1024 * 1024  # 100MB limit
        
        if file_size > max_size:
            raise FileProcessingError(f"File too large ({file_size} bytes). Maximum allowed: {max_size} bytes")
        
        self.logger.debug(f"Input file validation passed: {file_path}")
        return True
    
    def create_backup(self, source_path: str, backup_name: Optional[str] = None) -> str:
        """
        Create backup of a file or directory.
        
        Args:
            source_path: Path to source file/directory
            backup_name: Optional custom backup name
            
        Returns:
            Path to created backup
            
        Raises:
            BackupError: If backup creation fails
        """
        if not self.config_manager.get('CREATE_BACKUP', True):
            self.logger.debug("Backup creation disabled in configuration")
            return ""
        
        try:
            source = Path(source_path)
            if not source.exists():
                raise BackupError(f"Source path does not exist: {source_path}")
            
            # Generate backup name with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if backup_name:
                backup_filename = f"{backup_name}_{timestamp}"
            else:
                backup_filename = f"{source.stem}_backup_{timestamp}{source.suffix}"
            
            backup_dir = self.config_manager.get_path('BACKUP_DIR')
            backup_path = backup_dir / backup_filename
            
            # Ensure backup directory exists
            self.ensure_directory_exists(str(backup_dir))
            
            # Create backup
            if source.is_file():
                shutil.copy2(source, backup_path)
            else:
                shutil.copytree(source, backup_path)
            
            self.logger.info(f"Created backup: {backup_path}")
            return str(backup_path)
            
        except Exception as e:
            raise BackupError(f"Failed to create backup of {source_path}: {str(e)}")
    
    def write_json_file(self, data: Dict[str, Any], output_path: str, 
                       create_backup: bool = True) -> str:
        """
        Write data to JSON file with optional backup.
        
        Args:
            data: Data to write
            output_path: Output file path
            create_backup: Whether to create backup if file exists
            
        Returns:
            Path to written file
            
        Raises:
            FileProcessingError: If write operation fails
        """
        try:
            output_file = Path(output_path)
            
            # Create backup if file exists and backup is enabled
            if output_file.exists() and create_backup:
                self.create_backup(str(output_file))
            
            # Check if we should overwrite existing file
            if output_file.exists() and not self.config_manager.get('OVERWRITE_EXISTING', False):
                # Generate unique filename
                counter = 1
                while output_file.exists():
                    stem = output_file.stem
                    suffix = output_file.suffix
                    parent = output_file.parent
                    output_file = parent / f"{stem}_{counter}{suffix}"
                    counter += 1
                
                self.logger.info(f"File exists, writing to: {output_file}")
            
            # Ensure output directory exists
            self.ensure_directory_exists(str(output_file.parent))
            
            # Write JSON file with proper formatting
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
            
            self.logger.info(f"Successfully wrote JSON file: {output_file}")
            return str(output_file)
            
        except Exception as e:
            raise FileProcessingError(f"Failed to write JSON file {output_path}: {str(e)}")
    
    def read_json_file(self, file_path: str) -> Dict[str, Any]:
        """
        Read and parse JSON file.
        
        Args:
            file_path: Path to JSON file
            
        Returns:
            Parsed JSON data
            
        Raises:
            FileProcessingError: If read operation fails
        """
        try:
            self.validate_input_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self.logger.debug(f"Successfully read JSON file: {file_path}")
            return data
            
        except json.JSONDecodeError as e:
            raise FileProcessingError(f"Invalid JSON in file {file_path}: {str(e)}")
        except Exception as e:
            raise FileProcessingError(f"Failed to read JSON file {file_path}: {str(e)}")
    
    def validate_json_schema(self, data: Dict[str, Any], schema_path: str) -> bool:
        """
        Validate JSON data against schema.
        
        Args:
            data: JSON data to validate
            schema_path: Path to JSON schema file
            
        Returns:
            True if validation passes
            
        Raises:
            ValidationError: If validation fails
        """
        try:
            import jsonschema
            
            # Read schema
            schema = self.read_json_file(schema_path)
            
            # Validate data
            jsonschema.validate(data, schema)
            
            self.logger.debug("JSON schema validation passed")
            return True
            
        except ImportError:
            self.logger.warning("jsonschema library not available, skipping validation")
            return True
        except jsonschema.ValidationError as e:
            raise ValidationError(f"JSON schema validation failed: {str(e)}")
        except Exception as e:
            raise ValidationError(f"Schema validation error: {str(e)}")
    
    def list_files_by_extension(self, directory: str, extension: str) -> List[str]:
        """
        List all files with specific extension in directory.
        
        Args:
            directory: Directory to search
            extension: File extension (e.g., '.zip', '.json')
            
        Returns:
            List of file paths
        """
        try:
            dir_path = Path(directory)
            if not dir_path.exists():
                return []
            
            pattern = f"*{extension}" if not extension.startswith('.') else f"*{extension}"
            files = [str(f) for f in dir_path.glob(pattern) if f.is_file()]
            
            self.logger.debug(f"Found {len(files)} files with extension {extension} in {directory}")
            return files
            
        except Exception as e:
            self.logger.warning(f"Error listing files in {directory}: {str(e)}")
            return []
    
    def get_file_info(self, file_path: str) -> Dict[str, Any]:
        """
        Get detailed file information.
        
        Args:
            file_path: Path to file
            
        Returns:
            Dictionary with file information
        """
        try:
            path = Path(file_path)
            if not path.exists():
                return {}
            
            stat = path.stat()
            
            info = {
                'name': path.name,
                'stem': path.stem,
                'suffix': path.suffix,
                'size': stat.st_size,
                'size_human': self._format_file_size(stat.st_size),
                'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'is_file': path.is_file(),
                'is_directory': path.is_dir(),
                'absolute_path': str(path.absolute()),
                'relative_path': str(path)
            }
            
            return info
            
        except Exception as e:
            self.logger.warning(f"Error getting file info for {file_path}: {str(e)}")
            return {}
    
    def cleanup_temp_files(self, temp_directory: str) -> None:
        """
        Clean up temporary files and directories.
        
        Args:
            temp_directory: Path to temporary directory
        """
        try:
            temp_path = Path(temp_directory)
            if temp_path.exists() and temp_path.is_dir():
                shutil.rmtree(temp_path)
                self.logger.debug(f"Cleaned up temporary directory: {temp_directory}")
        except Exception as e:
            self.logger.warning(f"Error cleaning up temporary files: {str(e)}")
    
    def _format_file_size(self, size_bytes: int) -> str:
        """Format file size in human-readable format."""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        import math
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        
        return f"{s} {size_names[i]}"