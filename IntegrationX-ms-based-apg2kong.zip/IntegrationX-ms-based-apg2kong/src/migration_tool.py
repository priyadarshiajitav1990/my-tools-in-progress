"""
Main Migration Tool Class
========================

Orchestrates the complete migration process from Apigee proxy bundles 
to Kong Gateway configurations.
"""

import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging

# Import components directly
from core.config_manager import ConfigManager
from core.logger import LoggerManager
from core.exceptions import MigrationToolError, FileProcessingError, ValidationError
from parsers.apigee_parser import ApigeeProxyParser
from converters.kong_converter import KongConfigurationConverter
from utils.file_manager import FileManager
from utils.validator import ConfigurationValidator
from utils.report_generator import MigrationReportGenerator


class ApigeeMigrationTool:
    """Main migration tool class that orchestrates the entire process."""
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the migration tool.
        
        Args:
            config_file: Optional path to configuration file
        """
        # Initialize core components
        self.config_manager = ConfigManager(config_file)
        self.logger_manager = LoggerManager(self.config_manager)
        self.logger = self.logger_manager.get_logger()
        
        # Initialize utility components
        self.file_manager = FileManager(self.logger, self.config_manager)
        self.validator = ConfigurationValidator(self.logger)
        self.report_generator = MigrationReportGenerator(self.logger)
        
        # Initialize processing components
        self.apigee_parser = ApigeeProxyParser(self.logger)
        self.kong_converter = KongConfigurationConverter(self.logger)
        
        # Migration state
        self.migration_results: List[Dict[str, Any]] = []
        
        # Setup
        self._initialize_tool()
    
    def _initialize_tool(self) -> None:
        """Initialize the migration tool."""
        try:
            # Validate configuration
            self.config_manager.validate_configuration()
            
            # Ensure required directories exist
            self.config_manager.ensure_directories()
            
            # Log system information
            self.logger_manager.log_system_info()
            
            self.logger.info("Migration tool initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize migration tool: {str(e)}")
            raise MigrationToolError(f"Initialization failed: {str(e)}")
    
    def migrate_single_bundle(self, bundle_path: str, output_name: Optional[str] = None, 
                             validate_with_deck: bool = False, deploy_with_deck: bool = False) -> Dict[str, Any]:
        """
        Migrate a single Apigee proxy bundle to Kong configuration.
        
        Args:
            bundle_path: Path to Apigee proxy bundle ZIP file
            output_name: Optional custom output filename
            validate_with_deck: Run deck validation after migration
            deploy_with_deck: Deploy to Kong Gateway using deck
            
        Returns:
            Migration result dictionary
            
        Raises:
            MigrationToolError: If migration fails
        """
        self.logger.info(f"Starting migration of bundle: {bundle_path}")
        
        migration_result = {
            'input_file': bundle_path,
            'output_file': '',
            'success': False,
            'proxy_name': '',
            'errors': [],
            'warnings': [],
            'validation_passed': False,
            'deck_validation_passed': False,
            'deck_deployment_status': '',
            'backup_created': '',
            'migration_time': None
        }
        
        try:
            import time
            start_time = time.time()
            
            # Validate input file
            self.file_manager.validate_input_file(bundle_path)
            
            # Parse Apigee proxy bundle
            self.logger.info("Parsing Apigee proxy bundle...")
            apigee_data = self.apigee_parser.parse_proxy_bundle(bundle_path)
            proxy_name = apigee_data.get('name', 'unknown')
            migration_result['proxy_name'] = proxy_name
            
            # Convert to Kong configuration
            self.logger.info("Converting to Kong configuration...")
            kong_config = self.kong_converter.convert_to_kong(apigee_data)
            
            # Validate Kong configuration
            if self.config_manager.get('VALIDATE_OUTPUT', True):
                self.logger.info("Validating Kong configuration...")
                is_valid, errors, warnings = self.validator.validate_kong_configuration(kong_config)
                migration_result['validation_passed'] = is_valid
                migration_result['errors'].extend(errors)
                migration_result['warnings'].extend(warnings)
                
                if not is_valid:
                    self.logger.warning(f"Validation failed with {len(errors)} errors")
            else:
                migration_result['validation_passed'] = True
            
            # Generate output filename using API name (no incremental numbers)
            if not output_name:
                output_name = f"{proxy_name}.json"
            
            output_path = self.config_manager.get_path('OUTPUT_DIR') / output_name
            
            # Write Kong configuration
            self.logger.info("Writing Kong configuration file...")
            written_file = self.file_manager.write_json_file(
                kong_config, 
                str(output_path),
                create_backup=self.config_manager.get('CREATE_BACKUP', True)
            )
            
            migration_result['output_file'] = written_file
            migration_result['success'] = True
            migration_result['migration_time'] = time.time() - start_time
            
            self.logger.info(f"Successfully migrated {bundle_path} to {written_file}")
            
            # Run deck validation if requested
            if validate_with_deck:
                self.logger.info("Running deck validation...")
                deck_result = self._run_deck_validation(written_file)
                migration_result['deck_validation_passed'] = deck_result['success']
                if not deck_result['success']:
                    migration_result['errors'].extend(deck_result['errors'])
                if deck_result.get('warnings'):
                    migration_result['warnings'].extend(deck_result['warnings'])
            
            # Deploy with deck if requested and validation passed
            if deploy_with_deck and (not validate_with_deck or migration_result['deck_validation_passed']):
                self.logger.info("Deploying to Kong Gateway using deck...")
                deploy_result = self._run_deck_deployment(written_file, proxy_name)
                migration_result['deck_deployment_status'] = deploy_result['status']
                if not deploy_result['success']:
                    migration_result['errors'].extend(deploy_result['errors'])
                    migration_result['success'] = False
            
        except Exception as e:
            error_msg = f"Migration failed for {bundle_path}: {str(e)}"
            self.logger.error(error_msg)
            migration_result['errors'].append(error_msg)
            migration_result['success'] = False
        
        self.migration_results.append(migration_result)
        return migration_result
    
    def migrate_multiple_bundles(self, input_directory: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Migrate multiple Apigee proxy bundles from a directory.
        
        Args:
            input_directory: Directory containing proxy bundles (uses config default if None)
            
        Returns:
            List of migration results
        """
        if not input_directory:
            input_directory = str(self.config_manager.get_path('INPUT_DIR'))
        
        self.logger.info(f"Starting batch migration from directory: {input_directory}")
        
        # Find all ZIP files in input directory
        zip_files = self.file_manager.list_files_by_extension(input_directory, '.zip')
        
        if not zip_files:
            self.logger.warning(f"No ZIP files found in {input_directory}")
            return []
        
        self.logger.info(f"Found {len(zip_files)} ZIP files to process")
        
        results = []
        for zip_file in zip_files:
            try:
                result = self.migrate_single_bundle(zip_file)
                results.append(result)
            except Exception as e:
                self.logger.error(f"Failed to process {zip_file}: {str(e)}")
                error_result = {
                    'input_file': zip_file,
                    'success': False,
                    'errors': [str(e)],
                    'warnings': [],
                    'validation_passed': False
                }
                results.append(error_result)
        
        # Generate summary report
        self._generate_migration_report(results)
        
        # Generate comprehensive report
        comprehensive_report_path = self.config_manager.get_path('OUTPUT_DIR') / 'comprehensive_migration_report.json'
        self.report_generator.generate_comprehensive_report(results, str(comprehensive_report_path))
        
        return results
    
    def _generate_migration_report(self, results: List[Dict[str, Any]]) -> None:
        """Generate migration summary report."""
        successful = sum(1 for r in results if r['success'])
        failed = len(results) - successful
        
        self.logger.info("=" * 50)
        self.logger.info("MIGRATION SUMMARY REPORT")
        self.logger.info("=" * 50)
        self.logger.info(f"Total bundles processed: {len(results)}")
        self.logger.info(f"Successful migrations: {successful}")
        self.logger.info(f"Failed migrations: {failed}")
        
        if failed > 0:
            self.logger.info("\nFailed migrations:")
            for result in results:
                if not result['success']:
                    self.logger.info(f"  - {result['input_file']}: {'; '.join(result['errors'])}")
        
        # Generate detailed report file
        report_path = self.config_manager.get_path('OUTPUT_DIR') / 'migration_report.json'
        try:
            self.file_manager.write_json_file(
                {
                    'summary': {
                        'total': len(results),
                        'successful': successful,
                        'failed': failed,
                        'timestamp': self._get_current_timestamp()
                    },
                    'results': results
                },
                str(report_path),
                create_backup=False
            )
            self.logger.info(f"Detailed report saved to: {report_path}")
        except Exception as e:
            self.logger.warning(f"Failed to save detailed report: {str(e)}")
        
        self.logger.info("=" * 50)
    
    def validate_existing_kong_config(self, config_path: str) -> Dict[str, Any]:
        """
        Validate an existing Kong configuration file.
        
        Args:
            config_path: Path to Kong configuration JSON file
            
        Returns:
            Validation result dictionary
        """
        self.logger.info(f"Validating Kong configuration: {config_path}")
        
        try:
            # Read configuration file
            kong_config = self.file_manager.read_json_file(config_path)
            
            # Validate configuration
            is_valid, errors, warnings = self.validator.validate_kong_configuration(kong_config)
            
            result = {
                'file_path': config_path,
                'is_valid': is_valid,
                'errors': errors,
                'warnings': warnings,
                'services_count': len(kong_config.get('services', [])),
                'routes_count': len(kong_config.get('routes', [])),
                'plugins_count': len(kong_config.get('plugins', []))
            }
            
            if is_valid:
                self.logger.info("Kong configuration validation passed")
            else:
                self.logger.error(f"Kong configuration validation failed with {len(errors)} errors")
            
            return result
            
        except Exception as e:
            error_msg = f"Failed to validate Kong configuration: {str(e)}"
            self.logger.error(error_msg)
            return {
                'file_path': config_path,
                'is_valid': False,
                'errors': [error_msg],
                'warnings': [],
                'services_count': 0,
                'routes_count': 0,
                'plugins_count': 0
            }
    
    def get_migration_statistics(self) -> Dict[str, Any]:
        """Get statistics about completed migrations."""
        if not self.migration_results:
            return {'total': 0, 'successful': 0, 'failed': 0}
        
        successful = sum(1 for r in self.migration_results if r['success'])
        failed = len(self.migration_results) - successful
        
        return {
            'total': len(self.migration_results),
            'successful': successful,
            'failed': failed,
            'success_rate': (successful / len(self.migration_results)) * 100 if self.migration_results else 0
        }
    
    def cleanup_resources(self) -> None:
        """Clean up temporary resources and files."""
        self.logger.info("Cleaning up resources...")
        
        # Clean up any temporary files
        temp_dir = Path.cwd() / 'temp'
        if temp_dir.exists():
            self.file_manager.cleanup_temp_files(str(temp_dir))
        
        self.logger.info("Resource cleanup completed")
    
    def _run_deck_validation(self, config_file: str) -> Dict[str, Any]:
        """
        Run deck validation on the generated Kong configuration.
        
        Args:
            config_file: Path to Kong configuration file
            
        Returns:
            Validation result dictionary
        """
        import subprocess
        
        result = {
            'success': False,
            'errors': [],
            'warnings': [],
            'output': ''
        }
        
        try:
            # Check if deck is installed
            check_cmd = ['deck', 'version']
            subprocess.run(check_cmd, capture_output=True, check=True, timeout=10)
            
            # Run deck file validate
            self.logger.info(f"Running: deck file validate {config_file}")
            validate_cmd = ['deck', 'file', 'validate', config_file]
            process = subprocess.run(
                validate_cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            result['output'] = process.stdout + process.stderr
            
            if process.returncode == 0:
                result['success'] = True
                self.logger.info("deck file validate: PASSED")
            else:
                result['errors'].append(f"deck file validate failed: {process.stderr}")
                self.logger.error(f"deck file validate: FAILED\n{process.stderr}")
            
        except FileNotFoundError:
            error_msg = "deck CLI not found. Please install deck: https://docs.konghq.com/deck/latest/installation/"
            result['errors'].append(error_msg)
            self.logger.warning(error_msg)
        except subprocess.TimeoutExpired:
            error_msg = "deck validation timed out"
            result['errors'].append(error_msg)
            self.logger.error(error_msg)
        except Exception as e:
            error_msg = f"deck validation error: {str(e)}"
            result['errors'].append(error_msg)
            self.logger.error(error_msg)
        
        return result
    
    def _run_deck_deployment(self, config_file: str, api_name: str) -> Dict[str, Any]:
        """
        Deploy Kong configuration using deck with selective sync.
        Supports both Kong Gateway (self-hosted) and Kong Konnect (cloud).
        Uses --select-tag to only sync the specific API without affecting others.
        
        Args:
            config_file: Path to Kong configuration file
            api_name: Name of the API being deployed
            
        Returns:
            Deployment result dictionary
        """
        import subprocess
        
        result = {
            'success': False,
            'status': 'not_started',
            'errors': [],
            'warnings': [],
            'output': ''
        }
        
        try:
            # Check if deck is installed
            check_cmd = ['deck', 'version']
            subprocess.run(check_cmd, capture_output=True, check=True, timeout=10)
            
            # Determine if using Konnect or self-hosted Kong
            konnect_token = self.config_manager.get('KONNECT_TOKEN')
            konnect_admin_api = self.config_manager.get('KONNECT_ADMIN_API')
            kong_admin_url = self.config_manager.get('KONG_ADMIN_URL')
            
            # Build base deck command
            base_cmd = ['deck', 'gateway']
            
            # Add Konnect or Kong Gateway specific flags
            if konnect_token and konnect_admin_api:
                # Using Kong Konnect (Cloud)
                self.logger.info("Using Kong Konnect for deployment")
                base_cmd.extend([
                    '--konnect-token', konnect_token,
                    '--konnect-addr', konnect_admin_api
                ])
            elif kong_admin_url:
                # Using self-hosted Kong Gateway
                self.logger.info(f"Using Kong Gateway at {kong_admin_url}")
                base_cmd.extend(['--kong-addr', kong_admin_url])
            else:
                error_msg = "Neither KONNECT_TOKEN nor KONG_ADMIN_URL configured. Please configure one in config/config.env"
                result['errors'].append(error_msg)
                result['status'] = 'not_configured'
                self.logger.error(error_msg)
                return result
            
            # Run deck gateway validate first
            self.logger.info("Running deck gateway validate...")
            gateway_validate_cmd = base_cmd + ['validate', config_file]
            
            process = subprocess.run(
                gateway_validate_cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            result['output'] += f"=== Gateway Validation ===\n{process.stdout}\n{process.stderr}\n\n"
            
            if process.returncode != 0:
                result['errors'].append(f"deck gateway validate failed: {process.stderr}")
                result['status'] = 'gateway_validation_failed'
                self.logger.error(f"deck gateway validate: FAILED\n{process.stderr}")
                return result
            
            self.logger.info("deck gateway validate: PASSED")
            
            # Deploy using deck gateway sync with selective tag
            # This ensures only this API is synced, not affecting other APIs
            self.logger.info(f"Running deck gateway sync with --select-tag apigee-api:{api_name}")
            sync_cmd = base_cmd + [
                'sync',
                config_file,
                '--select-tag', f'apigee-api:{api_name}',
                '--skip-consumers'  # Don't sync consumers to avoid affecting other APIs
            ]
            
            # Add workspace if configured (for self-hosted Kong Enterprise)
            if not konnect_token:
                workspace = self.config_manager.get('KONG_WORKSPACE')
                if workspace:
                    sync_cmd.extend(['--workspace', workspace])
            
            process = subprocess.run(
                sync_cmd,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            result['output'] += f"=== Gateway Sync ===\n{process.stdout}\n{process.stderr}\n"
            
            if process.returncode == 0:
                result['success'] = True
                result['status'] = 'deployed'
                platform = "Kong Konnect" if konnect_token else "Kong Gateway"
                self.logger.info(f"deck gateway sync: SUCCESS - {api_name} deployed to {platform}")
            else:
                result['errors'].append(f"deck gateway sync failed: {process.stderr}")
                result['status'] = 'deployment_failed'
                self.logger.error(f"deck gateway sync: FAILED\n{process.stderr}")
            
        except FileNotFoundError:
            error_msg = "deck CLI not found. Please install deck: https://docs.konghq.com/deck/latest/installation/"
            result['errors'].append(error_msg)
            result['status'] = 'deck_not_installed'
            self.logger.warning(error_msg)
        except subprocess.TimeoutExpired:
            error_msg = "deck deployment timed out"
            result['errors'].append(error_msg)
            result['status'] = 'timeout'
            self.logger.error(error_msg)
        except Exception as e:
            error_msg = f"deck deployment error: {str(e)}"
            result['errors'].append(error_msg)
            result['status'] = 'error'
            self.logger.error(error_msg)
        
        return result
    
    def _get_current_timestamp(self) -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.cleanup_resources()