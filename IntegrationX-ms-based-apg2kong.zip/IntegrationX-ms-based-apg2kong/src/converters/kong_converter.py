"""
Kong Configuration Converter
============================

Converts parsed Apigee proxy configurations to Kong Gateway format.
Handles services, routes, plugins, and other Kong-specific configurations.
"""

import json
from typing import Dict, List, Any, Optional
import logging
from urllib.parse import urlparse
from core.exceptions import KongConfigurationError


class KongConfigurationConverter:
    """Converts Apigee proxy data to Kong Gateway configuration."""
    
    def __init__(self, logger: logging.Logger):
        """
        Initialize Kong configuration converter.
        
        Args:
            logger: Logger instance for logging operations
        """
        self.logger = logger
        self.kong_config: Dict[str, Any] = {}
        self.apigee_metadata: Dict[str, Any] = {}
    
    def _generate_plugin_id(self, plugin_name: str, service_name: str, policy_name: str) -> str:
        """Generate consistent UUID for plugin instance."""
        import uuid
        unique_str = f"{plugin_name}-{service_name}-{policy_name}"
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, unique_str))
    
    def convert_to_kong(self, apigee_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert Apigee proxy data to Kong configuration.
        
        Args:
            apigee_data: Parsed Apigee proxy configuration
            
        Returns:
            Kong configuration dictionary
            
        Raises:
            KongConfigurationError: If conversion fails
        """
        self.logger.info(f"Converting Apigee proxy '{apigee_data.get('name', 'Unknown')}' to Kong configuration")
        
        try:
            # Store metadata separately for deck compatibility
            self.apigee_metadata = {
                'route_rules': [],
                'fault_rules': [],
                'conditional_flows': [],
                'conversion_notes': []
            }
            
            self.kong_config = {
                '_format_version': '3.0',
                '_transform': True,
                'services': [],
                'routes': [],
                'plugins': [],
                'consumers': [],
                'upstreams': [],
                'certificates': []
            }
            
            # Convert main service
            service = self._create_kong_service(apigee_data)
            self.kong_config['services'].append(service)
            
            # Convert routes (including RouteRules)
            routes = self._create_kong_routes(apigee_data, service['name'])
            self.kong_config['routes'].extend(routes)
            
            # Convert RouteRules to Kong routes
            route_rule_routes = self._convert_route_rules_to_routes(apigee_data, service['name'])
            self.kong_config['routes'].extend(route_rule_routes)
            
            # Convert policies to plugins
            plugins = self._convert_policies_to_plugins(apigee_data)
            self.kong_config['plugins'].extend(plugins)
            
            # Convert conditional flows to plugins
            conditional_plugins = self._convert_conditional_flows_to_plugins(apigee_data, service['name'])
            self.kong_config['plugins'].extend(conditional_plugins)
            
            # Convert fault rules to error handling plugins
            fault_plugins = self._convert_fault_rules_to_plugins(apigee_data, service['name'])
            self.kong_config['plugins'].extend(fault_plugins)
            
            # Add upstream if needed
            upstream = self._create_upstream_if_needed(apigee_data)
            if upstream:
                self.kong_config['upstreams'].append(upstream)
            
            self.logger.info(f"Successfully converted to Kong configuration with {len(self.kong_config['services'])} services, {len(self.kong_config['routes'])} routes, and {len(self.kong_config['plugins'])} plugins")
            return self.kong_config
            
        except Exception as e:
            raise KongConfigurationError(f"Failed to convert Apigee configuration to Kong: {str(e)}")
    
    def _create_kong_service(self, apigee_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create Kong service from Apigee proxy data."""
        service_name = self._sanitize_name(apigee_data.get('name', 'unknown-service'))
        api_name = apigee_data.get('name', 'unknown')
        
        # Extract target URL from target endpoints
        target_url = self._extract_target_url(apigee_data)
        parsed_url = urlparse(target_url) if target_url else None
        
        service = {
            'name': service_name,
            'protocol': parsed_url.scheme if parsed_url and parsed_url.scheme else 'http',
            'host': parsed_url.hostname if parsed_url and parsed_url.hostname else 'localhost',
            'port': parsed_url.port if parsed_url and parsed_url.port else (443 if parsed_url and parsed_url.scheme == 'https' else 80),
            'path': parsed_url.path if parsed_url and parsed_url.path else '/',
            'retries': 5,
            'connect_timeout': 60000,
            'write_timeout': 60000,
            'read_timeout': 60000,
            'tags': [
                'apigee-migration',
                f"apigee-api:{api_name}",  # Tag for selective deck sync
                f"source:{api_name}"
            ]
        }
        
        # Add metadata
        if apigee_data.get('description'):
            service['tags'].append(f"description:{apigee_data['description']}")
        
        return service
    
    def _create_kong_routes(self, apigee_data: Dict[str, Any], service_name: str) -> List[Dict[str, Any]]:
        """Create Kong routes from Apigee proxy endpoints."""
        routes = []
        api_name = apigee_data.get('name', 'unknown')
        
        # Extract base path from proxy endpoints
        base_paths = self._extract_base_paths(apigee_data)
        
        for i, base_path in enumerate(base_paths):
            route_name = f"{service_name}-route-{i}" if i > 0 else f"{service_name}-route"
            
            route = {
                'name': route_name,
                'service': {'name': service_name},
                'paths': [base_path],
                'methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'],
                'strip_path': False,
                'preserve_host': False,
                'tags': [
                    'apigee-migration',
                    f"apigee-api:{api_name}",  # Tag for selective deck sync
                    f"source:{api_name}"
                ]
            }
            
            routes.append(route)
        
        # If no base paths found, create a default route
        if not routes:
            default_route = {
                'name': f"{service_name}-route",
                'service': {'name': service_name},
                'paths': ['/'],
                'methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'],
                'strip_path': False,
                'preserve_host': False,
                'tags': [
                    'apigee-migration',
                    f"source:{apigee_data.get('name', 'unknown')}"
                ]
            }
            routes.append(default_route)
        
        return routes
    
    def _convert_policies_to_plugins(self, apigee_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert Apigee policies to Kong plugins."""
        plugins = []
        
        for policy in apigee_data.get('policies', []):
            try:
                plugin = self._convert_policy_to_plugin(policy, apigee_data.get('name', 'unknown'))
                if plugin:
                    plugins.append(plugin)
            except Exception as e:
                self.logger.error(f"Failed to convert policy '{policy.get('name', 'unknown')}': {str(e)}")
                # Continue with other policies instead of failing completely
                continue
        
        return plugins
    
    def _convert_policy_to_plugin(self, policy: Dict[str, Any], service_name: str) -> Optional[Dict[str, Any]]:
        """Convert individual Apigee policy to Kong plugin."""
        policy_type = policy.get('type', '').lower()
        policy_name = policy.get('name', '')
        
        # Rate limiting policies
        if 'ratelimit' in policy_type or 'quota' in policy_type:
            return self._create_rate_limiting_plugin(policy, service_name)
        
        # Spike arrest (rate limiting variant)
        elif 'spikearrest' in policy_type:
            return self._create_spike_arrest_plugin(policy, service_name)
        
        # CORS policies
        elif 'cors' in policy_type:
            return self._create_cors_plugin(policy, service_name)
        
        # Authentication policies
        elif any(auth_type in policy_type for auth_type in ['oauth', 'apikey', 'basicauth', 'jwt']):
            return self._create_auth_plugin(policy, service_name)
        
        # Transformation policies
        elif any(transform_type in policy_type for transform_type in ['assignmessage', 'extractvariables', 'javascript']):
            return self._create_transformation_plugin(policy, service_name)
        
        # Security policies
        elif any(security_type in policy_type for security_type in ['regularexpressionprotection', 'jsonprotection', 'xmlprotection']):
            return self._create_security_plugin(policy, service_name)
        
        # Access control policies
        elif 'accesscontrol' in policy_type:
            return self._create_access_control_plugin(policy, service_name)
        
        # Response cache policies
        elif 'responsecache' in policy_type or 'invalidatecache' in policy_type:
            return self._create_cache_plugin(policy, service_name)
        
        # Message validation policies
        elif any(validation_type in policy_type for validation_type in ['messagevalidation', 'oasvalidation']):
            return self._create_validation_plugin(policy, service_name)
        
        # Service callout policies
        elif 'servicecallout' in policy_type:
            return self._create_service_callout_plugin(policy, service_name)
        
        # Message logging policies
        elif 'messagelogging' in policy_type:
            return self._create_logging_plugin(policy, service_name)
        
        # Key-Value Map operations
        elif 'keyvaluemapoperations' in policy_type:
            return self._create_kvm_plugin(policy, service_name)
        
        # Raise fault policies
        elif 'raisefault' in policy_type:
            return self._create_fault_plugin(policy, service_name)
        
        # Data transformation policies
        elif any(transform_type in policy_type for transform_type in ['xmltojson', 'jsontoxml', 'xsl']):
            return self._create_data_transformation_plugin(policy, service_name)
        
        # JWS/JWT policies
        elif any(jwt_type in policy_type for jwt_type in ['decodejws', 'verifyjws']):
            return self._create_jws_plugin(policy, service_name)
        
        # SAML policies
        elif any(saml_type in policy_type for saml_type in ['validatesamlassertion', 'generatesamlassertion']):
            return self._create_saml_plugin(policy, service_name)
        
        # HMAC policies
        elif 'hmac' in policy_type:
            return self._create_hmac_plugin(policy, service_name)
        
        # Script policies
        elif 'script' in policy_type:
            return self._create_script_plugin(policy, service_name)
        
        # External callout policies
        elif 'externalcallout' in policy_type or 'javacallout' in policy_type:
            return self._create_external_callout_plugin(policy, service_name)
        
        # Publish message policies
        elif 'publishmessage' in policy_type:
            return self._create_publish_plugin(policy, service_name)
        
        # HTTP modifier policies
        elif 'httpmodifier' in policy_type:
            return self._create_http_modifier_plugin(policy, service_name)
        
        # Assert condition policies
        elif 'assertcondition' in policy_type:
            return self._create_assert_plugin(policy, service_name)
        
        # Access entity policies
        elif 'accessentity' in policy_type:
            return self._create_access_entity_plugin(policy, service_name)
        
        else:
            self.logger.warning(f"Unsupported policy type '{policy_type}' for policy '{policy_name}' - creating generic transformation plugin")
            return self._create_generic_plugin(policy, service_name)
    
    def _create_rate_limiting_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong rate limiting plugin from Apigee rate limiting policy."""
        config = policy.get('configuration', {})
        
        # Extract rate limiting configuration
        rate = self._extract_rate_limit_config(config)
        
        policy_name = policy.get('name', 'unknown')
        
        plugin = {
            'id': self._generate_plugin_id('rate-limiting', service_name, policy_name),
            'name': 'rate-limiting',
            'id': self._generate_plugin_id('rate-limiting', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'minute': rate.get('per_minute'),
                'hour': rate.get('per_hour'),
                'day': rate.get('per_day'),
                'policy': 'local',
                'fault_tolerant': True,
                'hide_client_headers': False
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy_name}",
                f"apigee-api:{service_name}"
            ]
        }
        
        return plugin
    
    def _create_cors_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong CORS plugin from Apigee CORS policy."""
        config = policy.get('configuration', {})
        
        # Handle different CORS configuration formats
        origins = self._safe_get_config_value(config, ['AllowOrigins', 'origins'], ['*'])
        methods = self._safe_get_config_value(config, ['AllowMethods', 'methods'], ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
        headers = self._safe_get_config_value(config, ['AllowHeaders', 'headers'], ['Accept', 'Content-Type', 'Authorization'])
        exposed_headers = self._safe_get_config_value(config, ['ExposeHeaders', 'exposed_headers'], [])
        credentials = self._safe_get_config_value(config, ['AllowCredentials', 'credentials'], False)
        max_age = self._safe_get_config_value(config, ['MaxAge', 'max_age'], 3600)
        
        # Handle string values that might contain variables
        if isinstance(origins, str):
            origins = [origins] if origins != '*' else ['*']
        if isinstance(methods, str):
            methods = [m.strip() for m in methods.split(',')]
        if isinstance(headers, str):
            headers = [h.strip() for h in headers.split(',')]
        if isinstance(exposed_headers, str):
            exposed_headers = [h.strip() for h in exposed_headers.split(',')]
        
        # Convert string boolean to actual boolean
        if isinstance(credentials, str):
            credentials = credentials.lower() in ('true', '1', 'yes')
        
        # Convert string max_age to integer
        if isinstance(max_age, str):
            try:
                max_age = int(max_age)
            except ValueError:
                max_age = 3600
        
        plugin = {
            'name': 'cors',
            'id': self._generate_plugin_id('cors', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'origins': origins,
                'methods': methods,
                'headers': headers,
                'exposed_headers': exposed_headers,
                'credentials': credentials,
                'max_age': max_age,
                'preflight_continue': False
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}"
            ],
        }
        
        return plugin
    
    def _create_auth_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong authentication plugin from Apigee auth policy."""
        policy_type = policy.get('type', '').lower()
        
        if 'apikey' in policy_type:
            plugin_name = 'key-auth'
            config = {
                'key_names': ['apikey', 'api-key', 'x-api-key'],
                'hide_credentials': True
            }
        elif 'basicauth' in policy_type:
            plugin_name = 'basic-auth'
            config = {
                'hide_credentials': True
            }
        elif 'jwt' in policy_type:
            plugin_name = 'jwt'
            config = {
                'uri_param_names': ['jwt'],
                'header_names': ['authorization'],
                'claims_to_verify': ['exp']
            }
        elif 'oauth' in policy_type:
            plugin_name = 'oauth2'
            config = {
                'scopes': ['read', 'write'],
                'mandatory_scope': True,
                'enable_authorization_code': True
            }
        else:
            plugin_name = 'key-auth'  # Default fallback
            config = {
                'key_names': ['apikey'],
                'hide_credentials': True
            }
        
        plugin = {
            'name': plugin_name,
            'service': service_name,
            'config': config,
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}"
            ],
        }
        
        return plugin
    
    def _create_transformation_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong transformation plugin from Apigee transformation policy."""
        # For complex transformations, we'll use the request-transformer plugin
        # In production, you might want to use custom plugins or Lua scripts
        
        plugin = {
            'name': 'request-transformer',
            'id': self._generate_plugin_id('request-transformer', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'add': {
                    'headers': ['X-Migrated-From:Apigee']
                }
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'transformation'
            ],
        }
        
        return plugin
    
    def _create_security_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong security plugin from Apigee security policy."""
        # Use bot detection or similar security plugins
        
        plugin = {
            'name': 'bot-detection',
            'id': self._generate_plugin_id('bot-detection', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'blacklist': [],
                'whitelist': []
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'security'
            ],
        }
        
        return plugin
    
    def _create_upstream_if_needed(self, apigee_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create Kong upstream if load balancing is needed."""
        # Check if multiple target endpoints exist
        target_endpoints = apigee_data.get('target_endpoints', [])
        
        if len(target_endpoints) > 1:
            upstream_name = f"{self._sanitize_name(apigee_data.get('name', 'unknown'))}-upstream"
            
            upstream = {
                'name': upstream_name,
                'algorithm': 'round-robin',
                'hash_on': 'none',
                'hash_fallback': 'none',
                'healthchecks': {
                    'active': {
                        'timeout': 1,
                        'concurrency': 10,
                        'http_path': '/',
                        'healthy': {
                            'interval': 0,
                            'http_statuses': [200, 302],
                            'successes': 0
                        },
                        'unhealthy': {
                            'interval': 0,
                            'http_statuses': [429, 404, 500, 501, 502, 503, 504, 505],
                            'tcp_failures': 0,
                            'timeouts': 0,
                            'http_failures': 0
                        }
                    }
                },
                'tags': [
                    'apigee-migration',
                    f"source:{apigee_data.get('name', 'unknown')}"
                ]
            }
            
            return upstream
        
        return None
    
    def _extract_target_url(self, apigee_data: Dict[str, Any]) -> str:
        """Extract target URL from Apigee configuration."""
        target_endpoints = apigee_data.get('target_endpoints', [])
        
        if target_endpoints:
            return target_endpoints[0].get('url', '')
        
        return ''
    
    def _extract_base_paths(self, apigee_data: Dict[str, Any]) -> List[str]:
        """Extract base paths from Apigee proxy endpoints."""
        base_paths = []
        
        proxy_endpoints = apigee_data.get('proxy_endpoints', [])
        for endpoint in proxy_endpoints:
            base_path = endpoint.get('base_path', '/')
            if base_path and base_path not in base_paths:
                base_paths.append(base_path)
        
        # Fallback to main base_path if no proxy endpoints
        if not base_paths:
            main_base_path = apigee_data.get('base_path', '/')
            base_paths.append(main_base_path)
        
        return base_paths
    
    def _extract_rate_limit_config(self, config: Dict[str, Any]) -> Dict[str, Optional[int]]:
        """Extract rate limiting configuration from Apigee policy."""
        rate_config = {
            'per_minute': None,
            'per_hour': None,
            'per_day': None
        }
        
        # Try to extract rate limits from various Apigee policy formats
        if 'Allow' in config:
            allow_config = config['Allow']
            if isinstance(allow_config, dict):
                count = allow_config.get('Count', allow_config.get('count'))
                interval = allow_config.get('TimeUnit', allow_config.get('timeUnit', '')).lower()
                
                if count and interval:
                    try:
                        count = int(count)
                        if 'minute' in interval:
                            rate_config['per_minute'] = count
                        elif 'hour' in interval:
                            rate_config['per_hour'] = count
                        elif 'day' in interval:
                            rate_config['per_day'] = count
                    except ValueError:
                        pass
        
        # Set defaults if no configuration found
        if not any(rate_config.values()):
            rate_config['per_minute'] = 100  # Default rate limit
        
        return rate_config
    
    def _sanitize_name(self, name: str) -> str:
        """Sanitize name for Kong compatibility."""
        # Kong names should be alphanumeric with hyphens and underscores
        import re
        sanitized = re.sub(r'[^a-zA-Z0-9\-_]', '-', name.lower())
        sanitized = re.sub(r'-+', '-', sanitized)  # Remove multiple consecutive hyphens
        sanitized = sanitized.strip('-')  # Remove leading/trailing hyphens
        
        return sanitized or 'unknown'
    
    def _create_spike_arrest_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong rate limiting plugin from Apigee spike arrest policy."""
        config = policy.get('configuration', {})
        
        # Spike arrest is similar to rate limiting but typically more aggressive
        rate = self._extract_spike_arrest_config(config)
        
        plugin = {
            'name': 'rate-limiting',
            'id': self._generate_plugin_id('rate-limiting', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'second': rate.get('per_second'),
                'minute': rate.get('per_minute'),
                'hour': rate.get('per_hour'),
                'policy': 'local',
                'fault_tolerant': False,  # Spike arrest is typically strict
                'hide_client_headers': False
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'spike-arrest'
            ],
        }
        
        return plugin
    
    def _create_access_control_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong IP restriction plugin from Apigee access control policy."""
        config = policy.get('configuration', {})
        
        plugin = {
            'name': 'ip-restriction',
            'id': self._generate_plugin_id('ip-restriction', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'allow': config.get('AllowedIPs', []),
                'deny': config.get('DeniedIPs', [])
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'access-control'
            ],
        }
        
        return plugin
    
    def _create_cache_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong proxy cache plugin from Apigee response cache policy."""
        config = policy.get('configuration', {})
        
        plugin = {
            'name': 'proxy-cache',
            'id': self._generate_plugin_id('proxy-cache', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'response_code': [200, 301, 404],
                'request_method': ['GET', 'HEAD'],
                'content_type': ['text/plain', 'application/json'],
                'cache_ttl': config.get('ExpirySettings', {}).get('TimeoutInSec', 300),
                'strategy': 'memory'
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'caching'
            ],
        }
        
        return plugin
    
    def _create_validation_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong request validation plugin from Apigee validation policies."""
        plugin = {
            'name': 'request-validator',
            'id': self._generate_plugin_id('request-validator', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'version': 'draft4',
                'body_schema': '{}',  # Would need to extract from policy config
                'allowed_content_types': ['application/json', 'application/xml']
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'validation'
            ],
        }
        
        return plugin
    
    def _create_service_callout_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong HTTP proxy plugin from Apigee service callout policy."""
        config = policy.get('configuration', {})
        
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, flow.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Service callout for {policy.get('name', 'unknown')}",
                    "-- This requires custom implementation",
                    f"-- Original URL: {config.get('HTTPTargetConnection', {}).get('URL', 'unknown')}"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'service-callout',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_logging_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong logging plugin from Apigee message logging policy."""
        plugin = {
            'name': 'file-log',
            'id': self._generate_plugin_id('file-log', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'path': '/tmp/kong.log'
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'logging'
            ],
        }
        
        return plugin
    
    def _create_kvm_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for key-value map operations."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, rule.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- KVM operations for {policy.get('name', 'unknown')}",
                    "-- This requires custom implementation using Kong's shared dictionary",
                    "-- or external storage like Redis"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'kvm',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_fault_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for raise fault policy."""
        config = policy.get('configuration', {})
        
        plugin = {
            'name': 'request-termination',
            'id': self._generate_plugin_id('request-termination', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'status_code': config.get('FaultResponse', {}).get('StatusCode', 400),
                'message': config.get('FaultResponse', {}).get('ReasonPhrase', 'Bad Request')
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'fault-handling'
            ],
        }
        
        return plugin
    
    def _create_data_transformation_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for data transformation policies."""
        policy_type = policy.get('type', '').lower()
        
        if 'xmltojson' in policy_type:
            transform_type = 'XML to JSON'
        elif 'jsontoxml' in policy_type:
            transform_type = 'JSON to XML'
        elif 'xsl' in policy_type:
            transform_type = 'XSL Transform'
        else:
            transform_type = 'Data Transform'
        
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- {transform_type} for {policy.get('name', 'unknown')}",
                    "-- This requires custom Lua implementation",
                    "-- Consider using Kong's request/response transformer plugins"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'data-transformation',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_jws_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong JWT plugin for JWS policies."""
        plugin = {
            'name': 'jwt',
            'id': self._generate_plugin_id('jwt', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'uri_param_names': ['jwt'],
                'header_names': ['authorization'],
                'claims_to_verify': ['exp', 'iss'],
                'key_claim_name': 'iss'
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'jws'
            ],
        }
        
        return plugin
    
    def _create_saml_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for SAML policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- SAML processing for {policy.get('name', 'unknown')}",
                    "-- This requires custom SAML implementation",
                    "-- Consider using Kong Enterprise SAML plugin or custom Lua script"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'saml',
                'requires-enterprise-or-custom'
            ],
        }
        
        return plugin
    
    def _create_hmac_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong HMAC plugin from Apigee HMAC policy."""
        plugin = {
            'name': 'hmac-auth',
            'id': self._generate_plugin_id('hmac-auth', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'hide_credentials': True,
                'clock_skew': 300
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'hmac'
            ],
        }
        
        return plugin
    
    def _create_script_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for script policies."""
        config = policy.get('configuration', {})
        script_type = config.get('ResourceURL', '').split('.')[-1] if config.get('ResourceURL') else 'unknown'
        
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Script execution for {policy.get('name', 'unknown')}",
                    f"-- Original script type: {script_type}",
                    "-- This requires porting the script logic to Lua",
                    "-- Script resource: " + config.get('ResourceURL', 'unknown')
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'script',
                'requires-porting'
            ],
        }
        
        return plugin
    
    def _create_external_callout_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for external callout policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- External callout for {policy.get('name', 'unknown')}",
                    "-- This requires custom implementation",
                    "-- Consider using Kong's HTTP service or custom plugin"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'external-callout',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_publish_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for publish message policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Message publishing for {policy.get('name', 'unknown')}",
                    "-- This requires integration with message queue",
                    "-- Consider using Kong's HTTP service to publish to queue"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'message-publishing',
                'requires-queue-integration'
            ],
        }
        
        return plugin
    
    def _create_http_modifier_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong request transformer plugin for HTTP modifier policies."""
        plugin = {
            'name': 'request-transformer',
            'id': self._generate_plugin_id('request-transformer', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'add': {
                    'headers': [f'X-Modified-By:{policy.get("name", "unknown")}']
                }
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'http-modifier'
            ],
        }
        
        return plugin
    
    def _create_assert_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for assert condition policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Condition assertion for {policy.get('name', 'unknown')}",
                    "-- This requires custom Lua implementation",
                    "-- Implement condition checking logic"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'assertion',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_access_entity_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create Kong plugin for access entity policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Entity access for {policy.get('name', 'unknown')}",
                    "-- This requires custom implementation",
                    "-- Access entity data from Kong's data store"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'entity-access',
                'requires-custom-implementation'
            ],
        }
        
        return plugin
    
    def _create_generic_plugin(self, policy: Dict[str, Any], service_name: str) -> Dict[str, Any]:
        """Create generic Kong plugin for unsupported policies."""
        plugin = {
            'name': 'pre-function',
            'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
            'service': service_name,
            'config': {
                'access': [
                    f"-- Generic handler for {policy.get('name', 'unknown')}",
                    f"-- Policy type: {policy.get('type', 'unknown')}",
                    "-- This policy requires manual implementation",
                    "-- Review Apigee policy configuration and implement equivalent logic"
                ]
            },
            'tags': [
                'apigee-migration',
                f"source-policy:{policy.get('name', 'unknown')}",
                'generic',
                'requires-manual-implementation'
            ],
        }
        
        return plugin
    
    def _extract_spike_arrest_config(self, config: Dict[str, Any]) -> Dict[str, Optional[int]]:
        """Extract spike arrest configuration from Apigee policy."""
        rate_config = {
            'per_second': None,
            'per_minute': None,
            'per_hour': None
        }
        
        # Try to extract rate limits from Apigee spike arrest format
        if 'Rate' in config:
            rate_str = config['Rate']
            if isinstance(rate_str, str):
                # Parse formats like "10ps", "100pm", "1000ph"
                import re
                match = re.match(r'(\d+)(ps|pm|ph)', rate_str.lower())
                if match:
                    count = int(match.group(1))
                    unit = match.group(2)
                    
                    if unit == 'ps':
                        rate_config['per_second'] = count
                    elif unit == 'pm':
                        rate_config['per_minute'] = count
                    elif unit == 'ph':
                        rate_config['per_hour'] = count
        
        # Set defaults if no configuration found
        if not any(rate_config.values()):
            rate_config['per_minute'] = 60  # Default spike arrest rate
        
        return rate_config
    
    def _safe_get_config_value(self, config: Dict[str, Any], keys: List[str], default: Any) -> Any:
        """Safely get configuration value from multiple possible keys."""
        for key in keys:
            if isinstance(config, dict) and key in config:
                return config[key]
        return default
    
    def _convert_route_rules_to_routes(self, apigee_data: Dict[str, Any], service_name: str) -> List[Dict[str, Any]]:
        """Convert Apigee RouteRules to Kong routes."""
        routes = []
        
        for endpoint in apigee_data.get('proxy_endpoints', []):
            route_rules = endpoint.get('route_rules', [])
            
            for i, rule in enumerate(route_rules):
                route_name = f"{service_name}-routerule-{rule.get('name', i)}"
                
                # Create route with condition-based configuration
                route = {
                    'name': route_name,
                    'service': {'name': service_name},
                    'paths': [endpoint.get('base_path', '/')],
                    'methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'],
                    'strip_path': False,
                    'preserve_host': False,
                    'tags': [
                        'apigee-migration',
                        'route-rule',
                        f"source:{apigee_data.get('name', 'unknown')}",
                        f"condition:{rule.get('condition', 'none')}"
                    ]
                }
                
                # Add condition as metadata
                if rule.get('condition'):
                    route['tags'].append(f"apigee-condition:{rule['condition']}")
                    
                    # Store condition for microservice processing
                    self.apigee_metadata['route_rules'].append({
                        'route_name': route_name,
                        'condition': rule['condition'],
                        'target_endpoint': rule.get('target_endpoint'),
                        'url': rule.get('url')
                    })
                
                routes.append(route)
                
                # Add note about condition handling
                self.apigee_metadata['conversion_notes'].append(
                    f"RouteRule '{rule.get('name')}' with condition '{rule.get('condition')}' "
                    f"requires custom Kong plugin or Lua script for condition evaluation"
                )
        
        return routes
    
    def _convert_conditional_flows_to_plugins(self, apigee_data: Dict[str, Any], service_name: str) -> List[Dict[str, Any]]:
        """Convert Apigee conditional flows to Kong plugins."""
        plugins = []
        
        for endpoint in apigee_data.get('proxy_endpoints', []) + apigee_data.get('target_endpoints', []):
            flows = endpoint.get('flows', [])
            
            for flow in flows:
                if flow.get('is_conditional') and flow.get('condition'):
                    # Create a plugin to handle conditional flow
                    plugin = {
                        'name': 'pre-function',
                        'id': self._generate_plugin_id('pre-function', service_name, flow.get('name', 'unknown')),
                        'service': service_name,
                        'config': {
                            'access': [
                                f"-- Conditional Flow: {flow.get('name', 'unknown')}",
                                f"-- Condition: {flow['condition']}",
                                "-- This requires custom Lua implementation to evaluate condition",
                                "",
                                "-- Request policies:",
                                *[f"--   - {step}" for step in flow.get('request', [])],
                                "",
                                "-- Response policies:",
                                *[f"--   - {step}" for step in flow.get('response', [])],
                                "",
                                "-- Use Apigee Policy Microservice for policy execution:",
                                "-- local http = require 'resty.http'",
                                "-- local httpc = http.new()",
                                f"-- local condition = '{flow['condition']}'",
                                "-- if evaluate_condition(condition) then",
                                "--   execute_policies(request_policies)",
                                "-- end"
                            ]
                        },
                        'tags': [
                            'apigee-migration',
                            'conditional-flow',
                            f"source-flow:{flow.get('name', 'unknown')}",
                            f"condition:{flow['condition']}",
                            'requires-custom-implementation'
                        ]
                    }
                    
                    plugins.append(plugin)
                    
                    # Store metadata
                    self.apigee_metadata['conditional_flows'].append({
                        'flow_name': flow.get('name'),
                        'condition': flow['condition'],
                        'request_policies': flow.get('request', []),
                        'response_policies': flow.get('response', [])
                    })
        
        return plugins
    
    def _convert_fault_rules_to_plugins(self, apigee_data: Dict[str, Any], service_name: str) -> List[Dict[str, Any]]:
        """Convert Apigee FaultRules to Kong error handling plugins."""
        plugins = []
        
        for endpoint in apigee_data.get('proxy_endpoints', []) + apigee_data.get('target_endpoints', []):
            # Handle FaultRules
            fault_rules = endpoint.get('fault_rules', [])
            
            for rule in fault_rules:
                plugin = {
                    'name': 'pre-function',
                    'id': self._generate_plugin_id('pre-function', service_name, rule.get('name', 'unknown')),
                    'service': service_name,
                    'config': {
                        'access': [
                            f"-- Fault Rule: {rule.get('name', 'unknown')}",
                            f"-- Condition: {rule.get('condition', 'any error')}",
                            "-- This handles errors matching the condition",
                            "",
                            "-- Error handling policies:",
                            *[f"--   - {step}" for step in rule.get('steps', [])],
                            "",
                            "-- Implementation using Kong error handling:",
                            "-- kong.response.error(status_code, message, headers)"
                        ]
                    },
                    'tags': [
                        'apigee-migration',
                        'fault-rule',
                        f"source-rule:{rule.get('name', 'unknown')}",
                        f"condition:{rule.get('condition', 'any')}",
                        'error-handling'
                    ]
                }
                
                plugins.append(plugin)
                
                # Store metadata
                self.apigee_metadata['fault_rules'].append({
                    'rule_name': rule.get('name'),
                    'condition': rule.get('condition'),
                    'steps': rule.get('steps', [])
                })
            
            # Handle DefaultFaultRule
            default_fault_rule = endpoint.get('default_fault_rule', {})
            if default_fault_rule and default_fault_rule.get('steps'):
                plugin = {
                    'name': 'pre-function',
                    'id': self._generate_plugin_id('pre-function', service_name, policy.get('name', 'unknown')),
                    'service': service_name,
                    'config': {
                        'access': [
                            "-- Default Fault Rule",
                            "-- This handles all errors not caught by specific fault rules",
                            "",
                            "-- Error handling policies:",
                            *[f"--   - {step}" for step in default_fault_rule.get('steps', [])],
                            "",
                            "-- Implementation:",
                            "-- Use Kong's error handling hooks",
                            "-- kong.log.err('Error occurred: ', err)",
                            "-- kong.response.error(500, 'Internal Server Error')"
                        ]
                    },
                    'tags': [
                        'apigee-migration',
                        'default-fault-rule',
                        'error-handling'
                    ]
                }
                
                plugins.append(plugin)
        
        return plugins