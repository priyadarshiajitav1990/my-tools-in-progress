"""
Apigee Proxy Bundle Parser
==========================

Parses Apigee proxy bundle ZIP files and extracts configuration data
for conversion to Kong Gateway format.
"""

import zipfile
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging
from core.exceptions import ApigeeParsingError, FileProcessingError


class ApigeeProxyParser:
    """Parses Apigee proxy bundles and extracts configuration data."""
    
    def __init__(self, logger: logging.Logger):
        """
        Initialize Apigee proxy parser.
        
        Args:
            logger: Logger instance for logging operations
        """
        self.logger = logger
        self.proxy_data: Dict[str, Any] = {}
    
    def parse_proxy_bundle(self, bundle_path: str) -> Dict[str, Any]:
        """
        Parse Apigee proxy bundle ZIP file.
        
        Args:
            bundle_path: Path to the Apigee proxy bundle ZIP file
            
        Returns:
            Dictionary containing parsed proxy configuration
            
        Raises:
            ApigeeParsingError: If parsing fails
            FileProcessingError: If file operations fail
        """
        self.logger.info(f"Starting to parse Apigee proxy bundle: {bundle_path}")
        
        try:
            bundle_path = Path(bundle_path)
            if not bundle_path.exists():
                raise FileProcessingError(f"Proxy bundle file not found: {bundle_path}")
            
            if not bundle_path.suffix.lower() == '.zip':
                raise ApigeeParsingError(f"Invalid file format. Expected ZIP file: {bundle_path}")
            
            with zipfile.ZipFile(bundle_path, 'r') as zip_file:
                self.proxy_data = self._extract_proxy_data(zip_file)
            
            self.logger.info(f"Successfully parsed proxy bundle: {self.proxy_data.get('name', 'Unknown')}")
            return self.proxy_data
            
        except zipfile.BadZipFile:
            raise ApigeeParsingError(f"Invalid ZIP file: {bundle_path}")
        except Exception as e:
            raise ApigeeParsingError(f"Failed to parse proxy bundle: {str(e)}")
    
    def _extract_proxy_data(self, zip_file: zipfile.ZipFile) -> Dict[str, Any]:
        """Extract and parse proxy data from ZIP file."""
        proxy_data = {
            'name': '',
            'display_name': '',
            'description': '',
            'base_path': '',
            'target_url': '',
            'policies': [],
            'flows': [],
            'resources': [],
            'proxy_endpoints': [],
            'target_endpoints': [],
            'security': {},
            'rate_limiting': {},
            'cors': {},
            'transformations': []
        }
        
        # Parse proxy configuration
        proxy_data.update(self._parse_proxy_configuration(zip_file))
        
        # Parse proxy endpoints
        proxy_data['proxy_endpoints'] = self._parse_proxy_endpoints(zip_file)
        
        # Parse target endpoints
        proxy_data['target_endpoints'] = self._parse_target_endpoints(zip_file)
        
        # Parse policies
        proxy_data['policies'] = self._parse_policies(zip_file)
        
        # Parse resources
        proxy_data['resources'] = self._parse_resources(zip_file)
        
        return proxy_data
    
    def _parse_proxy_configuration(self, zip_file: zipfile.ZipFile) -> Dict[str, Any]:
        """Parse main proxy configuration file."""
        config_data = {}
        
        try:
            # Look for proxy configuration files
            proxy_files = [f for f in zip_file.namelist() if f.endswith('.xml') and 'apiproxy' in f.lower()]
            
            if not proxy_files:
                raise ApigeeParsingError("No proxy configuration file found")
            
            # Parse the main proxy file
            proxy_file = proxy_files[0]
            with zip_file.open(proxy_file) as f:
                root = ET.parse(f).getroot()
                
                config_data['name'] = root.get('name', '')
                config_data['display_name'] = self._get_element_text(root, 'DisplayName')
                config_data['description'] = self._get_element_text(root, 'Description')
                
                # Extract base path from proxy endpoints
                proxy_endpoints = root.findall('.//ProxyEndpoint')
                if proxy_endpoints:
                    config_data['base_path'] = self._extract_base_path(proxy_endpoints[0])
                
        except ET.ParseError as e:
            raise ApigeeParsingError(f"Failed to parse proxy configuration XML: {str(e)}")
        except Exception as e:
            self.logger.warning(f"Error parsing proxy configuration: {str(e)}")
        
        return config_data
    
    def _parse_proxy_endpoints(self, zip_file: zipfile.ZipFile) -> List[Dict[str, Any]]:
        """Parse proxy endpoint configurations."""
        endpoints = []
        
        try:
            endpoint_files = [f for f in zip_file.namelist() 
                            if 'proxies/' in f and f.endswith('.xml')]
            
            for endpoint_file in endpoint_files:
                with zip_file.open(endpoint_file) as f:
                    root = ET.parse(f).getroot()
                    
                    endpoint_data = {
                        'name': root.get('name', ''),
                        'base_path': self._extract_base_path(root),
                        'http_proxy_connection': self._parse_http_proxy_connection(root),
                        'flows': self._parse_flows(root),
                        'pre_flow': self._parse_pre_flow(root),
                        'post_flow': self._parse_post_flow(root),
                        'route_rules': self._parse_route_rules(root),
                        'fault_rules': self._parse_fault_rules(root),
                        'default_fault_rule': self._parse_default_fault_rule(root)
                    }
                    
                    endpoints.append(endpoint_data)
                    
        except Exception as e:
            self.logger.warning(f"Error parsing proxy endpoints: {str(e)}")
        
        return endpoints
    
    def _parse_target_endpoints(self, zip_file: zipfile.ZipFile) -> List[Dict[str, Any]]:
        """Parse target endpoint configurations."""
        endpoints = []
        
        try:
            endpoint_files = [f for f in zip_file.namelist() 
                            if 'targets/' in f and f.endswith('.xml')]
            
            for endpoint_file in endpoint_files:
                with zip_file.open(endpoint_file) as f:
                    root = ET.parse(f).getroot()
                    
                    endpoint_data = {
                        'name': root.get('name', ''),
                        'url': self._extract_target_url(root),
                        'http_target_connection': self._parse_http_target_connection(root),
                        'flows': self._parse_flows(root),
                        'pre_flow': self._parse_pre_flow(root),
                        'post_flow': self._parse_post_flow(root),
                        'fault_rules': self._parse_fault_rules(root),
                        'default_fault_rule': self._parse_default_fault_rule(root)
                    }
                    
                    endpoints.append(endpoint_data)
                    
        except Exception as e:
            self.logger.warning(f"Error parsing target endpoints: {str(e)}")
        
        return endpoints
    
    def _parse_policies(self, zip_file: zipfile.ZipFile) -> List[Dict[str, Any]]:
        """Parse policy configurations."""
        policies = []
        
        try:
            policy_files = [f for f in zip_file.namelist() 
                          if 'policies/' in f and f.endswith('.xml')]
            
            for policy_file in policy_files:
                with zip_file.open(policy_file) as f:
                    root = ET.parse(f).getroot()
                    
                    policy_data = {
                        'name': root.get('name', ''),
                        'type': root.tag,
                        'display_name': self._get_element_text(root, 'DisplayName'),
                        'configuration': self._parse_policy_configuration(root)
                    }
                    
                    policies.append(policy_data)
                    
        except Exception as e:
            self.logger.warning(f"Error parsing policies: {str(e)}")
        
        return policies
    
    def _parse_resources(self, zip_file: zipfile.ZipFile) -> List[Dict[str, Any]]:
        """Parse resource files."""
        resources = []
        
        try:
            resource_files = [f for f in zip_file.namelist() 
                            if 'resources/' in f and not f.endswith('/')]
            
            for resource_file in resource_files:
                resource_data = {
                    'name': Path(resource_file).name,
                    'path': resource_file,
                    'type': self._determine_resource_type(resource_file),
                    'size': zip_file.getinfo(resource_file).file_size
                }
                
                resources.append(resource_data)
                
        except Exception as e:
            self.logger.warning(f"Error parsing resources: {str(e)}")
        
        return resources
    
    def _get_element_text(self, parent: ET.Element, tag_name: str) -> str:
        """Get text content of an XML element."""
        element = parent.find(tag_name)
        return element.text if element is not None and element.text else ''
    
    def _extract_base_path(self, endpoint: ET.Element) -> str:
        """Extract base path from endpoint configuration."""
        http_proxy = endpoint.find('.//HTTPProxyConnection')
        if http_proxy is not None:
            base_path = http_proxy.find('BasePath')
            if base_path is not None and base_path.text:
                return base_path.text
        return '/'
    
    def _extract_target_url(self, endpoint: ET.Element) -> str:
        """Extract target URL from endpoint configuration."""
        http_target = endpoint.find('.//HTTPTargetConnection')
        if http_target is not None:
            url_element = http_target.find('URL')
            if url_element is not None and url_element.text:
                return url_element.text
        return ''
    
    def _parse_http_proxy_connection(self, root: ET.Element) -> Dict[str, Any]:
        """Parse HTTP proxy connection configuration."""
        connection = {}
        http_proxy = root.find('.//HTTPProxyConnection')
        
        if http_proxy is not None:
            connection['base_path'] = self._get_element_text(http_proxy, 'BasePath')
            connection['virtual_host'] = self._get_element_text(http_proxy, 'VirtualHost')
            
        return connection
    
    def _parse_http_target_connection(self, root: ET.Element) -> Dict[str, Any]:
        """Parse HTTP target connection configuration."""
        connection = {}
        http_target = root.find('.//HTTPTargetConnection')
        
        if http_target is not None:
            connection['url'] = self._get_element_text(http_target, 'URL')
            
            # Parse SSL info if present
            ssl_info = http_target.find('SSLInfo')
            if ssl_info is not None:
                connection['ssl'] = {
                    'enabled': ssl_info.find('Enabled') is not None,
                    'client_auth_enabled': ssl_info.find('ClientAuthEnabled') is not None,
                    'keystore': self._get_element_text(ssl_info, 'KeyStore'),
                    'truststore': self._get_element_text(ssl_info, 'TrustStore')
                }
        
        return connection
    
    def _parse_flows(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Parse flow configurations including conditional flows."""
        flows = []
        flow_elements = root.findall('.//Flow')
        
        for flow in flow_elements:
            flow_data = {
                'name': flow.get('name', ''),
                'condition': self._get_element_text(flow, 'Condition'),
                'description': self._get_element_text(flow, 'Description'),
                'request': self._parse_flow_steps(flow, 'Request'),
                'response': self._parse_flow_steps(flow, 'Response'),
                'is_conditional': bool(self._get_element_text(flow, 'Condition'))
            }
            flows.append(flow_data)
        
        return flows
    
    def _parse_route_rules(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Parse RouteRule configurations."""
        route_rules = []
        route_rule_elements = root.findall('.//RouteRule')
        
        for rule in route_rule_elements:
            rule_data = {
                'name': rule.get('name', ''),
                'condition': self._get_element_text(rule, 'Condition'),
                'target_endpoint': self._get_element_text(rule, 'TargetEndpoint'),
                'url': self._get_element_text(rule, 'URL')
            }
            route_rules.append(rule_data)
        
        return route_rules
    
    def _parse_fault_rules(self, root: ET.Element) -> List[Dict[str, Any]]:
        """Parse FaultRule configurations."""
        fault_rules = []
        fault_rule_elements = root.findall('.//FaultRule')
        
        for rule in fault_rule_elements:
            rule_data = {
                'name': rule.get('name', ''),
                'condition': self._get_element_text(rule, 'Condition'),
                'steps': self._parse_flow_steps(rule, 'Step')
            }
            fault_rules.append(rule_data)
        
        return fault_rules
    
    def _parse_default_fault_rule(self, root: ET.Element) -> Dict[str, Any]:
        """Parse DefaultFaultRule configuration."""
        default_fault_rule = root.find('.//DefaultFaultRule')
        if default_fault_rule is not None:
            return {
                'always_enforce': default_fault_rule.get('name') == 'true',
                'steps': self._parse_flow_steps(default_fault_rule, 'Step')
            }
        return {}
    
    def _parse_pre_flow(self, root: ET.Element) -> Dict[str, Any]:
        """Parse pre-flow configuration."""
        pre_flow = root.find('.//PreFlow')
        if pre_flow is not None:
            return {
                'request': self._parse_flow_steps(pre_flow, 'Request'),
                'response': self._parse_flow_steps(pre_flow, 'Response')
            }
        return {}
    
    def _parse_post_flow(self, root: ET.Element) -> Dict[str, Any]:
        """Parse post-flow configuration."""
        post_flow = root.find('.//PostFlow')
        if post_flow is not None:
            return {
                'request': self._parse_flow_steps(post_flow, 'Request'),
                'response': self._parse_flow_steps(post_flow, 'Response')
            }
        return {}
    
    def _parse_flow_steps(self, flow: ET.Element, step_type: str) -> List[str]:
        """Parse flow steps for request or response."""
        steps = []
        step_elements = flow.findall(f'.//{step_type}/Step')
        
        for step in step_elements:
            name_element = step.find('Name')
            if name_element is not None and name_element.text:
                steps.append(name_element.text)
        
        return steps
    
    def _parse_policy_configuration(self, root: ET.Element) -> Dict[str, Any]:
        """Parse policy-specific configuration."""
        config = {}
        
        # This is a simplified parser - in production, you'd want specific
        # parsers for each policy type (RateLimiting, CORS, etc.)
        for child in root:
            if child.tag not in ['DisplayName', 'Properties']:
                config[child.tag] = child.text or self._element_to_dict(child)
        
        return config
    
    def _element_to_dict(self, element: ET.Element) -> Dict[str, Any]:
        """Convert XML element to dictionary."""
        result = {}
        
        # Add attributes
        if element.attrib:
            result.update(element.attrib)
        
        # Add text content
        if element.text and element.text.strip():
            if len(element) == 0:
                return element.text.strip()
            result['text'] = element.text.strip()
        
        # Add child elements
        for child in element:
            child_data = self._element_to_dict(child)
            if child.tag in result:
                if not isinstance(result[child.tag], list):
                    result[child.tag] = [result[child.tag]]
                result[child.tag].append(child_data)
            else:
                result[child.tag] = child_data
        
        return result
    
    def _determine_resource_type(self, file_path: str) -> str:
        """Determine resource type based on file extension."""
        extension = Path(file_path).suffix.lower()
        
        type_mapping = {
            '.js': 'javascript',
            '.py': 'python',
            '.java': 'java',
            '.json': 'json',
            '.xml': 'xml',
            '.xsl': 'xslt',
            '.xslt': 'xslt',
            '.properties': 'properties',
            '.wsdl': 'wsdl'
        }
        
        return type_mapping.get(extension, 'unknown')