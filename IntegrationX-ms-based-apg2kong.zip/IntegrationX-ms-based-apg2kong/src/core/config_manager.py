"""
Configuration Manager Module
===========================

Handles all configuration loading, validation, and management for the migration tool.
Supports environment variables, config files, and runtime overrides.
"""

import os
import sys
import platform
from typing import Dict, Any, Optional
from pathlib import Path
import logging


class ConfigManager:
    """Manages application configuration with OS-independent path handling."""
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize configuration manager.
        
        Args:
            config_file: Optional path to configuration file
        """
        self.config_file = config_file or self._get_default_config_path()
        self.config: Dict[str, Any] = {}
        self.os_info = self._detect_os_info()
        self._load_configuration()
    
    def _detect_os_info(self) -> Dict[str, str]:
        """Detect operating system information for cross-platform compatibility."""
        return {
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python_version': platform.python_version(),
            'path_separator': os.sep,
            'line_separator': os.linesep
        }
    
    def _get_default_config_path(self) -> str:
        """Get default configuration file path based on OS."""
        base_path = Path(__file__).parent.parent.parent
        return str(base_path / "config" / "config.env")
    
    def _load_configuration(self) -> None:
        """Load configuration from file and environment variables."""
        # Default configuration
        self.config = {
            'LOG_LEVEL': 'INFO',
            'LOG_FORMAT': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            'LOG_FILE': 'logs/migration.log',
            'MAX_LOG_SIZE': 10485760,
            'BACKUP_COUNT': 5,
            'INPUT_DIR': 'input',
            'OUTPUT_DIR': 'output',
            'BACKUP_DIR': 'backup',
            'KONG_ADMIN_API_VERSION': 'v1',
            'KONG_DEFAULT_PROTOCOL': 'http',
            'KONG_DEFAULT_HOST': 'localhost',
            'KONG_DEFAULT_PORT': 8000,
            'PRESERVE_ORIGINAL_STRUCTURE': True,
            'VALIDATE_OUTPUT': True,
            'CREATE_BACKUP': True,
            'OVERWRITE_EXISTING': False,
            'MAX_CONCURRENT_PROCESSES': 4,
            'CHUNK_SIZE': 1024,
            'TIMEOUT_SECONDS': 30
        }
        
        # Load from config file if exists
        if os.path.exists(self.config_file):
            self._load_from_file()
        
        # Override with environment variables
        self._load_from_environment()
        
        # Convert string booleans to actual booleans
        self._convert_boolean_values()
    
    def _load_from_file(self) -> None:
        """Load configuration from file."""
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        self.config[key.strip()] = value.strip()
        except Exception as e:
            logging.warning(f"Could not load config file {self.config_file}: {e}")
    
    def _load_from_environment(self) -> None:
        """Load configuration from environment variables."""
        for key in self.config.keys():
            env_value = os.getenv(key)
            if env_value is not None:
                self.config[key] = env_value
    
    def _convert_boolean_values(self) -> None:
        """Convert string boolean values to actual booleans."""
        boolean_keys = [
            'PRESERVE_ORIGINAL_STRUCTURE', 'VALIDATE_OUTPUT', 
            'CREATE_BACKUP', 'OVERWRITE_EXISTING'
        ]
        
        for key in boolean_keys:
            if key in self.config:
                value = str(self.config[key]).lower()
                self.config[key] = value in ('true', '1', 'yes', 'on')
        
        # Convert numeric values
        numeric_keys = [
            'MAX_LOG_SIZE', 'BACKUP_COUNT', 'KONG_DEFAULT_PORT',
            'MAX_CONCURRENT_PROCESSES', 'CHUNK_SIZE', 'TIMEOUT_SECONDS'
        ]
        
        for key in numeric_keys:
            if key in self.config:
                try:
                    self.config[key] = int(self.config[key])
                except (ValueError, TypeError):
                    pass  # Keep original value if conversion fails
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self.config.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """Set configuration value."""
        self.config[key] = value
    
    def get_path(self, path_key: str) -> Path:
        """Get OS-independent path from configuration."""
        path_str = self.get(path_key, '')
        if not path_str:
            raise ValueError(f"Path configuration '{path_key}' not found")
        
        # Convert to Path object for OS independence
        base_path = Path(__file__).parent.parent.parent
        return base_path / path_str
    
    def ensure_directories(self) -> None:
        """Ensure all required directories exist."""
        directories = ['INPUT_DIR', 'OUTPUT_DIR', 'BACKUP_DIR']
        
        for dir_key in directories:
            dir_path = self.get_path(dir_key)
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Ensure logs directory exists
        log_file_path = Path(self.get('LOG_FILE'))
        log_file_path.parent.mkdir(parents=True, exist_ok=True)
    
    def is_windows(self) -> bool:
        """Check if running on Windows."""
        return self.os_info['system'].lower() == 'windows'
    
    def is_linux(self) -> bool:
        """Check if running on Linux."""
        return self.os_info['system'].lower() == 'linux'
    
    def is_macos(self) -> bool:
        """Check if running on macOS."""
        return self.os_info['system'].lower() == 'darwin'
    
    def get_os_info(self) -> Dict[str, str]:
        """Get operating system information."""
        return self.os_info.copy()
    
    def validate_configuration(self) -> bool:
        """Validate configuration values."""
        required_keys = [
            'INPUT_DIR', 'OUTPUT_DIR', 'LOG_LEVEL', 'LOG_FILE'
        ]
        
        for key in required_keys:
            if key not in self.config or not self.config[key]:
                raise ValueError(f"Required configuration '{key}' is missing or empty")
        
        # Validate log level
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.get('LOG_LEVEL') not in valid_log_levels:
            raise ValueError(f"Invalid log level: {self.get('LOG_LEVEL')}")
        
        return True