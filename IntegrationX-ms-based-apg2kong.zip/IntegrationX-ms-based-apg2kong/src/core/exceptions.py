"""
Custom Exceptions Module
========================

Defines custom exceptions for the Apigee to Kong migration tool.
Provides specific error types for better error handling and debugging.
"""


class MigrationToolError(Exception):
    """Base exception for all migration tool errors."""
    
    def __init__(self, message: str, error_code: str = None):
        """
        Initialize migration tool error.
        
        Args:
            message: Error message
            error_code: Optional error code for categorization
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "GENERAL_ERROR"


class ConfigurationError(MigrationToolError):
    """Raised when there's a configuration-related error."""
    
    def __init__(self, message: str):
        super().__init__(message, "CONFIG_ERROR")


class FileProcessingError(MigrationToolError):
    """Raised when there's an error processing files."""
    
    def __init__(self, message: str, file_path: str = None):
        super().__init__(message, "FILE_PROCESSING_ERROR")
        self.file_path = file_path


class ApigeeParsingError(MigrationToolError):
    """Raised when there's an error parsing Apigee proxy bundle."""
    
    def __init__(self, message: str, proxy_name: str = None):
        super().__init__(message, "APIGEE_PARSING_ERROR")
        self.proxy_name = proxy_name


class KongConfigurationError(MigrationToolError):
    """Raised when there's an error generating Kong configuration."""
    
    def __init__(self, message: str, service_name: str = None):
        super().__init__(message, "KONG_CONFIG_ERROR")
        self.service_name = service_name


class ValidationError(MigrationToolError):
    """Raised when validation fails."""
    
    def __init__(self, message: str, validation_type: str = None):
        super().__init__(message, "VALIDATION_ERROR")
        self.validation_type = validation_type


class NetworkError(MigrationToolError):
    """Raised when there's a network-related error."""
    
    def __init__(self, message: str, url: str = None):
        super().__init__(message, "NETWORK_ERROR")
        self.url = url


class BackupError(MigrationToolError):
    """Raised when there's an error creating or managing backups."""
    
    def __init__(self, message: str, backup_path: str = None):
        super().__init__(message, "BACKUP_ERROR")
        self.backup_path = backup_path