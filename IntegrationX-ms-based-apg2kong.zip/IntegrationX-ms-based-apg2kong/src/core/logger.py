"""
Logging Module
==============

Provides comprehensive logging functionality with file rotation, 
multiple log levels, and OS-independent file handling.
"""

import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Optional
from .config_manager import ConfigManager


class LoggerManager:
    """Manages application logging with enterprise-grade features."""
    
    def __init__(self, config_manager: ConfigManager, logger_name: str = 'apigee_kong_migration'):
        """
        Initialize logger manager.
        
        Args:
            config_manager: Configuration manager instance
            logger_name: Name for the logger
        """
        self.config_manager = config_manager
        self.logger_name = logger_name
        self.logger: Optional[logging.Logger] = None
        self._setup_logger()
    
    def _setup_logger(self) -> None:
        """Setup logger with file and console handlers."""
        # Create logger
        self.logger = logging.getLogger(self.logger_name)
        self.logger.setLevel(getattr(logging, self.config_manager.get('LOG_LEVEL', 'INFO')))
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # Create formatter
        formatter = logging.Formatter(
            self.config_manager.get('LOG_FORMAT'),
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Setup file handler with rotation
        self._setup_file_handler(formatter)
        
        # Setup console handler
        self._setup_console_handler(formatter)
    
    def _setup_file_handler(self, formatter: logging.Formatter) -> None:
        """Setup rotating file handler."""
        log_file = Path(self.config_manager.get('LOG_FILE'))
        log_file.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.handlers.RotatingFileHandler(
            filename=str(log_file),
            maxBytes=self.config_manager.get('MAX_LOG_SIZE', 10485760),
            backupCount=self.config_manager.get('BACKUP_COUNT', 5),
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
    
    def _setup_console_handler(self, formatter: logging.Formatter) -> None:
        """Setup console handler with color support."""
        console_handler = logging.StreamHandler(sys.stdout)
        
        # Create colored formatter for console
        if self._supports_color():
            console_formatter = ColoredFormatter(
                self.config_manager.get('LOG_FORMAT'),
                datefmt='%Y-%m-%d %H:%M:%S'
            )
        else:
            console_formatter = formatter
        
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)
    
    def _supports_color(self) -> bool:
        """Check if terminal supports color output."""
        try:
            import colorama
            colorama.init()
            return True
        except ImportError:
            return False
        except Exception:
            return False
    
    def get_logger(self) -> logging.Logger:
        """Get the configured logger instance."""
        return self.logger
    
    def log_system_info(self) -> None:
        """Log system information for debugging."""
        os_info = self.config_manager.get_os_info()
        self.logger.info("=== System Information ===")
        for key, value in os_info.items():
            self.logger.info(f"{key}: {value}")
        self.logger.info("=" * 30)


class ColoredFormatter(logging.Formatter):
    """Custom formatter with color support for different log levels."""
    
    # Color codes
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
        'RESET': '\033[0m'        # Reset
    }
    
    def format(self, record):
        """Format log record with colors."""
        log_color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset_color = self.COLORS['RESET']
        
        # Add color to level name
        record.levelname = f"{log_color}{record.levelname}{reset_color}"
        
        return super().format(record)