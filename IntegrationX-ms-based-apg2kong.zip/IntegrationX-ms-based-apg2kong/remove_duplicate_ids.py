import re

# Read the file
with open('src/converters/kong_converter.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Remove duplicate 'id': lines
new_lines = []
prev_was_id = False

for line in lines:
    is_id_line = "'id': self._generate_plugin_id" in line
    
    if is_id_line and prev_was_id:
        # Skip duplicate ID line
        continue
    
    new_lines.append(line)
    prev_was_id = is_id_line

# Write back
with open('src/converters/kong_converter.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print(f"Removed duplicate ID lines")
