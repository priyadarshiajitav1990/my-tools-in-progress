# Resource File Handling Guide

## 🎯 Overview

Apigee policies often reference external resource files (JavaScript, Java/JAR, Python, XSLT, WSDL, OpenAPI). The microservice provides **multiple strategies** for handling these files during migration and runtime execution.

## 📁 Supported Resource Types

| Resource Type | File Extensions | Associated Policies | Storage Strategy |
|--------------|----------------|---------------------|------------------|
| **JavaScript** | `.js` | JavaScript Policy | Inline, File System, URL |
| **Python** | `.py` | Python Script Policy | Inline, File System, URL |
| **Java/JAR** | `.jar`, `.class` | Java Callout Policy | File System, Classpath |
| **XSLT** | `.xsl`, `.xslt` | XSL Transform Policy | Inline, File System, URL |
| **WSDL** | `.wsdl` | SOAP Service Callout | URL, File System |
| **OpenAPI** | `.json`, `.yaml` | API Validation | URL, File System |
| **XML Schema** | `.xsd` | XML Validation | Inline, File System |

## 🔄 Resource Handling Strategies

### **Strategy 1: Inline Content (Recommended for Small Files)**

Store the file content directly in the policy configuration.

**Advantages:**
- ✅ No external dependencies
- ✅ Version controlled with policy
- ✅ Easy to deploy
- ✅ Fast execution (no I/O)

**Best for:** Small scripts, XSLT templates, schemas

### **Strategy 2: File System Storage**

Store files in the microservice's file system.

**Advantages:**
- ✅ Supports large files
- ✅ Reusable across policies
- ✅ Easy to update
- ✅ Supports JAR files

**Best for:** JAR files, large scripts, shared resources

### **Strategy 3: URL/HTTP Reference**

Reference files via HTTP/HTTPS URLs.

**Advantages:**
- ✅ Centralized management
- ✅ Dynamic updates
- ✅ Shared across services
- ✅ CDN support

**Best for:** Shared schemas, WSDL files, OpenAPI specs

### **Strategy 4: Base64 Encoding**

Encode binary files (JARs) as Base64 in configuration.

**Advantages:**
- ✅ Works with binary files
- ✅ No file system needed
- ✅ Portable

**Best for:** Small JAR files, compiled classes

## 📋 Implementation by Resource Type

### **1. JavaScript Files**

#### **Option A: Inline Script (Recommended)**

```json
{
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "function validateUser(request) {\n  var body = JSON.parse(request.body);\n  if (!body.email) {\n    throw new Error('Email required');\n  }\n  return true;\n}",
    "timeout_ms": 5000
  }
}
```

#### **Option B: File System Reference**

```json
{
  "policy_type": "javascript",
  "policy_config": {
    "script_file": "scripts/validate-user.js",
    "script_base_path": "/app/resources",
    "timeout_ms": 5000
  }
}
```

**File Structure:**
```
microservice/
├── resources/
│   └── scripts/
│       ├── validate-user.js
│       ├── transform-data.js
│       └── enrich-request.js
```

#### **Option C: URL Reference**

```json
{
  "policy_type": "javascript",
  "policy_config": {
    "script_url": "https://cdn.example.com/scripts/validate-user.js",
    "cache_ttl": 3600,
    "timeout_ms": 5000
  }
}
```

### **2. Python Files**

#### **Option A: Inline Script**

```json
{
  "policy_type": "python_script",
  "policy_config": {
    "script_content": "def validate_user(request):\n    import json\n    body = json.loads(request['body'])\n    if 'email' not in body:\n        raise ValueError('Email required')\n    return True",
    "timeout_ms": 5000
  }
}
```

#### **Option B: File System Reference**

```json
{
  "policy_type": "python_script",
  "policy_config": {
    "script_file": "scripts/validate_user.py",
    "script_base_path": "/app/resources",
    "timeout_ms": 5000
  }
}
```

### **3. Java/JAR Files**

#### **Option A: File System with Classpath**

```json
{
  "policy_type": "java_callout",
  "policy_config": {
    "jar_file": "lib/custom-validator-1.0.jar",
    "class_name": "com.example.validators.UserValidator",
    "method_name": "validate",
    "classpath": "/app/resources/lib/*",
    "timeout_seconds": 10
  }
}
```

**File Structure:**
```
microservice/
├── resources/
│   └── lib/
│       ├── custom-validator-1.0.jar
│       ├── commons-lang3-3.12.0.jar
│       └── jackson-core-2.13.0.jar
```

#### **Option B: Base64 Encoded JAR**

```json
{
  "policy_type": "java_callout",
  "policy_config": {
    "jar_content_base64": "UEsDBBQACAgIAAAAIQAAAAAAAAAAAAAAAA...",
    "class_name": "com.example.validators.UserValidator",
    "method_name": "validate",
    "timeout_seconds": 10
  }
}
```

### **4. XSLT Files**

#### **Option A: Inline XSLT**

```json
{
  "policy_type": "xsl_transform",
  "policy_config": {
    "xslt_content": "<?xml version=\"1.0\"?>\n<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n  <xsl:template match=\"/\">\n    <transformed>\n      <xsl:value-of select=\"//user/name\"/>\n    </transformed>\n  </xsl:template>\n</xsl:stylesheet>",
    "source": "request_body",
    "destination": "response_body"
  }
}
```

#### **Option B: File System Reference**

```json
{
  "policy_type": "xsl_transform",
  "policy_config": {
    "xslt_file": "transforms/user-transform.xsl",
    "xslt_base_path": "/app/resources",
    "source": "request_body",
    "destination": "response_body"
  }
}
```

### **5. WSDL Files**

#### **Option A: URL Reference (Recommended)**

```json
{
  "policy_type": "service_callout",
  "policy_config": {
    "wsdl_url": "https://services.example.com/UserService?wsdl",
    "service_name": "UserService",
    "port_name": "UserServicePort",
    "operation": "GetUser",
    "soap_action": "http://example.com/GetUser"
  }
}
```

#### **Option B: File System Reference**

```json
{
  "policy_type": "service_callout",
  "policy_config": {
    "wsdl_file": "wsdl/UserService.wsdl",
    "wsdl_base_path": "/app/resources",
    "service_name": "UserService",
    "operation": "GetUser"
  }
}
```

### **6. OpenAPI/Swagger Files**

#### **Option A: URL Reference**

```json
{
  "policy_type": "api_validation",
  "policy_config": {
    "openapi_url": "https://api.example.com/openapi.json",
    "validate_request": true,
    "validate_response": true,
    "cache_ttl": 3600
  }
}
```

#### **Option B: Inline Specification**

```json
{
  "policy_type": "api_validation",
  "policy_config": {
    "openapi_spec": {
      "openapi": "3.0.0",
      "info": {
        "title": "User API",
        "version": "1.0.0"
      },
      "paths": {
        "/users": {
          "post": {
            "requestBody": {
              "required": true,
              "content": {
                "application/json": {
                  "schema": {
                    "type": "object",
                    "required": ["email"],
                    "properties": {
                      "email": {"type": "string"}
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
```

## 🔧 Enhanced Handler Implementations

### **JavaScript Handler with File Support**

```python
class JavaScriptPolicyHandler(BasePolicyHandler):
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        # Get script content from various sources
        script_content = await self._get_script_content(request.policy_config)
        
        # Execute script
        return await self._execute_javascript(script_content, request)
    
    async def _get_script_content(self, config: Dict[str, Any]) -> str:
        """Get script content from inline, file, or URL."""
        
        # Option 1: Inline content
        if 'script_content' in config:
            return config['script_content']
        
        # Option 2: File system
        if 'script_file' in config:
            base_path = config.get('script_base_path', '/app/resources')
            file_path = Path(base_path) / config['script_file']
            
            if not file_path.exists():
                raise FileNotFoundError(f"Script file not found: {file_path}")
            
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                return await f.read()
        
        # Option 3: URL
        if 'script_url' in config:
            return await self._fetch_script_from_url(
                config['script_url'],
                config.get('cache_ttl', 3600)
            )
        
        raise ValueError("No script source specified")
    
    async def _fetch_script_from_url(self, url: str, cache_ttl: int) -> str:
        """Fetch script from URL with caching."""
        
        # Check cache
        cache_key = f"script:{url}"
        if cache_key in self.script_cache:
            cached = self.script_cache[cache_key]
            if time.time() - cached['timestamp'] < cache_ttl:
                return cached['content']
        
        # Fetch from URL
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()
            content = response.text
        
        # Cache it
        self.script_cache[cache_key] = {
            'content': content,
            'timestamp': time.time()
        }
        
        return content
```

### **Java Callout Handler with JAR Support**

```python
class JavaCalloutPolicyHandler(BasePolicyHandler):
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        # Prepare Java execution environment
        jar_path = await self._prepare_jar(request.policy_config)
        
        # Execute Java callout
        return await self._execute_java_callout(jar_path, request)
    
    async def _prepare_jar(self, config: Dict[str, Any]) -> Path:
        """Prepare JAR file for execution."""
        
        # Option 1: File system reference
        if 'jar_file' in config:
            base_path = config.get('classpath', '/app/resources/lib')
            jar_path = Path(base_path) / config['jar_file']
            
            if not jar_path.exists():
                raise FileNotFoundError(f"JAR file not found: {jar_path}")
            
            return jar_path
        
        # Option 2: Base64 encoded JAR
        if 'jar_content_base64' in config:
            import base64
            
            # Decode JAR content
            jar_content = base64.b64decode(config['jar_content_base64'])
            
            # Write to temporary file
            temp_jar = self.temp_dir / f"jar_{uuid.uuid4()}.jar"
            async with aiofiles.open(temp_jar, 'wb') as f:
                await f.write(jar_content)
            
            return temp_jar
        
        raise ValueError("No JAR source specified")
    
    async def _execute_java_callout(self, jar_path: Path, request: PolicyRequest) -> PolicyResponse:
        """Execute Java callout."""
        
        config = request.policy_config
        class_name = config.get('class_name')
        method_name = config.get('method_name', 'execute')
        
        # Build Java command
        java_cmd = [
            'java',
            '-cp', str(jar_path),
            class_name,
            method_name,
            json.dumps({
                'request': {
                    'method': request.method,
                    'path': request.path,
                    'headers': request.headers,
                    'body': request.body
                },
                'variables': request.variables
            })
        ]
        
        # Execute Java process
        process = await asyncio.create_subprocess_exec(
            *java_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        timeout = config.get('timeout_seconds', 10)
        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            return self._create_error_response(
                f"Java callout timed out after {timeout}s"
            )
        
        # Process results
        if process.returncode != 0:
            error_msg = stderr.decode('utf-8') if stderr else "Java execution failed"
            return self._create_error_response(f"Java error: {error_msg}")
        
        # Parse output
        try:
            result = json.loads(stdout.decode('utf-8'))
            return PolicyResponse(
                success=True,
                variables=result.get('variables', {}),
                message="Java callout executed successfully"
            )
        except json.JSONDecodeError:
            return self._create_error_response(
                "Invalid JSON output from Java callout"
            )
```

### **XSLT Handler with File Support**

```python
class XSLTTransformHandler(BasePolicyHandler):
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        # Get XSLT content
        xslt_content = await self._get_xslt_content(request.policy_config)
        
        # Perform transformation
        return await self._transform_xml(xslt_content, request)
    
    async def _get_xslt_content(self, config: Dict[str, Any]) -> str:
        """Get XSLT content from inline, file, or URL."""
        
        # Option 1: Inline content
        if 'xslt_content' in config:
            return config['xslt_content']
        
        # Option 2: File system
        if 'xslt_file' in config:
            base_path = config.get('xslt_base_path', '/app/resources')
            file_path = Path(base_path) / config['xslt_file']
            
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                return await f.read()
        
        # Option 3: URL
        if 'xslt_url' in config:
            async with httpx.AsyncClient() as client:
                response = await client.get(config['xslt_url'])
                response.raise_for_status()
                return response.text
        
        raise ValueError("No XSLT source specified")
    
    async def _transform_xml(self, xslt_content: str, request: PolicyRequest) -> PolicyResponse:
        """Transform XML using XSLT."""
        from lxml import etree
        
        try:
            # Parse XSLT
            xslt_doc = etree.fromstring(xslt_content.encode('utf-8'))
            transform = etree.XSLT(xslt_doc)
            
            # Parse source XML
            source_xml = etree.fromstring(request.body.encode('utf-8'))
            
            # Transform
            result = transform(source_xml)
            
            return PolicyResponse(
                success=True,
                body=str(result),
                message="XSLT transformation completed"
            )
            
        except Exception as e:
            return self._create_error_response(f"XSLT transformation failed: {str(e)}")
```

## 📦 Resource File Deployment

### **Docker Volume Mounting**

```yaml
# docker-compose.yml
version: '3.8'

services:
  apigee-policy-service:
    build: .
    volumes:
      # Mount resource files
      - ./resources:/app/resources:ro
      # Mount JAR files
      - ./java/lib:/app/resources/lib:ro
      # Mount scripts
      - ./scripts:/app/resources/scripts:ro
      # Mount XSLT files
      - ./transforms:/app/resources/transforms:ro
```

**Directory Structure:**
```
project/
├── microservice/
│   ├── main.py
│   └── ...
├── resources/
│   ├── scripts/
│   │   ├── validate-user.js
│   │   ├── transform-data.js
│   │   └── enrich-request.py
│   ├── lib/
│   │   ├── custom-validator-1.0.jar
│   │   └── commons-lang3-3.12.0.jar
│   ├── transforms/
│   │   ├── user-transform.xsl
│   │   └── order-transform.xsl
│   └── wsdl/
│       └── UserService.wsdl
└── docker-compose.yml
```

### **Kubernetes ConfigMap/Volume**

```yaml
# configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: apigee-scripts
data:
  validate-user.js: |
    function validateUser(request) {
      var body = JSON.parse(request.body);
      if (!body.email) {
        throw new Error('Email required');
      }
      return true;
    }
  
  transform-data.js: |
    function transformData(data) {
      return {
        transformed: true,
        data: data
      };
    }

---
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apigee-policy-service
spec:
  template:
    spec:
      containers:
      - name: apigee-policy-service
        image: apigee-policy-service:latest
        volumeMounts:
        - name: scripts
          mountPath: /app/resources/scripts
          readOnly: true
        - name: java-libs
          mountPath: /app/resources/lib
          readOnly: true
      volumes:
      - name: scripts
        configMap:
          name: apigee-scripts
      - name: java-libs
        persistentVolumeClaim:
          claimName: java-libs-pvc
```

## 🔄 Migration Process

### **Step 1: Extract Resources from Apigee**

```bash
# Extract Apigee proxy bundle
unzip migration-test-api_rev1.zip

# Directory structure
migration-test-api/
├── apiproxy/
│   ├── policies/
│   │   ├── JavaScript-ValidateUser.xml
│   │   └── JavaCallout-CustomValidator.xml
│   ├── resources/
│   │   ├── jsc/
│   │   │   └── validate-user.js
│   │   ├── java/
│   │   │   └── custom-validator-1.0.jar
│   │   └── xsl/
│   │       └── transform.xsl
│   └── proxies/
│       └── default.xml
```

### **Step 2: Organize Resources**

```bash
# Create resource directory structure
mkdir -p microservice/resources/{scripts,lib,transforms,wsdl}

# Copy JavaScript files
cp migration-test-api/apiproxy/resources/jsc/*.js \
   microservice/resources/scripts/

# Copy JAR files
cp migration-test-api/apiproxy/resources/java/*.jar \
   microservice/resources/lib/

# Copy XSLT files
cp migration-test-api/apiproxy/resources/xsl/*.xsl \
   microservice/resources/transforms/
```

### **Step 3: Update Policy Configurations**

```python
# Migration script to convert Apigee policies
def convert_javascript_policy(apigee_policy):
    """Convert Apigee JavaScript policy to microservice format."""
    
    # Extract resource file reference
    resource_url = apigee_policy.find('.//ResourceURL').text
    # Example: "jsc://validate-user.js"
    
    script_file = resource_url.replace('jsc://', '')
    
    return {
        "policy_type": "javascript",
        "policy_config": {
            "script_file": f"scripts/{script_file}",
            "script_base_path": "/app/resources",
            "timeout_ms": 5000
        }
    }

def convert_java_callout_policy(apigee_policy):
    """Convert Apigee Java Callout policy to microservice format."""
    
    # Extract JAR reference
    resource_url = apigee_policy.find('.//ResourceURL').text
    # Example: "java://custom-validator-1.0.jar"
    
    jar_file = resource_url.replace('java://', '')
    class_name = apigee_policy.find('.//ClassName').text
    
    return {
        "policy_type": "java_callout",
        "policy_config": {
            "jar_file": jar_file,
            "class_name": class_name,
            "classpath": "/app/resources/lib",
            "timeout_seconds": 10
        }
    }
```

## 🔐 Security Considerations

### **1. File System Security**

```python
# Validate file paths to prevent directory traversal
def validate_file_path(base_path: Path, file_path: str) -> Path:
    """Validate and resolve file path safely."""
    
    # Resolve absolute path
    full_path = (base_path / file_path).resolve()
    
    # Ensure path is within base directory
    if not str(full_path).startswith(str(base_path.resolve())):
        raise ValueError(f"Invalid file path: {file_path}")
    
    return full_path
```

### **2. Resource Size Limits**

```python
# Configuration
MAX_SCRIPT_SIZE = 1024 * 1024  # 1MB
MAX_JAR_SIZE = 50 * 1024 * 1024  # 50MB

async def load_resource_file(file_path: Path, max_size: int) -> bytes:
    """Load resource file with size limit."""
    
    file_size = file_path.stat().st_size
    if file_size > max_size:
        raise ValueError(f"File too large: {file_size} bytes (max: {max_size})")
    
    async with aiofiles.open(file_path, 'rb') as f:
        return await f.read()
```

### **3. Content Validation**

```python
# Validate JavaScript syntax
def validate_javascript(script_content: str) -> bool:
    """Validate JavaScript syntax."""
    try:
        # Use Node.js to check syntax
        process = subprocess.run(
            ['node', '--check'],
            input=script_content.encode(),
            capture_output=True,
            timeout=5
        )
        return process.returncode == 0
    except Exception:
        return False
```

## 📊 Performance Optimization

### **1. Resource Caching**

```python
class ResourceCache:
    """Cache for resource files."""
    
    def __init__(self, max_size: int = 100, ttl: int = 3600):
        self.cache = {}
        self.max_size = max_size
        self.ttl = ttl
        self.lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[str]:
        """Get cached resource."""
        async with self.lock:
            if key in self.cache:
                entry = self.cache[key]
                if time.time() - entry['timestamp'] < self.ttl:
                    return entry['content']
                else:
                    del self.cache[key]
        return None
    
    async def set(self, key: str, content: str):
        """Cache resource."""
        async with self.lock:
            if len(self.cache) >= self.max_size:
                # Remove oldest entry
                oldest_key = min(self.cache.keys(), 
                               key=lambda k: self.cache[k]['timestamp'])
                del self.cache[oldest_key]
            
            self.cache[key] = {
                'content': content,
                'timestamp': time.time()
            }
```

### **2. Lazy Loading**

```python
# Load resources only when needed
class LazyResourceLoader:
    """Lazy loader for resource files."""
    
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.loaded_resources = {}
    
    async def load(self, resource_path: str) -> str:
        """Load resource on demand."""
        if resource_path not in self.loaded_resources:
            full_path = self.base_path / resource_path
            async with aiofiles.open(full_path, 'r') as f:
                self.loaded_resources[resource_path] = await f.read()
        
        return self.loaded_resources[resource_path]
```

## 🎯 Best Practices

### ✅ **DO:**
1. Use inline content for small scripts (<10KB)
2. Use file system for JAR files and large resources
3. Use URLs for shared resources (WSDL, OpenAPI)
4. Implement caching for URL-based resources
5. Validate file paths to prevent security issues
6. Set resource size limits
7. Use read-only volume mounts in production

### ❌ **DON'T:**
1. Store large files inline in configuration
2. Allow arbitrary file system access
3. Skip content validation
4. Ignore resource size limits
5. Hard-code file paths
6. Skip error handling for missing files

## 📋 Summary

The microservice handles resource files through:

1. **Multiple Storage Options**: Inline, file system, URL, Base64
2. **Flexible Configuration**: Choose best strategy per resource type
3. **Secure Access**: Path validation, size limits, content validation
4. **Performance**: Caching, lazy loading, efficient I/O
5. **Easy Migration**: Automated extraction from Apigee bundles
6. **Production Ready**: Docker volumes, Kubernetes ConfigMaps

This provides **complete resource file support** for seamless Apigee policy migration! 🚀