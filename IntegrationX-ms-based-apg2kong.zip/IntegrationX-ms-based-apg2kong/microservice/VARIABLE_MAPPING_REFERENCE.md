# Apigee to Kong Variable Mapping Reference

## 🎯 Overview

The microservice includes a **built-in variable mapping system** that automatically translates between Apigee and Kong variable formats. This ensures seamless integration and eliminates manual variable translation.

## 📊 Complete Variable Mapping Table

### **Request Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `request.verb` | `kong.request.method` | HTTP method | `POST` |
| `request.method` | `kong.request.method` | HTTP method (alias) | `GET` |
| `request.uri` | `kong.request.path_with_query` | Full URI with query | `/api/users?limit=10` |
| `request.path` | `kong.request.path` | Path without query | `/api/users` |
| `request.querystring` | `kong.request.query_string` | Query string | `limit=10&offset=0` |
| `request.content` | `kong.request.body` | Request body | `{"name": "John"}` |
| `request.body` | `kong.request.body` | Request body (alias) | `{"name": "John"}` |
| `request.header.{name}` | `kong.request.header.{name}` | Request header | `Bearer token123` |
| `request.queryparam.{name}` | `kong.request.query.{name}` | Query parameter | `10` |
| `request.formparam.{name}` | `kong.request.form.{name}` | Form parameter | `john@example.com` |

### **Client Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `client.ip` | `kong.client.ip` | Client IP address | `192.168.1.100` |
| `client.host` | `kong.request.host` | Request host | `api.example.com` |
| `client.port` | `kong.request.port` | Request port | `443` |
| `client.scheme` | `kong.request.scheme` | Protocol scheme | `https` |

### **Response Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `response.status.code` | `kong.response.status` | HTTP status code | `200` |
| `response.reason.phrase` | `kong.response.reason` | Status reason | `OK` |
| `response.content` | `kong.response.body` | Response body | `{"result": "success"}` |
| `response.body` | `kong.response.body` | Response body (alias) | `{"result": "success"}` |
| `response.header.{name}` | `kong.response.header.{name}` | Response header | `application/json` |

### **System Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `messageid` | `kong.request.id` | Unique request ID | `req-123-456-789` |
| `system.uuid` | `kong.request.id` | System UUID (alias) | `550e8400-e29b-41d4...` |
| `system.time` | N/A | Current timestamp (ms) | `1640995200000` |
| `system.time.year` | N/A | Current year | `2024` |
| `system.time.month` | N/A | Current month | `01` |
| `system.time.day` | N/A | Current day | `08` |

### **Target/Upstream Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `target.url` | `kong.upstream.url` | Upstream URL | `https://backend.example.com` |
| `target.host` | `kong.upstream.host` | Upstream host | `backend.example.com` |
| `target.port` | `kong.upstream.port` | Upstream port | `443` |
| `target.scheme` | `kong.upstream.scheme` | Upstream scheme | `https` |
| `target.response.header.{name}` | `kong.upstream.response.header.{name}` | Upstream response header | `application/json` |

### **Organization/Environment Variables**

| Apigee Variable | Kong Variable | Description | Example Value |
|----------------|---------------|-------------|---------------|
| `organization.name` | `kong.service.organization` | Organization name | `my-org` |
| `environment.name` | `kong.service.environment` | Environment name | `production` |
| `apiproxy.name` | `kong.service.name` | API proxy/service name | `users-api` |
| `apiproxy.revision` | `kong.service.version` | API revision | `1` |

## 🔧 Using the Variable Mapper

### **Automatic Variable Resolution**

The microservice automatically resolves variables in both formats:

```python
# In policy handlers, use the helper method
value = self._get_variable("request.verb", request)
# Works with both "request.verb" (Apigee) and "kong.request.method" (Kong)

# Set variables
self._set_variable("user_id", "123", flow_variables, custom_variables)
```

### **Template Substitution**

Variables are automatically substituted in templates:

```python
# Template with Apigee variables
template = "User {user_id} from {client.ip} accessed {request.path}"

# Automatically substitutes values
result = self._substitute_variables(template, request)
# Result: "User 123 from 192.168.1.100 accessed /api/users"
```

### **API Endpoints**

#### **Get All Mappings**

```bash
GET /variables/mappings
```

**Response:**
```json
{
  "apigee_to_kong": {
    "request.verb": "kong.request.method",
    "request.path": "kong.request.path",
    "client.ip": "kong.client.ip",
    "request.header.{name}": "kong.request.header.{name}",
    ...
  },
  "description": "Variable name mappings between Apigee and Kong formats",
  "usage": {
    "apigee_format": "request.verb, request.header.content-type, client.ip",
    "kong_format": "kong.request.method, kong.request.header.content-type, kong.client.ip"
  }
}
```

#### **Translate Variable Name**

```bash
POST /variables/translate
Content-Type: application/json

{
  "variable": "request.verb",
  "from_format": "apigee",
  "to_format": "kong"
}
```

**Response:**
```json
{
  "original": "request.verb",
  "translated": "kong.request.method",
  "from_format": "apigee",
  "to_format": "kong"
}
```

## 💡 Practical Examples

### **Example 1: Automatic Variable Resolution in JavaScript Policy**

```javascript
// Apigee format (works automatically)
var method = getVariable("request.verb");
var clientIp = getVariable("client.ip");
var authHeader = getVariable("request.header.authorization");

// Kong format (also works automatically)
var method = getVariable("kong.request.method");
var clientIp = getVariable("kong.client.ip");
var authHeader = getVariable("kong.request.header.authorization");

// Both formats resolve to the same value!
```

### **Example 2: Service Callout with Variable Substitution**

```json
{
  "policy_type": "service_callout",
  "policy_config": {
    "target_url": "https://api.example.com/users/{user_id}",
    "target_headers": {
      "X-Client-IP": "{client.ip}",
      "X-Request-ID": "{messageid}",
      "X-Original-Path": "{request.path}"
    }
  },
  "variables": {
    "user_id": "123"
  },
  "flow_variables": {
    "client.ip": "192.168.1.100",
    "messageid": "req-456",
    "request.path": "/api/users"
  }
}
```

**Result:**
- URL: `https://api.example.com/users/123`
- Headers:
  - `X-Client-IP: 192.168.1.100`
  - `X-Request-ID: req-456`
  - `X-Original-Path: /api/users`

### **Example 3: Condition Policy with Mixed Formats**

```json
{
  "policy_type": "assert_condition",
  "policy_config": {
    "condition": "request.verb == 'POST' and client.ip startswith '192.168'"
  },
  "flow_variables": {
    "request.verb": "POST",
    "client.ip": "192.168.1.100"
  }
}
```

**Works with Kong format too:**
```json
{
  "policy_config": {
    "condition": "kong.request.method == 'POST' and kong.client.ip startswith '192.168'"
  }
}
```

### **Example 4: Kong Plugin Using Mapped Variables**

```lua
-- Kong plugin automatically maps to Apigee format
local function build_policy_request()
  local flow_variables = {
    -- These are automatically mapped to Apigee format
    ["request.verb"] = kong.request.get_method(),
    ["request.path"] = kong.request.get_path(),
    ["client.ip"] = kong.client.get_ip(),
    ["messageid"] = kong.request.get_header("X-Request-ID")
  }
  
  -- Headers are automatically prefixed
  local headers = kong.request.get_headers()
  for name, value in pairs(headers) do
    flow_variables["request.header." .. name:lower()] = value
  end
  
  return {
    flow_variables = flow_variables,
    variables = kong.ctx.shared.apigee_variables or {}
  }
end
```

## 🎯 Benefits of Built-in Mapping

### ✅ **Automatic Translation**
- No manual variable name conversion needed
- Works with both Apigee and Kong formats
- Transparent to policy implementations

### ✅ **Backward Compatibility**
- Existing Apigee policies work without modification
- Kong-native integrations also supported
- Gradual migration path

### ✅ **Error Prevention**
- Eliminates variable name typos
- Consistent naming across policies
- Clear documentation of mappings

### ✅ **Flexibility**
- Use Apigee format in policies
- Use Kong format in Kong plugins
- Mix formats as needed

### ✅ **Debugging Support**
- API endpoints to inspect mappings
- Translation testing endpoint
- Clear error messages

## 🔍 Variable Resolution Order

When resolving a variable, the mapper checks in this order:

1. **Custom Variables** - User-defined variables (highest priority)
2. **Flow Variables (Direct)** - Exact match in flow variables
3. **Flow Variables (Mapped)** - Try Kong→Apigee or Apigee→Kong mapping
4. **Default Value** - Return None if not found

```python
# Example resolution
getVariable("request.verb")
  ↓
1. Check custom_variables["request.verb"] → Not found
  ↓
2. Check flow_variables["request.verb"] → Found! Return "POST"

# Or with Kong format
getVariable("kong.request.method")
  ↓
1. Check custom_variables["kong.request.method"] → Not found
  ↓
2. Check flow_variables["kong.request.method"] → Not found
  ↓
3. Map to Apigee: "kong.request.method" → "request.verb"
  ↓
4. Check flow_variables["request.verb"] → Found! Return "POST"
```

## 📋 Custom Variable Naming

Custom variables (set by policies) don't need mapping:

```javascript
// Custom variables work as-is
setVariable("user_id", "123");
setVariable("validation_result", "passed");
setVariable("my_custom_flag", true);

// Access them directly
var userId = getVariable("user_id");
```

## 🚀 Integration Best Practices

### **1. Use Apigee Format in Policies**
```javascript
// Recommended: Use Apigee format for consistency
var method = getVariable("request.verb");
var ip = getVariable("client.ip");
```

### **2. Use Kong Format in Kong Plugins**
```lua
-- Recommended: Use Kong native format in plugins
local method = kong.request.get_method()
local ip = kong.client.get_ip()

-- Then map to Apigee format for microservice
flow_variables["request.verb"] = method
flow_variables["client.ip"] = ip
```

### **3. Document Custom Variables**
```javascript
// Good: Clear variable names with comments
setVariable("user_authenticated", true);  // Boolean flag
setVariable("auth_timestamp", Date.now());  // Unix timestamp
setVariable("user_profile", {...});  // User object
```

### **4. Use Template Substitution**
```json
{
  "message_template": "User {user_id} from {client.ip} accessed {request.path}",
  "target_url": "https://api.example.com/users/{user_id}/profile",
  "cache_key": "session_{user_id}_{messageid}"
}
```

## 🎉 Summary

The built-in variable mapping system provides:

- ✅ **Automatic translation** between Apigee and Kong formats
- ✅ **Bidirectional mapping** (Apigee ↔ Kong)
- ✅ **Pattern-based mapping** for headers, query params, etc.
- ✅ **API endpoints** for inspection and testing
- ✅ **Helper methods** in policy handlers
- ✅ **Template substitution** support
- ✅ **Complete documentation** of all mappings

This makes the microservice **truly plug-and-play** for Kong integration! 🚀