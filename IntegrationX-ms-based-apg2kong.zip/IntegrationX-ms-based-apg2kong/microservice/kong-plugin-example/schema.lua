-- Apigee Policy Kong Plugin Schema
-- Defines the configuration schema for the plugin

local typedefs = require "kong.db.schema.typedefs"

return {
  name = "apigee-policy",
  fields = {
    {
      config = {
        type = "record",
        fields = {
          -- Microservice connection settings
          {
            microservice_url = {
              type = "string",
              default = "http://apigee-policy-service:8080",
              description = "URL of the Apigee Policy Microservice"
            }
          },
          
          -- Error handling strategy
          {
            on_error = {
              type = "string",
              default = "terminate",
              one_of = { "terminate", "continue" },
              description = "Action to take when policy execution fails"
            }
          },
          
          -- Request phase policies (executed before upstream)
          {
            policies = {
              type = "array",
              elements = {
                type = "record",
                fields = {
                  {
                    type = {
                      type = "string",
                      required = true,
                      one_of = {
                        "javascript",
                        "python_script",
                        "java_callout",
                        "service_callout",
                        "external_callout",
                        "kvm_operations",
                        "raise_fault",
                        "xml_threat_protection",
                        "json_threat_protection",
                        "xml_to_json",
                        "json_to_xml",
                        "xsl_transform",
                        "saml_validate",
                        "saml_generate",
                        "jws_verify",
                        "jws_decode",
                        "publish_message",
                        "message_logging",
                        "assert_condition",
                        "access_entity",
                        "http_modifier"
                      },
                      description = "Type of Apigee policy to execute"
                    }
                  },
                  {
                    config = {
                      type = "record",
                      fields = {
                        {
                          name = {
                            type = "string",
                            description = "Name of the policy instance"
                          }
                        }
                      },
                      additional_properties = true,
                      description = "Policy-specific configuration"
                    }
                  }
                }
              },
              description = "List of policies to execute in the request phase"
            }
          },
          
          -- Response phase policies (executed after upstream)
          {
            response_policies = {
              type = "array",
              elements = {
                type = "record",
                fields = {
                  {
                    type = {
                      type = "string",
                      required = true,
                      description = "Type of Apigee policy to execute"
                    }
                  },
                  {
                    config = {
                      type = "record",
                      fields = {
                        {
                          name = {
                            type = "string",
                            description = "Name of the policy instance"
                          }
                        }
                      },
                      additional_properties = true,
                      description = "Policy-specific configuration"
                    }
                  }
                }
              },
              description = "List of policies to execute in the response phase"
            }
          },
          
          -- Timeout settings
          {
            timeout = {
              type = "number",
              default = 30000,
              description = "Timeout for policy execution in milliseconds"
            }
          },
          
          -- Enable debug logging
          {
            debug = {
              type = "boolean",
              default = false,
              description = "Enable debug logging for policy execution"
            }
          }
        }
      }
    }
  }
}