# Kong Plugin for Apigee Policy Microservice

This Kong plugin integrates Kong Gateway with the Apigee Policy Microservice, enabling execution of Apigee policies within Kong's request/response lifecycle.

## Features

- **Complete Variable Mapping**: Automatically maps Kong variables to Apigee format
- **Variable Persistence**: Maintains variable state across multiple policy executions
- **Request & Response Phases**: Execute policies before and after upstream
- **Error Handling**: Configurable error handling strategies
- **Debug Support**: Built-in debug logging for troubleshooting

## Installation

### 1. Copy Plugin Files

```bash
# Copy plugin to Kong's plugin directory
mkdir -p /usr/local/share/lua/5.1/kong/plugins/apigee-policy
cp handler.lua /usr/local/share/lua/5.1/kong/plugins/apigee-policy/
cp schema.lua /usr/local/share/lua/5.1/kong/plugins/apigee-policy/
```

### 2. Enable Plugin in Kong Configuration

Edit `kong.conf`:

```conf
plugins = bundled,apigee-policy
```

### 3. Restart Kong

```bash
kong restart
```

## Configuration

### Basic Configuration

```bash
curl -X POST http://kong-admin:8001/services/{service}/plugins \
  --data "name=apigee-policy" \
  --data "config.microservice_url=http://apigee-policy-service:8080" \
  --data "config.policies[1].type=javascript" \
  --data "config.policies[1].config.name=ValidateRequest" \
  --data "config.policies[1].config.script_content=function validate() { return true; }"
```

### Advanced Configuration (JSON)

```json
{
  "name": "apigee-policy",
  "config": {
    "microservice_url": "http://apigee-policy-service:8080",
    "on_error": "terminate",
    "timeout": 30000,
    "debug": false,
    "policies": [
      {
        "type": "javascript",
        "config": {
          "name": "ExtractToken",
          "script_content": "var authHeader = getVariable('request.header.authorization');\nif (authHeader && authHeader.startsWith('Bearer ')) {\n  var token = authHeader.substring(7);\n  setVariable('jwt_token', token);\n}"
        }
      },
      {
        "type": "jws_verify",
        "config": {
          "name": "VerifyJWT",
          "operation": "verify",
          "token_source": "variable",
          "token_variable": "jwt_token",
          "algorithm": "RS256",
          "verification_key": "-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----"
        }
      },
      {
        "type": "assert_condition",
        "config": {
          "name": "CheckRole",
          "operation": "assert",
          "condition": "user_role == 'admin'",
          "failure_message": "Admin access required",
          "failure_status_code": 403
        }
      }
    ],
    "response_policies": [
      {
        "type": "message_logging",
        "config": {
          "name": "LogResponse",
          "operation": "log",
          "log_level": "INFO",
          "message": "Request processed successfully"
        }
      }
    ]
  }
}
```

## Variable Handling

### Automatic Variable Mapping

The plugin automatically maps Kong variables to Apigee format:

| Kong Variable | Apigee Variable | Example |
|--------------|-----------------|---------|
| `kong.request.get_method()` | `request.verb` | `POST` |
| `kong.request.get_path()` | `request.path` | `/api/users` |
| `kong.request.get_header("X")` | `request.header.x` | `Bearer token` |
| `kong.client.get_ip()` | `client.ip` | `192.168.1.100` |
| `kong.request.get_query()` | `request.queryparam.*` | `limit=10` |

### Variable Persistence Example

```lua
-- Policy 1: Set variable
{
  "type": "javascript",
  "config": {
    "script_content": "setVariable('user_id', '123');"
  }
}

-- Policy 2: Use variable (automatically available)
{
  "type": "kvm_operations",
  "config": {
    "operation": "get",
    "key": "user_{user_id}_profile"  -- Will resolve to "user_123_profile"
  }
}
```

## Usage Examples

### Example 1: JWT Authentication

```bash
curl -X POST http://kong-admin:8001/services/my-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "policies": [
        {
          "type": "jws_verify",
          "config": {
            "name": "VerifyJWT",
            "operation": "verify",
            "token_source": "header",
            "header_name": "Authorization",
            "algorithm": "RS256",
            "verification_key": "YOUR_PUBLIC_KEY"
          }
        }
      ]
    }
  }'
```

### Example 2: Rate Limiting with KVM

```bash
curl -X POST http://kong-admin:8001/services/my-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ExtractUserId",
            "script_content": "var userId = getVariable(\"request.header.x-user-id\");\nsetVariable(\"user_id\", userId);"
          }
        },
        {
          "type": "kvm_operations",
          "config": {
            "name": "CheckRateLimit",
            "operation": "get",
            "key": "rate_limit_{user_id}",
            "map_name": "rate_limits"
          }
        },
        {
          "type": "assert_condition",
          "config": {
            "name": "ValidateLimit",
            "operation": "assert",
            "condition": "kvm_value < 100",
            "failure_message": "Rate limit exceeded",
            "failure_status_code": 429
          }
        }
      ]
    }
  }'
```

### Example 3: Service Callout for Enrichment

```bash
curl -X POST http://kong-admin:8001/services/my-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "policies": [
        {
          "type": "service_callout",
          "config": {
            "name": "GetUserProfile",
            "target_url": "https://user-service.example.com/users/{user_id}",
            "target_method": "GET",
            "response_variable": "user_profile"
          }
        },
        {
          "type": "javascript",
          "config": {
            "name": "EnrichRequest",
            "script_content": "var profile = getVariable(\"user_profile\");\nsetVariable(\"response.header.x-user-name\", profile.name);"
          }
        }
      ]
    }
  }'
```

### Example 4: Data Transformation

```bash
curl -X POST http://kong-admin:8001/services/my-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "response_policies": [
        {
          "type": "xml_to_json",
          "config": {
            "name": "ConvertResponse",
            "source": "response_body",
            "destination": "response_body"
          }
        }
      ]
    }
  }'
```

## Debugging

### Enable Debug Logging

```bash
curl -X PATCH http://kong-admin:8001/plugins/{plugin-id} \
  --data "config.debug=true"
```

### View Logs

```bash
# Kong logs
tail -f /usr/local/kong/logs/error.log

# Look for lines containing "Apigee Policy Plugin"
```

### Test Variable State

```bash
# Add a logging policy to see variable state
{
  "type": "message_logging",
  "config": {
    "name": "DebugVariables",
    "operation": "log",
    "log_level": "DEBUG",
    "message": "Variables: {variables}"
  }
}
```

## Error Handling

### Terminate on Error (Default)

```json
{
  "config": {
    "on_error": "terminate"
  }
}
```

If any policy fails, the request is terminated with an error response.

### Continue on Error

```json
{
  "config": {
    "on_error": "continue"
  }
}
```

If a policy fails, log the error but continue processing.

## Performance Considerations

1. **Connection Pooling**: The plugin reuses HTTP connections to the microservice
2. **Timeout Configuration**: Adjust timeout based on policy complexity
3. **Variable Caching**: Variables are cached in Kong context for the request lifecycle
4. **Async Execution**: Policies are executed asynchronously when possible

## Troubleshooting

### Common Issues

1. **Plugin not loading**
   - Check Kong logs: `kong check`
   - Verify plugin files are in correct directory
   - Ensure plugin is enabled in `kong.conf`

2. **Microservice unreachable**
   - Verify microservice URL is correct
   - Check network connectivity: `curl http://apigee-policy-service:8080/health`
   - Review Kong error logs

3. **Policy execution fails**
   - Enable debug logging
   - Check microservice logs
   - Verify policy configuration is correct

4. **Variables not persisting**
   - Ensure variables are set in policy response
   - Check Kong context is initialized
   - Review variable names (case-sensitive)

## Best Practices

1. **Policy Ordering**: Order policies logically (auth → validation → enrichment)
2. **Error Handling**: Use appropriate error handling strategy for your use case
3. **Variable Naming**: Use clear, descriptive variable names
4. **Logging**: Add logging policies for debugging in development
5. **Testing**: Test policies individually before chaining them
6. **Performance**: Monitor execution times and optimize slow policies

## Support

For issues and questions:
1. Check microservice logs
2. Enable debug logging
3. Review Kong error logs
4. Test policies individually using microservice API directly