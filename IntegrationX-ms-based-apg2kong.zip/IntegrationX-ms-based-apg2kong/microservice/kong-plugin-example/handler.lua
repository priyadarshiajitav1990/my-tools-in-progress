-- Apigee Policy Kong Plugin Handler
-- This plugin integrates Kong with the Apigee Policy Microservice

local http = require "resty.http"
local cjson = require "cjson"

local ApigeePolicy = {
  VERSION = "1.0.0",
  PRIORITY = 1000
}

-- Build Apigee-compatible flow variables from Kong request
local function build_flow_variables()
  local request = kong.request
  local flow_vars = {}
  
  -- Request variables
  flow_vars["request.verb"] = request.get_method()
  flow_vars["request.uri"] = request.get_path_with_query()
  flow_vars["request.path"] = request.get_path()
  flow_vars["request.querystring"] = request.get_raw_query() or ""
  
  -- Get request body if available
  local body = request.get_raw_body()
  if body then
    flow_vars["request.content"] = body
  end
  
  -- Client variables
  flow_vars["client.ip"] = kong.client.get_ip()
  flow_vars["client.host"] = request.get_host()
  flow_vars["client.port"] = tostring(request.get_port())
  flow_vars["client.scheme"] = request.get_scheme()
  
  -- Request headers (all headers with request.header. prefix)
  local headers = request.get_headers()
  for name, value in pairs(headers) do
    local header_name = name:lower()
    if type(value) == "table" then
      flow_vars["request.header." .. header_name] = table.concat(value, ",")
    else
      flow_vars["request.header." .. header_name] = tostring(value)
    end
  end
  
  -- Query parameters
  local query_params = request.get_query()
  for name, value in pairs(query_params) do
    if type(value) == "table" then
      flow_vars["request.queryparam." .. name] = table.concat(value, ",")
    else
      flow_vars["request.queryparam." .. name] = tostring(value)
    end
  end
  
  -- System variables
  flow_vars["system.time"] = ngx.now() * 1000
  flow_vars["system.time.year"] = os.date("%Y")
  flow_vars["system.time.month"] = os.date("%m")
  flow_vars["system.time.day"] = os.date("%d")
  flow_vars["system.uuid"] = kong.request.get_header("X-Request-ID") or ngx.var.request_id
  flow_vars["messageid"] = kong.request.get_header("X-Request-ID") or ngx.var.request_id
  
  -- Kong-specific variables
  flow_vars["kong.service.name"] = kong.router.get_service() and kong.router.get_service().name or ""
  flow_vars["kong.route.name"] = kong.router.get_route() and kong.router.get_route().name or ""
  
  return flow_vars
end

-- Call the Apigee Policy Microservice
local function call_policy_service(policy_type, policy_config, custom_variables)
  local httpc = http.new()
  httpc:set_timeout(30000) -- 30 second timeout
  
  -- Get or initialize custom variables
  local variables = custom_variables or kong.ctx.shared.apigee_variables or {}
  
  -- Build flow variables
  local flow_variables = build_flow_variables()
  
  -- Build policy request
  local policy_request = {
    method = kong.request.get_method(),
    path = kong.request.get_path(),
    headers = kong.request.get_headers(),
    query_params = kong.request.get_query(),
    body = kong.request.get_raw_body(),
    policy_name = policy_config.name or policy_type,
    policy_type = policy_type,
    policy_config = policy_config,
    variables = variables,
    flow_variables = flow_variables,
    client_ip = kong.client.get_ip(),
    user_agent = kong.request.get_header("User-Agent"),
    request_id = kong.request.get_header("X-Request-ID") or ngx.var.request_id
  }
  
  -- Get microservice URL from config
  local microservice_url = policy_config.microservice_url or "http://apigee-policy-service:8080"
  local endpoint = microservice_url .. "/policies/" .. policy_type
  
  kong.log.debug("Calling policy service: ", endpoint)
  kong.log.debug("Policy request: ", cjson.encode(policy_request))
  
  -- Make HTTP call to microservice
  local res, err = httpc:request_uri(endpoint, {
    method = "POST",
    body = cjson.encode(policy_request),
    headers = {
      ["Content-Type"] = "application/json",
      ["X-Kong-Request-ID"] = kong.request.get_header("X-Request-ID") or ngx.var.request_id
    }
  })
  
  if not res then
    kong.log.err("Failed to call policy service: ", err)
    return nil, "Policy service unavailable: " .. tostring(err)
  end
  
  if res.status ~= 200 then
    kong.log.err("Policy service returned error: ", res.status, " - ", res.body)
    return nil, "Policy execution failed with status: " .. res.status
  end
  
  -- Parse response
  local ok, response_data = pcall(cjson.decode, res.body)
  if not ok then
    kong.log.err("Failed to parse policy response: ", res.body)
    return nil, "Invalid policy response"
  end
  
  kong.log.debug("Policy response: ", cjson.encode(response_data))
  
  return response_data, nil
end

-- Update Kong context with policy response
local function apply_policy_response(response)
  if not response then
    return
  end
  
  -- Update custom variables in Kong context
  if response.variables then
    kong.ctx.shared.apigee_variables = kong.ctx.shared.apigee_variables or {}
    for key, value in pairs(response.variables) do
      kong.ctx.shared.apigee_variables[key] = value
    end
  end
  
  -- Add response headers
  if response.headers then
    for name, value in pairs(response.headers) do
      kong.response.set_header(name, value)
    end
  end
  
  -- Handle request termination
  if response.terminate_request or not response.continue_processing then
    local status_code = response.status_code or 500
    local body = response.body or cjson.encode({
      error = true,
      message = response.message or "Policy execution failed"
    })
    
    -- Set content type if body is JSON
    if type(body) == "string" and body:match("^%s*{") then
      kong.response.set_header("Content-Type", "application/json")
    end
    
    kong.response.exit(status_code, body)
  end
end

-- Plugin handler: access phase (before upstream)
function ApigeePolicy:access(conf)
  kong.log.debug("Apigee Policy Plugin - Access Phase")
  
  -- Initialize variable context if not exists
  kong.ctx.shared.apigee_variables = kong.ctx.shared.apigee_variables or {}
  
  -- Execute configured policies in sequence
  if conf.policies then
    for i, policy in ipairs(conf.policies) do
      kong.log.debug("Executing policy ", i, ": ", policy.type)
      
      local response, err = call_policy_service(
        policy.type,
        policy.config,
        kong.ctx.shared.apigee_variables
      )
      
      if err then
        kong.log.err("Policy execution failed: ", err)
        
        if conf.on_error == "continue" then
          -- Continue processing on error
          kong.log.warn("Continuing despite policy error")
        else
          -- Terminate on error (default)
          kong.response.exit(500, {
            error = true,
            message = "Policy execution failed: " .. err
          })
        end
      else
        -- Apply policy response
        apply_policy_response(response)
        
        -- Log execution time
        if response.execution_time_ms then
          kong.log.debug("Policy executed in ", response.execution_time_ms, "ms")
        end
      end
    end
  end
end

-- Plugin handler: header_filter phase (after upstream, before response)
function ApigeePolicy:header_filter(conf)
  kong.log.debug("Apigee Policy Plugin - Header Filter Phase")
  
  -- Execute response policies if configured
  if conf.response_policies then
    -- Build response flow variables
    local flow_vars = kong.ctx.shared.flow_variables or {}
    flow_vars["response.status.code"] = kong.response.get_status()
    
    local response_headers = kong.response.get_headers()
    for name, value in pairs(response_headers) do
      local header_name = name:lower()
      if type(value) == "table" then
        flow_vars["response.header." .. header_name] = table.concat(value, ",")
      else
        flow_vars["response.header." .. header_name] = tostring(value)
      end
    end
    
    kong.ctx.shared.flow_variables = flow_vars
    
    -- Execute response policies
    for i, policy in ipairs(conf.response_policies) do
      kong.log.debug("Executing response policy ", i, ": ", policy.type)
      
      local response, err = call_policy_service(
        policy.type,
        policy.config,
        kong.ctx.shared.apigee_variables
      )
      
      if response and response.headers then
        for name, value in pairs(response.headers) do
          kong.response.set_header(name, value)
        end
      end
    end
  end
end

-- Plugin handler: body_filter phase (modify response body)
function ApigeePolicy:body_filter(conf)
  -- This phase can be used for response body transformation
  -- if needed in the future
end

return ApigeePolicy