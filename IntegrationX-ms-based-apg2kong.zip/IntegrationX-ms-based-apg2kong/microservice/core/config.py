"""
Configuration Management
=======================

Handles all configuration for the Apigee Policy Microservice.
"""

from pydantic_settings import BaseSettings
from typing import Optional, List
import os
from pathlib import Path


class Settings(BaseSettings):
    """Application settings."""
    
    # Server configuration
    host: str = "0.0.0.0"
    port: int = 8080
    debug: bool = False
    
    # Logging configuration
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Redis configuration for KVM operations
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None
    
    # Security settings
    secret_key: str = "your-secret-key-change-in-production"
    algorithm: str = "HS256"
    
    # External service settings
    external_service_timeout: int = 30
    max_retries: int = 3
    
    # JavaScript execution settings
    js_timeout: int = 5000  # milliseconds
    js_memory_limit: int = 64  # MB
    
    # Java execution settings (if using subprocess)
    java_timeout: int = 10  # seconds
    java_classpath: str = "./java/lib/*"
    
    # SAML settings
    saml_cert_path: Optional[str] = None
    saml_key_path: Optional[str] = None
    
    # Message queue settings
    message_queue_url: Optional[str] = None
    message_queue_type: str = "redis"  # redis, rabbitmq, kafka
    
    # Threat protection limits
    xml_max_depth: int = 10
    xml_max_attributes: int = 100
    json_max_depth: int = 20
    json_max_string_length: int = 10000
    
    # Performance settings
    max_concurrent_requests: int = 100
    request_timeout: int = 30
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        
    @classmethod
    def load_config(cls) -> "Settings":
        """Load configuration with environment-specific overrides."""
        # Check for environment-specific config files
        env = os.getenv("ENVIRONMENT", "development")
        
        config_files = [".env"]
        if Path(f".env.{env}").exists():
            config_files.append(f".env.{env}")
        
        return cls(_env_file=config_files)
    
    def get_redis_url(self) -> str:
        """Get Redis connection URL."""
        if self.redis_password:
            return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/{self.redis_db}"
        return f"redis://{self.redis_host}:{self.redis_port}/{self.redis_db}"