"""
Middleware Components
====================

Custom middleware for the policy microservice.
"""

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import time
import logging
import uuid

logger = logging.getLogger("apigee_policy_service")


class PolicyMiddleware(BaseHTTPMiddleware):
    """Custom middleware for policy request handling."""
    
    async def dispatch(self, request: Request, call_next):
        """Process request and response."""
        
        # Generate request ID if not present
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        
        # Start timing
        start_time = time.time()
        
        # Log request
        logger.info(
            f"Request {request_id}: {request.method} {request.url.path} "
            f"from {request.client.host if request.client else 'unknown'}"
        )
        
        # Import metrics here to avoid circular imports
        from core.metrics import metrics
        metrics.start_request()
        
        try:
            # Process request
            response = await call_next(request)
            
            # Calculate processing time
            process_time = time.time() - start_time
            
            # Add headers
            response.headers["X-Request-ID"] = request_id
            response.headers["X-Process-Time"] = str(process_time)
            
            # Log response
            logger.info(
                f"Response {request_id}: {response.status_code} "
                f"in {process_time:.3f}s"
            )
            
            return response
            
        except Exception as e:
            # Calculate processing time
            process_time = time.time() - start_time
            
            # Log error
            logger.error(
                f"Error {request_id}: {str(e)} "
                f"in {process_time:.3f}s"
            )
            
            raise
        
        finally:
            # Import metrics here to avoid circular imports
            from core.metrics import metrics
            metrics.end_request()