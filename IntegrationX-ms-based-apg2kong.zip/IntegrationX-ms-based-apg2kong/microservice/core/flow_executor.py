"""
Flow Executor
=============

Executes Apigee flows including PreFlow, Conditional Flows, PostFlow,
RouteRules, and FaultRules.
"""

import logging
from typing import Dict, Any, List, Optional
from core.models import PolicyRequest, PolicyResponse
from core.condition_evaluator import condition_evaluator

logger = logging.getLogger("apigee_policy_service")


class FlowExecutor:
    """Executes Apigee flows with condition evaluation."""
    
    def __init__(self, policy_handlers: Dict[str, Any]):
        """
        Initialize flow executor.
        
        Args:
            policy_handlers: Dictionary of policy handlers
        """
        self.policy_handlers = policy_handlers
        self.condition_evaluator = condition_evaluator
        self.logger = logger
    
    async def execute_flows(
        self,
        request: PolicyRequest,
        flows_config: Dict[str, Any]
    ) -> PolicyResponse:
        """
        Execute complete flow sequence.
        
        Flow execution order:
        1. PreFlow (Request)
        2. Conditional Flows (Request) - first matching flow
        3. PostFlow (Request)
        4. [Backend call happens here]
        5. PostFlow (Response)
        6. Conditional Flows (Response) - same flow as request
        7. PreFlow (Response)
        
        Args:
            request: Policy request
            flows_config: Flow configuration
        
        Returns:
            Policy response
        """
        response = PolicyResponse(
            success=True,
            message="Flows executed successfully",
            variables=request.variables.copy(),
            policy_name="FlowExecutor"
        )
        
        context = self._build_context(request)
        matched_flow = None
        
        try:
            # 1. Execute PreFlow (Request)
            if flows_config.get('pre_flow'):
                self.logger.info("Executing PreFlow (Request)")
                await self._execute_flow_steps(
                    flows_config['pre_flow'].get('request', []),
                    context,
                    response
                )
            
            # 2. Execute Conditional Flows (Request)
            if flows_config.get('conditional_flows'):
                self.logger.info("Evaluating conditional flows")
                matched_flow = await self._execute_conditional_flows(
                    flows_config['conditional_flows'],
                    context,
                    response,
                    phase='request'
                )
            
            # 3. Execute PostFlow (Request)
            if flows_config.get('post_flow'):
                self.logger.info("Executing PostFlow (Request)")
                await self._execute_flow_steps(
                    flows_config['post_flow'].get('request', []),
                    context,
                    response
                )
            
            # Note: Backend call happens between request and response phases
            
            # 4. Execute PostFlow (Response)
            if flows_config.get('post_flow'):
                self.logger.info("Executing PostFlow (Response)")
                await self._execute_flow_steps(
                    flows_config['post_flow'].get('response', []),
                    context,
                    response
                )
            
            # 5. Execute Conditional Flows (Response) - same flow as request
            if matched_flow:
                self.logger.info(f"Executing matched flow '{matched_flow['name']}' (Response)")
                await self._execute_flow_steps(
                    matched_flow.get('response_policies', []),
                    context,
                    response
                )
            
            # 6. Execute PreFlow (Response)
            if flows_config.get('pre_flow'):
                self.logger.info("Executing PreFlow (Response)")
                await self._execute_flow_steps(
                    flows_config['pre_flow'].get('response', []),
                    context,
                    response
                )
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error executing flows: {str(e)}")
            
            # Execute fault rules
            if flows_config.get('fault_rules'):
                return await self._execute_fault_rules(
                    flows_config['fault_rules'],
                    context,
                    str(e)
                )
            
            # Execute default fault rule
            if flows_config.get('default_fault_rule'):
                return await self._execute_default_fault_rule(
                    flows_config['default_fault_rule'],
                    context,
                    str(e)
                )
            
            # Return error response
            return PolicyResponse(
                success=False,
                message=f"Flow execution failed: {str(e)}",
                status_code=500,
                terminate_request=True
            )
    
    async def _execute_conditional_flows(
        self,
        flows: List[Dict[str, Any]],
        context: Dict[str, Any],
        response: PolicyResponse,
        phase: str = 'request'
    ) -> Optional[Dict[str, Any]]:
        """
        Execute conditional flows - first matching flow wins.
        
        Args:
            flows: List of conditional flows
            context: Request context
            response: Policy response to update
            phase: 'request' or 'response'
        
        Returns:
            Matched flow configuration (for response phase execution)
        """
        for flow in flows:
            condition = flow.get('condition', '')
            
            # Evaluate condition
            if self.condition_evaluator.evaluate(condition, context):
                self.logger.info(f"Flow '{flow.get('name')}' matched condition: {condition}")
                
                # Execute request policies
                if phase == 'request':
                    await self._execute_flow_steps(
                        flow.get('request_policies', []),
                        context,
                        response
                    )
                    return flow  # Return matched flow for response phase
                
                # Execute response policies
                elif phase == 'response':
                    await self._execute_flow_steps(
                        flow.get('response_policies', []),
                        context,
                        response
                    )
                
                break  # First matching flow wins
        
        return None
    
    async def _execute_flow_steps(
        self,
        steps: List[Dict[str, Any]],
        context: Dict[str, Any],
        response: PolicyResponse
    ) -> None:
        """Execute flow steps (policies)."""
        for step in steps:
            try:
                policy_type = step.get('type', '').lower()
                policy_config = step.get('config', {})
                
                # Get policy handler
                handler = self.policy_handlers.get(policy_type)
                if not handler:
                    self.logger.warning(f"No handler found for policy type: {policy_type}")
                    continue
                
                # Build policy request
                policy_request = PolicyRequest(
                    method=context.get('method', 'GET'),
                    path=context.get('path', '/'),
                    headers=context.get('headers', {}),
                    query_params=context.get('query_params', {}),
                    body=context.get('body'),
                    api_name=context.get('api_name'),
                    policy_name=step.get('name', policy_type),
                    policy_type=policy_type,
                    policy_config=policy_config,
                    variables=response.variables,
                    flow_variables=context.get('flow_variables', {})
                )
                
                # Execute policy
                policy_response = await handler.execute(policy_request)
                
                # Update response
                if policy_response.success:
                    response.variables.update(policy_response.variables)
                    if policy_response.headers:
                        response.headers.update(policy_response.headers)
                    if policy_response.body:
                        response.body = policy_response.body
                    if policy_response.status_code:
                        response.status_code = policy_response.status_code
                    
                    # Check if request should be terminated
                    if policy_response.terminate_request:
                        response.terminate_request = True
                        response.continue_processing = False
                        break
                else:
                    self.logger.error(f"Policy execution failed: {policy_response.message}")
                    raise Exception(policy_response.message)
                    
            except Exception as e:
                self.logger.error(f"Error executing flow step: {str(e)}")
                raise
    
    async def _execute_fault_rules(
        self,
        fault_rules: List[Dict[str, Any]],
        context: Dict[str, Any],
        error: str
    ) -> PolicyResponse:
        """Execute fault rules based on error condition."""
        # Add fault information to context
        context['fault'] = {
            'name': 'GenericError',
            'message': error
        }
        
        # Find matching fault rule
        for rule in fault_rules:
            condition = rule.get('condition', '')
            
            if self.condition_evaluator.evaluate(condition, context):
                self.logger.info(f"Fault rule '{rule.get('name')}' matched")
                
                response = PolicyResponse(
                    success=False,
                    message=f"Fault rule executed: {rule.get('name')}",
                    status_code=500,
                    terminate_request=True
                )
                
                # Execute fault rule steps
                await self._execute_flow_steps(
                    rule.get('policies', []),
                    context,
                    response
                )
                
                return response
        
        # No matching fault rule
        return PolicyResponse(
            success=False,
            message=f"Error: {error}",
            status_code=500,
            terminate_request=True
        )
    
    async def _execute_default_fault_rule(
        self,
        default_fault_rule: Dict[str, Any],
        context: Dict[str, Any],
        error: str
    ) -> PolicyResponse:
        """Execute default fault rule."""
        self.logger.info("Executing default fault rule")
        
        response = PolicyResponse(
            success=False,
            message="Default fault rule executed",
            status_code=500,
            terminate_request=True
        )
        
        # Execute default fault rule steps
        await self._execute_flow_steps(
            default_fault_rule.get('policies', []),
            context,
            response
        )
        
        return response
    
    def evaluate_route_rules(
        self,
        route_rules: List[Dict[str, Any]],
        context: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Evaluate route rules to determine target endpoint.
        
        Args:
            route_rules: List of route rules
            context: Request context
        
        Returns:
            Matched route rule or None
        """
        for rule in route_rules:
            condition = rule.get('condition', '')
            
            # If no condition, it's the default route
            if not condition:
                self.logger.info(f"Using default route rule: {rule.get('name')}")
                return rule
            
            # Evaluate condition
            if self.condition_evaluator.evaluate(condition, context):
                self.logger.info(f"Route rule '{rule.get('name')}' matched condition: {condition}")
                return rule
        
        return None
    
    def _build_context(self, request: PolicyRequest) -> Dict[str, Any]:
        """Build context from request for condition evaluation."""
        return {
            'method': request.method,
            'path': request.path,
            'headers': request.headers,
            'query_params': request.query_params,
            'body': request.body,
            'api_name': request.api_name,
            'variables': request.variables,
            'flow_variables': request.flow_variables,
            'request': {
                'verb': request.method,
                'path': request.path,
                'header': request.headers,
                'queryparam': request.query_params,
                'content': request.body
            },
            'proxy': {
                'pathsuffix': request.path.split('/')[-1] if request.path else '',
                'basepath': '/'.join(request.path.split('/')[:-1]) if request.path else '/'
            },
            'client': {
                'ip': request.client_ip or '0.0.0.0'
            }
        }


# Global instance will be created when policy handlers are available
flow_executor = None


def initialize_flow_executor(policy_handlers: Dict[str, Any]) -> FlowExecutor:
    """Initialize global flow executor with policy handlers."""
    global flow_executor
    flow_executor = FlowExecutor(policy_handlers)
    return flow_executor
