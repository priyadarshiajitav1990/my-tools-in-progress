"""
Data Models
===========

Pydantic models for request/response handling.
"""

from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List, Union
from enum import Enum


class PolicyType(str, Enum):
    """Supported policy types."""
    JAVASCRIPT = "javascript"
    PYTHON_SCRIPT = "python_script"
    JAVA_CALLOUT = "java_callout"
    SERVICE_CALLOUT = "service_callout"
    EXTERNAL_CALLOUT = "external_callout"
    KVM_OPERATIONS = "kvm_operations"
    RAISE_FAULT = "raise_fault"
    XML_THREAT_PROTECTION = "xml_threat_protection"
    JSON_THREAT_PROTECTION = "json_threat_protection"
    XML_TO_JSON = "xml_to_json"
    JSON_TO_XML = "json_to_xml"
    XSL_TRANSFORM = "xsl_transform"
    SAML_VALIDATE = "saml_validate"
    SAML_GENERATE = "saml_generate"
    JWS_VERIFY = "jws_verify"
    JWS_DECODE = "jws_decode"
    PUBLISH_MESSAGE = "publish_message"
    MESSAGE_LOGGING = "message_logging"
    ASSERT_CONDITION = "assert_condition"
    ACCESS_ENTITY = "access_entity"
    HTTP_MODIFIER = "http_modifier"


class PolicyRequest(BaseModel):
    """Request model for policy execution."""
    
    # Request context from Kong
    method: str = Field(..., description="HTTP method")
    path: str = Field(..., description="Request path")
    headers: Dict[str, str] = Field(default_factory=dict, description="Request headers")
    query_params: Dict[str, str] = Field(default_factory=dict, description="Query parameters")
    body: Optional[str] = Field(None, description="Request body")
    
    # API context (for resource scoping)
    api_name: Optional[str] = Field(None, description="API name for resource scoping")
    api_version: Optional[str] = Field(None, description="API version")
    
    # Policy configuration
    policy_name: str = Field(..., description="Name of the policy")
    policy_type: str = Field(..., description="Type of the policy")
    policy_config: Dict[str, Any] = Field(default_factory=dict, description="Policy configuration")
    
    # Execution context
    variables: Dict[str, Any] = Field(default_factory=dict, description="Context variables")
    flow_variables: Dict[str, Any] = Field(default_factory=dict, description="Flow variables")
    
    # Additional metadata
    client_ip: Optional[str] = Field(None, description="Client IP address")
    user_agent: Optional[str] = Field(None, description="User agent")
    request_id: Optional[str] = Field(None, description="Unique request ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "method": "POST",
                "path": "/api/v1/users",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer token123"
                },
                "query_params": {
                    "limit": "10"
                },
                "body": '{"name": "John Doe"}',
                "policy_name": "ValidateUser",
                "policy_type": "javascript",
                "policy_config": {
                    "script": "function validate() { return true; }"
                },
                "variables": {
                    "user_id": "12345"
                },
                "client_ip": "192.168.1.1",
                "request_id": "req-123-456"
            }
        }


class PolicyResponse(BaseModel):
    """Response model for policy execution."""
    
    # Execution result
    success: bool = Field(..., description="Whether policy execution succeeded")
    message: Optional[str] = Field(None, description="Result message")
    
    # Response modifications
    status_code: Optional[int] = Field(None, description="HTTP status code to return")
    headers: Dict[str, str] = Field(default_factory=dict, description="Headers to add/modify")
    body: Optional[str] = Field(None, description="Response body")
    
    # Flow control
    continue_processing: bool = Field(True, description="Whether to continue request processing")
    terminate_request: bool = Field(False, description="Whether to terminate the request")
    
    # Variable updates
    variables: Dict[str, Any] = Field(default_factory=dict, description="Updated variables")
    
    # Execution metadata
    execution_time_ms: Optional[float] = Field(None, description="Execution time in milliseconds")
    policy_name: Optional[str] = Field(None, description="Name of executed policy")
    
    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "message": "Policy executed successfully",
                "status_code": 200,
                "headers": {
                    "X-Policy-Executed": "ValidateUser"
                },
                "body": '{"validated": true}',
                "continue_processing": True,
                "terminate_request": False,
                "variables": {
                    "validation_result": "passed"
                },
                "execution_time_ms": 15.5,
                "policy_name": "ValidateUser"
            }
        }


class HealthResponse(BaseModel):
    """Health check response model."""
    
    status: str = Field(..., description="Service status")
    version: str = Field(..., description="Service version")
    handlers_loaded: int = Field(..., description="Number of policy handlers loaded")
    available_policies: List[str] = Field(..., description="List of available policy types")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "handlers_loaded": 20,
                "available_policies": [
                    "javascript",
                    "java_callout",
                    "service_callout",
                    "kvm_operations"
                ]
            }
        }


class ErrorResponse(BaseModel):
    """Error response model."""
    
    error: bool = Field(True, description="Error flag")
    status_code: int = Field(..., description="HTTP status code")
    message: str = Field(..., description="Error message")
    path: Optional[str] = Field(None, description="Request path")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": True,
                "status_code": 500,
                "message": "Policy execution failed",
                "path": "/policies/javascript",
                "details": {
                    "policy_name": "ValidateUser",
                    "error_type": "ScriptExecutionError"
                }
            }
        }


# Specific request/response models for different policy types

class JavaScriptPolicyRequest(PolicyRequest):
    """JavaScript policy specific request."""
    
    script_content: str = Field(..., description="JavaScript code to execute")
    timeout_ms: int = Field(5000, description="Execution timeout in milliseconds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "method": "POST",
                "path": "/api/users",
                "policy_name": "ValidateUser",
                "policy_type": "javascript",
                "script_content": "function validate(request) { return request.body.name !== ''; }",
                "timeout_ms": 3000
            }
        }


class ServiceCalloutRequest(PolicyRequest):
    """Service callout policy specific request."""
    
    target_url: str = Field(..., description="Target service URL")
    target_method: str = Field("GET", description="HTTP method for target service")
    target_headers: Dict[str, str] = Field(default_factory=dict, description="Headers for target service")
    target_body: Optional[str] = Field(None, description="Body for target service")
    timeout_seconds: int = Field(30, description="Request timeout in seconds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "method": "POST",
                "path": "/api/users",
                "policy_name": "CallUserService",
                "policy_type": "service_callout",
                "target_url": "https://user-service.example.com/validate",
                "target_method": "POST",
                "target_headers": {
                    "Content-Type": "application/json"
                },
                "target_body": '{"user_id": "123"}',
                "timeout_seconds": 10
            }
        }


class KVMOperationRequest(PolicyRequest):
    """KVM operations policy specific request."""
    
    operation: str = Field(..., description="KVM operation: get, set, delete")
    key: str = Field(..., description="KVM key")
    value: Optional[str] = Field(None, description="Value for set operation")
    map_name: str = Field("default", description="KVM map name")
    ttl_seconds: Optional[int] = Field(None, description="TTL for set operation")
    
    class Config:
        json_schema_extra = {
            "example": {
                "method": "GET",
                "path": "/api/users/123",
                "policy_name": "GetUserCache",
                "policy_type": "kvm_operations",
                "operation": "get",
                "key": "user_123",
                "map_name": "user_cache"
            }
        }


class ThreatProtectionRequest(PolicyRequest):
    """Threat protection policy specific request."""
    
    content_type: str = Field(..., description="Content type to validate")
    max_depth: int = Field(10, description="Maximum nesting depth")
    max_attributes: int = Field(100, description="Maximum attributes (XML)")
    max_string_length: int = Field(10000, description="Maximum string length")
    
    class Config:
        json_schema_extra = {
            "example": {
                "method": "POST",
                "path": "/api/data",
                "body": '{"user": {"profile": {"name": "John"}}}',
                "policy_name": "ValidateJSON",
                "policy_type": "json_threat_protection",
                "content_type": "application/json",
                "max_depth": 5,
                "max_string_length": 1000
            }
        }