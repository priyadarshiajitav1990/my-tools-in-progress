"""
Resource Loader
===============

Handles loading of external resource files (JavaScript, Java/JAR, Python, XSLT, etc.)
with support for multiple storage strategies.
"""

import asyncio
import aiofiles
import httpx
import base64
import hashlib
import time
from pathlib import Path
from typing import Dict, Any, Optional, Union
import logging

logger = logging.getLogger("apigee_policy_service")


class ResourceCache:
    """Cache for resource files with TTL support."""
    
    def __init__(self, max_size: int = 100, default_ttl: int = 3600):
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Union[str, bytes]]:
        """Get cached resource."""
        async with self.lock:
            if key in self.cache:
                entry = self.cache[key]
                if time.time() - entry['timestamp'] < entry['ttl']:
                    logger.debug(f"Cache hit for: {key}")
                    return entry['content']
                else:
                    logger.debug(f"Cache expired for: {key}")
                    del self.cache[key]
        return None
    
    async def set(self, key: str, content: Union[str, bytes], ttl: Optional[int] = None):
        """Cache resource with TTL."""
        async with self.lock:
            # Evict oldest entry if cache is full
            if len(self.cache) >= self.max_size:
                oldest_key = min(
                    self.cache.keys(),
                    key=lambda k: self.cache[k]['timestamp']
                )
                del self.cache[oldest_key]
                logger.debug(f"Evicted cache entry: {oldest_key}")
            
            self.cache[key] = {
                'content': content,
                'timestamp': time.time(),
                'ttl': ttl or self.default_ttl
            }
            logger.debug(f"Cached resource: {key}")
    
    async def clear(self):
        """Clear all cached resources."""
        async with self.lock:
            self.cache.clear()
            logger.info("Resource cache cleared")


class ResourceLoader:
    """Loads resources from various sources with caching and validation."""
    
    # Resource size limits (bytes)
    MAX_SCRIPT_SIZE = 1024 * 1024  # 1MB for scripts
    MAX_JAR_SIZE = 50 * 1024 * 1024  # 50MB for JAR files
    MAX_XSLT_SIZE = 512 * 1024  # 512KB for XSLT
    
    def __init__(self, base_path: str = "/app/resources"):
        self.base_path = Path(base_path)
        self.cache = ResourceCache()
        self.http_client = None
    
    async def initialize(self):
        """Initialize the resource loader."""
        self.http_client = httpx.AsyncClient(timeout=30.0)
        
        # Ensure base path exists
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Resource loader initialized with base path: {self.base_path}")
    
    async def cleanup(self):
        """Cleanup resources."""
        if self.http_client:
            await self.http_client.aclose()
        await self.cache.clear()
    
    async def load_script(
        self,
        config: Dict[str, Any],
        api_name: Optional[str] = None,
        resource_type: str = "script"
    ) -> str:
        """
        Load script content from inline, file, or URL with API scoping.
        
        Args:
            config: Policy configuration containing script source
            api_name: API name for scoping resources
            resource_type: Type of resource (script, xslt, etc.)
        
        Returns:
            Script content as string
        """
        # Option 1: Inline content
        content_key = f"{resource_type}_content"
        if content_key in config:
            logger.debug(f"Using inline {resource_type} content")
            return config[content_key]
        
        # Option 2: File system with API scoping
        file_key = f"{resource_type}_file"
        if file_key in config:
            file_path = config[file_key]
            
            # Determine API name (from config or parameter)
            api = config.get('api_name') or api_name
            
            # Build base path with API scoping if API name provided
            if api:
                base_path_override = str(self.base_path / api)
                logger.debug(f"Using API-scoped path: {base_path_override}")
            else:
                base_path_override = config.get(f"{resource_type}_base_path")
            
            return await self.load_from_file(
                file_path,
                base_path_override,
                max_size=self.MAX_SCRIPT_SIZE
            )
        
        # Option 3: URL
        url_key = f"{resource_type}_url"
        if url_key in config:
            url = config[url_key]
            cache_ttl = config.get('cache_ttl', 3600)
            
            return await self.load_from_url(
                url,
                cache_ttl=cache_ttl,
                max_size=self.MAX_SCRIPT_SIZE
            )
        
        raise ValueError(f"No {resource_type} source specified in configuration")
    
    async def load_from_file(
        self,
        file_path: str,
        base_path_override: Optional[str] = None,
        max_size: int = MAX_SCRIPT_SIZE,
        binary: bool = False
    ) -> Union[str, bytes]:
        """
        Load resource from file system.
        
        Args:
            file_path: Relative path to file
            base_path_override: Override default base path
            max_size: Maximum file size in bytes
            binary: Load as binary data
        
        Returns:
            File content as string or bytes
        """
        # Determine base path
        base = Path(base_path_override) if base_path_override else self.base_path
        
        # Validate and resolve path
        full_path = self._validate_file_path(base, file_path)
        
        # Check cache
        cache_key = f"file:{full_path}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        # Check file exists
        if not full_path.exists():
            raise FileNotFoundError(f"Resource file not found: {full_path}")
        
        # Check file size
        file_size = full_path.stat().st_size
        if file_size > max_size:
            raise ValueError(
                f"File too large: {file_size} bytes (max: {max_size})"
            )
        
        # Load file
        logger.info(f"Loading resource from file: {full_path}")
        
        mode = 'rb' if binary else 'r'
        encoding = None if binary else 'utf-8'
        
        async with aiofiles.open(full_path, mode=mode, encoding=encoding) as f:
            content = await f.read()
        
        # Cache it
        await self.cache.set(cache_key, content)
        
        return content
    
    async def load_from_url(
        self,
        url: str,
        cache_ttl: int = 3600,
        max_size: int = MAX_SCRIPT_SIZE,
        binary: bool = False
    ) -> Union[str, bytes]:
        """
        Load resource from URL.
        
        Args:
            url: Resource URL
            cache_ttl: Cache TTL in seconds
            max_size: Maximum content size in bytes
            binary: Load as binary data
        
        Returns:
            Resource content as string or bytes
        """
        # Check cache
        cache_key = f"url:{url}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        # Fetch from URL
        logger.info(f"Fetching resource from URL: {url}")
        
        if not self.http_client:
            raise RuntimeError("Resource loader not initialized")
        
        try:
            response = await self.http_client.get(url)
            response.raise_for_status()
            
            # Check content size
            content_length = response.headers.get('content-length')
            if content_length and int(content_length) > max_size:
                raise ValueError(
                    f"Content too large: {content_length} bytes (max: {max_size})"
                )
            
            # Get content
            content = response.content if binary else response.text
            
            # Validate size
            actual_size = len(content)
            if actual_size > max_size:
                raise ValueError(
                    f"Content too large: {actual_size} bytes (max: {max_size})"
                )
            
            # Cache it
            await self.cache.set(cache_key, content, ttl=cache_ttl)
            
            return content
            
        except httpx.HTTPError as e:
            raise RuntimeError(f"Failed to fetch resource from {url}: {str(e)}")
    
    async def load_jar(self, config: Dict[str, Any], api_name: Optional[str] = None) -> Path:
        """
        Load JAR file for Java callout with API scoping.
        
        Args:
            config: Policy configuration
            api_name: API name for scoping
        
        Returns:
            Path to JAR file
        """
        # Option 1: File system reference with API scoping
        if 'jar_file' in config:
            jar_file = config['jar_file']
            
            # Determine API name (from config or parameter)
            api = config.get('api_name') or api_name
            
            # Build classpath with API scoping if API name provided
            if api:
                classpath = str(self.base_path / api / 'lib')
                logger.debug(f"Using API-scoped classpath: {classpath}")
            else:
                classpath = config.get('classpath', str(self.base_path / 'lib'))
            
            full_path = self._validate_file_path(Path(classpath), jar_file)
            
            if not full_path.exists():
                raise FileNotFoundError(f"JAR file not found: {full_path}")
            
            # Validate size
            file_size = full_path.stat().st_size
            if file_size > self.MAX_JAR_SIZE:
                raise ValueError(
                    f"JAR file too large: {file_size} bytes (max: {self.MAX_JAR_SIZE})"
                )
            
            logger.info(f"Using JAR file: {full_path}")
            return full_path
        
        # Option 2: Base64 encoded JAR
        if 'jar_content_base64' in config:
            # Decode JAR content
            jar_content = base64.b64decode(config['jar_content_base64'])
            
            # Validate size
            if len(jar_content) > self.MAX_JAR_SIZE:
                raise ValueError(
                    f"JAR content too large: {len(jar_content)} bytes (max: {self.MAX_JAR_SIZE})"
                )
            
            # Create temporary file
            import uuid
            temp_dir = self.base_path / 'temp'
            temp_dir.mkdir(exist_ok=True)
            
            temp_jar = temp_dir / f"jar_{uuid.uuid4().hex}.jar"
            
            async with aiofiles.open(temp_jar, 'wb') as f:
                await f.write(jar_content)
            
            logger.info(f"Created temporary JAR file: {temp_jar}")
            return temp_jar
        
        # Option 3: URL reference
        if 'jar_url' in config:
            url = config['jar_url']
            
            # Download JAR
            jar_content = await self.load_from_url(
                url,
                cache_ttl=config.get('cache_ttl', 86400),  # 24 hours
                max_size=self.MAX_JAR_SIZE,
                binary=True
            )
            
            # Save to temporary file
            import uuid
            temp_dir = self.base_path / 'temp'
            temp_dir.mkdir(exist_ok=True)
            
            # Use URL hash as filename for caching
            url_hash = hashlib.md5(url.encode()).hexdigest()
            temp_jar = temp_dir / f"jar_{url_hash}.jar"
            
            if not temp_jar.exists():
                async with aiofiles.open(temp_jar, 'wb') as f:
                    await f.write(jar_content)
            
            logger.info(f"Downloaded JAR from URL: {temp_jar}")
            return temp_jar
        
        raise ValueError("No JAR source specified in configuration")
    
    def _validate_file_path(self, base_path: Path, file_path: str) -> Path:
        """
        Validate file path to prevent directory traversal attacks.
        
        Args:
            base_path: Base directory path
            file_path: Relative file path
        
        Returns:
            Validated absolute path
        
        Raises:
            ValueError: If path is invalid or outside base directory
        """
        # Resolve absolute path
        full_path = (base_path / file_path).resolve()
        
        # Ensure path is within base directory
        try:
            full_path.relative_to(base_path.resolve())
        except ValueError:
            raise ValueError(
                f"Invalid file path: {file_path} (outside base directory)"
            )
        
        return full_path
    
    async def validate_javascript(self, script_content: str) -> bool:
        """
        Validate JavaScript syntax.
        
        Args:
            script_content: JavaScript code
        
        Returns:
            True if valid, False otherwise
        """
        try:
            process = await asyncio.create_subprocess_exec(
                'node', '--check',
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(script_content.encode()),
                timeout=5
            )
            
            return process.returncode == 0
            
        except (FileNotFoundError, asyncio.TimeoutError):
            logger.warning("JavaScript validation skipped (Node.js not available)")
            return True  # Skip validation if Node.js not available
        except Exception as e:
            logger.error(f"JavaScript validation error: {str(e)}")
            return False
    
    async def validate_python(self, script_content: str) -> bool:
        """
        Validate Python syntax.
        
        Args:
            script_content: Python code
        
        Returns:
            True if valid, False otherwise
        """
        try:
            compile(script_content, '<string>', 'exec')
            return True
        except SyntaxError as e:
            logger.error(f"Python syntax error: {str(e)}")
            return False


# Global resource loader instance
resource_loader = ResourceLoader()