"""
Metrics Collection
==================

Simple metrics collection for monitoring policy execution.
"""

import time
from typing import Dict, Any, Optional
from collections import defaultdict, deque
from datetime import datetime, timedelta
import threading


class MetricsCollector:
    """Simple metrics collector for policy execution."""
    
    def __init__(self, max_history: int = 1000):
        self.max_history = max_history
        self.lock = threading.Lock()
        
        # Counters
        self.policy_executions = defaultdict(int)
        self.policy_successes = defaultdict(int)
        self.policy_failures = defaultdict(int)
        
        # Timing data
        self.execution_times = defaultdict(lambda: deque(maxlen=max_history))
        
        # Error tracking
        self.error_counts = defaultdict(int)
        self.recent_errors = deque(maxlen=100)
        
        # System metrics
        self.start_time = time.time()
        self.total_requests = 0
        self.active_requests = 0
    
    def record_policy_execution(
        self, 
        policy_type: str, 
        execution_time: float, 
        success: bool, 
        error: Optional[str] = None
    ):
        """Record a policy execution."""
        with self.lock:
            self.policy_executions[policy_type] += 1
            self.total_requests += 1
            
            if success:
                self.policy_successes[policy_type] += 1
            else:
                self.policy_failures[policy_type] += 1
                if error:
                    self.error_counts[error] += 1
                    self.recent_errors.append({
                        'timestamp': datetime.utcnow().isoformat(),
                        'policy_type': policy_type,
                        'error': error
                    })
            
            self.execution_times[policy_type].append(execution_time)
    
    def start_request(self):
        """Mark the start of a request."""
        with self.lock:
            self.active_requests += 1
    
    def end_request(self):
        """Mark the end of a request."""
        with self.lock:
            self.active_requests = max(0, self.active_requests - 1)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics."""
        with self.lock:
            uptime = time.time() - self.start_time
            
            # Calculate averages
            avg_times = {}
            for policy_type, times in self.execution_times.items():
                if times:
                    avg_times[policy_type] = sum(times) / len(times)
            
            # Calculate success rates
            success_rates = {}
            for policy_type in self.policy_executions:
                total = self.policy_executions[policy_type]
                successes = self.policy_successes[policy_type]
                success_rates[policy_type] = (successes / total * 100) if total > 0 else 0
            
            return {
                'system': {
                    'uptime_seconds': uptime,
                    'total_requests': self.total_requests,
                    'active_requests': self.active_requests,
                    'requests_per_second': self.total_requests / uptime if uptime > 0 else 0
                },
                'policies': {
                    'executions': dict(self.policy_executions),
                    'successes': dict(self.policy_successes),
                    'failures': dict(self.policy_failures),
                    'success_rates': success_rates,
                    'average_execution_times': avg_times
                },
                'errors': {
                    'error_counts': dict(self.error_counts),
                    'recent_errors': list(self.recent_errors)[-10:]  # Last 10 errors
                }
            }
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status based on metrics."""
        with self.lock:
            # Calculate overall success rate
            total_successes = sum(self.policy_successes.values())
            total_executions = sum(self.policy_executions.values())
            overall_success_rate = (total_successes / total_executions * 100) if total_executions > 0 else 100
            
            # Determine health status
            if overall_success_rate >= 95:
                status = "healthy"
            elif overall_success_rate >= 80:
                status = "degraded"
            else:
                status = "unhealthy"
            
            return {
                'status': status,
                'success_rate': overall_success_rate,
                'total_requests': total_executions,
                'active_requests': self.active_requests,
                'uptime_seconds': time.time() - self.start_time
            }


# Global metrics collector instance
metrics = MetricsCollector()