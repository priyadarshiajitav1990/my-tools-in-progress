"""
Apigee Condition Evaluator
==========================

Evaluates Apigee-style condition expressions for conditional flows,
route rules, and fault rules.
"""

import re
import logging
from typing import Dict, Any, Optional, Union
from fnmatch import fnmatch

logger = logging.getLogger("apigee_policy_service")


class ConditionEvaluator:
    """Evaluates Apigee condition expressions."""
    
    # Supported operators
    OPERATORS = {
        '=': lambda a, b: str(a) == str(b),
        '!=': lambda a, b: str(a) != str(b),
        '>': lambda a, b: float(a) > float(b),
        '<': lambda a, b: float(a) < float(b),
        '>=': lambda a, b: float(a) >= float(b),
        '<=': lambda a, b: float(a) <= float(b),
        'MatchesPath': lambda a, b: fnmatch(str(a), str(b)),
        'Contains': lambda a, b: str(b) in str(a),
        'StartsWith': lambda a, b: str(a).startswith(str(b)),
        'EndsWith': lambda a, b: str(a).endswith(str(b)),
        '~': lambda a, b: bool(re.search(str(b), str(a))),  # Regex match
        '!~': lambda a, b: not bool(re.search(str(b), str(a)))  # Regex not match
    }
    
    def __init__(self):
        """Initialize condition evaluator."""
        self.logger = logger
    
    def evaluate(self, condition: str, context: Dict[str, Any]) -> bool:
        """
        Evaluate Apigee condition expression.
        
        Args:
            condition: Apigee condition string
            context: Context containing variables (request, response, proxy, etc.)
        
        Returns:
            Boolean result of condition evaluation
        
        Examples:
            >>> evaluator.evaluate('request.verb = "GET"', context)
            True
            >>> evaluator.evaluate('request.header.content-type = "application/json"', context)
            True
            >>> evaluator.evaluate('proxy.pathsuffix MatchesPath "/users/*"', context)
            True
        """
        if not condition or not condition.strip():
            return True  # Empty condition is always true
        
        try:
            # Handle logical operators (and, or, not)
            if ' and ' in condition.lower():
                return self._evaluate_and(condition, context)
            elif ' or ' in condition.lower():
                return self._evaluate_or(condition, context)
            elif condition.strip().lower().startswith('not '):
                return not self.evaluate(condition[4:].strip(), context)
            
            # Evaluate single condition
            return self._evaluate_single_condition(condition, context)
            
        except Exception as e:
            self.logger.error(f"Error evaluating condition '{condition}': {str(e)}")
            return False
    
    def _evaluate_and(self, condition: str, context: Dict[str, Any]) -> bool:
        """Evaluate AND condition."""
        # Split by 'and' (case insensitive)
        parts = re.split(r'\s+and\s+', condition, flags=re.IGNORECASE)
        
        for part in parts:
            if not self.evaluate(part.strip(), context):
                return False
        
        return True
    
    def _evaluate_or(self, condition: str, context: Dict[str, Any]) -> bool:
        """Evaluate OR condition."""
        # Split by 'or' (case insensitive)
        parts = re.split(r'\s+or\s+', condition, flags=re.IGNORECASE)
        
        for part in parts:
            if self.evaluate(part.strip(), context):
                return True
        
        return False
    
    def _evaluate_single_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """Evaluate single condition expression."""
        # Remove parentheses
        condition = condition.strip('()')
        
        # Try to match operator patterns
        for op_name, op_func in self.OPERATORS.items():
            # Handle special operators (MatchesPath, Contains, etc.)
            if op_name in ['MatchesPath', 'Contains', 'StartsWith', 'EndsWith']:
                pattern = rf'(.+?)\s+{op_name}\s+(.+)'
                match = re.match(pattern, condition, re.IGNORECASE)
                if match:
                    left = match.group(1).strip()
                    right = match.group(2).strip()
                    
                    left_value = self._get_variable_value(left, context)
                    right_value = self._parse_literal(right)
                    
                    return op_func(left_value, right_value)
            
            # Handle comparison operators
            elif op_name in ['=', '!=', '>', '<', '>=', '<=', '~', '!~']:
                # Escape special regex characters in operator
                escaped_op = re.escape(op_name)
                pattern = rf'(.+?)\s*{escaped_op}\s*(.+)'
                match = re.match(pattern, condition)
                if match:
                    left = match.group(1).strip()
                    right = match.group(2).strip()
                    
                    left_value = self._get_variable_value(left, context)
                    right_value = self._parse_literal(right)
                    
                    try:
                        return op_func(left_value, right_value)
                    except (ValueError, TypeError):
                        # If numeric comparison fails, try string comparison
                        return str(left_value) == str(right_value) if op_name == '=' else str(left_value) != str(right_value)
        
        # If no operator found, check if it's a boolean variable
        value = self._get_variable_value(condition, context)
        return self._to_boolean(value)
    
    def _get_variable_value(self, variable: str, context: Dict[str, Any]) -> Any:
        """
        Get variable value from context.
        
        Supports Apigee variable syntax:
        - request.verb
        - request.header.content-type
        - request.queryparam.limit
        - proxy.pathsuffix
        - response.status.code
        - client.ip
        - flow.variable_name
        """
        variable = variable.strip()
        
        # Handle quoted strings as literals
        if (variable.startswith('"') and variable.endswith('"')) or \
           (variable.startswith("'") and variable.endswith("'")):
            return variable[1:-1]
        
        # Handle numeric literals
        try:
            if '.' in variable:
                return float(variable)
            return int(variable)
        except ValueError:
            pass
        
        # Split variable path
        parts = variable.split('.')
        
        # Navigate through context
        value = context
        for part in parts:
            if isinstance(value, dict):
                # Handle special cases
                if part == 'header' and 'headers' in value:
                    value = value['headers']
                elif part == 'queryparam' and 'query_params' in value:
                    value = value['query_params']
                elif part in value:
                    value = value[part]
                else:
                    # Try flow_variables
                    if 'flow_variables' in context:
                        flow_var = f"{'.'.join(parts)}"
                        if flow_var in context['flow_variables']:
                            return context['flow_variables'][flow_var]
                    
                    # Try variables
                    if 'variables' in context:
                        var_name = f"{'.'.join(parts)}"
                        if var_name in context['variables']:
                            return context['variables'][var_name]
                    
                    return None
            else:
                return None
        
        return value
    
    def _parse_literal(self, value: str) -> Union[str, int, float, bool]:
        """Parse literal value from string."""
        value = value.strip()
        
        # Handle quoted strings
        if (value.startswith('"') and value.endswith('"')) or \
           (value.startswith("'") and value.endswith("'")):
            return value[1:-1]
        
        # Handle boolean
        if value.lower() == 'true':
            return True
        if value.lower() == 'false':
            return False
        
        # Handle null
        if value.lower() in ['null', 'nil', 'none']:
            return None
        
        # Handle numbers
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except ValueError:
            pass
        
        # Return as string
        return value
    
    def _to_boolean(self, value: Any) -> bool:
        """Convert value to boolean."""
        if isinstance(value, bool):
            return value
        
        if isinstance(value, str):
            return value.lower() in ['true', '1', 'yes', 'on']
        
        if isinstance(value, (int, float)):
            return value != 0
        
        if value is None:
            return False
        
        return bool(value)
    
    def validate_condition_syntax(self, condition: str) -> tuple[bool, Optional[str]]:
        """
        Validate condition syntax.
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not condition or not condition.strip():
            return True, None
        
        try:
            # Check for balanced parentheses
            if condition.count('(') != condition.count(')'):
                return False, "Unbalanced parentheses"
            
            # Check for valid operators
            has_operator = False
            for op in self.OPERATORS.keys():
                if op in condition:
                    has_operator = True
                    break
            
            # Check for logical operators
            if any(logical_op in condition.lower() for logical_op in [' and ', ' or ', 'not ']):
                has_operator = True
            
            if not has_operator:
                # Might be a simple boolean variable
                return True, None
            
            return True, None
            
        except Exception as e:
            return False, str(e)


# Global instance
condition_evaluator = ConditionEvaluator()
