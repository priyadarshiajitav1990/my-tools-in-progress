"""
Apigee to Kong Variable Mapper
===============================

Provides bidirectional mapping between Apigee and Kong variables,
enabling seamless integration and automatic variable translation.
"""

from typing import Dict, Any, Optional, List
import re
from datetime import datetime
import logging

logger = logging.getLogger("apigee_policy_service")


class VariableMapper:
    """Maps variables between Apigee and Kong formats."""
    
    # Apigee to Kong variable mappings
    APIGEE_TO_KONG_MAP = {
        # Request variables
        "request.verb": "kong.request.method",
        "request.method": "kong.request.method",
        "request.uri": "kong.request.path_with_query",
        "request.path": "kong.request.path",
        "request.querystring": "kong.request.query_string",
        "request.content": "kong.request.body",
        "request.body": "kong.request.body",
        
        # Client variables
        "client.ip": "kong.client.ip",
        "client.host": "kong.request.host",
        "client.port": "kong.request.port",
        "client.scheme": "kong.request.scheme",
        
        # Response variables
        "response.status.code": "kong.response.status",
        "response.reason.phrase": "kong.response.reason",
        "response.content": "kong.response.body",
        "response.body": "kong.response.body",
        
        # System variables
        "messageid": "kong.request.id",
        "system.uuid": "kong.request.id",
        
        # Target/Upstream variables
        "target.url": "kong.upstream.url",
        "target.host": "kong.upstream.host",
        "target.port": "kong.upstream.port",
        "target.scheme": "kong.upstream.scheme"
    }
    
    # Kong to Apigee variable mappings (reverse)
    KONG_TO_APIGEE_MAP = {v: k for k, v in APIGEE_TO_KONG_MAP.items()}
    
    # Variable patterns for dynamic mapping
    APIGEE_PATTERNS = {
        r"^request\.header\.(.+)$": "kong.request.header.{0}",
        r"^request\.queryparam\.(.+)$": "kong.request.query.{0}",
        r"^request\.formparam\.(.+)$": "kong.request.form.{0}",
        r"^response\.header\.(.+)$": "kong.response.header.{0}",
        r"^target\.response\.header\.(.+)$": "kong.upstream.response.header.{0}"
    }
    
    KONG_PATTERNS = {
        r"^kong\.request\.header\.(.+)$": "request.header.{0}",
        r"^kong\.request\.query\.(.+)$": "request.queryparam.{0}",
        r"^kong\.request\.form\.(.+)$": "request.formparam.{0}",
        r"^kong\.response\.header\.(.+)$": "response.header.{0}",
        r"^kong\.upstream\.response\.header\.(.+)$": "target.response.header.{0}"
    }
    
    def __init__(self):
        """Initialize the variable mapper."""
        self.logger = logger
    
    def apigee_to_kong(self, apigee_var: str) -> str:
        """
        Convert Apigee variable name to Kong format.
        
        Args:
            apigee_var: Apigee variable name
            
        Returns:
            Kong variable name
        """
        # Check direct mapping
        if apigee_var in self.APIGEE_TO_KONG_MAP:
            return self.APIGEE_TO_KONG_MAP[apigee_var]
        
        # Check pattern-based mapping
        for pattern, template in self.APIGEE_PATTERNS.items():
            match = re.match(pattern, apigee_var)
            if match:
                return template.format(match.group(1))
        
        # No mapping found, return as-is
        self.logger.debug(f"No Kong mapping found for Apigee variable: {apigee_var}")
        return apigee_var
    
    def kong_to_apigee(self, kong_var: str) -> str:
        """
        Convert Kong variable name to Apigee format.
        
        Args:
            kong_var: Kong variable name
            
        Returns:
            Apigee variable name
        """
        # Check direct mapping
        if kong_var in self.KONG_TO_APIGEE_MAP:
            return self.KONG_TO_APIGEE_MAP[kong_var]
        
        # Check pattern-based mapping
        for pattern, template in self.KONG_PATTERNS.items():
            match = re.match(pattern, kong_var)
            if match:
                return template.format(match.group(1))
        
        # No mapping found, return as-is
        self.logger.debug(f"No Apigee mapping found for Kong variable: {kong_var}")
        return kong_var
    
    def map_kong_to_apigee_context(self, kong_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map Kong context to Apigee flow variables.
        
        Args:
            kong_context: Kong context dictionary
            
        Returns:
            Apigee flow variables dictionary
        """
        flow_variables = {}
        
        # Map request variables
        if "request" in kong_context:
            request = kong_context["request"]
            
            flow_variables["request.verb"] = request.get("method", "")
            flow_variables["request.method"] = request.get("method", "")
            flow_variables["request.uri"] = request.get("uri", "")
            flow_variables["request.path"] = request.get("path", "")
            flow_variables["request.querystring"] = request.get("querystring", "")
            flow_variables["request.content"] = request.get("body", "")
            flow_variables["request.body"] = request.get("body", "")
            
            # Map headers
            if "headers" in request:
                for name, value in request["headers"].items():
                    header_name = name.lower()
                    flow_variables[f"request.header.{header_name}"] = value
            
            # Map query parameters
            if "query_params" in request:
                for name, value in request["query_params"].items():
                    flow_variables[f"request.queryparam.{name}"] = value
        
        # Map client variables
        if "client" in kong_context:
            client = kong_context["client"]
            flow_variables["client.ip"] = client.get("ip", "")
            flow_variables["client.host"] = client.get("host", "")
            flow_variables["client.port"] = str(client.get("port", ""))
            flow_variables["client.scheme"] = client.get("scheme", "")
        
        # Map system variables
        if "system" in kong_context:
            system = kong_context["system"]
            flow_variables["system.time"] = system.get("time", 0)
            flow_variables["system.uuid"] = system.get("uuid", "")
            flow_variables["messageid"] = system.get("request_id", "")
        
        # Map service/route variables
        if "service" in kong_context:
            service = kong_context["service"]
            flow_variables["apiproxy.name"] = service.get("name", "")
            flow_variables["organization.name"] = service.get("organization", "")
            flow_variables["environment.name"] = service.get("environment", "")
        
        # Map response variables (if available)
        if "response" in kong_context:
            response = kong_context["response"]
            flow_variables["response.status.code"] = response.get("status_code", 0)
            flow_variables["response.reason.phrase"] = response.get("reason", "")
            flow_variables["response.content"] = response.get("body", "")
            
            # Map response headers
            if "headers" in response:
                for name, value in response["headers"].items():
                    header_name = name.lower()
                    flow_variables[f"response.header.{header_name}"] = value
        
        return flow_variables
    
    def map_apigee_to_kong_context(self, flow_variables: Dict[str, Any]) -> Dict[str, Any]:
        """
        Map Apigee flow variables to Kong context.
        
        Args:
            flow_variables: Apigee flow variables dictionary
            
        Returns:
            Kong context dictionary
        """
        kong_context = {
            "request": {},
            "client": {},
            "system": {},
            "response": {}
        }
        
        # Map request variables
        kong_context["request"]["method"] = flow_variables.get("request.verb", "")
        kong_context["request"]["uri"] = flow_variables.get("request.uri", "")
        kong_context["request"]["path"] = flow_variables.get("request.path", "")
        kong_context["request"]["querystring"] = flow_variables.get("request.querystring", "")
        kong_context["request"]["body"] = flow_variables.get("request.content", "")
        
        # Extract headers
        kong_context["request"]["headers"] = {}
        for key, value in flow_variables.items():
            if key.startswith("request.header."):
                header_name = key.replace("request.header.", "")
                kong_context["request"]["headers"][header_name] = value
        
        # Extract query parameters
        kong_context["request"]["query_params"] = {}
        for key, value in flow_variables.items():
            if key.startswith("request.queryparam."):
                param_name = key.replace("request.queryparam.", "")
                kong_context["request"]["query_params"][param_name] = value
        
        # Map client variables
        kong_context["client"]["ip"] = flow_variables.get("client.ip", "")
        kong_context["client"]["host"] = flow_variables.get("client.host", "")
        kong_context["client"]["port"] = flow_variables.get("client.port", "")
        kong_context["client"]["scheme"] = flow_variables.get("client.scheme", "")
        
        # Map system variables
        kong_context["system"]["time"] = flow_variables.get("system.time", 0)
        kong_context["system"]["uuid"] = flow_variables.get("system.uuid", "")
        kong_context["system"]["request_id"] = flow_variables.get("messageid", "")
        
        # Map response variables
        kong_context["response"]["status_code"] = flow_variables.get("response.status.code", 0)
        kong_context["response"]["reason"] = flow_variables.get("response.reason.phrase", "")
        kong_context["response"]["body"] = flow_variables.get("response.content", "")
        
        # Extract response headers
        kong_context["response"]["headers"] = {}
        for key, value in flow_variables.items():
            if key.startswith("response.header."):
                header_name = key.replace("response.header.", "")
                kong_context["response"]["headers"][header_name] = value
        
        return kong_context
    
    def normalize_variable_name(self, var_name: str, target_format: str = "apigee") -> str:
        """
        Normalize variable name to target format.
        
        Args:
            var_name: Variable name to normalize
            target_format: Target format ('apigee' or 'kong')
            
        Returns:
            Normalized variable name
        """
        if target_format.lower() == "apigee":
            return self.kong_to_apigee(var_name)
        elif target_format.lower() == "kong":
            return self.apigee_to_kong(var_name)
        else:
            return var_name
    
    def get_variable_value(
        self, 
        var_name: str, 
        flow_variables: Dict[str, Any], 
        custom_variables: Dict[str, Any]
    ) -> Any:
        """
        Get variable value with automatic format detection and mapping.
        
        Args:
            var_name: Variable name (Apigee or Kong format)
            flow_variables: Flow variables dictionary
            custom_variables: Custom variables dictionary
            
        Returns:
            Variable value or None if not found
        """
        # Try direct lookup in custom variables first
        if var_name in custom_variables:
            return custom_variables[var_name]
        
        # Try direct lookup in flow variables
        if var_name in flow_variables:
            return flow_variables[var_name]
        
        # Try Kong to Apigee mapping
        apigee_name = self.kong_to_apigee(var_name)
        if apigee_name != var_name and apigee_name in flow_variables:
            return flow_variables[apigee_name]
        
        # Try Apigee to Kong mapping
        kong_name = self.apigee_to_kong(var_name)
        if kong_name != var_name and kong_name in flow_variables:
            return flow_variables[kong_name]
        
        return None
    
    def set_variable_value(
        self,
        var_name: str,
        value: Any,
        flow_variables: Dict[str, Any],
        custom_variables: Dict[str, Any]
    ) -> None:
        """
        Set variable value with automatic format handling.
        
        Args:
            var_name: Variable name
            value: Variable value
            flow_variables: Flow variables dictionary (modified in place)
            custom_variables: Custom variables dictionary (modified in place)
        """
        # Response headers go to flow variables
        if var_name.startswith("response.header."):
            flow_variables[var_name] = value
        # Request modifications go to flow variables
        elif var_name.startswith("request."):
            flow_variables[var_name] = value
        # System variables go to flow variables
        elif var_name.startswith("system."):
            flow_variables[var_name] = value
        # Everything else goes to custom variables
        else:
            custom_variables[var_name] = value
    
    def get_all_variable_mappings(self) -> Dict[str, str]:
        """
        Get all variable mappings for documentation/debugging.
        
        Returns:
            Dictionary of Apigee to Kong mappings
        """
        mappings = dict(self.APIGEE_TO_KONG_MAP)
        
        # Add pattern examples
        pattern_examples = {
            "request.header.{name}": "kong.request.header.{name}",
            "request.queryparam.{name}": "kong.request.query.{name}",
            "response.header.{name}": "kong.response.header.{name}"
        }
        mappings.update(pattern_examples)
        
        return mappings
    
    def validate_variable_name(self, var_name: str) -> bool:
        """
        Validate if variable name is in valid Apigee or Kong format.
        
        Args:
            var_name: Variable name to validate
            
        Returns:
            True if valid, False otherwise
        """
        # Check if it's a known Apigee variable
        if var_name in self.APIGEE_TO_KONG_MAP:
            return True
        
        # Check if it's a known Kong variable
        if var_name in self.KONG_TO_APIGEE_MAP:
            return True
        
        # Check if it matches Apigee patterns
        for pattern in self.APIGEE_PATTERNS.keys():
            if re.match(pattern, var_name):
                return True
        
        # Check if it matches Kong patterns
        for pattern in self.KONG_PATTERNS.keys():
            if re.match(pattern, var_name):
                return True
        
        # Custom variables are always valid
        return True


# Global variable mapper instance
variable_mapper = VariableMapper()