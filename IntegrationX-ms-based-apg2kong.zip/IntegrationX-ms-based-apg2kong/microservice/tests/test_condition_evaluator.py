"""
Tests for Condition Evaluator
=============================

Tests Apigee condition evaluation logic.
"""

import pytest
from core.condition_evaluator import ConditionEvaluator


@pytest.fixture
def evaluator():
    """Create condition evaluator instance."""
    return ConditionEvaluator()


@pytest.fixture
def context():
    """Create test context."""
    return {
        'request': {
            'verb': 'GET',
            'path': '/api/users/123',
            'header': {
                'content-type': 'application/json',
                'authorization': 'Bearer token123',
                'api-version': 'v2'
            },
            'queryparam': {
                'limit': '10',
                'offset': '0'
            },
            'content': '{"name": "John Doe"}'
        },
        'response': {
            'status': {
                'code': 200
            }
        },
        'proxy': {
            'pathsuffix': '/users/123',
            'basepath': '/api'
        },
        'client': {
            'ip': '192.168.1.100'
        },
        'variables': {
            'user_id': '123',
            'user_validated': True
        },
        'flow_variables': {
            'request.verb': 'GET',
            'request.path': '/api/users/123'
        }
    }


class TestSimpleConditions:
    """Test simple condition evaluation."""
    
    def test_equals_operator(self, evaluator, context):
        """Test equals operator."""
        assert evaluator.evaluate('request.verb = "GET"', context) == True
        assert evaluator.evaluate('request.verb = "POST"', context) == False
    
    def test_not_equals_operator(self, evaluator, context):
        """Test not equals operator."""
        assert evaluator.evaluate('request.verb != "POST"', context) == True
        assert evaluator.evaluate('request.verb != "GET"', context) == False
    
    def test_greater_than_operator(self, evaluator, context):
        """Test greater than operator."""
        assert evaluator.evaluate('request.queryparam.limit > 5', context) == True
        assert evaluator.evaluate('request.queryparam.limit > 20', context) == False
    
    def test_less_than_operator(self, evaluator, context):
        """Test less than operator."""
        assert evaluator.evaluate('request.queryparam.limit < 20', context) == True
        assert evaluator.evaluate('request.queryparam.limit < 5', context) == False
    
    def test_header_access(self, evaluator, context):
        """Test header access."""
        assert evaluator.evaluate('request.header.content-type = "application/json"', context) == True
        assert evaluator.evaluate('request.header.api-version = "v2"', context) == True


class TestPathMatching:
    """Test path matching conditions."""
    
    def test_matches_path_wildcard(self, evaluator, context):
        """Test MatchesPath with wildcards."""
        assert evaluator.evaluate('proxy.pathsuffix MatchesPath "/users/*"', context) == True
        assert evaluator.evaluate('proxy.pathsuffix MatchesPath "/orders/*"', context) == False
    
    def test_matches_path_exact(self, evaluator, context):
        """Test MatchesPath exact match."""
        assert evaluator.evaluate('proxy.pathsuffix MatchesPath "/users/123"', context) == True
        assert evaluator.evaluate('proxy.pathsuffix MatchesPath "/users/456"', context) == False
    
    def test_contains_operator(self, evaluator, context):
        """Test Contains operator."""
        assert evaluator.evaluate('request.path Contains "/users/"', context) == True
        assert evaluator.evaluate('request.path Contains "/orders/"', context) == False
    
    def test_starts_with_operator(self, evaluator, context):
        """Test StartsWith operator."""
        assert evaluator.evaluate('request.path StartsWith "/api"', context) == True
        assert evaluator.evaluate('request.path StartsWith "/v1"', context) == False
    
    def test_ends_with_operator(self, evaluator, context):
        """Test EndsWith operator."""
        assert evaluator.evaluate('proxy.pathsuffix EndsWith "/123"', context) == True
        assert evaluator.evaluate('proxy.pathsuffix EndsWith "/456"', context) == False


class TestLogicalOperators:
    """Test logical operators."""
    
    def test_and_operator(self, evaluator, context):
        """Test AND operator."""
        assert evaluator.evaluate(
            'request.verb = "GET" and request.header.content-type = "application/json"',
            context
        ) == True
        
        assert evaluator.evaluate(
            'request.verb = "GET" and request.header.content-type = "text/xml"',
            context
        ) == False
    
    def test_or_operator(self, evaluator, context):
        """Test OR operator."""
        assert evaluator.evaluate(
            'request.verb = "GET" or request.verb = "POST"',
            context
        ) == True
        
        assert evaluator.evaluate(
            'request.verb = "PUT" or request.verb = "DELETE"',
            context
        ) == False
    
    def test_not_operator(self, evaluator, context):
        """Test NOT operator."""
        assert evaluator.evaluate('not request.verb = "POST"', context) == True
        assert evaluator.evaluate('not request.verb = "GET"', context) == False
    
    def test_complex_condition(self, evaluator, context):
        """Test complex condition with multiple operators."""
        assert evaluator.evaluate(
            '(request.verb = "GET" or request.verb = "HEAD") and proxy.pathsuffix MatchesPath "/users/*"',
            context
        ) == True


class TestVariableAccess:
    """Test variable access."""
    
    def test_custom_variables(self, evaluator, context):
        """Test custom variables."""
        assert evaluator.evaluate('variables.user_id = "123"', context) == True
        assert evaluator.evaluate('variables.user_validated = true', context) == True
    
    def test_flow_variables(self, evaluator, context):
        """Test flow variables."""
        assert evaluator.evaluate('flow_variables.request.verb = "GET"', context) == True
    
    def test_nested_access(self, evaluator, context):
        """Test nested variable access."""
        assert evaluator.evaluate('response.status.code = 200', context) == True
        assert evaluator.evaluate('client.ip = "192.168.1.100"', context) == True


class TestEdgeCases:
    """Test edge cases."""
    
    def test_empty_condition(self, evaluator, context):
        """Test empty condition."""
        assert evaluator.evaluate('', context) == True
        assert evaluator.evaluate('   ', context) == True
    
    def test_missing_variable(self, evaluator, context):
        """Test missing variable."""
        assert evaluator.evaluate('request.header.missing = "value"', context) == False
    
    def test_numeric_comparison(self, evaluator, context):
        """Test numeric comparison."""
        assert evaluator.evaluate('response.status.code >= 200', context) == True
        assert evaluator.evaluate('response.status.code < 300', context) == True
    
    def test_boolean_variable(self, evaluator, context):
        """Test boolean variable."""
        assert evaluator.evaluate('variables.user_validated', context) == True


class TestConditionValidation:
    """Test condition syntax validation."""
    
    def test_valid_condition(self, evaluator):
        """Test valid condition syntax."""
        is_valid, error = evaluator.validate_condition_syntax('request.verb = "GET"')
        assert is_valid == True
        assert error is None
    
    def test_unbalanced_parentheses(self, evaluator):
        """Test unbalanced parentheses."""
        is_valid, error = evaluator.validate_condition_syntax('(request.verb = "GET"')
        assert is_valid == False
        assert 'parentheses' in error.lower()
    
    def test_empty_condition_validation(self, evaluator):
        """Test empty condition validation."""
        is_valid, error = evaluator.validate_condition_syntax('')
        assert is_valid == True
        assert error is None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
