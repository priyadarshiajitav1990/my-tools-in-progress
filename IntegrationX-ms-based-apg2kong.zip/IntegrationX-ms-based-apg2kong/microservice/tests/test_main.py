"""
Main Application Tests
=====================

Tests for the main FastAPI application.
"""

import pytest
import asyncio
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import app
from core.models import PolicyRequest


class TestMainApplication:
    """Test the main FastAPI application."""
    
    def setup_method(self):
        """Setup test client."""
        self.client = TestClient(app)
    
    def test_health_endpoint(self):
        """Test health check endpoint."""
        response = self.client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "healthy"
        assert "version" in data
        assert "handlers_loaded" in data
        assert "available_policies" in data
    
    def test_list_policies_endpoint(self):
        """Test list policies endpoint."""
        response = self.client.get("/policies")
        assert response.status_code == 200
        
        data = response.json()
        assert "available_policies" in data
        assert "total_handlers" in data
        assert "service_info" in data
    
    def test_javascript_policy_endpoint(self):
        """Test JavaScript policy endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestJS",
            "policy_type": "javascript",
            "policy_config": {
                "script_content": "console.log('test');"
            }
        }
        
        response = self.client.post("/policies/javascript", json=request_data)
        # Note: This might fail if Node.js is not available, which is expected
        assert response.status_code in [200, 500]
    
    def test_service_callout_endpoint(self):
        """Test service callout endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestCallout",
            "policy_type": "service_callout",
            "policy_config": {
                "target_url": "https://httpbin.org/get",
                "target_method": "GET"
            }
        }
        
        response = self.client.post("/policies/service-callout", json=request_data)
        assert response.status_code in [200, 500]  # May fail due to network
    
    def test_kvm_operations_endpoint(self):
        """Test KVM operations endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestKVM",
            "policy_type": "kvm_operations",
            "policy_config": {
                "operation": "get",
                "key": "test_key",
                "map_name": "test_map"
            }
        }
        
        response = self.client.post("/policies/kvm-operations", json=request_data)
        # May fail if Redis is not available
        assert response.status_code in [200, 500]
    
    def test_raise_fault_endpoint(self):
        """Test raise fault endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestFault",
            "policy_type": "raise_fault",
            "policy_config": {
                "fault_code": "TEST_ERROR",
                "fault_string": "Test error message",
                "status_code": 400
            }
        }
        
        response = self.client.post("/policies/raise-fault", json=request_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] == False
        assert data["status_code"] == 400
    
    def test_condition_assertion_endpoint(self):
        """Test condition assertion endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestCondition",
            "policy_type": "assert_condition",
            "policy_config": {
                "operation": "evaluate",
                "condition": "true"
            }
        }
        
        response = self.client.post("/policies/assert-condition", json=request_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["success"] == True
    
    def test_generic_policy_endpoint(self):
        """Test generic policy endpoint."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestGeneric",
            "policy_type": "javascript",
            "policy_config": {
                "script_content": "console.log('test');"
            }
        }
        
        response = self.client.post("/policies/javascript", json=request_data)
        # Should work the same as specific endpoint
        assert response.status_code in [200, 500]
    
    def test_invalid_policy_type(self):
        """Test invalid policy type."""
        request_data = {
            "method": "GET",
            "path": "/test",
            "policy_name": "TestInvalid",
            "policy_type": "invalid_policy",
            "policy_config": {}
        }
        
        response = self.client.post("/policies/invalid-policy-type", json=request_data)
        assert response.status_code == 404
    
    def test_malformed_request(self):
        """Test malformed request."""
        response = self.client.post("/policies/javascript", json={"invalid": "data"})
        assert response.status_code == 422  # Validation error
    
    def test_cors_headers(self):
        """Test CORS headers are present."""
        response = self.client.options("/health")
        assert response.status_code == 200
        # CORS headers should be present due to middleware


if __name__ == "__main__":
    pytest.main([__file__])