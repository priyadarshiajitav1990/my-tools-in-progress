"""
Policy Handler Tests
===================

Tests for individual policy handlers.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.models import PolicyRequest
from policies.condition_handler import ConditionPolicyHandler
from policies.raise_fault_handler import RaiseFaultPolicyHandler
from policies.message_handler import MessagePolicyHandler
from policies.entity_handler import EntityPolicyHandler


class TestConditionHandler:
    """Test condition policy handler."""
    
    @pytest.fixture
    async def handler(self):
        """Create and initialize handler."""
        handler = ConditionPolicyHandler()
        await handler.initialize()
        yield handler
        await handler.cleanup()
    
    @pytest.mark.asyncio
    async def test_simple_condition_true(self, handler):
        """Test simple true condition."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestCondition",
            policy_type="assert_condition",
            policy_config={
                "operation": "evaluate",
                "condition": "true"
            }
        )
        
        response = await handler.execute(request)
        assert response.success == True
        assert response.variables["condition_result"] == True
    
    @pytest.mark.asyncio
    async def test_simple_condition_false(self, handler):
        """Test simple false condition."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestCondition",
            policy_type="assert_condition",
            policy_config={
                "operation": "evaluate",
                "condition": "false"
            }
        )
        
        response = await handler.execute(request)
        assert response.success == True
        assert response.variables["condition_result"] == False
    
    @pytest.mark.asyncio
    async def test_variable_condition(self, handler):
        """Test condition with variables."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestCondition",
            policy_type="assert_condition",
            variables={"user_id": "123"},
            policy_config={
                "operation": "evaluate",
                "condition": "user_id == '123'"
            }
        )
        
        response = await handler.execute(request)
        assert response.success == True
        assert response.variables["condition_result"] == True
    
    @pytest.mark.asyncio
    async def test_assertion_failure(self, handler):
        """Test assertion failure."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestCondition",
            policy_type="assert_condition",
            policy_config={
                "operation": "assert",
                "condition": "false",
                "failure_message": "Assertion failed",
                "failure_status_code": 403
            }
        )
        
        response = await handler.execute(request)
        assert response.success == False
        assert response.status_code == 403
        assert "Assertion failed" in response.message


class TestRaiseFaultHandler:
    """Test raise fault policy handler."""
    
    @pytest.fixture
    async def handler(self):
        """Create and initialize handler."""
        handler = RaiseFaultPolicyHandler()
        await handler.initialize()
        yield handler
        await handler.cleanup()
    
    @pytest.mark.asyncio
    async def test_simple_fault(self, handler):
        """Test simple fault raising."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestFault",
            policy_type="raise_fault",
            policy_config={
                "fault_code": "TEST_ERROR",
                "fault_string": "Test error message",
                "status_code": 400
            }
        )
        
        response = await handler.execute(request)
        assert response.success == False
        assert response.status_code == 400
        assert "Test error message" in response.message
        assert response.terminate_request == True
    
    @pytest.mark.asyncio
    async def test_fault_with_variables(self, handler):
        """Test fault with variable substitution."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestFault",
            policy_type="raise_fault",
            variables={"error_code": "CUSTOM_ERROR"},
            policy_config={
                "fault_code": "{error_code}",
                "fault_string": "Custom error occurred",
                "status_code": 500
            }
        )
        
        response = await handler.execute(request)
        assert response.success == False
        assert response.status_code == 500


class TestMessageHandler:
    """Test message policy handler."""
    
    @pytest.fixture
    async def handler(self):
        """Create and initialize handler."""
        handler = MessagePolicyHandler()
        await handler.initialize()
        yield handler
        await handler.cleanup()
    
    @pytest.mark.asyncio
    async def test_message_logging(self, handler):
        """Test message logging."""
        request = PolicyRequest(
            method="GET",
            path="/test",
            policy_name="TestLog",
            policy_type="message_logging",
            policy_config={
                "operation": "log",
                "log_level": "INFO",
                "message": "Test log message",
                "log_file": "test.log"
            }
        )
        
        response = await handler.execute(request)
        assert response.success == True
        assert response.variables["message_logged"] == True
    
    @pytest.mark.asyncio
    async def test_message_publishing(self, handler):
        """Test message publishing."""
        request = PolicyRequest(
            method="POST",
            path="/api/users",
            policy_name="TestPublish",
            policy_type="publish_message",
            policy_config={
                "operation": "publish",
                "topic": "user_events",
                "message_template": '{"event": "user_created", "user_id": "{user_id}"}'
            },
            variables={"user_id": "123"}
        )
        
        response = await handler.execute(request)
        assert response.success == True
        assert response.variables["message_published"] == True
        assert response.variables["message_topic"] == "user_events"


class TestEntityHandler:
    """Test entity policy handler."""
    
    @pytest.fixture
    async def handler(self):
        """Create and initialize handler."""
        handler = EntityPolicyHandler()
        await handler.initialize()
        yield handler
        await handler.cleanup()
    
    @pytest.mark.asyncio
    async def test_entity_validation_success(self, handler):
        """Test successful entity validation."""
        # Mock the entity fetch
        mock_entity = {"id": "123", "status": "active", "name": "Test User"}
        
        with patch.object(handler, '_fetch_entity', return_value=mock_entity):
            request = PolicyRequest(
                method="GET",
                path="/test",
                policy_name="TestEntity",
                policy_type="access_entity",
                policy_config={
                    "operation": "validate",
                    "entity_type": "user",
                    "entity_id": "123",
                    "validation_rules": [
                        {"field": "status", "operator": "==", "value": "active"},
                        {"field": "name", "operator": "exists"}
                    ]
                }
            )
            
            response = await handler.execute(request)
            assert response.success == True
            assert response.variables["entity_valid"] == True
    
    @pytest.mark.asyncio
    async def test_entity_validation_failure(self, handler):
        """Test failed entity validation."""
        # Mock the entity fetch
        mock_entity = {"id": "123", "status": "inactive", "name": "Test User"}
        
        with patch.object(handler, '_fetch_entity', return_value=mock_entity):
            request = PolicyRequest(
                method="GET",
                path="/test",
                policy_name="TestEntity",
                policy_type="access_entity",
                policy_config={
                    "operation": "validate",
                    "entity_type": "user",
                    "entity_id": "123",
                    "validation_rules": [
                        {"field": "status", "operator": "==", "value": "active"}
                    ],
                    "failure_action": "reject"
                }
            )
            
            response = await handler.execute(request)
            assert response.success == False
            assert response.status_code == 403


if __name__ == "__main__":
    pytest.main([__file__])