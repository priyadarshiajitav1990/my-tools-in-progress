# Resource File Handling - Complete Summary

## 🎯 Overview

The microservice provides **comprehensive support** for handling external resource files (JavaScript, Java/JAR, Python, XSLT, WSDL, OpenAPI) that are associated with Apigee policies through multiple storage and loading strategies.

## 📁 Supported Resource Types

| Resource Type | Extensions | Policies | Max Size | Storage Options |
|--------------|-----------|----------|----------|----------------|
| **JavaScript** | `.js` | JavaScript Policy | 1MB | Inline, File, URL |
| **Python** | `.py` | Python Script | 1MB | Inline, File, URL |
| **Java/JAR** | `.jar`, `.class` | Java Callout | 50MB | File, Base64, URL |
| **XSLT** | `.xsl`, `.xslt` | XSL Transform | 512KB | Inline, File, URL |
| **WSDL** | `.wsdl` | SOAP Callout | 512KB | File, URL |
| **OpenAPI** | `.json`, `.yaml` | API Validation | 512KB | Inline, File, URL |

## 🔄 Three Loading Strategies

### **1. Inline Content (Recommended for Small Files)**

**When to Use:**
- Scripts < 10KB
- XSLT templates < 50KB
- OpenAPI specs < 100KB
- Frequently changing content

**Advantages:**
- ✅ No external dependencies
- ✅ Version controlled with policy
- ✅ Fast execution (no I/O)
- ✅ Easy deployment

**Example:**
```json
{
  "policy_config": {
    "script_content": "function validate() { return true; }"
  }
}
```

### **2. File System Storage (Recommended for Large Files)**

**When to Use:**
- JAR files (any size)
- Large scripts > 10KB
- Shared resources
- Static content

**Advantages:**
- ✅ Supports large files
- ✅ Reusable across policies
- ✅ Easy to update
- ✅ Organized structure

**Example:**
```json
{
  "policy_config": {
    "script_file": "scripts/validate-user.js",
    "script_base_path": "/app/resources"
  }
}
```

**Directory Structure:**
```
microservice/
├── resources/
│   ├── scripts/
│   │   ├── validate-user.js
│   │   └── transform-data.py
│   ├── lib/
│   │   ├── custom-validator-1.0.jar
│   │   └── commons-lang3-3.12.0.jar
│   ├── transforms/
│   │   └── user-transform.xsl
│   └── wsdl/
│       └── UserService.wsdl
```

### **3. URL/HTTP Reference (Recommended for Shared Resources)**

**When to Use:**
- Shared schemas
- WSDL files
- OpenAPI specs
- CDN-hosted resources
- Dynamic updates

**Advantages:**
- ✅ Centralized management
- ✅ Dynamic updates
- ✅ CDN support
- ✅ Shared across services

**Example:**
```json
{
  "policy_config": {
    "script_url": "https://cdn.example.com/scripts/validate-user.js",
    "cache_ttl": 3600
  }
}
```

## 🔧 Implementation Architecture

### **Resource Loader Component**

```python
# Core resource loader with caching
class ResourceLoader:
    - load_script()      # Load JS/Python scripts
    - load_from_file()   # Load from file system
    - load_from_url()    # Load from HTTP/HTTPS
    - load_jar()         # Load JAR files
    - validate_*()       # Syntax validation
```

### **Caching System**

```python
# Automatic caching with TTL
ResourceCache:
    - In-memory cache
    - Configurable TTL (default: 1 hour)
    - LRU eviction (max 100 entries)
    - Per-resource TTL override
```

### **Security Features**

```python
# Built-in security
- Path validation (prevent directory traversal)
- Size limits (prevent resource exhaustion)
- Syntax validation (catch errors early)
- Read-only file access
- Timeout controls
```

## 📋 Policy-Specific Handling

### **JavaScript Policy**

```json
// Option 1: Inline
{
  "policy_config": {
    "script_content": "function validate() {...}",
    "timeout_ms": 5000
  }
}

// Option 2: File System
{
  "policy_config": {
    "script_file": "scripts/validate-user.js",
    "script_base_path": "/app/resources",
    "validate_syntax": true,
    "timeout_ms": 5000
  }
}

// Option 3: URL
{
  "policy_config": {
    "script_url": "https://cdn.example.com/scripts/validate.js",
    "cache_ttl": 3600,
    "timeout_ms": 5000
  }
}
```

### **Java Callout Policy**

```json
// Option 1: File System
{
  "policy_config": {
    "jar_file": "custom-validator-1.0.jar",
    "class_name": "com.example.validators.UserValidator",
    "classpath": "/app/resources/lib",
    "timeout_seconds": 10
  }
}

// Option 2: Base64 Encoded
{
  "policy_config": {
    "jar_content_base64": "UEsDBBQACAgIAAAAIQAAAA...",
    "class_name": "com.example.validators.UserValidator",
    "timeout_seconds": 10
  }
}

// Option 3: URL
{
  "policy_config": {
    "jar_url": "https://repo.example.com/jars/validator-1.0.jar",
    "class_name": "com.example.validators.UserValidator",
    "cache_ttl": 86400,
    "timeout_seconds": 10
  }
}
```

### **XSLT Transform Policy**

```json
// Option 1: Inline
{
  "policy_config": {
    "xslt_content": "<?xml version=\"1.0\"?>...",
    "source": "request_body",
    "destination": "response_body"
  }
}

// Option 2: File System
{
  "policy_config": {
    "xslt_file": "transforms/user-transform.xsl",
    "xslt_base_path": "/app/resources",
    "source": "request_body"
  }
}

// Option 3: URL
{
  "policy_config": {
    "xslt_url": "https://cdn.example.com/transforms/user.xsl",
    "cache_ttl": 3600,
    "source": "request_body"
  }
}
```

## 🚀 Migration Process

### **Step 1: Extract from Apigee**

```bash
# Extract Apigee proxy bundle
unzip migration-test-api_rev1.zip

# Apigee structure
migration-test-api/
├── apiproxy/
│   ├── policies/
│   │   ├── JavaScript-ValidateUser.xml
│   │   └── JavaCallout-CustomValidator.xml
│   └── resources/
│       ├── jsc/          # JavaScript files
│       ├── java/         # JAR files
│       ├── py/           # Python files
│       └── xsl/          # XSLT files
```

### **Step 2: Organize Resources**

```bash
# Create microservice resource structure
mkdir -p microservice/resources/{scripts,lib,transforms,wsdl}

# Copy resources
cp migration-test-api/apiproxy/resources/jsc/*.js \
   microservice/resources/scripts/

cp migration-test-api/apiproxy/resources/java/*.jar \
   microservice/resources/lib/

cp migration-test-api/apiproxy/resources/xsl/*.xsl \
   microservice/resources/transforms/
```

### **Step 3: Update Policy Configurations**

```python
# Convert Apigee policy references
def convert_policy(apigee_policy):
    resource_url = apigee_policy.find('.//ResourceURL').text
    # "jsc://validate-user.js" → "scripts/validate-user.js"
    
    return {
        "policy_config": {
            "script_file": resource_url.replace('jsc://', 'scripts/'),
            "script_base_path": "/app/resources"
        }
    }
```

## 📦 Deployment Options

### **Docker Compose**

```yaml
services:
  apigee-policy-service:
    build: .
    volumes:
      - ./resources/scripts:/app/resources/scripts:ro
      - ./resources/lib:/app/resources/lib:ro
      - ./resources/transforms:/app/resources/transforms:ro
```

### **Kubernetes ConfigMap**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: apigee-scripts
data:
  validate-user.js: |
    function validateUser() {
      // Script content
    }
---
apiVersion: apps/v1
kind: Deployment
spec:
  template:
    spec:
      volumes:
      - name: scripts
        configMap:
          name: apigee-scripts
      containers:
      - volumeMounts:
        - name: scripts
          mountPath: /app/resources/scripts
```

### **Kubernetes PersistentVolume (for JARs)**

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: java-libs-pvc
spec:
  accessModes:
    - ReadOnlyMany
  resources:
    requests:
      storage: 1Gi
---
apiVersion: apps/v1
kind: Deployment
spec:
  template:
    spec:
      volumes:
      - name: java-libs
        persistentVolumeClaim:
          claimName: java-libs-pvc
      containers:
      - volumeMounts:
        - name: java-libs
          mountPath: /app/resources/lib
```

## 🔐 Security Best Practices

### **1. Path Validation**
```python
# Prevent directory traversal
validate_file_path(base_path, file_path)
# Ensures: /app/resources/scripts/../../etc/passwd → BLOCKED
```

### **2. Size Limits**
```python
# Prevent resource exhaustion
MAX_SCRIPT_SIZE = 1MB
MAX_JAR_SIZE = 50MB
```

### **3. Read-Only Mounts**
```yaml
# Docker/Kubernetes
volumes:
  - ./resources:/app/resources:ro  # Read-only
```

### **4. Content Validation**
```python
# Validate syntax before execution
validate_javascript(script_content)
validate_python(script_content)
```

## 📊 Performance Features

### **1. Caching**
- In-memory cache with TTL
- URL-based resources cached
- File system resources cached
- Configurable cache size

### **2. Lazy Loading**
- Resources loaded on-demand
- Not loaded until first use
- Reduces startup time

### **3. Async I/O**
- Non-blocking file operations
- Concurrent resource loading
- Efficient HTTP fetching

## 🎯 Key Benefits

### ✅ **Flexibility**
- Multiple storage options
- Choose best strategy per resource
- Mix strategies in same deployment

### ✅ **Performance**
- Automatic caching
- Lazy loading
- Async operations

### ✅ **Security**
- Path validation
- Size limits
- Read-only access
- Syntax validation

### ✅ **Ease of Use**
- Simple configuration
- Automatic migration
- Clear examples

### ✅ **Production Ready**
- Docker support
- Kubernetes support
- Monitoring & logging
- Error handling

## 📋 Quick Reference

| Need | Use Strategy | Configuration Key |
|------|-------------|------------------|
| Small script | Inline | `script_content` |
| Large script | File System | `script_file` + `script_base_path` |
| Shared script | URL | `script_url` + `cache_ttl` |
| JAR file | File System | `jar_file` + `classpath` |
| Binary JAR | Base64 | `jar_content_base64` |
| WSDL | URL | `wsdl_url` |
| OpenAPI | Inline/URL | `openapi_spec` or `openapi_url` |

## 🚀 Summary

The microservice handles resource files through:

1. **Three Storage Strategies**: Inline, File System, URL
2. **Automatic Caching**: With configurable TTL
3. **Security**: Path validation, size limits, read-only access
4. **Performance**: Lazy loading, async I/O, efficient caching
5. **Easy Migration**: Automated extraction from Apigee bundles
6. **Production Ready**: Docker, Kubernetes, monitoring

This provides **complete resource file support** for seamless Apigee policy migration! 🎯