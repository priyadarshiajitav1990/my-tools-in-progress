# Resource File Usage Examples

## 🎯 Complete Examples for Each Resource Type

### **1. JavaScript Files**

#### **Example 1A: Inline JavaScript (Small Scripts)**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "headers": {
      "Content-Type": "application/json"
    },
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    "policy_name": "ValidateUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_content": "function validate() {\n  var body = JSON.parse(getVariable(\"request.content\"));\n  if (!body.email || !body.name) {\n    setVariable(\"validation_error\", \"Name and email required\");\n    return false;\n  }\n  setVariable(\"user_validated\", true);\n  return true;\n}\nvalidate();",
      "timeout_ms": 5000
    }
  }'
```

#### **Example 1B: File System JavaScript**

**File: `resources/scripts/validate-user.js`**
```javascript
function validateUser() {
  var body = JSON.parse(getVariable('request.content'));
  
  // Validate email
  if (!body.email || !body.email.includes('@')) {
    setVariable('validation_error', 'Invalid email address');
    return false;
  }
  
  // Validate name
  if (!body.name || body.name.length < 2) {
    setVariable('validation_error', 'Name must be at least 2 characters');
    return false;
  }
  
  // Set success variables
  setVariable('user_validated', true);
  setVariable('user_email', body.email);
  setVariable('user_name', body.name);
  
  return true;
}

validateUser();
```

**API Request:**
```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    "policy_name": "ValidateUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/validate-user.js",
      "script_base_path": "/app/resources",
      "timeout_ms": 5000,
      "validate_syntax": true
    }
  }'
```

#### **Example 1C: URL-Based JavaScript**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type": application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "policy_name": "ValidateUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_url": "https://cdn.example.com/scripts/validate-user.js",
      "cache_ttl": 3600,
      "timeout_ms": 5000
    }
  }'
```

### **2. Python Files**

#### **Example 2A: Inline Python**

```bash
curl -X POST http://localhost:8080/policies/python-script \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/data",
    "body": "{\"value\": 42}",
    "policy_name": "ProcessData",
    "policy_type": "python_script",
    "policy_config": {
      "script_content": "import json\nimport math\n\ndef process_data():\n    body = json.loads(get_variable(\"request.content\"))\n    value = body.get(\"value\", 0)\n    result = math.sqrt(value)\n    set_variable(\"processed_value\", result)\n    return True\n\nprocess_data()",
      "timeout_ms": 5000
    }
  }'
```

#### **Example 2B: File System Python**

**File: `resources/scripts/data_processor.py`**
```python
import json
import math
from datetime import datetime

def process_data():
    """Process incoming data with complex logic."""
    
    # Get request data
    body_str = get_variable('request.content')
    body = json.loads(body_str)
    
    # Process data
    value = body.get('value', 0)
    
    # Perform calculations
    result = {
        'original': value,
        'squared': value ** 2,
        'sqrt': math.sqrt(abs(value)),
        'processed_at': datetime.utcnow().isoformat()
    }
    
    # Set variables
    set_variable('processed_data', json.dumps(result))
    set_variable('processing_complete', True)
    
    return True

# Execute
process_data()
```

**API Request:**
```bash
curl -X POST http://localhost:8080/policies/python-script \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/data",
    "body": "{\"value\": 42}",
    "policy_name": "ProcessData",
    "policy_type": "python_script",
    "policy_config": {
      "script_file": "scripts/data_processor.py",
      "script_base_path": "/app/resources",
      "timeout_ms": 5000
    }
  }'
```

### **3. Java/JAR Files**

#### **Example 3A: File System JAR**

**Java Class: `com.example.validators.UserValidator`**
```java
package com.example.validators;

import org.json.JSONObject;

public class UserValidator {
    public static String validate(String requestJson) {
        try {
            JSONObject request = new JSONObject(requestJson);
            JSONObject body = request.getJSONObject("body");
            
            // Validate email
            if (!body.has("email") || !body.getString("email").contains("@")) {
                return createErrorResponse("Invalid email address");
            }
            
            // Validate name
            if (!body.has("name") || body.getString("name").length() < 2) {
                return createErrorResponse("Name must be at least 2 characters");
            }
            
            // Return success
            JSONObject response = new JSONObject();
            response.put("success", true);
            response.put("validated", true);
            response.put("email", body.getString("email"));
            
            return response.toString();
            
        } catch (Exception e) {
            return createErrorResponse("Validation error: " + e.getMessage());
        }
    }
    
    private static String createErrorResponse(String message) {
        JSONObject response = new JSONObject();
        response.put("success", false);
        response.put("error", message);
        return response.toString();
    }
}
```

**API Request:**
```bash
curl -X POST http://localhost:8080/policies/java-callout \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    "policy_name": "ValidateUserJava",
    "policy_type": "java_callout",
    "policy_config": {
      "jar_file": "custom-validator-1.0.jar",
      "class_name": "com.example.validators.UserValidator",
      "method_name": "validate",
      "classpath": "/app/resources/lib",
      "timeout_seconds": 10
    }
  }'
```

#### **Example 3B: Base64 Encoded JAR**

```bash
# First, encode your JAR file
JAR_BASE64=$(base64 -w 0 custom-validator-1.0.jar)

# Then use it in the request
curl -X POST http://localhost:8080/policies/java-callout \
  -H "Content-Type: application/json" \
  -d "{
    \"method\": \"POST\",
    \"path\": \"/api/users\",
    \"body\": \"{\\\"name\\\": \\\"John Doe\\\", \\\"email\\\": \\\"john@example.com\\\"}\",
    \"policy_name\": \"ValidateUserJava\",
    \"policy_type\": \"java_callout\",
    \"policy_config\": {
      \"jar_content_base64\": \"$JAR_BASE64\",
      \"class_name\": \"com.example.validators.UserValidator\",
      \"method_name\": \"validate\",
      \"timeout_seconds\": 10
    }
  }"
```

### **4. XSLT Files**

#### **Example 4A: Inline XSLT**

```bash
curl -X POST http://localhost:8080/policies/xsl-transform \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/transform",
    "body": "<?xml version=\"1.0\"?><user><id>123</id><name>John Doe</name><email>john@example.com</email></user>",
    "policy_name": "TransformUser",
    "policy_type": "xsl_transform",
    "policy_config": {
      "xslt_content": "<?xml version=\"1.0\"?>\n<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n  <xsl:template match=\"/\">\n    <transformed>\n      <userId><xsl:value-of select=\"//user/id\"/></userId>\n      <userName><xsl:value-of select=\"//user/name\"/></userName>\n      <userEmail><xsl:value-of select=\"//user/email\"/></userEmail>\n    </transformed>\n  </xsl:template>\n</xsl:stylesheet>",
      "source": "request_body",
      "destination": "response_body"
    }
  }'
```

#### **Example 4B: File System XSLT**

**File: `resources/transforms/user-transform.xsl`**
```xml
<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" indent="yes"/>
  
  <xsl:template match="/">
    <transformed>
      <user>
        <id><xsl:value-of select="//user/id"/></id>
        <fullName><xsl:value-of select="//user/name"/></fullName>
        <emailAddress><xsl:value-of select="//user/email"/></emailAddress>
        <transformedAt><xsl:value-of select="current-dateTime()"/></transformedAt>
      </user>
    </transformed>
  </xsl:template>
</xsl:stylesheet>
```

**API Request:**
```bash
curl -X POST http://localhost:8080/policies/xsl-transform \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/transform",
    "body": "<?xml version=\"1.0\"?><user><id>123</id><name>John Doe</name><email>john@example.com</email></user>",
    "policy_name": "TransformUser",
    "policy_type": "xsl_transform",
    "policy_config": {
      "xslt_file": "transforms/user-transform.xsl",
      "xslt_base_path": "/app/resources",
      "source": "request_body",
      "destination": "response_body"
    }
  }'
```

### **5. WSDL Files**

#### **Example 5A: URL-Based WSDL**

```bash
curl -X POST http://localhost:8080/policies/service-callout \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/soap",
    "policy_name": "CallUserService",
    "policy_type": "service_callout",
    "policy_config": {
      "wsdl_url": "https://services.example.com/UserService?wsdl",
      "service_name": "UserService",
      "port_name": "UserServicePort",
      "operation": "GetUser",
      "soap_action": "http://example.com/GetUser",
      "soap_body": "<GetUser><userId>123</userId></GetUser>",
      "response_variable": "soap_response"
    }
  }'
```

#### **Example 5B: File System WSDL**

**File: `resources/wsdl/UserService.wsdl`**
```xml
<?xml version="1.0"?>
<definitions name="UserService"
  targetNamespace="http://example.com/userservice"
  xmlns="http://schemas.xmlsoap.org/wsdl/"
  xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/"
  xmlns:tns="http://example.com/userservice"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  
  <message name="GetUserRequest">
    <part name="userId" type="xsd:string"/>
  </message>
  
  <message name="GetUserResponse">
    <part name="user" type="tns:User"/>
  </message>
  
  <portType name="UserServicePortType">
    <operation name="GetUser">
      <input message="tns:GetUserRequest"/>
      <output message="tns:GetUserResponse"/>
    </operation>
  </portType>
  
  <binding name="UserServiceBinding" type="tns:UserServicePortType">
    <soap:binding transport="http://schemas.xmlsoap.org/soap/http"/>
    <operation name="GetUser">
      <soap:operation soapAction="http://example.com/GetUser"/>
      <input><soap:body use="literal"/></input>
      <output><soap:body use="literal"/></output>
    </operation>
  </binding>
  
  <service name="UserService">
    <port name="UserServicePort" binding="tns:UserServiceBinding">
      <soap:address location="https://services.example.com/UserService"/>
    </port>
  </service>
</definitions>
```

**API Request:**
```bash
curl -X POST http://localhost:8080/policies/service-callout \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/soap",
    "policy_name": "CallUserService",
    "policy_type": "service_callout",
    "policy_config": {
      "wsdl_file": "wsdl/UserService.wsdl",
      "wsdl_base_path": "/app/resources",
      "operation": "GetUser",
      "soap_body": "<GetUser><userId>123</userId></GetUser>"
    }
  }'
```

### **6. OpenAPI/Swagger Files**

#### **Example 6A: URL-Based OpenAPI**

```bash
curl -X POST http://localhost:8080/policies/api-validation \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    "policy_name": "ValidateAPI",
    "policy_type": "api_validation",
    "policy_config": {
      "openapi_url": "https://api.example.com/openapi.json",
      "validate_request": true,
      "validate_response": false,
      "cache_ttl": 3600
    }
  }'
```

#### **Example 6B: Inline OpenAPI Spec**

```bash
curl -X POST http://localhost:8080/policies/api-validation \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    "policy_name": "ValidateAPI",
    "policy_type": "api_validation",
    "policy_config": {
      "openapi_spec": {
        "openapi": "3.0.0",
        "info": {
          "title": "User API",
          "version": "1.0.0"
        },
        "paths": {
          "/api/users": {
            "post": {
              "requestBody": {
                "required": true,
                "content": {
                  "application/json": {
                    "schema": {
                      "type": "object",
                      "required": ["name", "email"],
                      "properties": {
                        "name": {
                          "type": "string",
                          "minLength": 2
                        },
                        "email": {
                          "type": "string",
                          "format": "email"
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }'
```

## 🚀 Deployment Examples

### **Docker Compose with Resource Files**

```yaml
version: '3.8'

services:
  apigee-policy-service:
    build: .
    ports:
      - "8080:8080"
    volumes:
      # Mount JavaScript/Python scripts
      - ./resources/scripts:/app/resources/scripts:ro
      
      # Mount JAR files
      - ./resources/lib:/app/resources/lib:ro
      
      # Mount XSLT files
      - ./resources/transforms:/app/resources/transforms:ro
      
      # Mount WSDL files
      - ./resources/wsdl:/app/resources/wsdl:ro
    environment:
      - LOG_LEVEL=INFO
      - REDIS_HOST=redis
    depends_on:
      - redis

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
```

### **Kubernetes with ConfigMaps**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: apigee-scripts
data:
  validate-user.js: |
    function validateUser() {
      var body = JSON.parse(getVariable('request.content'));
      if (!body.email || !body.name) {
        setVariable('validation_error', 'Name and email required');
        return false;
      }
      setVariable('user_validated', true);
      return true;
    }
    validateUser();
  
  data-processor.py: |
    import json
    def process_data():
        body = json.loads(get_variable('request.content'))
        set_variable('processed', True)
        return True
    process_data()

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apigee-policy-service
spec:
  template:
    spec:
      containers:
      - name: apigee-policy-service
        image: apigee-policy-service:latest
        volumeMounts:
        - name: scripts
          mountPath: /app/resources/scripts
          readOnly: true
      volumes:
      - name: scripts
        configMap:
          name: apigee-scripts
```

## 📊 Summary

The microservice supports multiple resource loading strategies:

1. **Inline Content**: Best for small scripts and templates
2. **File System**: Best for JAR files and large resources
3. **URL References**: Best for shared resources and dynamic updates
4. **Base64 Encoding**: Best for binary files in configuration

Choose the strategy that best fits your deployment model and resource size! 🚀