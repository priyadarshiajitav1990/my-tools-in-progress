# Complete API-Scoped Example

## 🎯 Scenario: Three APIs with Different Resources

Let's set up a complete example with three APIs: `users-api`, `orders-api`, and `payments-api`.

## 📁 Step 1: Directory Setup

```bash
# Create directory structure
mkdir -p microservice/resources/{users-api,orders-api,payments-api}/{scripts,lib,transforms,wsdl}

# Verify structure
tree microservice/resources/
```

**Result:**
```
microservice/resources/
├── users-api/
│   ├── scripts/
│   ├── lib/
│   ├── transforms/
│   └── wsdl/
├── orders-api/
│   ├── scripts/
│   ├── lib/
│   ├── transforms/
│   └── wsdl/
└── payments-api/
    ├── scripts/
    ├── lib/
    ├── transforms/
    └── wsdl/
```

## 📝 Step 2: Create Resource Files

### **Users API Resources**

**File: `resources/users-api/scripts/validate-user.js`**
```javascript
function validateUser() {
  var body = JSON.parse(getVariable('request.content'));
  
  // Validate email
  if (!body.email || !body.email.includes('@')) {
    setVariable('validation_error', 'Invalid email address');
    setVariable('validation_passed', false);
    return false;
  }
  
  // Validate name
  if (!body.name || body.name.length < 2) {
    setVariable('validation_error', 'Name must be at least 2 characters');
    setVariable('validation_passed', false);
    return false;
  }
  
  // Success
  setVariable('validation_passed', true);
  setVariable('user_email', body.email);
  setVariable('user_name', body.name);
  setVariable('response.header.x-validation-status', 'passed');
  
  return true;
}

validateUser();
```

**File: `resources/users-api/scripts/enrich-user.js`**
```javascript
function enrichUser() {
  var userId = getVariable('user_id');
  var userName = getVariable('user_name');
  
  // Add enrichment data
  setVariable('user_enriched', true);
  setVariable('enrichment_timestamp', Date.now());
  setVariable('user_display_name', userName.toUpperCase());
  
  return true;
}

enrichUser();
```

### **Orders API Resources**

**File: `resources/orders-api/scripts/validate-order.js`**
```javascript
function validateOrder() {
  var body = JSON.parse(getVariable('request.content'));
  
  // Validate order ID
  if (!body.orderId) {
    setVariable('validation_error', 'Order ID required');
    return false;
  }
  
  // Validate amount
  if (!body.amount || body.amount <= 0) {
    setVariable('validation_error', 'Invalid amount');
    return false;
  }
  
  // Calculate tax
  var tax = body.amount * 0.1;
  var total = body.amount + tax;
  
  setVariable('order_validated', true);
  setVariable('order_tax', tax);
  setVariable('order_total', total);
  
  return true;
}

validateOrder();
```

**File: `resources/orders-api/transforms/order-transform.xsl`**
```xml
<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="xml" indent="yes"/>
  
  <xsl:template match="/">
    <transformedOrder>
      <id><xsl:value-of select="//order/orderId"/></id>
      <amount><xsl:value-of select="//order/amount"/></amount>
      <status>VALIDATED</status>
      <transformedAt><xsl:value-of select="current-dateTime()"/></transformedAt>
    </transformedOrder>
  </xsl:template>
</xsl:stylesheet>
```

### **Payments API Resources**

**File: `resources/payments-api/scripts/validate-payment.js`**
```javascript
function validatePayment() {
  var body = JSON.parse(getVariable('request.content'));
  
  // Validate payment method
  var validMethods = ['credit_card', 'debit_card', 'paypal'];
  if (!body.paymentMethod || !validMethods.includes(body.paymentMethod)) {
    setVariable('validation_error', 'Invalid payment method');
    return false;
  }
  
  // Validate amount
  if (!body.amount || body.amount <= 0) {
    setVariable('validation_error', 'Invalid payment amount');
    return false;
  }
  
  setVariable('payment_validated', true);
  setVariable('payment_method', body.paymentMethod);
  setVariable('payment_amount', body.amount);
  
  return true;
}

validatePayment();
```

## 🚀 Step 3: API Requests

### **Request 1: Users API - Validate User**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    "headers": {
      "Content-Type": "application/json"
    },
    "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
    
    "api_name": "users-api",
    
    "policy_name": "ValidateUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/validate-user.js"
    },
    
    "flow_variables": {
      "request.content": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}"
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Script executed successfully",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "validation_passed": true,
    "user_email": "john@example.com",
    "user_name": "John Doe"
  },
  "headers": {
    "x-validation-status": "passed"
  },
  "execution_time_ms": 23.5,
  "policy_name": "ValidateUser"
}
```

### **Request 2: Users API - Enrich User (Chained)**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/users",
    
    "api_name": "users-api",
    
    "policy_name": "EnrichUser",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/enrich-user.js"
    },
    
    "variables": {
      "user_id": "123",
      "user_name": "John Doe",
      "validation_passed": true
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Script executed successfully",
  "variables": {
    "user_enriched": true,
    "enrichment_timestamp": 1640995200000,
    "user_display_name": "JOHN DOE"
  },
  "execution_time_ms": 15.2
}
```

### **Request 3: Orders API - Validate Order**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/orders",
    "body": "{\"orderId\": \"ORD-12345\", \"amount\": 100.00}",
    
    "api_name": "orders-api",
    
    "policy_name": "ValidateOrder",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/validate-order.js"
    },
    
    "flow_variables": {
      "request.content": "{\"orderId\": \"ORD-12345\", \"amount\": 100.00}"
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Script executed successfully",
  "variables": {
    "order_validated": true,
    "order_tax": 10.0,
    "order_total": 110.0
  },
  "execution_time_ms": 18.7
}
```

### **Request 4: Orders API - Transform Order (XSLT)**

```bash
curl -X POST http://localhost:8080/policies/xsl-transform \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/orders/transform",
    "body": "<?xml version=\"1.0\"?><order><orderId>ORD-12345</orderId><amount>100.00</amount></order>",
    
    "api_name": "orders-api",
    
    "policy_name": "TransformOrder",
    "policy_type": "xsl_transform",
    "policy_config": {
      "xslt_file": "transforms/order-transform.xsl",
      "source": "request_body",
      "destination": "response_body"
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "XSLT transformation completed",
  "body": "<?xml version=\"1.0\"?>\n<transformedOrder>\n  <id>ORD-12345</id>\n  <amount>100.00</amount>\n  <status>VALIDATED</status>\n  <transformedAt>2024-01-08T10:30:00Z</transformedAt>\n</transformedOrder>",
  "execution_time_ms": 12.3
}
```

### **Request 5: Payments API - Validate Payment**

```bash
curl -X POST http://localhost:8080/policies/javascript \
  -H "Content-Type: application/json" \
  -d '{
    "method": "POST",
    "path": "/api/payments",
    "body": "{\"paymentMethod\": \"credit_card\", \"amount\": 99.99}",
    
    "api_name": "payments-api",
    
    "policy_name": "ValidatePayment",
    "policy_type": "javascript",
    "policy_config": {
      "script_file": "scripts/validate-payment.js"
    },
    
    "flow_variables": {
      "request.content": "{\"paymentMethod\": \"credit_card\", \"amount\": 99.99}"
    }
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Script executed successfully",
  "variables": {
    "payment_validated": true,
    "payment_method": "credit_card",
    "payment_amount": 99.99
  },
  "execution_time_ms": 16.8
}
```

## 🔗 Step 4: Kong Integration

### **Configure Kong Services**

```bash
# Users API
curl -X POST http://kong:8001/services \
  --data "name=users-api" \
  --data "url=http://backend:8080/users"

curl -X POST http://kong:8001/services/users-api/routes \
  --data "paths[]=/api/users"

curl -X POST http://kong:8001/services/users-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "microservice_url": "http://apigee-policy-service:8080",
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ValidateUser",
            "script_file": "scripts/validate-user.js"
          }
        },
        {
          "type": "javascript",
          "config": {
            "name": "EnrichUser",
            "script_file": "scripts/enrich-user.js"
          }
        }
      ]
    }
  }'

# Orders API
curl -X POST http://kong:8001/services \
  --data "name=orders-api" \
  --data "url=http://backend:8080/orders"

curl -X POST http://kong:8001/services/orders-api/routes \
  --data "paths[]=/api/orders"

curl -X POST http://kong:8001/services/orders-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ValidateOrder",
            "script_file": "scripts/validate-order.js"
          }
        }
      ]
    }
  }'

# Payments API
curl -X POST http://kong:8001/services \
  --data "name=payments-api" \
  --data "url=http://backend:8080/payments"

curl -X POST http://kong:8001/services/payments-api/routes \
  --data "paths[]=/api/payments"

curl -X POST http://kong:8001/services/payments-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ValidatePayment",
            "script_file": "scripts/validate-payment.js"
          }
        }
      ]
    }
  }'
```

### **Test Through Kong**

```bash
# Test Users API
curl -X POST http://kong:8000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "John Doe", "email": "john@example.com"}'

# Test Orders API
curl -X POST http://kong:8000/api/orders \
  -H "Content-Type: application/json" \
  -d '{"orderId": "ORD-12345", "amount": 100.00}'

# Test Payments API
curl -X POST http://kong:8000/api/payments \
  -H "Content-Type: application/json" \
  -d '{"paymentMethod": "credit_card", "amount": 99.99}'
```

## 📦 Step 5: Docker Deployment

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  apigee-policy-service:
    build: ./microservice
    ports:
      - "8080:8080"
    volumes:
      # Mount all API resources
      - ./resources:/app/resources:ro
    environment:
      - LOG_LEVEL=INFO
      - RESOURCE_BASE_PATH=/app/resources
    networks:
      - api-network

  kong:
    image: kong:latest
    environment:
      - KONG_DATABASE=off
      - KONG_DECLARATIVE_CONFIG=/kong/kong.yml
      - KONG_PROXY_ACCESS_LOG=/dev/stdout
      - KONG_ADMIN_ACCESS_LOG=/dev/stdout
      - KONG_PROXY_ERROR_LOG=/dev/stderr
      - KONG_ADMIN_ERROR_LOG=/dev/stderr
      - KONG_ADMIN_LISTEN=0.0.0.0:8001
    ports:
      - "8000:8000"
      - "8001:8001"
    volumes:
      - ./kong.yml:/kong/kong.yml:ro
    networks:
      - api-network
    depends_on:
      - apigee-policy-service

networks:
  api-network:
    driver: bridge
```

**Start Everything:**
```bash
docker-compose up -d
```

## 🎯 Summary

This complete example demonstrates:

1. **✅ API-Scoped Organization**: Each API has its own resource directory
2. **✅ Multiple Resource Types**: JavaScript, XSLT, and more
3. **✅ Automatic Scoping**: API name automatically determines resource path
4. **✅ Kong Integration**: Seamless integration with Kong Gateway
5. **✅ Production Ready**: Docker deployment with proper isolation

The microservice automatically:
- Loads resources from `/app/resources/{api-name}/{resource-type}/{file}`
- Caches resources for performance
- Validates paths for security
- Provides clear error messages

**This is the recommended production setup!** 🚀