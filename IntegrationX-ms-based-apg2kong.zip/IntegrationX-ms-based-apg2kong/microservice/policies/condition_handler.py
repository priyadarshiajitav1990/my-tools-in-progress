"""
Condition Policy Handler
========================

Handles condition assertion and evaluation policies.
"""

import re
import json
from typing import Dict, Any, Optional, Union
from datetime import datetime
import operator

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class ConditionPolicyHandler(BasePolicyHandler):
    """Handler for condition assertion and evaluation policies."""
    
    def __init__(self):
        super().__init__()
        self.operators = {
            '==': operator.eq,
            '!=': operator.ne,
            '<': operator.lt,
            '<=': operator.le,
            '>': operator.gt,
            '>=': operator.ge,
            'contains': lambda a, b: str(b) in str(a),
            'startswith': lambda a, b: str(a).startswith(str(b)),
            'endswith': lambda a, b: str(a).endswith(str(b)),
            'matches': lambda a, b: bool(re.search(str(b), str(a))),
            'in': lambda a, b: str(a) in str(b).split(','),
            'not_in': lambda a, b: str(a) not in str(b).split(',')
        }
    
    async def _initialize(self) -> None:
        """Initialize condition handler."""
        self.logger.info("Condition handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup condition handler resources."""
        pass
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute condition policy."""
        
        operation = self._extract_config_value(
            request.policy_config, 'operation', 'assert'
        ).lower()
        
        if operation == 'assert':
            return await self._assert_condition(request)
        elif operation == 'evaluate':
            return await self._evaluate_condition(request)
        else:
            return self._create_error_response(
                f"Unsupported condition operation: {operation}"
            )
    
    async def _assert_condition(self, request: PolicyRequest) -> PolicyResponse:
        """Assert that a condition is true, fail if false."""
        try:
            # Get condition configuration
            condition = self._extract_config_value(
                request.policy_config, 'condition', required=True
            )
            
            # Evaluate condition
            result = self._evaluate_condition_expression(condition, request)
            
            if result:
                return self._create_success_response(
                    message="Condition assertion passed",
                    variables={'condition_result': True}
                )
            else:
                # Get failure configuration
                failure_message = self._extract_config_value(
                    request.policy_config, 'failure_message', 
                    'Condition assertion failed'
                )
                
                failure_status = self._extract_config_value(
                    request.policy_config, 'failure_status_code', 400
                )
                
                return self._create_error_response(
                    message=failure_message,
                    status_code=failure_status,
                    terminate=True
                )
                
        except Exception as e:
            return self._create_error_response(f"Condition assertion error: {str(e)}")
    
    async def _evaluate_condition(self, request: PolicyRequest) -> PolicyResponse:
        """Evaluate condition and store result without failing."""
        try:
            # Get condition configuration
            condition = self._extract_config_value(
                request.policy_config, 'condition', required=True
            )
            
            # Evaluate condition
            result = self._evaluate_condition_expression(condition, request)
            
            # Store result in variable
            result_variable = self._extract_config_value(
                request.policy_config, 'result_variable', 'condition_result'
            )
            
            variables = {
                result_variable: result,
                'condition_evaluated': True
            }
            
            return self._create_success_response(
                message=f"Condition evaluated: {result}",
                variables=variables
            )
            
        except Exception as e:
            return self._create_error_response(f"Condition evaluation error: {str(e)}")
    
    def _evaluate_condition_expression(self, condition: str, request: PolicyRequest) -> bool:
        """Evaluate a condition expression."""
        try:
            # Handle different condition formats
            if isinstance(condition, dict):
                return self._evaluate_structured_condition(condition, request)
            elif isinstance(condition, str):
                return self._evaluate_string_condition(condition, request)
            else:
                raise ValueError(f"Unsupported condition type: {type(condition)}")
                
        except Exception as e:
            self.logger.error(f"Error evaluating condition: {str(e)}")
            return False
    
    def _evaluate_structured_condition(self, condition: Dict[str, Any], request: PolicyRequest) -> bool:
        """Evaluate structured condition (JSON format)."""
        
        # Handle logical operators
        if 'and' in condition:
            conditions = condition['and']
            return all(self._evaluate_condition_expression(c, request) for c in conditions)
        
        if 'or' in condition:
            conditions = condition['or']
            return any(self._evaluate_condition_expression(c, request) for c in conditions)
        
        if 'not' in condition:
            return not self._evaluate_condition_expression(condition['not'], request)
        
        # Handle comparison
        left = self._resolve_value(condition.get('left'), request)
        operator_name = condition.get('operator', '==')
        right = self._resolve_value(condition.get('right'), request)
        
        if operator_name not in self.operators:
            raise ValueError(f"Unsupported operator: {operator_name}")
        
        return self.operators[operator_name](left, right)
    
    def _evaluate_string_condition(self, condition: str, request: PolicyRequest) -> bool:
        """Evaluate string condition expression."""
        
        # Simple pattern matching for common conditions
        # Format: "variable operator value"
        
        # Handle parentheses and logical operators
        condition = condition.strip()
        
        # Simple AND/OR handling
        if ' and ' in condition.lower():
            parts = condition.lower().split(' and ')
            return all(self._evaluate_simple_condition(part.strip(), request) for part in parts)
        
        if ' or ' in condition.lower():
            parts = condition.lower().split(' or ')
            return any(self._evaluate_simple_condition(part.strip(), request) for part in parts)
        
        return self._evaluate_simple_condition(condition, request)
    
    def _evaluate_simple_condition(self, condition: str, request: PolicyRequest) -> bool:
        """Evaluate a simple condition expression."""
        
        # Parse condition: "left operator right"
        for op_name, op_func in self.operators.items():
            if f' {op_name} ' in condition:
                parts = condition.split(f' {op_name} ', 1)
                if len(parts) == 2:
                    left = self._resolve_value(parts[0].strip(), request)
                    right = self._resolve_value(parts[1].strip(), request)
                    return op_func(left, right)
        
        # If no operator found, treat as boolean variable
        return bool(self._resolve_value(condition, request))
    
    def _resolve_value(self, value: Union[str, Any], request: PolicyRequest) -> Any:
        """Resolve a value from variables, headers, etc."""
        
        if not isinstance(value, str):
            return value
        
        value = value.strip()
        
        # Handle quoted strings
        if (value.startswith('"') and value.endswith('"')) or \
           (value.startswith("'") and value.endswith("'")):
            return value[1:-1]
        
        # Handle numbers
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            pass
        
        # Handle boolean
        if value.lower() in ('true', 'false'):
            return value.lower() == 'true'
        
        # Handle null/none
        if value.lower() in ('null', 'none', 'nil'):
            return None
        
        # Handle variable references
        if value.startswith('request.'):
            return self._get_request_value(value[8:], request)
        
        if value.startswith('header.'):
            header_name = value[7:]
            return request.headers.get(header_name)
        
        if value.startswith('query.'):
            param_name = value[6:]
            return request.query_params.get(param_name)
        
        if value.startswith('variable.'):
            var_name = value[9:]
            return request.variables.get(var_name) or request.flow_variables.get(var_name)
        
        # Check in variables directly
        if value in request.variables:
            return request.variables[value]
        
        if value in request.flow_variables:
            return request.flow_variables[value]
        
        # Return as literal string
        return value
    
    def _get_request_value(self, path: str, request: PolicyRequest) -> Any:
        """Get value from request object by path."""
        
        if path == 'method':
            return request.method
        elif path == 'path':
            return request.path
        elif path == 'body':
            return request.body
        elif path == 'client_ip':
            return request.client_ip
        elif path == 'user_agent':
            return request.user_agent
        elif path.startswith('header.'):
            header_name = path[7:]
            return request.headers.get(header_name)
        elif path.startswith('query.'):
            param_name = path[6:]
            return request.query_params.get(param_name)
        else:
            return None