"""
Java Callout Policy Handler
===========================

Handles Java callout policies by executing Java code through subprocess calls.
Supports JAR execution and Java class invocation with security sandboxing.
"""

import subprocess
import tempfile
import os
import json
import asyncio
from typing import Dict, Any, Optional
from pathlib import Path

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse
from core.config import Settings

settings = Settings()


class JavaCalloutPolicyHandler(BasePolicyHandler):
    """Handler for Java callout policies."""
    
    def __init__(self):
        super().__init__()
        self.java_home = os.environ.get('JAVA_HOME')
        self.temp_dir = None
        self.classpath = []
    
    async def _initialize(self) -> None:
        """Initialize Java callout handler."""
        # Check if Java is available
        if not self.java_home:
            self.logger.warning("JAVA_HOME not set, trying to find Java in PATH")
        
        try:
            result = await asyncio.create_subprocess_exec(
                'java', '-version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await result.wait()
            
            if result.returncode != 0:
                raise RuntimeError("Java not found in system")
                
        except Exception as e:
            self.logger.error(f"Java runtime not available: {str(e)}")
            raise
        
        # Create temporary directory for Java execution
        self.temp_dir = tempfile.mkdtemp(prefix="apigee_java_")
        self.logger.info(f"Java callout handler initialized with temp dir: {self.temp_dir}")
    
    async def _cleanup(self) -> None:
        """Cleanup resources."""
        if self.temp_dir and os.path.exists(self.temp_dir):
            import shutil
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute Java callout policy."""
        try:
            config = request.policy_config
            
            # Extract Java configuration
            jar_file = self._extract_config_value(config, 'jar_file')
            class_name = self._extract_config_value(config, 'class_name')
            method_name = self._extract_config_value(config, 'method_name', 'execute')
            java_code = self._extract_config_value(config, 'java_code')
            timeout_seconds = self._extract_config_value(config, 'timeout_seconds', 30)
            
            if jar_file:
                return await self._execute_jar(request, jar_file, class_name, method_name, timeout_seconds)
            elif java_code:
                return await self._execute_java_code(request, java_code, timeout_seconds)
            else:
                return self._create_error_response("Either jar_file or java_code must be provided")
                
        except Exception as e:
            return self._create_error_response(f"Java callout execution failed: {str(e)}")
    
    async def _execute_jar(
        self,
        request: PolicyRequest,
        jar_file: str,
        class_name: str,
        method_name: str,
        timeout_seconds: int
    ) -> PolicyResponse:
        """Execute Java JAR file."""
        try:
            # Prepare input data
            input_data = {
                'request': {
                    'method': request.method,
                    'path': request.path,
                    'headers': request.headers,
                    'query_params': request.query_params,
                    'body': request.body
                },
                'variables': request.variables,
                'flow_variables': request.flow_variables,
                'config': request.policy_config
            }
            
            # Write input to temporary file
            input_file = os.path.join(self.temp_dir, f"input_{request.request_id or 'default'}.json")
            with open(input_file, 'w') as f:
                json.dump(input_data, f)
            
            # Prepare Java command
            java_cmd = [
                'java',
                '-cp', jar_file,
                '-Djava.security.manager',
                '-Djava.security.policy=java.policy',
                class_name,
                method_name,
                input_file
            ]
            
            # Execute Java process
            process = await asyncio.create_subprocess_exec(
                *java_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.temp_dir
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout_seconds
                )
            except asyncio.TimeoutError:
                process.kill()
                return self._create_error_response("Java execution timeout")
            
            if process.returncode != 0:
                error_msg = stderr.decode('utf-8') if stderr else "Java execution failed"
                return self._create_error_response(f"Java execution error: {error_msg}")
            
            # Parse output
            try:
                output = json.loads(stdout.decode('utf-8'))
                return self._process_java_output(output)
            except json.JSONDecodeError:
                # If not JSON, treat as plain text
                return self._create_success_response(
                    "Java callout executed successfully",
                    body=stdout.decode('utf-8')
                )
            
        except Exception as e:
            return self._create_error_response(f"JAR execution failed: {str(e)}")
        finally:
            # Cleanup input file
            if 'input_file' in locals() and os.path.exists(input_file):
                os.remove(input_file)
    
    async def _execute_java_code(
        self,
        request: PolicyRequest,
        java_code: str,
        timeout_seconds: int
    ) -> PolicyResponse:
        """Execute inline Java code."""
        try:
            # Create a wrapper Java class
            class_name = f"ApigeePolicy_{request.request_id or 'default'}".replace('-', '_')
            
            wrapper_code = f"""
import java.util.*;
import java.io.*;
import com.google.gson.*;

public class {class_name} {{
    public static void main(String[] args) {{
        try {{
            // Read input
            String inputFile = args[0];
            Gson gson = new Gson();
            JsonObject input = gson.fromJson(new FileReader(inputFile), JsonObject.class);
            
            // Execute user code
            JsonObject result = execute(input);
            
            // Output result
            System.out.println(gson.toJson(result));
        }} catch (Exception e) {{
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }}
    }}
    
    public static JsonObject execute(JsonObject input) {{
        JsonObject result = new JsonObject();
        result.addProperty("success", true);
        result.addProperty("message", "Java code executed successfully");
        
        try {{
            // User code starts here
            {java_code}
            // User code ends here
            
        }} catch (Exception e) {{
            result.addProperty("success", false);
            result.addProperty("message", "Java code execution failed: " + e.getMessage());
        }}
        
        return result;
    }}
}}
"""
            
            # Write Java file
            java_file = os.path.join(self.temp_dir, f"{class_name}.java")
            with open(java_file, 'w') as f:
                f.write(wrapper_code)
            
            # Compile Java code
            compile_cmd = ['javac', '-cp', '.', java_file]
            compile_process = await asyncio.create_subprocess_exec(
                *compile_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.temp_dir
            )
            
            compile_stdout, compile_stderr = await compile_process.communicate()
            
            if compile_process.returncode != 0:
                error_msg = compile_stderr.decode('utf-8') if compile_stderr else "Compilation failed"
                return self._create_error_response(f"Java compilation error: {error_msg}")
            
            # Execute compiled class
            return await self._execute_jar(
                request,
                self.temp_dir,
                class_name,
                "main",
                timeout_seconds
            )
            
        except Exception as e:
            return self._create_error_response(f"Java code execution failed: {str(e)}")
        finally:
            # Cleanup generated files
            for ext in ['.java', '.class']:
                file_path = os.path.join(self.temp_dir, f"{class_name}{ext}")
                if os.path.exists(file_path):
                    os.remove(file_path)
    
    def _process_java_output(self, output: Dict[str, Any]) -> PolicyResponse:
        """Process Java execution output."""
        success = output.get('success', True)
        message = output.get('message', 'Java callout executed')
        
        if not success:
            return self._create_error_response(message)
        
        # Extract response data
        response_data = {
            'success': success,
            'message': message,
            'continue_processing': output.get('continue_processing', True),
            'terminate_request': output.get('terminate_request', False)
        }
        
        # Add optional fields
        if 'status_code' in output:
            response_data['status_code'] = output['status_code']
        
        if 'headers' in output:
            response_data['headers'] = output['headers']
        
        if 'body' in output:
            response_data['body'] = output['body']
        
        if 'variables' in output:
            response_data['variables'] = output['variables']
        
        return PolicyResponse(**response_data)