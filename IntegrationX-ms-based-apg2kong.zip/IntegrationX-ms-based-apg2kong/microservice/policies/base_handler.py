"""
Base Policy Handler
==================

Abstract base class for all policy handlers.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import time
import logging
from core.models import PolicyRequest, PolicyResponse
from core.variable_mapper import variable_mapper

logger = logging.getLogger("apigee_policy_service")


class BasePolicyHandler(ABC):
    """Abstract base class for policy handlers."""
    
    def __init__(self):
        """Initialize the policy handler."""
        self.name = self.__class__.__name__
        self.initialized = False
        self.logger = logger
    
    async def initialize(self) -> None:
        """Initialize the policy handler."""
        try:
            await self._initialize()
            self.initialized = True
            self.logger.info(f"Initialized policy handler: {self.name}")
        except Exception as e:
            self.logger.error(f"Failed to initialize {self.name}: {str(e)}")
            raise
    
    async def cleanup(self) -> None:
        """Cleanup resources."""
        try:
            await self._cleanup()
            self.initialized = False
            self.logger.info(f"Cleaned up policy handler: {self.name}")
        except Exception as e:
            self.logger.error(f"Error cleaning up {self.name}: {str(e)}")
    
    async def execute(self, request: PolicyRequest) -> PolicyResponse:
        """Execute the policy."""
        if not self.initialized:
            raise RuntimeError(f"Policy handler {self.name} not initialized")
        
        start_time = time.time()
        
        try:
            self.logger.debug(f"Executing policy {self.name} for request {request.request_id}")
            
            # Validate request
            await self._validate_request(request)
            
            # Execute policy logic
            response = await self._execute_policy(request)
            
            # Calculate execution time
            execution_time = (time.time() - start_time) * 1000  # Convert to milliseconds
            response.execution_time_ms = execution_time
            response.policy_name = request.policy_name
            
            self.logger.debug(
                f"Policy {self.name} executed successfully in {execution_time:.2f}ms"
            )
            
            return response
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            self.logger.error(
                f"Policy {self.name} execution failed in {execution_time:.2f}ms: {str(e)}"
            )
            
            # Return error response
            return PolicyResponse(
                success=False,
                message=f"Policy execution failed: {str(e)}",
                continue_processing=False,
                terminate_request=True,
                execution_time_ms=execution_time,
                policy_name=request.policy_name
            )
    
    @abstractmethod
    async def _initialize(self) -> None:
        """Initialize handler-specific resources."""
        pass
    
    @abstractmethod
    async def _cleanup(self) -> None:
        """Cleanup handler-specific resources."""
        pass
    
    @abstractmethod
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute the policy logic."""
        pass
    
    async def _validate_request(self, request: PolicyRequest) -> None:
        """Validate the policy request."""
        if not request.policy_name:
            raise ValueError("Policy name is required")
        
        if not request.policy_type:
            raise ValueError("Policy type is required")
        
        if not request.method:
            raise ValueError("HTTP method is required")
        
        if not request.path:
            raise ValueError("Request path is required")
    
    def _create_success_response(
        self,
        message: str = "Policy executed successfully",
        **kwargs
    ) -> PolicyResponse:
        """Create a successful policy response."""
        return PolicyResponse(
            success=True,
            message=message,
            continue_processing=True,
            terminate_request=False,
            **kwargs
        )
    
    def _create_error_response(
        self,
        message: str,
        status_code: Optional[int] = None,
        terminate: bool = True,
        **kwargs
    ) -> PolicyResponse:
        """Create an error policy response."""
        return PolicyResponse(
            success=False,
            message=message,
            status_code=status_code,
            continue_processing=not terminate,
            terminate_request=terminate,
            **kwargs
        )
    
    def _extract_config_value(
        self,
        config: Dict[str, Any],
        key: str,
        default: Any = None,
        required: bool = False
    ) -> Any:
        """Extract configuration value with validation."""
        value = config.get(key, default)
        
        if required and value is None:
            raise ValueError(f"Required configuration '{key}' is missing")
        
        return value
    
    def _get_variable(
        self,
        var_name: str,
        request: PolicyRequest
    ) -> Any:
        """
        Get variable value with automatic Apigee/Kong mapping.
        
        Args:
            var_name: Variable name (Apigee or Kong format)
            request: Policy request containing variables
            
        Returns:
            Variable value or None
        """
        return variable_mapper.get_variable_value(
            var_name,
            request.flow_variables,
            request.variables
        )
    
    def _set_variable(
        self,
        var_name: str,
        value: Any,
        flow_variables: Dict[str, Any],
        custom_variables: Dict[str, Any]
    ) -> None:
        """
        Set variable value with automatic format handling.
        
        Args:
            var_name: Variable name
            value: Variable value
            flow_variables: Flow variables dictionary
            custom_variables: Custom variables dictionary
        """
        variable_mapper.set_variable_value(
            var_name,
            value,
            flow_variables,
            custom_variables
        )
    
    def _substitute_variables(
        self,
        template: str,
        request: PolicyRequest
    ) -> str:
        """
        Substitute variables in template string.
        
        Args:
            template: Template string with {variable} placeholders
            request: Policy request containing variables
            
        Returns:
            String with variables substituted
        """
        result = template
        
        # Substitute flow variables
        for key, value in request.flow_variables.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        
        # Substitute custom variables
        for key, value in request.variables.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        
        return result