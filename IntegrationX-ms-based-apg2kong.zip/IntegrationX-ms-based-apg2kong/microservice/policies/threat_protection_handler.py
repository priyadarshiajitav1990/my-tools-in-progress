"""
Threat Protection Policy Handler
===============================

Handles XML and JSON threat protection policies with configurable limits
for depth, attributes, string length, and other security validations.
"""

import json
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional
from defusedxml import ElementTree as DefusedET
from defusedxml.common import EntitiesForbidden, ExternalReferenceForbidden

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse
from core.config import Settings

settings = Settings()


class ThreatProtectionPolicyHandler(BasePolicyHandler):
    """Handler for XML and JSON threat protection policies."""
    
    def __init__(self):
        super().__init__()
        self.xml_max_depth = settings.xml_max_depth
        self.xml_max_attributes = settings.xml_max_attributes
        self.json_max_depth = settings.json_max_depth
        self.json_max_string_length = settings.json_max_string_length
    
    async def _initialize(self) -> None:
        """Initialize threat protection handler."""
        self.logger.info("Threat protection handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup resources."""
        pass
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute threat protection policy."""
        try:
            policy_type = request.policy_type.lower()
            
            if 'xml' in policy_type:
                return await self._validate_xml_content(request)
            elif 'json' in policy_type:
                return await self._validate_json_content(request)
            else:
                return self._create_error_response(f"Unsupported threat protection type: {policy_type}")
                
        except Exception as e:
            return self._create_error_response(f"Threat protection validation failed: {str(e)}")
    
    async def _validate_xml_content(self, request: PolicyRequest) -> PolicyResponse:
        """Validate XML content for threats."""
        try:
            # Get XML content
            xml_content = request.body
            if not xml_content:
                return self._create_success_response("No XML content to validate")
            
            # Extract configuration
            config = request.policy_config
            max_depth = self._extract_config_value(config, 'max_depth', self.xml_max_depth)
            max_attributes = self._extract_config_value(config, 'max_attributes', self.xml_max_attributes)
            max_element_name_length = self._extract_config_value(config, 'max_element_name_length', 1000)
            max_text_length = self._extract_config_value(config, 'max_text_length', 10000)
            
            # Parse XML using defusedxml for security
            try:
                root = DefusedET.fromstring(xml_content)
            except (EntitiesForbidden, ExternalReferenceForbidden) as e:
                return self._create_error_response(
                    f"XML security violation: {str(e)}",
                    status_code=400
                )
            except ET.ParseError as e:
                return self._create_error_response(
                    f"Invalid XML format: {str(e)}",
                    status_code=400
                )
            
            # Validate XML structure
            violations = []
            
            # Check depth
            actual_depth = self._calculate_xml_depth(root)
            if actual_depth > max_depth:
                violations.append(f"XML depth {actual_depth} exceeds maximum {max_depth}")
            
            # Check attributes and element names
            for elem in root.iter():
                # Check element name length
                if len(elem.tag) > max_element_name_length:
                    violations.append(f"Element name length {len(elem.tag)} exceeds maximum {max_element_name_length}")
                
                # Check attribute count
                if len(elem.attrib) > max_attributes:
                    violations.append(f"Element '{elem.tag}' has {len(elem.attrib)} attributes, exceeds maximum {max_attributes}")
                
                # Check text content length
                if elem.text and len(elem.text) > max_text_length:
                    violations.append(f"Text content length {len(elem.text)} exceeds maximum {max_text_length}")
            
            if violations:
                return self._create_error_response(
                    f"XML threat protection violations: {'; '.join(violations)}",
                    status_code=400
                )
            
            return self._create_success_response("XML validation passed")
            
        except Exception as e:
            return self._create_error_response(f"XML validation error: {str(e)}")
    
    async def _validate_json_content(self, request: PolicyRequest) -> PolicyResponse:
        """Validate JSON content for threats."""
        try:
            # Get JSON content
            json_content = request.body
            if not json_content:
                return self._create_success_response("No JSON content to validate")
            
            # Extract configuration
            config = request.policy_config
            max_depth = self._extract_config_value(config, 'max_depth', self.json_max_depth)
            max_string_length = self._extract_config_value(config, 'max_string_length', self.json_max_string_length)
            max_array_length = self._extract_config_value(config, 'max_array_length', 1000)
            max_object_entries = self._extract_config_value(config, 'max_object_entries', 1000)
            
            # Parse JSON
            try:
                json_data = json.loads(json_content)
            except json.JSONDecodeError as e:
                return self._create_error_response(
                    f"Invalid JSON format: {str(e)}",
                    status_code=400
                )
            
            # Validate JSON structure
            violations = []
            
            # Check depth
            actual_depth = self._calculate_json_depth(json_data)
            if actual_depth > max_depth:
                violations.append(f"JSON depth {actual_depth} exceeds maximum {max_depth}")
            
            # Check content recursively
            self._validate_json_recursive(
                json_data, violations, max_string_length, max_array_length, max_object_entries
            )
            
            if violations:
                return self._create_error_response(
                    f"JSON threat protection violations: {'; '.join(violations)}",
                    status_code=400
                )
            
            return self._create_success_response("JSON validation passed")
            
        except Exception as e:
            return self._create_error_response(f"JSON validation error: {str(e)}")
    
    def _calculate_xml_depth(self, element, current_depth=1):
        """Calculate maximum depth of XML element tree."""
        if not list(element):
            return current_depth
        
        max_child_depth = current_depth
        for child in element:
            child_depth = self._calculate_xml_depth(child, current_depth + 1)
            max_child_depth = max(max_child_depth, child_depth)
        
        return max_child_depth
    
    def _calculate_json_depth(self, obj, current_depth=1):
        """Calculate maximum depth of JSON object."""
        if isinstance(obj, dict):
            if not obj:
                return current_depth
            return max(
                self._calculate_json_depth(value, current_depth + 1)
                for value in obj.values()
            )
        elif isinstance(obj, list):
            if not obj:
                return current_depth
            return max(
                self._calculate_json_depth(item, current_depth + 1)
                for item in obj
            )
        else:
            return current_depth
    
    def _validate_json_recursive(
        self,
        obj,
        violations,
        max_string_length,
        max_array_length,
        max_object_entries,
        path=""
    ):
        """Recursively validate JSON object structure."""
        if isinstance(obj, dict):
            # Check object entries count
            if len(obj) > max_object_entries:
                violations.append(
                    f"Object at '{path}' has {len(obj)} entries, exceeds maximum {max_object_entries}"
                )
            
            # Validate each key-value pair
            for key, value in obj.items():
                # Check key length
                if isinstance(key, str) and len(key) > max_string_length:
                    violations.append(
                        f"Object key at '{path}' length {len(key)} exceeds maximum {max_string_length}"
                    )
                
                # Recursively validate value
                new_path = f"{path}.{key}" if path else key
                self._validate_json_recursive(
                    value, violations, max_string_length, max_array_length, max_object_entries, new_path
                )
        
        elif isinstance(obj, list):
            # Check array length
            if len(obj) > max_array_length:
                violations.append(
                    f"Array at '{path}' has {len(obj)} items, exceeds maximum {max_array_length}"
                )
            
            # Validate each item
            for i, item in enumerate(obj):
                new_path = f"{path}[{i}]" if path else f"[{i}]"
                self._validate_json_recursive(
                    item, violations, max_string_length, max_array_length, max_object_entries, new_path
                )
        
        elif isinstance(obj, str):
            # Check string length
            if len(obj) > max_string_length:
                violations.append(
                    f"String at '{path}' length {len(obj)} exceeds maximum {max_string_length}"
                )