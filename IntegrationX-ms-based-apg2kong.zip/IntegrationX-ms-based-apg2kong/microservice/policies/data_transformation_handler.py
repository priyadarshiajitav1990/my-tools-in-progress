"""
Data Transformation Policy Handler
==================================

Handles data transformation policies including XML to JSON conversion,
JSON to XML conversion, XSL transformations, and HTTP message modifications.
"""

import json
import xml.etree.ElementTree as ET
from xml.dom import minidom
import xmltodict
from lxml import etree
from typing import Dict, Any, Optional
import re

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class DataTransformationHandler(BasePolicyHandler):
    """Handler for data transformation policies."""
    
    def __init__(self):
        super().__init__()
    
    async def _initialize(self) -> None:
        """Initialize data transformation handler."""
        self.logger.info("Data transformation handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup resources."""
        pass
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute data transformation policy."""
        try:
            policy_type = request.policy_type.lower()
            
            if 'xml_to_json' in policy_type or 'xmltojson' in policy_type:
                return await self._transform_xml_to_json(request)
            elif 'json_to_xml' in policy_type or 'jsontoxml' in policy_type:
                return await self._transform_json_to_xml(request)
            elif 'xsl_transform' in policy_type or 'xsl' in policy_type:
                return await self._apply_xsl_transform(request)
            elif 'http_modifier' in policy_type:
                return await self._modify_http_message(request)
            else:
                return self._create_error_response(f"Unsupported transformation type: {policy_type}")
                
        except Exception as e:
            return self._create_error_response(f"Data transformation failed: {str(e)}")
    
    async def _transform_xml_to_json(self, request: PolicyRequest) -> PolicyResponse:
        """Transform XML content to JSON."""
        try:
            # Get XML content
            xml_content = request.body
            if not xml_content:
                return self._create_error_response("No XML content to transform")
            
            config = request.policy_config
            
            # Configuration options
            array_notation = self._extract_config_value(config, 'array_notation', False)
            attribute_prefix = self._extract_config_value(config, 'attribute_prefix', '@')
            text_key = self._extract_config_value(config, 'text_key', '#text')
            pretty_print = self._extract_config_value(config, 'pretty_print', True)
            
            # Parse XML
            try:
                # Use xmltodict for better conversion
                json_data = xmltodict.parse(
                    xml_content,
                    attr_prefix=attribute_prefix,
                    item_depth=0 if array_notation else 1
                )
            except Exception as e:
                return self._create_error_response(f"XML parsing failed: {str(e)}")
            
            # Convert to JSON string
            if pretty_print:
                json_output = json.dumps(json_data, indent=2, ensure_ascii=False)
            else:
                json_output = json.dumps(json_data, ensure_ascii=False)
            
            # Update response headers
            headers = {'Content-Type': 'application/json'}
            
            return self._create_success_response(
                "XML to JSON transformation completed",
                headers=headers,
                body=json_output
            )
            
        except Exception as e:
            return self._create_error_response(f"XML to JSON transformation failed: {str(e)}")
    
    async def _transform_json_to_xml(self, request: PolicyRequest) -> PolicyResponse:
        """Transform JSON content to XML."""
        try:
            # Get JSON content
            json_content = request.body
            if not json_content:
                return self._create_error_response("No JSON content to transform")
            
            config = request.policy_config
            
            # Configuration options
            root_element = self._extract_config_value(config, 'root_element', 'root')
            attribute_prefix = self._extract_config_value(config, 'attribute_prefix', '@')
            text_key = self._extract_config_value(config, 'text_key', '#text')
            pretty_print = self._extract_config_value(config, 'pretty_print', True)
            
            # Parse JSON
            try:
                json_data = json.loads(json_content)
            except json.JSONDecodeError as e:
                return self._create_error_response(f"JSON parsing failed: {str(e)}")
            
            # Convert to XML
            xml_output = await self._json_to_xml_recursive(
                json_data, root_element, attribute_prefix, text_key
            )
            
            # Pretty print if requested
            if pretty_print:
                try:
                    dom = minidom.parseString(xml_output)
                    xml_output = dom.toprettyxml(indent="  ", encoding=None)
                    # Remove empty lines
                    xml_output = '\n'.join([line for line in xml_output.split('\n') if line.strip()])
                except Exception:
                    pass  # Use original if pretty printing fails
            
            # Update response headers
            headers = {'Content-Type': 'application/xml'}
            
            return self._create_success_response(
                "JSON to XML transformation completed",
                headers=headers,
                body=xml_output
            )
            
        except Exception as e:
            return self._create_error_response(f"JSON to XML transformation failed: {str(e)}")
    
    async def _apply_xsl_transform(self, request: PolicyRequest) -> PolicyResponse:
        """Apply XSL transformation to XML content."""
        try:
            # Get XML content
            xml_content = request.body
            if not xml_content:
                return self._create_error_response("No XML content to transform")
            
            config = request.policy_config
            
            # Get XSL stylesheet
            xsl_content = self._extract_config_value(config, 'xsl_stylesheet', required=True)
            output_method = self._extract_config_value(config, 'output_method', 'xml')
            
            try:
                # Parse XML and XSL
                xml_doc = etree.fromstring(xml_content.encode('utf-8'))
                xsl_doc = etree.fromstring(xsl_content.encode('utf-8'))
                
                # Create transformer
                transform = etree.XSLT(xsl_doc)
                
                # Apply transformation
                result = transform(xml_doc)
                
                # Get output
                if output_method.lower() == 'text':
                    output = str(result)
                    content_type = 'text/plain'
                elif output_method.lower() == 'html':
                    output = etree.tostring(result, method='html', encoding='unicode')
                    content_type = 'text/html'
                else:
                    output = etree.tostring(result, encoding='unicode', pretty_print=True)
                    content_type = 'application/xml'
                
                # Update response headers
                headers = {'Content-Type': content_type}
                
                return self._create_success_response(
                    "XSL transformation completed",
                    headers=headers,
                    body=output
                )
                
            except etree.XSLTParseError as e:
                return self._create_error_response(f"XSL parsing failed: {str(e)}")
            except etree.XMLSyntaxError as e:
                return self._create_error_response(f"XML syntax error: {str(e)}")
            except Exception as e:
                return self._create_error_response(f"XSL transformation failed: {str(e)}")
            
        except Exception as e:
            return self._create_error_response(f"XSL transformation failed: {str(e)}")
    
    async def _modify_http_message(self, request: PolicyRequest) -> PolicyResponse:
        """Modify HTTP message headers, body, or other attributes."""
        try:
            config = request.policy_config
            
            # Header modifications
            add_headers = self._extract_config_value(config, 'add_headers', {})
            remove_headers = self._extract_config_value(config, 'remove_headers', [])
            modify_headers = self._extract_config_value(config, 'modify_headers', {})
            
            # Body modifications
            body_transformation = self._extract_config_value(config, 'body_transformation')
            content_type_override = self._extract_config_value(config, 'content_type')
            
            # Query parameter modifications
            add_query_params = self._extract_config_value(config, 'add_query_params', {})
            remove_query_params = self._extract_config_value(config, 'remove_query_params', [])
            
            # Start with current headers
            response_headers = dict(request.headers)
            
            # Remove headers
            for header_name in remove_headers:
                response_headers.pop(header_name.lower(), None)
            
            # Add new headers
            response_headers.update(add_headers)
            
            # Modify existing headers
            for header_name, header_value in modify_headers.items():
                # Support variable substitution
                modified_value = await self._substitute_variables(header_value, request)
                response_headers[header_name] = modified_value
            
            # Handle body transformation
            response_body = request.body
            if body_transformation:
                response_body = await self._apply_body_transformation(
                    request.body, body_transformation, request
                )
            
            # Override content type if specified
            if content_type_override:
                response_headers['Content-Type'] = content_type_override
            
            # Handle query parameter modifications
            variables = {}
            if add_query_params or remove_query_params:
                # Store modified query params in variables for Kong to use
                modified_params = dict(request.query_params)
                
                # Remove parameters
                for param_name in remove_query_params:
                    modified_params.pop(param_name, None)
                
                # Add parameters
                modified_params.update(add_query_params)
                
                variables['modified_query_params'] = modified_params
            
            return self._create_success_response(
                "HTTP message modification completed",
                headers=response_headers,
                body=response_body,
                variables=variables
            )
            
        except Exception as e:
            return self._create_error_response(f"HTTP message modification failed: {str(e)}")
    
    async def _json_to_xml_recursive(
        self,
        data: Any,
        element_name: str,
        attribute_prefix: str,
        text_key: str
    ) -> str:
        """Recursively convert JSON data to XML."""
        if isinstance(data, dict):
            # Handle object
            element = ET.Element(element_name)
            
            # Process attributes (keys starting with attribute_prefix)
            for key, value in data.items():
                if key.startswith(attribute_prefix):
                    attr_name = key[len(attribute_prefix):]
                    element.set(attr_name, str(value))
                elif key == text_key:
                    element.text = str(value)
                else:
                    # Create child element
                    child_xml = await self._json_to_xml_recursive(
                        value, key, attribute_prefix, text_key
                    )
                    child_element = ET.fromstring(child_xml)
                    element.append(child_element)
            
            return ET.tostring(element, encoding='unicode')
            
        elif isinstance(data, list):
            # Handle array - create multiple elements with same name
            root = ET.Element('array')
            for item in data:
                item_xml = await self._json_to_xml_recursive(
                    item, 'item', attribute_prefix, text_key
                )
                item_element = ET.fromstring(item_xml)
                root.append(item_element)
            
            return ET.tostring(root, encoding='unicode')
            
        else:
            # Handle primitive value
            element = ET.Element(element_name)
            element.text = str(data)
            return ET.tostring(element, encoding='unicode')
    
    async def _apply_body_transformation(
        self,
        body: Optional[str],
        transformation: Dict[str, Any],
        request: PolicyRequest
    ) -> Optional[str]:
        """Apply body transformation rules."""
        if not body:
            return body
        
        try:
            transform_type = transformation.get('type', 'replace')
            
            if transform_type == 'replace':
                # Simple string replacement
                find_pattern = transformation.get('find', '')
                replace_with = transformation.get('replace', '')
                
                # Support variable substitution in replacement
                replace_with = await self._substitute_variables(replace_with, request)
                
                return body.replace(find_pattern, replace_with)
                
            elif transform_type == 'regex':
                # Regex replacement
                pattern = transformation.get('pattern', '')
                replacement = transformation.get('replacement', '')
                flags = transformation.get('flags', 0)
                
                # Support variable substitution in replacement
                replacement = await self._substitute_variables(replacement, request)
                
                return re.sub(pattern, replacement, body, flags=flags)
                
            elif transform_type == 'template':
                # Template substitution
                template = transformation.get('template', body)
                return await self._substitute_variables(template, request)
                
            else:
                self.logger.warning(f"Unknown body transformation type: {transform_type}")
                return body
                
        except Exception as e:
            self.logger.error(f"Body transformation failed: {str(e)}")
            return body
    
    async def _substitute_variables(self, template: str, request: PolicyRequest) -> str:
        """Substitute variables in template string."""
        try:
            # Build variable context
            variables = {
                'request.method': request.method,
                'request.path': request.path,
                'request.client_ip': request.client_ip or '',
                'request.user_agent': request.user_agent or '',
                'request.request_id': request.request_id or '',
                'policy.name': request.policy_name,
                'policy.type': request.policy_type
            }
            
            # Add custom variables
            variables.update(request.variables)
            variables.update(request.flow_variables)
            
            # Add request headers with prefix
            for key, value in request.headers.items():
                variables[f'request.header.{key.lower()}'] = value
            
            # Add query parameters with prefix
            for key, value in request.query_params.items():
                variables[f'request.queryparam.{key}'] = value
            
            # Perform substitution
            result = template
            for var_name, var_value in variables.items():
                placeholder = f'{{{var_name}}}'
                if placeholder in result:
                    result = result.replace(placeholder, str(var_value))
            
            return result
            
        except Exception as e:
            self.logger.error(f"Variable substitution failed: {str(e)}")
            return template