"""
JavaScript Policy Handler
=========================

Handles JavaScript and Python script policy execution using a secure sandbox.
Supports inline scripts, file system references, and URL-based scripts.
"""

import asyncio
import json
import subprocess
import tempfile
import os
from typing import Dict, Any, Optional
from pathlib import Path

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse
from core.resource_loader import resource_loader


class JavaScriptPolicyHandler(BasePolicyHandler):
    """Handler for JavaScript and Python script policies."""
    
    def __init__(self):
        super().__init__()
        self.node_available = False
        self.python_available = False
        self.temp_dir = None
    
    async def _initialize(self) -> None:
        """Initialize JavaScript execution environment."""
        # Check if Node.js is available
        try:
            result = await asyncio.create_subprocess_exec(
                'node', '--version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await result.communicate()
            self.node_available = result.returncode == 0
        except FileNotFoundError:
            self.node_available = False
        
        # Check if Python is available
        try:
            result = await asyncio.create_subprocess_exec(
                'python', '--version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await result.communicate()
            self.python_available = result.returncode == 0
        except FileNotFoundError:
            self.python_available = False
        
        # Create temporary directory for script execution
        self.temp_dir = Path(tempfile.mkdtemp(prefix="apigee_scripts_"))
        
        self.logger.info(f"JavaScript handler initialized - Node.js: {self.node_available}, Python: {self.python_available}")
    
    async def _cleanup(self) -> None:
        """Cleanup temporary resources."""
        if self.temp_dir and self.temp_dir.exists():
            import shutil
            shutil.rmtree(self.temp_dir)
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute JavaScript or Python script policy."""
        
        # Determine script type
        script_type = self._determine_script_type(request)
        
        # Load script content from various sources
        try:
            script_content = await resource_loader.load_script(
                request.policy_config,
                api_name=request.api_name,
                resource_type='script'
            )
        except Exception as e:
            return self._create_error_response(
                f"Failed to load script: {str(e)}"
            )
        
        # Validate script syntax if enabled
        if request.policy_config.get('validate_syntax', False):
            if script_type == "javascript":
                is_valid = await resource_loader.validate_javascript(script_content)
                if not is_valid:
                    return self._create_error_response("Invalid JavaScript syntax")
            elif script_type == "python":
                is_valid = await resource_loader.validate_python(script_content)
                if not is_valid:
                    return self._create_error_response("Invalid Python syntax")
        
        if script_type == "javascript":
            return await self._execute_javascript(script_content, request)
        elif script_type == "python":
            return await self._execute_python(script_content, request)
        else:
            return self._create_error_response(
                f"Unsupported script type: {script_type}"
            )
    
    def _determine_script_type(self, request: PolicyRequest) -> str:
        """Determine the script type from request."""
        policy_type = request.policy_type.lower()
        
        if "javascript" in policy_type or "js" in policy_type:
            return "javascript"
        elif "python" in policy_type or "py" in policy_type:
            return "python"
        
        # Check script content for hints
        script_content = self._extract_config_value(
            request.policy_config, 'script_content', ''
        )
        
        if 'function' in script_content or 'var ' in script_content:
            return "javascript"
        elif 'def ' in script_content or 'import ' in script_content:
            return "python"
        
        return "javascript"  # Default
    
    async def _execute_javascript(self, script_content: str, request: PolicyRequest) -> PolicyResponse:
        """Execute JavaScript code."""
        if not self.node_available:
            return self._create_error_response(
                "Node.js not available for JavaScript execution"
            )
        
        try:
            # Extract script content
            script_content = self._extract_config_value(
                request.policy_config, 'script_content', required=True
            )
            
            # Create execution context
            context = self._create_execution_context(request)
            
            # Create wrapper script
            wrapper_script = self._create_js_wrapper(script_content, context)
            
            # Write script to temporary file
            script_file = self.temp_dir / f"script_{request.request_id}.js"
            with open(script_file, 'w', encoding='utf-8') as f:
                f.write(wrapper_script)
            
            # Execute script
            timeout = self._extract_config_value(
                request.policy_config, 'timeout_ms', 5000
            ) / 1000  # Convert to seconds
            
            process = await asyncio.create_subprocess_exec(
                'node', str(script_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.temp_dir)
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return self._create_error_response(
                    f"Script execution timed out after {timeout}s"
                )
            
            # Clean up script file
            script_file.unlink(missing_ok=True)
            
            # Process results
            if process.returncode != 0:
                error_msg = stderr.decode('utf-8') if stderr else "Script execution failed"
                return self._create_error_response(f"JavaScript error: {error_msg}")
            
            # Parse output
            try:
                result = json.loads(stdout.decode('utf-8'))
                return self._process_script_result(result, request)
            except json.JSONDecodeError:
                return self._create_error_response(
                    "Invalid JSON output from JavaScript execution"
                )
                
        except Exception as e:
            return self._create_error_response(f"JavaScript execution failed: {str(e)}")
    
    async def _execute_python(self, request: PolicyRequest) -> PolicyResponse:
        """Execute Python code."""
        if not self.python_available:
            return self._create_error_response(
                "Python not available for script execution"
            )
        
        try:
            # Extract script content
            script_content = self._extract_config_value(
                request.policy_config, 'script_content', required=True
            )
            
            # Create execution context
            context = self._create_execution_context(request)
            
            # Create wrapper script
            wrapper_script = self._create_python_wrapper(script_content, context)
            
            # Write script to temporary file
            script_file = self.temp_dir / f"script_{request.request_id}.py"
            with open(script_file, 'w', encoding='utf-8') as f:
                f.write(wrapper_script)
            
            # Execute script
            timeout = self._extract_config_value(
                request.policy_config, 'timeout_ms', 5000
            ) / 1000  # Convert to seconds
            
            process = await asyncio.create_subprocess_exec(
                'python', str(script_file),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.temp_dir)
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return self._create_error_response(
                    f"Script execution timed out after {timeout}s"
                )
            
            # Clean up script file
            script_file.unlink(missing_ok=True)
            
            # Process results
            if process.returncode != 0:
                error_msg = stderr.decode('utf-8') if stderr else "Script execution failed"
                return self._create_error_response(f"Python error: {error_msg}")
            
            # Parse output
            try:
                result = json.loads(stdout.decode('utf-8'))
                return self._process_script_result(result, request)
            except json.JSONDecodeError:
                return self._create_error_response(
                    "Invalid JSON output from Python execution"
                )
                
        except Exception as e:
            return self._create_error_response(f"Python execution failed: {str(e)}")
    
    def _create_execution_context(self, request: PolicyRequest) -> Dict[str, Any]:
        """Create execution context for scripts."""
        return {
            'request': {
                'method': request.method,
                'path': request.path,
                'headers': request.headers,
                'queryParams': request.query_params,
                'body': request.body
            },
            'variables': request.variables,
            'flowVariables': request.flow_variables,
            'clientIp': request.client_ip,
            'userAgent': request.user_agent
        }
    
    def _create_js_wrapper(self, script_content: str, context: Dict[str, Any]) -> str:
        """Create JavaScript wrapper script."""
        return f"""
const context = {json.dumps(context, indent=2)};

// Apigee-like API functions
function getVariable(name) {{
    return context.variables[name] || context.flowVariables[name];
}}

function setVariable(name, value) {{
    context.variables[name] = value;
}}

function getHeader(name) {{
    return context.request.headers[name];
}}

function setHeader(name, value) {{
    if (!context.response) context.response = {{}};
    if (!context.response.headers) context.response.headers = {{}};
    context.response.headers[name] = value;
}}

// User script
try {{
    {script_content}
    
    // Output result
    console.log(JSON.stringify({{
        success: true,
        context: context,
        message: "Script executed successfully"
    }}));
}} catch (error) {{
    console.log(JSON.stringify({{
        success: false,
        error: error.message,
        message: "Script execution failed"
    }}));
    process.exit(1);
}}
"""
    
    def _create_python_wrapper(self, script_content: str, context: Dict[str, Any]) -> str:
        """Create Python wrapper script."""
        return f"""
import json
import sys

context = {json.dumps(context, indent=2)}

# Apigee-like API functions
def get_variable(name):
    return context.get('variables', {{}}).get(name) or context.get('flowVariables', {{}}).get(name)

def set_variable(name, value):
    if 'variables' not in context:
        context['variables'] = {{}}
    context['variables'][name] = value

def get_header(name):
    return context.get('request', {{}}).get('headers', {{}}).get(name)

def set_header(name, value):
    if 'response' not in context:
        context['response'] = {{}}
    if 'headers' not in context['response']:
        context['response']['headers'] = {{}}
    context['response']['headers'][name] = value

# User script
try:
{script_content}
    
    # Output result
    print(json.dumps({{
        "success": True,
        "context": context,
        "message": "Script executed successfully"
    }}))
except Exception as error:
    print(json.dumps({{
        "success": False,
        "error": str(error),
        "message": "Script execution failed"
    }}))
    sys.exit(1)
"""
    
    def _process_script_result(self, result: Dict[str, Any], request: PolicyRequest) -> PolicyResponse:
        """Process script execution result."""
        if not result.get('success', False):
            return self._create_error_response(
                result.get('message', 'Script execution failed')
            )
        
        # Extract context updates
        updated_context = result.get('context', {})
        response_data = updated_context.get('response', {})
        
        return PolicyResponse(
            success=True,
            message=result.get('message', 'Script executed successfully'),
            headers=response_data.get('headers', {}),
            body=response_data.get('body'),
            status_code=response_data.get('statusCode'),
            variables=updated_context.get('variables', {}),
            continue_processing=True,
            terminate_request=False
        )