"""
Service Callout Policy Handler
==============================

Handles service callout and external callout policies by making HTTP requests
to external services and processing their responses.
"""

import asyncio
import json
from typing import Dict, Any, Optional
import httpx
from urllib.parse import urljoin, urlparse

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class ServiceCalloutPolicyHandler(BasePolicyHandler):
    """Handler for service callout and external callout policies."""
    
    def __init__(self):
        super().__init__()
        self.http_client = None
        self.default_timeout = 30
        self.max_retries = 3
    
    async def _initialize(self) -> None:
        """Initialize HTTP client."""
        self.http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.default_timeout),
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100)
        )
        self.logger.info("Service callout handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup HTTP client."""
        if self.http_client:
            await self.http_client.aclose()
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute service callout policy."""
        try:
            # Extract callout configuration
            config = request.policy_config
            
            # Get target service details
            target_url = self._extract_config_value(config, 'target_url', required=True)
            target_method = self._extract_config_value(config, 'target_method', 'GET').upper()
            target_headers = self._extract_config_value(config, 'target_headers', {})
            target_body = self._extract_config_value(config, 'target_body')
            timeout_seconds = self._extract_config_value(config, 'timeout_seconds', self.default_timeout)
            
            # Process dynamic values (variable substitution)
            target_url = self._substitute_variables(target_url, request)
            target_body = self._substitute_variables(target_body, request) if target_body else None
            
            # Prepare headers
            processed_headers = {}
            for key, value in target_headers.items():
                processed_headers[key] = self._substitute_variables(value, request)
            
            # Add default headers if not present
            if target_body and 'Content-Type' not in processed_headers:
                processed_headers['Content-Type'] = 'application/json'
            
            # Make the service call
            response_data = await self._make_service_call(
                url=target_url,
                method=target_method,
                headers=processed_headers,
                body=target_body,
                timeout=timeout_seconds
            )
            
            # Process response based on policy configuration
            return await self._process_service_response(response_data, request)
            
        except Exception as e:
            return self._create_error_response(f"Service callout failed: {str(e)}")
    
    async def _make_service_call(
        self,
        url: str,
        method: str,
        headers: Dict[str, str],
        body: Optional[str],
        timeout: int
    ) -> Dict[str, Any]:
        """Make HTTP call to external service."""
        
        # Validate URL
        parsed_url = urlparse(url)
        if not parsed_url.scheme or not parsed_url.netloc:
            raise ValueError(f"Invalid target URL: {url}")
        
        # Prepare request data
        request_data = {
            'method': method,
            'url': url,
            'headers': headers,
            'timeout': timeout
        }
        
        if body and method in ['POST', 'PUT', 'PATCH']:
            # Try to parse as JSON, otherwise send as text
            try:
                json_body = json.loads(body)
                request_data['json'] = json_body
            except json.JSONDecodeError:
                request_data['content'] = body
        
        # Make the request with retries
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                self.logger.debug(f"Service call attempt {attempt + 1}: {method} {url}")
                
                response = await self.http_client.request(**request_data)
                
                # Prepare response data
                response_data = {
                    'status_code': response.status_code,
                    'headers': dict(response.headers),
                    'body': response.text,
                    'success': 200 <= response.status_code < 300,
                    'url': url,
                    'method': method,
                    'attempt': attempt + 1
                }
                
                # Try to parse response as JSON
                try:
                    response_data['json'] = response.json()
                except (json.JSONDecodeError, ValueError):
                    pass  # Keep as text
                
                self.logger.debug(f"Service call completed: {response.status_code}")
                return response_data
                
            except httpx.TimeoutException as e:
                last_exception = e
                self.logger.warning(f"Service call timeout (attempt {attempt + 1}): {str(e)}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
                
            except httpx.RequestError as e:
                last_exception = e
                self.logger.warning(f"Service call error (attempt {attempt + 1}): {str(e)}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        # All retries failed
        raise Exception(f"Service call failed after {self.max_retries} attempts: {str(last_exception)}")
    
    async def _process_service_response(
        self,
        response_data: Dict[str, Any],
        request: PolicyRequest
    ) -> PolicyResponse:
        """Process the service response and create policy response."""
        
        config = request.policy_config
        
        # Check if we should continue processing based on response
        continue_on_error = self._extract_config_value(config, 'continue_on_error', True)
        success_codes = self._extract_config_value(config, 'success_codes', [200, 201, 202, 204])
        
        is_success = response_data['status_code'] in success_codes
        
        # Extract response handling configuration
        response_variable = self._extract_config_value(config, 'response_variable', 'callout_response')
        extract_headers = self._extract_config_value(config, 'extract_headers', [])
        extract_json_paths = self._extract_config_value(config, 'extract_json_paths', {})
        
        # Prepare variables to set
        variables = {}
        
        # Store full response
        variables[response_variable] = {
            'status_code': response_data['status_code'],
            'headers': response_data['headers'],
            'body': response_data['body']
        }
        
        # Store response body in separate variable
        variables[f"{response_variable}_body"] = response_data['body']
        variables[f"{response_variable}_status"] = response_data['status_code']
        
        # Extract specific headers
        for header_name in extract_headers:
            header_value = response_data['headers'].get(header_name)
            if header_value:
                variables[f"{response_variable}_header_{header_name.lower()}"] = header_value
        
        # Extract JSON paths
        if 'json' in response_data:
            for var_name, json_path in extract_json_paths.items():
                try:
                    value = self._extract_json_path(response_data['json'], json_path)
                    if value is not None:
                        variables[var_name] = value
                except Exception as e:
                    self.logger.warning(f"Failed to extract JSON path {json_path}: {str(e)}")
        
        # Determine response behavior
        if is_success:
            return PolicyResponse(
                success=True,
                message=f"Service callout completed successfully (status: {response_data['status_code']})",
                variables=variables,
                continue_processing=True,
                terminate_request=False
            )
        else:
            if continue_on_error:
                return PolicyResponse(
                    success=True,
                    message=f"Service callout failed but continuing (status: {response_data['status_code']})",
                    variables=variables,
                    continue_processing=True,
                    terminate_request=False
                )
            else:
                return PolicyResponse(
                    success=False,
                    message=f"Service callout failed (status: {response_data['status_code']})",
                    status_code=response_data['status_code'],
                    body=response_data['body'],
                    variables=variables,
                    continue_processing=False,
                    terminate_request=True
                )
    
    def _substitute_variables(self, text: str, request: PolicyRequest) -> str:
        """Substitute variables in text using {variable_name} syntax."""
        if not text or not isinstance(text, str):
            return text
        
        # Combine all available variables
        all_variables = {}
        all_variables.update(request.variables)
        all_variables.update(request.flow_variables)
        
        # Add request context variables
        all_variables.update({
            'request.method': request.method,
            'request.path': request.path,
            'request.body': request.body or '',
            'client.ip': request.client_ip or '',
            'request.user_agent': request.user_agent or ''
        })
        
        # Add header variables
        for header_name, header_value in request.headers.items():
            all_variables[f'request.header.{header_name.lower()}'] = header_value
        
        # Add query parameter variables
        for param_name, param_value in request.query_params.items():
            all_variables[f'request.queryparam.{param_name}'] = param_value
        
        # Perform substitution
        result = text
        for var_name, var_value in all_variables.items():
            placeholder = f"{{{var_name}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(var_value))
        
        return result
    
    def _extract_json_path(self, json_data: Any, path: str) -> Any:
        """Extract value from JSON using dot notation path."""
        if not path:
            return json_data
        
        current = json_data
        parts = path.split('.')
        
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                index = int(part)
                if 0 <= index < len(current):
                    current = current[index]
                else:
                    return None
            else:
                return None
            
            if current is None:
                return None
        
        return current