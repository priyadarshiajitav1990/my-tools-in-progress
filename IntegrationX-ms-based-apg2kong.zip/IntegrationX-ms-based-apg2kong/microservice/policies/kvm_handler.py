"""
Key-Value Map (KVM) Policy Handler
==================================

Handles KVM operations using Redis as the backend storage.
Supports get, set, delete operations with TTL support.
"""

import json
from typing import Dict, Any, Optional, Union
import redis.asyncio as redis
from redis.exceptions import RedisError

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse
from core.config import Settings

settings = Settings()


class KVMPolicyHandler(BasePolicyHandler):
    """Handler for Key-Value Map operations."""
    
    def __init__(self):
        super().__init__()
        self.redis_client = None
        self.fallback_storage = {}  # In-memory fallback
        self.use_redis = True
    
    async def _initialize(self) -> None:
        """Initialize Redis connection."""
        try:
            self.redis_client = redis.Redis(
                host=settings.redis_host,
                port=settings.redis_port,
                db=settings.redis_db,
                password=settings.redis_password,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5
            )
            
            # Test connection
            await self.redis_client.ping()
            self.use_redis = True
            self.logger.info("KVM handler initialized with Redis backend")
            
        except Exception as e:
            self.logger.warning(f"Redis connection failed, using in-memory fallback: {str(e)}")
            self.use_redis = False
            self.redis_client = None
    
    async def _cleanup(self) -> None:
        """Cleanup Redis connection."""
        if self.redis_client:
            await self.redis_client.close()
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute KVM operation."""
        try:
            config = request.policy_config
            
            # Extract operation details
            operation = self._extract_config_value(config, 'operation', required=True).lower()
            key = self._extract_config_value(config, 'key', required=True)
            map_name = self._extract_config_value(config, 'map_name', 'default')
            
            # Substitute variables in key
            key = self._substitute_variables(key, request)
            
            # Create full key with map prefix
            full_key = f"kvm:{map_name}:{key}"
            
            # Execute operation
            if operation == 'get':
                return await self._handle_get_operation(full_key, request)
            elif operation == 'set':
                value = self._extract_config_value(config, 'value', required=True)
                ttl_seconds = self._extract_config_value(config, 'ttl_seconds')
                value = self._substitute_variables(value, request)
                return await self._handle_set_operation(full_key, value, ttl_seconds, request)
            elif operation == 'delete':
                return await self._handle_delete_operation(full_key, request)
            else:
                return self._create_error_response(f"Unsupported KVM operation: {operation}")
                
        except Exception as e:
            return self._create_error_response(f"KVM operation failed: {str(e)}")
    
    async def _handle_get_operation(self, key: str, request: PolicyRequest) -> PolicyResponse:
        """Handle KVM get operation."""
        try:
            value = await self._get_value(key)
            
            if value is not None:
                # Store value in variables
                variable_name = self._extract_config_value(
                    request.policy_config, 'result_variable', 'kvm_result'
                )
                
                variables = {variable_name: value}
                
                return PolicyResponse(
                    success=True,
                    message=f"KVM get successful for key: {key}",
                    variables=variables,
                    continue_processing=True,
                    terminate_request=False
                )
            else:
                # Key not found
                not_found_action = self._extract_config_value(
                    request.policy_config, 'not_found_action', 'continue'
                )
                
                if not_found_action == 'continue':
                    return PolicyResponse(
                        success=True,
                        message=f"KVM key not found: {key}",
                        continue_processing=True,
                        terminate_request=False
                    )
                else:
                    return self._create_error_response(
                        f"KVM key not found: {key}",
                        status_code=404
                    )
                    
        except Exception as e:
            return self._create_error_response(f"KVM get operation failed: {str(e)}")
    
    async def _handle_set_operation(
        self,
        key: str,
        value: str,
        ttl_seconds: Optional[int],
        request: PolicyRequest
    ) -> PolicyResponse:
        """Handle KVM set operation."""
        try:
            await self._set_value(key, value, ttl_seconds)
            
            return PolicyResponse(
                success=True,
                message=f"KVM set successful for key: {key}",
                continue_processing=True,
                terminate_request=False
            )
            
        except Exception as e:
            return self._create_error_response(f"KVM set operation failed: {str(e)}")
    
    async def _handle_delete_operation(self, key: str, request: PolicyRequest) -> PolicyResponse:
        """Handle KVM delete operation."""
        try:
            deleted = await self._delete_value(key)
            
            if deleted:
                return PolicyResponse(
                    success=True,
                    message=f"KVM delete successful for key: {key}",
                    continue_processing=True,
                    terminate_request=False
                )
            else:
                return PolicyResponse(
                    success=True,
                    message=f"KVM key not found for deletion: {key}",
                    continue_processing=True,
                    terminate_request=False
                )
                
        except Exception as e:
            return self._create_error_response(f"KVM delete operation failed: {str(e)}")
    
    async def _get_value(self, key: str) -> Optional[str]:
        """Get value from storage."""
        if self.use_redis and self.redis_client:
            try:
                return await self.redis_client.get(key)
            except RedisError as e:
                self.logger.warning(f"Redis get failed, using fallback: {str(e)}")
                return self.fallback_storage.get(key)
        else:
            return self.fallback_storage.get(key)
    
    async def _set_value(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> None:
        """Set value in storage."""
        if self.use_redis and self.redis_client:
            try:
                if ttl_seconds:
                    await self.redis_client.setex(key, ttl_seconds, value)
                else:
                    await self.redis_client.set(key, value)
                return
            except RedisError as e:
                self.logger.warning(f"Redis set failed, using fallback: {str(e)}")
        
        # Fallback to in-memory storage
        self.fallback_storage[key] = value
        
        # Note: TTL not supported in fallback storage
        if ttl_seconds:
            self.logger.warning("TTL not supported in fallback storage")
    
    async def _delete_value(self, key: str) -> bool:
        """Delete value from storage."""
        if self.use_redis and self.redis_client:
            try:
                result = await self.redis_client.delete(key)
                return result > 0
            except RedisError as e:
                self.logger.warning(f"Redis delete failed, using fallback: {str(e)}")
        
        # Fallback to in-memory storage
        if key in self.fallback_storage:
            del self.fallback_storage[key]
            return True
        return False
    
    def _substitute_variables(self, text: str, request: PolicyRequest) -> str:
        """Substitute variables in text using {variable_name} syntax."""
        if not text or not isinstance(text, str):
            return text
        
        # Combine all available variables
        all_variables = {}
        all_variables.update(request.variables)
        all_variables.update(request.flow_variables)
        
        # Add request context variables
        all_variables.update({
            'request.method': request.method,
            'request.path': request.path,
            'request.body': request.body or '',
            'client.ip': request.client_ip or '',
            'request.user_agent': request.user_agent or ''
        })
        
        # Add header variables
        for header_name, header_value in request.headers.items():
            all_variables[f'request.header.{header_name.lower()}'] = header_value
        
        # Add query parameter variables
        for param_name, param_value in request.query_params.items():
            all_variables[f'request.queryparam.{param_name}'] = param_value
        
        # Perform substitution
        result = text
        for var_name, var_value in all_variables.items():
            placeholder = f"{{{var_name}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(var_value))
        
        return result