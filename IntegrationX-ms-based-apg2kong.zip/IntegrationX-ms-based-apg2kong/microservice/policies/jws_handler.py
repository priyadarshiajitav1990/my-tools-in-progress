"""
JWS Policy Handler
==================

Handles JSON Web Signature (JWS) verification and decoding policies.
"""

import json
import jwt
from typing import Dict, Any, Optional
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
import base64
import time

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class JWSPolicyHandler(BasePolicyHandler):
    """Handler for JWS verification and decoding policies."""
    
    def __init__(self):
        super().__init__()
        self.supported_algorithms = ['RS256', 'RS384', 'RS512', 'ES256', 'ES384', 'ES512', 'HS256', 'HS384', 'HS512']
    
    async def _initialize(self) -> None:
        """Initialize JWS handler."""
        self.logger.info("JWS handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup JWS handler resources."""
        pass
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute JWS policy."""
        
        operation = self._extract_config_value(
            request.policy_config, 'operation', 'verify'
        ).lower()
        
        if operation == 'verify':
            return await self._verify_jws(request)
        elif operation == 'decode':
            return await self._decode_jws(request)
        else:
            return self._create_error_response(
                f"Unsupported JWS operation: {operation}"
            )
    
    async def _verify_jws(self, request: PolicyRequest) -> PolicyResponse:
        """Verify JWS signature."""
        try:
            # Extract JWS token
            token = self._extract_jws_token(request)
            if not token:
                return self._create_error_response("JWS token not found")
            
            # Get verification key
            key = self._get_verification_key(request.policy_config)
            if not key:
                return self._create_error_response("Verification key not configured")
            
            # Get algorithm
            algorithm = self._extract_config_value(
                request.policy_config, 'algorithm', 'RS256'
            )
            
            if algorithm not in self.supported_algorithms:
                return self._create_error_response(
                    f"Unsupported algorithm: {algorithm}"
                )
            
            # Verify token
            try:
                payload = jwt.decode(
                    token,
                    key,
                    algorithms=[algorithm],
                    options={
                        "verify_signature": True,
                        "verify_exp": self._extract_config_value(
                            request.policy_config, 'verify_expiration', True
                        ),
                        "verify_iat": self._extract_config_value(
                            request.policy_config, 'verify_issued_at', True
                        ),
                        "verify_nbf": self._extract_config_value(
                            request.policy_config, 'verify_not_before', True
                        )
                    }
                )
                
                # Store payload in variables
                variables = {
                    'jws_payload': payload,
                    'jws_verified': True,
                    'jws_algorithm': algorithm
                }
                
                return self._create_success_response(
                    message="JWS verification successful",
                    variables=variables
                )
                
            except jwt.ExpiredSignatureError:
                return self._create_error_response(
                    "JWS token has expired",
                    status_code=401
                )
            except jwt.InvalidTokenError as e:
                return self._create_error_response(
                    f"JWS verification failed: {str(e)}",
                    status_code=401
                )
                
        except Exception as e:
            return self._create_error_response(f"JWS verification error: {str(e)}")
    
    async def _decode_jws(self, request: PolicyRequest) -> PolicyResponse:
        """Decode JWS without verification."""
        try:
            # Extract JWS token
            token = self._extract_jws_token(request)
            if not token:
                return self._create_error_response("JWS token not found")
            
            # Decode without verification
            try:
                # Get header
                header = jwt.get_unverified_header(token)
                
                # Get payload
                payload = jwt.decode(
                    token,
                    options={"verify_signature": False}
                )
                
                # Store in variables
                variables = {
                    'jws_header': header,
                    'jws_payload': payload,
                    'jws_decoded': True
                }
                
                return self._create_success_response(
                    message="JWS decoded successfully",
                    variables=variables
                )
                
            except jwt.InvalidTokenError as e:
                return self._create_error_response(
                    f"JWS decoding failed: {str(e)}"
                )
                
        except Exception as e:
            return self._create_error_response(f"JWS decoding error: {str(e)}")
    
    def _extract_jws_token(self, request: PolicyRequest) -> Optional[str]:
        """Extract JWS token from request."""
        
        # Check policy config for token source
        token_source = self._extract_config_value(
            request.policy_config, 'token_source', 'header'
        ).lower()
        
        if token_source == 'header':
            header_name = self._extract_config_value(
                request.policy_config, 'header_name', 'Authorization'
            )
            
            auth_header = request.headers.get(header_name, '')
            if auth_header.startswith('Bearer '):
                return auth_header[7:]  # Remove 'Bearer ' prefix
            return auth_header
            
        elif token_source == 'query':
            param_name = self._extract_config_value(
                request.policy_config, 'query_param', 'token'
            )
            return request.query_params.get(param_name)
            
        elif token_source == 'body':
            if request.body:
                try:
                    body_data = json.loads(request.body)
                    field_name = self._extract_config_value(
                        request.policy_config, 'body_field', 'token'
                    )
                    return body_data.get(field_name)
                except json.JSONDecodeError:
                    return None
        
        return None
    
    def _get_verification_key(self, config: Dict[str, Any]) -> Optional[str]:
        """Get verification key from configuration."""
        
        # Check for direct key
        key = config.get('verification_key')
        if key:
            return key
        
        # Check for key from variable
        key_variable = config.get('key_variable')
        if key_variable:
            # In a real implementation, this would fetch from a secure store
            # For now, return a placeholder
            return config.get('key_value')
        
        # Check for JWKS URL (simplified implementation)
        jwks_url = config.get('jwks_url')
        if jwks_url:
            # In a real implementation, this would fetch and cache JWKS
            # For now, return None to indicate JWKS not implemented
            return None
        
        return None