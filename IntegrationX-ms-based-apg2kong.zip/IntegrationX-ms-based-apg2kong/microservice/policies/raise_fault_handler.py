"""
Raise Fault Policy Handler
==========================

Handles raise fault policies that generate error responses with custom
status codes, headers, and body content for API error handling.
"""

import json
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class RaiseFaultPolicyHandler(BasePolicyHandler):
    """Handler for raise fault policies."""
    
    def __init__(self):
        super().__init__()
    
    async def _initialize(self) -> None:
        """Initialize raise fault handler."""
        self.logger.info("Raise fault handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup resources."""
        pass
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute raise fault policy."""
        try:
            config = request.policy_config
            
            # Extract fault configuration
            fault_name = self._extract_config_value(config, 'fault_name', 'CustomFault')
            status_code = self._extract_config_value(config, 'status_code', 500)
            reason_phrase = self._extract_config_value(config, 'reason_phrase')
            
            # Extract response configuration
            response_headers = self._extract_config_value(config, 'headers', {})
            response_body = self._extract_config_value(config, 'body')
            content_type = self._extract_config_value(config, 'content_type', 'application/json')
            
            # Build fault response
            fault_response = await self._build_fault_response(
                fault_name=fault_name,
                status_code=status_code,
                reason_phrase=reason_phrase,
                headers=response_headers,
                body=response_body,
                content_type=content_type,
                request=request
            )
            
            return fault_response
            
        except Exception as e:
            return self._create_error_response(f"Raise fault policy failed: {str(e)}")
    
    async def _build_fault_response(
        self,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str],
        headers: Dict[str, str],
        body: Optional[str],
        content_type: str,
        request: PolicyRequest
    ) -> PolicyResponse:
        """Build the fault response."""
        try:
            # Prepare response headers
            response_headers = {
                'Content-Type': content_type,
                'X-Fault-Name': fault_name,
                'X-Policy-Name': request.policy_name
            }
            
            # Add custom headers
            response_headers.update(headers)
            
            # Build response body
            response_body = await self._build_response_body(
                body, content_type, fault_name, status_code, reason_phrase, request
            )
            
            # Create fault response
            return PolicyResponse(
                success=True,  # Policy executed successfully, but generates fault
                message=f"Fault '{fault_name}' raised successfully",
                status_code=status_code,
                headers=response_headers,
                body=response_body,
                continue_processing=False,
                terminate_request=True
            )
            
        except Exception as e:
            return self._create_error_response(f"Failed to build fault response: {str(e)}")
    
    async def _build_response_body(
        self,
        body_template: Optional[str],
        content_type: str,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str],
        request: PolicyRequest
    ) -> str:
        """Build the response body with variable substitution."""
        try:
            if body_template:
                # Perform variable substitution
                response_body = await self._substitute_variables(body_template, request)
            else:
                # Generate default response body based on content type
                response_body = await self._generate_default_body(
                    content_type, fault_name, status_code, reason_phrase
                )
            
            return response_body
            
        except Exception as e:
            self.logger.error(f"Error building response body: {str(e)}")
            return await self._generate_default_body(content_type, fault_name, status_code, reason_phrase)
    
    async def _substitute_variables(self, template: str, request: PolicyRequest) -> str:
        """Substitute variables in the response template."""
        try:
            # Build variable context
            variables = {
                'request.method': request.method,
                'request.path': request.path,
                'request.client_ip': request.client_ip or 'unknown',
                'request.user_agent': request.user_agent or 'unknown',
                'request.request_id': request.request_id or 'unknown',
                'policy.name': request.policy_name,
                'policy.type': request.policy_type
            }
            
            # Add custom variables
            variables.update(request.variables)
            variables.update(request.flow_variables)
            
            # Add request headers with prefix
            for key, value in request.headers.items():
                variables[f'request.header.{key.lower()}'] = value
            
            # Add query parameters with prefix
            for key, value in request.query_params.items():
                variables[f'request.queryparam.{key}'] = value
            
            # Perform substitution
            result = template
            for var_name, var_value in variables.items():
                placeholder = f'{{{var_name}}}'
                if placeholder in result:
                    result = result.replace(placeholder, str(var_value))
            
            return result
            
        except Exception as e:
            self.logger.error(f"Variable substitution failed: {str(e)}")
            return template
    
    async def _generate_default_body(
        self,
        content_type: str,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str]
    ) -> str:
        """Generate default response body based on content type."""
        try:
            if 'json' in content_type.lower():
                return await self._generate_json_fault(fault_name, status_code, reason_phrase)
            elif 'xml' in content_type.lower():
                return await self._generate_xml_fault(fault_name, status_code, reason_phrase)
            else:
                return await self._generate_text_fault(fault_name, status_code, reason_phrase)
                
        except Exception as e:
            self.logger.error(f"Error generating default body: {str(e)}")
            return f"Fault: {fault_name}"
    
    async def _generate_json_fault(
        self,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str]
    ) -> str:
        """Generate JSON fault response."""
        fault_data = {
            'fault': {
                'name': fault_name,
                'status_code': status_code,
                'message': reason_phrase or self._get_default_reason_phrase(status_code),
                'timestamp': self._get_current_timestamp()
            }
        }
        
        return json.dumps(fault_data, indent=2)
    
    async def _generate_xml_fault(
        self,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str]
    ) -> str:
        """Generate XML fault response."""
        root = ET.Element('fault')
        
        name_elem = ET.SubElement(root, 'name')
        name_elem.text = fault_name
        
        status_elem = ET.SubElement(root, 'status_code')
        status_elem.text = str(status_code)
        
        message_elem = ET.SubElement(root, 'message')
        message_elem.text = reason_phrase or self._get_default_reason_phrase(status_code)
        
        timestamp_elem = ET.SubElement(root, 'timestamp')
        timestamp_elem.text = self._get_current_timestamp()
        
        return ET.tostring(root, encoding='unicode')
    
    async def _generate_text_fault(
        self,
        fault_name: str,
        status_code: int,
        reason_phrase: Optional[str]
    ) -> str:
        """Generate plain text fault response."""
        message = reason_phrase or self._get_default_reason_phrase(status_code)
        return f"Fault: {fault_name}\nStatus: {status_code}\nMessage: {message}\nTimestamp: {self._get_current_timestamp()}"
    
    def _get_default_reason_phrase(self, status_code: int) -> str:
        """Get default reason phrase for HTTP status code."""
        reason_phrases = {
            400: "Bad Request",
            401: "Unauthorized",
            403: "Forbidden",
            404: "Not Found",
            405: "Method Not Allowed",
            409: "Conflict",
            429: "Too Many Requests",
            500: "Internal Server Error",
            501: "Not Implemented",
            502: "Bad Gateway",
            503: "Service Unavailable",
            504: "Gateway Timeout"
        }
        
        return reason_phrases.get(status_code, "Error")
    
    def _get_current_timestamp(self) -> str:
        """Get current timestamp in ISO format."""
        from datetime import datetime
        return datetime.utcnow().isoformat() + 'Z'