"""
Entity Policy Handler
=====================

Handles entity access and management policies (users, apps, developers, etc.).
"""

import json
import asyncio
from typing import Dict, Any, Optional, List
import httpx
from datetime import datetime

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class EntityPolicyHandler(BasePolicyHandler):
    """Handler for entity access and management policies."""
    
    def __init__(self):
        super().__init__()
        self.entity_cache = {}
        self.cache_ttl = 300  # 5 minutes
        self.http_client = None
    
    async def _initialize(self) -> None:
        """Initialize entity handler."""
        self.http_client = httpx.AsyncClient(timeout=30.0)
        self.logger.info("Entity handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup entity handler resources."""
        if self.http_client:
            await self.http_client.aclose()
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute entity policy."""
        
        operation = self._extract_config_value(
            request.policy_config, 'operation', 'get'
        ).lower()
        
        if operation == 'get':
            return await self._get_entity(request)
        elif operation == 'validate':
            return await self._validate_entity(request)
        elif operation == 'create':
            return await self._create_entity(request)
        elif operation == 'update':
            return await self._update_entity(request)
        elif operation == 'delete':
            return await self._delete_entity(request)
        else:
            return self._create_error_response(
                f"Unsupported entity operation: {operation}"
            )
    
    async def _get_entity(self, request: PolicyRequest) -> PolicyResponse:
        """Get entity information."""
        try:
            entity_type = self._extract_config_value(
                request.policy_config, 'entity_type', required=True
            )
            
            entity_id = self._extract_config_value(
                request.policy_config, 'entity_id', required=True
            )
            
            # Resolve entity ID from variables if needed
            entity_id = self._resolve_entity_id(entity_id, request)
            
            # Check cache first
            cache_key = f"{entity_type}:{entity_id}"
            cached_entity = self._get_from_cache(cache_key)
            
            if cached_entity:
                return self._create_success_response(
                    message="Entity retrieved from cache",
                    variables={
                        'entity': cached_entity,
                        'entity_found': True,
                        'entity_source': 'cache'
                    }
                )
            
            # Fetch entity
            entity = await self._fetch_entity(entity_type, entity_id, request)
            
            if entity:
                # Cache the entity
                self._store_in_cache(cache_key, entity)
                
                return self._create_success_response(
                    message="Entity retrieved successfully",
                    variables={
                        'entity': entity,
                        'entity_found': True,
                        'entity_source': 'api'
                    }
                )
            else:
                return self._create_error_response(
                    f"Entity not found: {entity_type}/{entity_id}",
                    status_code=404
                )
                
        except Exception as e:
            return self._create_error_response(f"Entity access error: {str(e)}")
    
    async def _validate_entity(self, request: PolicyRequest) -> PolicyResponse:
        """Validate entity against criteria."""
        try:
            # Get entity first
            entity_response = await self._get_entity(request)
            
            if not entity_response.success:
                return entity_response
            
            entity = entity_response.variables.get('entity')
            if not entity:
                return self._create_error_response("Entity not found for validation")
            
            # Get validation rules
            validation_rules = self._extract_config_value(
                request.policy_config, 'validation_rules', []
            )
            
            validation_results = []
            all_passed = True
            
            for rule in validation_rules:
                result = self._validate_rule(entity, rule, request)
                validation_results.append(result)
                if not result['passed']:
                    all_passed = False
            
            if all_passed:
                return self._create_success_response(
                    message="Entity validation passed",
                    variables={
                        'entity_valid': True,
                        'validation_results': validation_results
                    }
                )
            else:
                failure_action = self._extract_config_value(
                    request.policy_config, 'failure_action', 'reject'
                )
                
                if failure_action == 'reject':
                    return self._create_error_response(
                        "Entity validation failed",
                        status_code=403,
                        terminate=True
                    )
                else:
                    return self._create_success_response(
                        message="Entity validation completed with failures",
                        variables={
                            'entity_valid': False,
                            'validation_results': validation_results
                        }
                    )
                    
        except Exception as e:
            return self._create_error_response(f"Entity validation error: {str(e)}")
    
    async def _create_entity(self, request: PolicyRequest) -> PolicyResponse:
        """Create a new entity."""
        try:
            entity_type = self._extract_config_value(
                request.policy_config, 'entity_type', required=True
            )
            
            entity_data = self._extract_config_value(
                request.policy_config, 'entity_data', required=True
            )
            
            # Resolve entity data from variables
            entity_data = self._resolve_entity_data(entity_data, request)
            
            # Create entity via API
            created_entity = await self._create_entity_via_api(
                entity_type, entity_data, request
            )
            
            if created_entity:
                return self._create_success_response(
                    message="Entity created successfully",
                    variables={
                        'entity': created_entity,
                        'entity_created': True,
                        'entity_id': created_entity.get('id')
                    }
                )
            else:
                return self._create_error_response("Failed to create entity")
                
        except Exception as e:
            return self._create_error_response(f"Entity creation error: {str(e)}")
    
    async def _update_entity(self, request: PolicyRequest) -> PolicyResponse:
        """Update an existing entity."""
        try:
            entity_type = self._extract_config_value(
                request.policy_config, 'entity_type', required=True
            )
            
            entity_id = self._extract_config_value(
                request.policy_config, 'entity_id', required=True
            )
            
            update_data = self._extract_config_value(
                request.policy_config, 'update_data', required=True
            )
            
            # Resolve values
            entity_id = self._resolve_entity_id(entity_id, request)
            update_data = self._resolve_entity_data(update_data, request)
            
            # Update entity via API
            updated_entity = await self._update_entity_via_api(
                entity_type, entity_id, update_data, request
            )
            
            if updated_entity:
                # Invalidate cache
                cache_key = f"{entity_type}:{entity_id}"
                self._invalidate_cache(cache_key)
                
                return self._create_success_response(
                    message="Entity updated successfully",
                    variables={
                        'entity': updated_entity,
                        'entity_updated': True
                    }
                )
            else:
                return self._create_error_response("Failed to update entity")
                
        except Exception as e:
            return self._create_error_response(f"Entity update error: {str(e)}")
    
    async def _delete_entity(self, request: PolicyRequest) -> PolicyResponse:
        """Delete an entity."""
        try:
            entity_type = self._extract_config_value(
                request.policy_config, 'entity_type', required=True
            )
            
            entity_id = self._extract_config_value(
                request.policy_config, 'entity_id', required=True
            )
            
            # Resolve entity ID
            entity_id = self._resolve_entity_id(entity_id, request)
            
            # Delete entity via API
            success = await self._delete_entity_via_api(entity_type, entity_id, request)
            
            if success:
                # Invalidate cache
                cache_key = f"{entity_type}:{entity_id}"
                self._invalidate_cache(cache_key)
                
                return self._create_success_response(
                    message="Entity deleted successfully",
                    variables={'entity_deleted': True}
                )
            else:
                return self._create_error_response("Failed to delete entity")
                
        except Exception as e:
            return self._create_error_response(f"Entity deletion error: {str(e)}")
    
    async def _fetch_entity(self, entity_type: str, entity_id: str, request: PolicyRequest) -> Optional[Dict[str, Any]]:
        """Fetch entity from external API."""
        
        # Get API configuration
        api_base_url = self._extract_config_value(
            request.policy_config, 'api_base_url', 'http://localhost:8080/api'
        )
        
        api_key = self._extract_config_value(
            request.policy_config, 'api_key'
        )
        
        # Build URL
        url = f"{api_base_url}/{entity_type}/{entity_id}"
        
        # Prepare headers
        headers = {'Content-Type': 'application/json'}
        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"
        
        try:
            response = await self.http_client.get(url, headers=headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return None
            else:
                self.logger.error(f"API error fetching entity: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error fetching entity: {str(e)}")
            return None
    
    async def _create_entity_via_api(self, entity_type: str, entity_data: Dict[str, Any], request: PolicyRequest) -> Optional[Dict[str, Any]]:
        """Create entity via external API."""
        
        api_base_url = self._extract_config_value(
            request.policy_config, 'api_base_url', 'http://localhost:8080/api'
        )
        
        api_key = self._extract_config_value(
            request.policy_config, 'api_key'
        )
        
        url = f"{api_base_url}/{entity_type}"
        
        headers = {'Content-Type': 'application/json'}
        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"
        
        try:
            response = await self.http_client.post(
                url, 
                headers=headers, 
                json=entity_data
            )
            
            if response.status_code in (200, 201):
                return response.json()
            else:
                self.logger.error(f"API error creating entity: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating entity: {str(e)}")
            return None
    
    async def _update_entity_via_api(self, entity_type: str, entity_id: str, update_data: Dict[str, Any], request: PolicyRequest) -> Optional[Dict[str, Any]]:
        """Update entity via external API."""
        
        api_base_url = self._extract_config_value(
            request.policy_config, 'api_base_url', 'http://localhost:8080/api'
        )
        
        api_key = self._extract_config_value(
            request.policy_config, 'api_key'
        )
        
        url = f"{api_base_url}/{entity_type}/{entity_id}"
        
        headers = {'Content-Type': 'application/json'}
        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"
        
        try:
            response = await self.http_client.put(
                url, 
                headers=headers, 
                json=update_data
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"API error updating entity: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error updating entity: {str(e)}")
            return None
    
    async def _delete_entity_via_api(self, entity_type: str, entity_id: str, request: PolicyRequest) -> bool:
        """Delete entity via external API."""
        
        api_base_url = self._extract_config_value(
            request.policy_config, 'api_base_url', 'http://localhost:8080/api'
        )
        
        api_key = self._extract_config_value(
            request.policy_config, 'api_key'
        )
        
        url = f"{api_base_url}/{entity_type}/{entity_id}"
        
        headers = {}
        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"
        
        try:
            response = await self.http_client.delete(url, headers=headers)
            return response.status_code in (200, 204)
            
        except Exception as e:
            self.logger.error(f"Error deleting entity: {str(e)}")
            return False
    
    def _validate_rule(self, entity: Dict[str, Any], rule: Dict[str, Any], request: PolicyRequest) -> Dict[str, Any]:
        """Validate a single rule against entity."""
        
        field = rule.get('field')
        operator = rule.get('operator', '==')
        expected_value = rule.get('value')
        
        if not field:
            return {'passed': False, 'error': 'No field specified in rule'}
        
        actual_value = entity.get(field)
        
        try:
            if operator == '==':
                passed = actual_value == expected_value
            elif operator == '!=':
                passed = actual_value != expected_value
            elif operator == 'exists':
                passed = field in entity
            elif operator == 'not_exists':
                passed = field not in entity
            elif operator == 'contains':
                passed = expected_value in str(actual_value)
            elif operator == 'in':
                passed = actual_value in expected_value
            else:
                return {'passed': False, 'error': f'Unsupported operator: {operator}'}
            
            return {
                'passed': passed,
                'field': field,
                'operator': operator,
                'expected': expected_value,
                'actual': actual_value
            }
            
        except Exception as e:
            return {'passed': False, 'error': str(e)}
    
    def _resolve_entity_id(self, entity_id: str, request: PolicyRequest) -> str:
        """Resolve entity ID from variables."""
        if entity_id.startswith('${') and entity_id.endswith('}'):
            var_name = entity_id[2:-1]
            return str(request.variables.get(var_name, entity_id))
        return entity_id
    
    def _resolve_entity_data(self, entity_data: Dict[str, Any], request: PolicyRequest) -> Dict[str, Any]:
        """Resolve entity data from variables."""
        resolved = {}
        
        for key, value in entity_data.items():
            if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
                var_name = value[2:-1]
                resolved[key] = request.variables.get(var_name, value)
            else:
                resolved[key] = value
        
        return resolved
    
    def _get_from_cache(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get entity from cache."""
        if cache_key in self.entity_cache:
            cached_item = self.entity_cache[cache_key]
            if datetime.now().timestamp() - cached_item['timestamp'] < self.cache_ttl:
                return cached_item['data']
            else:
                del self.entity_cache[cache_key]
        return None
    
    def _store_in_cache(self, cache_key: str, entity: Dict[str, Any]) -> None:
        """Store entity in cache."""
        self.entity_cache[cache_key] = {
            'data': entity,
            'timestamp': datetime.now().timestamp()
        }
    
    def _invalidate_cache(self, cache_key: str) -> None:
        """Invalidate cache entry."""
        if cache_key in self.entity_cache:
            del self.entity_cache[cache_key]