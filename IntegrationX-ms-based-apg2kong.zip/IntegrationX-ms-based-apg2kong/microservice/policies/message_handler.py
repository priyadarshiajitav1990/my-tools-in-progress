"""
Message Policy Handler
======================

Handles message publishing and logging policies.
"""

import json
import asyncio
import aiofiles
from typing import Dict, Any, Optional
from datetime import datetime
import uuid

from .base_handler import BasePolicyHandler
from core.models import PolicyRequest, PolicyResponse


class MessagePolicyHandler(BasePolicyHandler):
    """Handler for message publishing and logging policies."""
    
    def __init__(self):
        super().__init__()
        self.message_queue = None
        self.log_file_handles = {}
    
    async def _initialize(self) -> None:
        """Initialize message handler."""
        # Initialize message queue connection (Redis, RabbitMQ, etc.)
        # For now, we'll use a simple in-memory queue
        self.message_queue = asyncio.Queue()
        self.logger.info("Message handler initialized")
    
    async def _cleanup(self) -> None:
        """Cleanup message handler resources."""
        # Close log file handles
        for handle in self.log_file_handles.values():
            try:
                await handle.close()
            except:
                pass
        self.log_file_handles.clear()
    
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        """Execute message policy."""
        
        operation = self._extract_config_value(
            request.policy_config, 'operation', 'publish'
        ).lower()
        
        if operation == 'publish':
            return await self._publish_message(request)
        elif operation == 'log':
            return await self._log_message(request)
        else:
            return self._create_error_response(
                f"Unsupported message operation: {operation}"
            )
    
    async def _publish_message(self, request: PolicyRequest) -> PolicyResponse:
        """Publish message to queue."""
        try:
            # Extract message configuration
            topic = self._extract_config_value(
                request.policy_config, 'topic', 'default'
            )
            
            message_template = self._extract_config_value(
                request.policy_config, 'message_template', '{}'
            )
            
            # Build message content
            message_content = self._build_message_content(
                message_template, request
            )
            
            # Create message envelope
            message = {
                'id': str(uuid.uuid4()),
                'timestamp': datetime.utcnow().isoformat(),
                'topic': topic,
                'content': message_content,
                'source': {
                    'method': request.method,
                    'path': request.path,
                    'client_ip': request.client_ip,
                    'request_id': request.request_id
                }
            }
            
            # Publish to queue
            await self._publish_to_queue(topic, message)
            
            # Store message ID in variables
            variables = {
                'message_id': message['id'],
                'message_published': True,
                'message_topic': topic
            }
            
            return self._create_success_response(
                message=f"Message published to topic: {topic}",
                variables=variables
            )
            
        except Exception as e:
            return self._create_error_response(f"Message publishing failed: {str(e)}")
    
    async def _log_message(self, request: PolicyRequest) -> PolicyResponse:
        """Log message to file or system."""
        try:
            # Extract logging configuration
            log_level = self._extract_config_value(
                request.policy_config, 'log_level', 'INFO'
            ).upper()
            
            log_file = self._extract_config_value(
                request.policy_config, 'log_file', 'application.log'
            )
            
            message_template = self._extract_config_value(
                request.policy_config, 'message_template', 
                '{timestamp} [{level}] {method} {path} - {message}'
            )
            
            custom_message = self._extract_config_value(
                request.policy_config, 'message', 'Request processed'
            )
            
            # Build log message
            log_data = {
                'timestamp': datetime.utcnow().isoformat(),
                'level': log_level,
                'method': request.method,
                'path': request.path,
                'message': custom_message,
                'client_ip': request.client_ip,
                'user_agent': request.user_agent,
                'request_id': request.request_id
            }
            
            # Format message
            formatted_message = self._format_template(message_template, log_data)
            
            # Write to log file
            await self._write_to_log_file(log_file, formatted_message)
            
            # Also log to system logger
            getattr(self.logger, log_level.lower(), self.logger.info)(
                f"Policy Log: {formatted_message}"
            )
            
            variables = {
                'message_logged': True,
                'log_file': log_file,
                'log_level': log_level
            }
            
            return self._create_success_response(
                message="Message logged successfully",
                variables=variables
            )
            
        except Exception as e:
            return self._create_error_response(f"Message logging failed: {str(e)}")
    
    def _build_message_content(self, template: str, request: PolicyRequest) -> Dict[str, Any]:
        """Build message content from template."""
        try:
            # Create context for template
            context = {
                'request': {
                    'method': request.method,
                    'path': request.path,
                    'headers': request.headers,
                    'query_params': request.query_params,
                    'body': request.body
                },
                'variables': request.variables,
                'flow_variables': request.flow_variables,
                'client_ip': request.client_ip,
                'user_agent': request.user_agent,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            # If template is JSON, parse and substitute
            if template.strip().startswith('{'):
                try:
                    template_obj = json.loads(template)
                    return self._substitute_template_values(template_obj, context)
                except json.JSONDecodeError:
                    pass
            
            # Simple string substitution
            return {
                'message': self._format_template(template, context),
                'context': context
            }
            
        except Exception as e:
            self.logger.error(f"Error building message content: {str(e)}")
            return {'error': str(e)}
    
    def _substitute_template_values(self, obj: Any, context: Dict[str, Any]) -> Any:
        """Recursively substitute template values."""
        if isinstance(obj, dict):
            return {k: self._substitute_template_values(v, context) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._substitute_template_values(item, context) for item in obj]
        elif isinstance(obj, str):
            return self._format_template(obj, context)
        else:
            return obj
    
    def _format_template(self, template: str, context: Dict[str, Any]) -> str:
        """Format template string with context values."""
        try:
            # Simple placeholder replacement
            formatted = template
            
            # Replace nested context values
            def replace_nested(obj, prefix=''):
                nonlocal formatted
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        placeholder = f"{{{prefix}{key}}}"
                        if isinstance(value, (str, int, float, bool)):
                            formatted = formatted.replace(placeholder, str(value))
                        elif isinstance(value, dict):
                            replace_nested(value, f"{prefix}{key}.")
                
            replace_nested(context)
            return formatted
            
        except Exception as e:
            self.logger.error(f"Error formatting template: {str(e)}")
            return template
    
    async def _publish_to_queue(self, topic: str, message: Dict[str, Any]) -> None:
        """Publish message to queue."""
        # In a real implementation, this would publish to Redis, RabbitMQ, Kafka, etc.
        # For now, we'll just add to in-memory queue
        await self.message_queue.put({
            'topic': topic,
            'message': message
        })
        
        self.logger.info(f"Message published to topic '{topic}': {message['id']}")
    
    async def _write_to_log_file(self, log_file: str, message: str) -> None:
        """Write message to log file."""
        try:
            # Ensure logs directory exists
            import os
            log_dir = os.path.dirname(log_file) if os.path.dirname(log_file) else 'logs'
            os.makedirs(log_dir, exist_ok=True)
            
            # Get or create file handle
            if log_file not in self.log_file_handles:
                self.log_file_handles[log_file] = await aiofiles.open(
                    log_file, mode='a', encoding='utf-8'
                )
            
            # Write message
            handle = self.log_file_handles[log_file]
            await handle.write(f"{message}\n")
            await handle.flush()
            
        except Exception as e:
            self.logger.error(f"Error writing to log file {log_file}: {str(e)}")
            raise