# Apigee Policy Microservice

A comprehensive microservice to handle all unsupported Apigee policies that Kong Gateway cannot natively process. This service provides REST APIs for each policy type and can be called from Kong using HTTP service plugins.

## Features

- **Comprehensive Policy Support**: Handles 20+ Apigee policy types
- **Production Ready**: Docker support, health checks, graceful shutdown
- **Scalable Architecture**: Async/await, connection pooling, caching
- **Robust Error Handling**: Comprehensive logging and error responses
- **Security**: Input validation, timeout controls, sandboxed execution
- **Monitoring**: Health checks, metrics, structured logging

## Supported Policies

### Script Execution
- **JavaScript Policy**: Execute JavaScript code with Apigee-like APIs
- **Python Script Policy**: Execute Python scripts in sandboxed environment

### External Integration
- **Service Callout**: Make HTTP calls to external services
- **External Callout**: Advanced external service integration
- **Java Callout**: Execute Java code (requires JVM)

### Data Management
- **KVM Operations**: Key-Value Map operations with Redis backend
- **Entity Access**: CRUD operations for users, apps, developers

### Security & Validation
- **JWS Verify/Decode**: JSON Web Signature verification and decoding
- **SAML Validate/Generate**: SAML assertion handling
- **Threat Protection**: XML/JSON threat protection with configurable limits

### Data Transformation
- **XML to JSON**: Convert XML payloads to JSON
- **JSON to XML**: Convert JSON payloads to XML
- **XSL Transform**: Apply XSL transformations

### Flow Control
- **Raise Fault**: Generate custom error responses
- **Assert Condition**: Conditional logic and assertions
- **HTTP Modifier**: Modify HTTP requests/responses

### Messaging & Logging
- **Publish Message**: Publish messages to queues/topics
- **Message Logging**: Structured logging with templates

## Quick Start

### Using Docker Compose (Recommended)

1. **Clone and navigate to microservice directory**:
   ```bash
   cd microservice
   ```

2. **Copy environment configuration**:
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start the services**:
   ```bash
   docker-compose up -d
   ```

4. **Verify the service is running**:
   ```bash
   curl http://localhost:8080/health
   ```

### Manual Installation

1. **Install Python 3.11+**:
   ```bash
   python --version  # Should be 3.11+
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Install optional runtime dependencies**:
   ```bash
   # For JavaScript execution
   node --version  # Should be 16+
   
   # For Java callouts
   java -version   # Should be 11+
   
   # For Redis (KVM operations)
   # Install Redis server or use Docker:
   docker run -d -p 6379:6379 redis:7-alpine
   ```

4. **Configure environment**:
   ```bash
   cp .env.example .env
   # Edit .env file with your settings
   ```

5. **Start the service**:
   ```bash
   python start.py
   ```

## Configuration

### Environment Variables

Key configuration options in `.env`:

```bash
# Server
HOST=0.0.0.0
PORT=8080
DEBUG=false

# Logging
LOG_LEVEL=INFO

# Redis (for KVM operations)
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# Security
SECRET_KEY=your-secret-key-here

# Performance
MAX_CONCURRENT_REQUESTS=100
REQUEST_TIMEOUT=30

# Script Execution
JS_TIMEOUT=5000
JAVA_TIMEOUT=10

# Threat Protection
JSON_MAX_DEPTH=20
XML_MAX_DEPTH=10
```

### Policy Configuration

Each policy is configured through the request payload. Example:

```json
{
  "method": "POST",
  "path": "/api/users",
  "policy_name": "ValidateUser",
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "function validate() { return true; }",
    "timeout_ms": 3000
  },
  "headers": {
    "Content-Type": "application/json"
  },
  "variables": {
    "user_id": "12345"
  }
}
```

## API Reference

### Health Check
```http
GET /health
```

### List Available Policies
```http
GET /policies
```

### Execute Policy
```http
POST /policies/{policy-type}
Content-Type: application/json

{
  "method": "string",
  "path": "string",
  "policy_name": "string",
  "policy_type": "string",
  "policy_config": {},
  "headers": {},
  "variables": {}
}
```

### Policy-Specific Endpoints

- `POST /policies/javascript` - Execute JavaScript
- `POST /policies/service-callout` - Make service calls
- `POST /policies/kvm-operations` - KVM operations
- `POST /policies/raise-fault` - Raise custom faults
- `POST /policies/assert-condition` - Assert conditions
- `POST /policies/jws-verify` - Verify JWS tokens
- And more...

## Integration with Kong

### 1. Add HTTP Service Plugin

```bash
curl -X POST http://kong:8001/services/{service}/plugins \
  --data "name=http-log" \
  --data "config.http_endpoint=http://apigee-policy-service:8080/policies/javascript"
```

### 2. Use Request Transformer

```bash
curl -X POST http://kong:8001/services/{service}/plugins \
  --data "name=request-transformer" \
  --data "config.add.headers=X-Policy-Type:javascript"
```

### 3. Custom Kong Plugin

Create a custom Kong plugin that forwards requests to this microservice for policy execution.

## Development

### Running Tests

```bash
# Install test dependencies
pip install -r requirements.txt

# Run all tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Run specific test file
pytest tests/test_main.py

# Run integration tests only
pytest -m integration
```

### Code Quality

```bash
# Format code
black .

# Lint code
flake8 .

# Type checking
mypy .
```

### Adding New Policies

1. Create handler in `policies/new_policy_handler.py`
2. Extend `BasePolicyHandler`
3. Add to policy registry in `main.py`
4. Add endpoint in `main.py`
5. Write tests in `tests/`

Example:

```python
from .base_handler import BasePolicyHandler

class NewPolicyHandler(BasePolicyHandler):
    async def _initialize(self):
        pass
    
    async def _cleanup(self):
        pass
    
    async def _execute_policy(self, request):
        # Implementation here
        return self._create_success_response("Policy executed")
```

## Monitoring & Observability

### Health Checks

The service provides comprehensive health checks:

```bash
curl http://localhost:8080/health
```

Response includes:
- Service status
- Loaded policy handlers
- Available policies
- Version information

### Logging

Structured logging with configurable levels:

```bash
# Set log level
export LOG_LEVEL=DEBUG

# Log format
export LOG_FORMAT="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
```

### Metrics

Basic metrics are logged for each policy execution:
- Execution time
- Success/failure rates
- Error types

## Security Considerations

### Script Execution
- JavaScript/Python scripts run in isolated processes
- Configurable timeouts prevent infinite loops
- Memory limits prevent resource exhaustion

### Input Validation
- All inputs validated using Pydantic models
- SQL injection prevention in entity operations
- XSS prevention in data transformations

### Network Security
- HTTPS support for external calls
- Certificate validation
- Configurable timeouts

## Performance Tuning

### Concurrency
```bash
MAX_CONCURRENT_REQUESTS=100  # Adjust based on resources
```

### Caching
```bash
# Entity cache TTL
ENTITY_CACHE_TTL=300  # 5 minutes
```

### Timeouts
```bash
JS_TIMEOUT=5000      # JavaScript execution timeout (ms)
JAVA_TIMEOUT=10      # Java execution timeout (seconds)
REQUEST_TIMEOUT=30   # HTTP request timeout (seconds)
```

## Troubleshooting

### Common Issues

1. **Node.js not found**
   ```bash
   # Install Node.js 16+
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

2. **Redis connection failed**
   ```bash
   # Start Redis
   docker run -d -p 6379:6379 redis:7-alpine
   ```

3. **Java not available**
   ```bash
   # Install OpenJDK 11
   sudo apt-get install openjdk-11-jre-headless
   ```

### Debug Mode

Enable debug logging:

```bash
export DEBUG=true
export LOG_LEVEL=DEBUG
python start.py
```

### Performance Issues

1. Check resource usage: `docker stats`
2. Monitor logs: `docker-compose logs -f`
3. Adjust concurrency limits
4. Enable Redis for caching

## Production Deployment

### Docker Swarm

```yaml
version: '3.8'
services:
  apigee-policy-service:
    image: apigee-policy-service:latest
    deploy:
      replicas: 3
      resources:
        limits:
          memory: 512M
        reservations:
          memory: 256M
```

### Kubernetes

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apigee-policy-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: apigee-policy-service
  template:
    spec:
      containers:
      - name: apigee-policy-service
        image: apigee-policy-service:latest
        ports:
        - containerPort: 8080
        resources:
          limits:
            memory: "512Mi"
            cpu: "500m"
```

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review logs with DEBUG level
3. Create an issue with reproduction steps