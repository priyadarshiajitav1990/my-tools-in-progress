# API-Scoped Resource Organization

## 🎯 Overview

Resources are organized by **API name** for better isolation, multi-tenancy, and organization. Each API has its own directory containing all associated resource files.

## 📁 Directory Structure

### **Recommended Structure**

```
microservice/
├── resources/
│   ├── users-api/                    # API: users-api
│   │   ├── scripts/
│   │   │   ├── validate-user.js
│   │   │   ├── enrich-user.js
│   │   │   └── transform-user.py
│   │   ├── lib/
│   │   │   ├── user-validator-1.0.jar
│   │   │   └── user-utils-2.1.jar
│   │   ├── transforms/
│   │   │   └── user-to-xml.xsl
│   │   └── wsdl/
│   │       └── UserService.wsdl
│   │
│   ├── orders-api/                   # API: orders-api
│   │   ├── scripts/
│   │   │   ├── validate-order.js
│   │   │   └── calculate-total.js
│   │   ├── lib/
│   │   │   └── order-processor-1.0.jar
│   │   └── transforms/
│   │       └── order-transform.xsl
│   │
│   ├── payments-api/                 # API: payments-api
│   │   ├── scripts/
│   │   │   ├── validate-payment.js
│   │   │   └── process-refund.js
│   │   └── lib/
│   │       └── payment-gateway-2.0.jar
│   │
│   └── shared/                       # Shared resources (optional)
│       ├── scripts/
│       │   └── common-utils.js
│       └── lib/
│           └── commons-lang3-3.12.0.jar
```

## 🔄 Request Format with API Context

### **Enhanced Request Model**

```json
{
  "method": "POST",
  "path": "/api/users",
  "headers": {...},
  "body": {...},
  
  // API Context (NEW)
  "api_name": "users-api",           // API identifier
  "api_version": "v1",               // API version (optional)
  
  // Policy Configuration
  "policy_name": "ValidateUser",
  "policy_type": "javascript",
  "policy_config": {
    // Simple file reference (relative to API directory)
    "script_file": "scripts/validate-user.js",
    
    // OR with explicit API name
    "api_name": "users-api",
    "script_file": "scripts/validate-user.js",
    
    // OR full path (legacy support)
    "script_file": "users-api/scripts/validate-user.js",
    "script_base_path": "/app/resources"
  },
  
  "variables": {...},
  "flow_variables": {...}
}
```

## 🔧 Enhanced Resource Loader

### **API-Aware Resource Loading**

```python
class APIResourceLoader(ResourceLoader):
    """Resource loader with API-scoped organization."""
    
    def __init__(self, base_path: str = "/app/resources"):
        super().__init__(base_path)
        self.api_cache = {}  # Cache per API
    
    async def load_script(
        self,
        config: Dict[str, Any],
        api_name: Optional[str] = None,
        resource_type: str = "script"
    ) -> str:
        """
        Load script with API context.
        
        Args:
            config: Policy configuration
            api_name: API name for scoping
            resource_type: Type of resource
        
        Returns:
            Script content
        """
        # Option 1: Inline content (no API scoping needed)
        content_key = f"{resource_type}_content"
        if content_key in config:
            return config[content_key]
        
        # Option 2: File system with API scoping
        file_key = f"{resource_type}_file"
        if file_key in config:
            file_path = config[file_key]
            
            # Determine API name
            api = config.get('api_name') or api_name
            if not api:
                raise ValueError("API name required for file-based resources")
            
            # Build API-scoped path
            api_base_path = self.base_path / api
            
            return await self.load_from_file(
                file_path,
                base_path_override=str(api_base_path),
                max_size=self.MAX_SCRIPT_SIZE
            )
        
        # Option 3: URL (no API scoping needed)
        url_key = f"{resource_type}_url"
        if url_key in config:
            return await self.load_from_url(
                config[url_key],
                cache_ttl=config.get('cache_ttl', 3600),
                max_size=self.MAX_SCRIPT_SIZE
            )
        
        raise ValueError(f"No {resource_type} source specified")
    
    async def load_jar(
        self,
        config: Dict[str, Any],
        api_name: Optional[str] = None
    ) -> Path:
        """Load JAR file with API scoping."""
        
        # Option 1: File system with API scoping
        if 'jar_file' in config:
            jar_file = config['jar_file']
            
            # Determine API name
            api = config.get('api_name') or api_name
            if not api:
                raise ValueError("API name required for JAR files")
            
            # Build API-scoped path
            api_lib_path = self.base_path / api / 'lib'
            
            full_path = self._validate_file_path(api_lib_path, jar_file)
            
            if not full_path.exists():
                raise FileNotFoundError(f"JAR file not found: {full_path}")
            
            return full_path
        
        # Option 2: Base64 encoded (no API scoping needed)
        if 'jar_content_base64' in config:
            return await super().load_jar(config, api_name)
        
        # Option 3: URL (no API scoping needed)
        if 'jar_url' in config:
            return await super().load_jar(config, api_name)
        
        raise ValueError("No JAR source specified")
    
    def get_api_resource_path(self, api_name: str, resource_type: str = "") -> Path:
        """Get the resource path for a specific API."""
        api_path = self.base_path / api_name
        
        if resource_type:
            return api_path / resource_type
        
        return api_path
    
    async def list_api_resources(self, api_name: str) -> Dict[str, List[str]]:
        """List all resources for an API."""
        api_path = self.base_path / api_name
        
        if not api_path.exists():
            return {}
        
        resources = {
            'scripts': [],
            'lib': [],
            'transforms': [],
            'wsdl': []
        }
        
        for resource_type in resources.keys():
            type_path = api_path / resource_type
            if type_path.exists():
                resources[resource_type] = [
                    f.name for f in type_path.iterdir() if f.is_file()
                ]
        
        return resources
```

## 📋 Complete Examples

### **Example 1: JavaScript with API Scoping**

**Directory Structure:**
```
resources/
└── users-api/
    └── scripts/
        └── validate-user.js
```

**Request:**
```json
{
  "method": "POST",
  "path": "/api/users",
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
  
  "api_name": "users-api",
  
  "policy_name": "ValidateUser",
  "policy_type": "javascript",
  "policy_config": {
    "script_file": "scripts/validate-user.js"
    // API name inherited from request.api_name
  }
}
```

**Alternative (explicit API in config):**
```json
{
  "policy_config": {
    "api_name": "users-api",
    "script_file": "scripts/validate-user.js"
  }
}
```

### **Example 2: Java Callout with API Scoping**

**Directory Structure:**
```
resources/
└── orders-api/
    └── lib/
        ├── order-validator-1.0.jar
        └── commons-lang3-3.12.0.jar
```

**Request:**
```json
{
  "method": "POST",
  "path": "/api/orders",
  "body": "{\"orderId\": \"12345\", \"amount\": 99.99}",
  
  "api_name": "orders-api",
  
  "policy_name": "ValidateOrder",
  "policy_type": "java_callout",
  "policy_config": {
    "jar_file": "order-validator-1.0.jar",
    "class_name": "com.example.orders.OrderValidator",
    "method_name": "validate"
    // Classpath automatically set to: /app/resources/orders-api/lib
  }
}
```

### **Example 3: XSLT with API Scoping**

**Directory Structure:**
```
resources/
└── payments-api/
    └── transforms/
        └── payment-transform.xsl
```

**Request:**
```json
{
  "method": "POST",
  "path": "/api/payments",
  "body": "<?xml version=\"1.0\"?><payment><amount>100</amount></payment>",
  
  "api_name": "payments-api",
  
  "policy_name": "TransformPayment",
  "policy_type": "xsl_transform",
  "policy_config": {
    "xslt_file": "transforms/payment-transform.xsl",
    "source": "request_body",
    "destination": "response_body"
  }
}
```

### **Example 4: Multiple APIs in Same Deployment**

**Directory Structure:**
```
resources/
├── users-api/
│   └── scripts/
│       └── validate-user.js
├── orders-api/
│   └── scripts/
│       └── validate-order.js
└── payments-api/
    └── scripts/
        └── validate-payment.js
```

**Request 1 (Users API):**
```json
{
  "api_name": "users-api",
  "policy_config": {
    "script_file": "scripts/validate-user.js"
  }
}
```

**Request 2 (Orders API):**
```json
{
  "api_name": "orders-api",
  "policy_config": {
    "script_file": "scripts/validate-order.js"
  }
}
```

**Request 3 (Payments API):**
```json
{
  "api_name": "payments-api",
  "policy_config": {
    "script_file": "scripts/validate-payment.js"
  }
}
```

## 🔗 Kong Integration with API Context

### **Kong Plugin Configuration**

```lua
-- Kong plugin extracts API name from route/service
function ApigeePolicy:access(conf)
  -- Get API name from Kong service or route
  local api_name = kong.router.get_service().name or conf.api_name
  
  -- Build policy request with API context
  local policy_request = {
    method = kong.request.get_method(),
    path = kong.request.get_path(),
    
    -- API Context
    api_name = api_name,
    api_version = conf.api_version,
    
    -- Policy Configuration
    policy_name = conf.policy_name,
    policy_type = conf.policy_type,
    policy_config = conf.policy_config,
    
    -- Variables
    variables = kong.ctx.shared.apigee_variables or {},
    flow_variables = build_flow_variables()
  }
  
  -- Call microservice
  local response = call_policy_service(policy_request)
  
  -- Process response
  apply_policy_response(response)
end
```

### **Kong Service/Route Configuration**

```bash
# Create service with API name
curl -X POST http://kong:8001/services \
  --data "name=users-api" \
  --data "url=http://backend:8080"

# Add route
curl -X POST http://kong:8001/services/users-api/routes \
  --data "paths[]=/api/users"

# Add Apigee policy plugin
curl -X POST http://kong:8001/services/users-api/plugins \
  --header "Content-Type: application/json" \
  --data '{
    "name": "apigee-policy",
    "config": {
      "api_name": "users-api",
      "policies": [
        {
          "type": "javascript",
          "config": {
            "name": "ValidateUser",
            "script_file": "scripts/validate-user.js"
          }
        }
      ]
    }
  }'
```

## 🚀 Migration from Apigee

### **Step 1: Extract Apigee Proxy**

```bash
# Extract Apigee proxy
unzip users-api_rev1.zip

# Apigee structure
users-api/
├── apiproxy/
│   ├── policies/
│   │   ├── JavaScript-ValidateUser.xml
│   │   └── JavaCallout-ProcessUser.xml
│   └── resources/
│       ├── jsc/
│       │   ├── validate-user.js
│       │   └── enrich-user.js
│       └── java/
│           └── user-processor-1.0.jar
```

### **Step 2: Organize by API Name**

```bash
# Create API-specific directory
mkdir -p microservice/resources/users-api/{scripts,lib,transforms,wsdl}

# Copy resources with API context
cp users-api/apiproxy/resources/jsc/*.js \
   microservice/resources/users-api/scripts/

cp users-api/apiproxy/resources/java/*.jar \
   microservice/resources/users-api/lib/
```

### **Step 3: Update Policy References**

```python
# Migration script
def migrate_apigee_proxy(proxy_name: str, proxy_path: str):
    """Migrate Apigee proxy to API-scoped structure."""
    
    # Create API directory
    api_dir = Path(f"microservice/resources/{proxy_name}")
    api_dir.mkdir(parents=True, exist_ok=True)
    
    # Create subdirectories
    (api_dir / "scripts").mkdir(exist_ok=True)
    (api_dir / "lib").mkdir(exist_ok=True)
    (api_dir / "transforms").mkdir(exist_ok=True)
    (api_dir / "wsdl").mkdir(exist_ok=True)
    
    # Copy JavaScript files
    jsc_dir = Path(proxy_path) / "apiproxy/resources/jsc"
    if jsc_dir.exists():
        for js_file in jsc_dir.glob("*.js"):
            shutil.copy(js_file, api_dir / "scripts" / js_file.name)
    
    # Copy JAR files
    java_dir = Path(proxy_path) / "apiproxy/resources/java"
    if java_dir.exists():
        for jar_file in java_dir.glob("*.jar"):
            shutil.copy(jar_file, api_dir / "lib" / jar_file.name)
    
    # Copy XSLT files
    xsl_dir = Path(proxy_path) / "apiproxy/resources/xsl"
    if xsl_dir.exists():
        for xsl_file in xsl_dir.glob("*.xsl"):
            shutil.copy(xsl_file, api_dir / "transforms" / xsl_file.name)
    
    print(f"✅ Migrated {proxy_name} to API-scoped structure")

# Usage
migrate_apigee_proxy("users-api", "extracted/users-api")
migrate_apigee_proxy("orders-api", "extracted/orders-api")
migrate_apigee_proxy("payments-api", "extracted/payments-api")
```

## 📦 Deployment with API-Scoped Resources

### **Docker Compose**

```yaml
version: '3.8'

services:
  apigee-policy-service:
    build: .
    ports:
      - "8080:8080"
    volumes:
      # Mount all API resources
      - ./resources:/app/resources:ro
    environment:
      - LOG_LEVEL=INFO
      - RESOURCE_BASE_PATH=/app/resources
```

**Directory Structure:**
```
project/
├── docker-compose.yml
├── microservice/
│   ├── Dockerfile
│   └── ...
└── resources/
    ├── users-api/
    │   ├── scripts/
    │   └── lib/
    ├── orders-api/
    │   ├── scripts/
    │   └── lib/
    └── payments-api/
        ├── scripts/
        └── lib/
```

### **Kubernetes with Multiple ConfigMaps**

```yaml
# ConfigMap per API
apiVersion: v1
kind: ConfigMap
metadata:
  name: users-api-scripts
data:
  validate-user.js: |
    function validateUser() {
      // User validation logic
    }
  enrich-user.js: |
    function enrichUser() {
      // User enrichment logic
    }

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: orders-api-scripts
data:
  validate-order.js: |
    function validateOrder() {
      // Order validation logic
    }

---
# Deployment with multiple mounts
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apigee-policy-service
spec:
  template:
    spec:
      containers:
      - name: apigee-policy-service
        image: apigee-policy-service:latest
        volumeMounts:
        # Mount each API's resources
        - name: users-api-scripts
          mountPath: /app/resources/users-api/scripts
        - name: orders-api-scripts
          mountPath: /app/resources/orders-api/scripts
        - name: java-libs
          mountPath: /app/resources
          subPath: lib
      volumes:
      - name: users-api-scripts
        configMap:
          name: users-api-scripts
      - name: orders-api-scripts
        configMap:
          name: orders-api-scripts
      - name: java-libs
        persistentVolumeClaim:
          claimName: java-libs-pvc
```

## 🎯 Benefits of API-Scoped Organization

### ✅ **Isolation**
- Each API has its own resource namespace
- No naming conflicts between APIs
- Clear ownership and boundaries

### ✅ **Multi-Tenancy**
- Support multiple APIs in single deployment
- Per-API resource limits
- Independent versioning

### ✅ **Organization**
- Clear directory structure
- Easy to find resources
- Logical grouping

### ✅ **Security**
- API-level access control
- Resource isolation
- Audit trail per API

### ✅ **Scalability**
- Easy to add new APIs
- Independent deployment
- Selective resource loading

### ✅ **Maintenance**
- Easy to update API resources
- Clear migration path
- Version control friendly

## 📊 Resource Discovery API

### **List APIs**

```bash
GET /apis

Response:
{
  "apis": [
    {
      "name": "users-api",
      "resources": {
        "scripts": ["validate-user.js", "enrich-user.js"],
        "lib": ["user-validator-1.0.jar"],
        "transforms": [],
        "wsdl": []
      }
    },
    {
      "name": "orders-api",
      "resources": {
        "scripts": ["validate-order.js"],
        "lib": ["order-processor-1.0.jar"],
        "transforms": ["order-transform.xsl"],
        "wsdl": []
      }
    }
  ]
}
```

### **List API Resources**

```bash
GET /apis/users-api/resources

Response:
{
  "api_name": "users-api",
  "resources": {
    "scripts": [
      "validate-user.js",
      "enrich-user.js",
      "transform-user.py"
    ],
    "lib": [
      "user-validator-1.0.jar",
      "user-utils-2.1.jar"
    ],
    "transforms": [
      "user-to-xml.xsl"
    ],
    "wsdl": []
  }
}
```

## 🚀 Summary

API-scoped resource organization provides:

1. **Clear Structure**: `/resources/{api-name}/{resource-type}/{file}`
2. **Automatic Scoping**: API name from request or Kong service
3. **Multi-Tenancy**: Multiple APIs in single deployment
4. **Easy Migration**: Direct mapping from Apigee structure
5. **Better Security**: API-level isolation
6. **Scalability**: Easy to add/remove APIs

This is the **recommended approach** for production deployments! 🎯