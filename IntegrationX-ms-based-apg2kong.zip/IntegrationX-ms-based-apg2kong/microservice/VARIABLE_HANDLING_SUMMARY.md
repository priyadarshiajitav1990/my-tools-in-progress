# Apigee Variables Handling - Complete Summary

## 🎯 Overview

The microservice provides **100% Apigee variable compatibility** through a sophisticated variable context system that maintains state across policy executions and provides seamless integration with Kong Gateway.

## 📊 Variable Architecture

### **Two-Tier Variable System**

```
┌─────────────────────────────────────────────────────────┐
│                  Variable Context                        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Flow Variables (flow_variables)                  │  │
│  │  - Apigee built-in variables                      │  │
│  │  - request.*, response.*, system.*, client.*      │  │
│  │  - Read-only or system-managed                    │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Custom Variables (variables)                     │  │
│  │  - User-defined variables                         │  │
│  │  - Set by policies                                │  │
│  │  - Read-write access                              │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

## 🔄 Variable Flow

### **Complete Request Lifecycle**

```
1. Kong Receives Request
   ↓
2. Kong Plugin Collects Variables
   - request.verb = "POST"
   - request.path = "/api/users"
   - request.header.* = headers
   - client.ip = "192.168.1.100"
   ↓
3. Policy 1: JavaScript (Authentication)
   Input:  flow_variables + variables
   Action: setVariable("jwt_token", token)
   Output: variables.jwt_token = "eyJhbGc..."
   ↓
4. Policy 2: JWS Verify
   Input:  flow_variables + variables (with jwt_token)
   Action: Verify token, extract payload
   Output: variables.user_id = "123"
           variables.user_role = "admin"
   ↓
5. Policy 3: Condition Check
   Input:  flow_variables + variables (with user_id, user_role)
   Action: Assert user_role == "admin"
   Output: variables.access_granted = true
   ↓
6. Kong Processes Response
   - Apply response headers from variables
   - Continue to upstream or terminate
```

## 📋 Variable Categories

### **1. Request Variables**

```javascript
// Automatically populated by Kong plugin
flow_variables = {
  "request.verb": "POST",
  "request.uri": "/api/users?limit=10",
  "request.path": "/api/users",
  "request.querystring": "limit=10",
  "request.content": "{\"name\": \"John\"}",
  "request.header.content-type": "application/json",
  "request.header.authorization": "Bearer token123",
  "request.queryparam.limit": "10"
}
```

### **2. Client Variables**

```javascript
flow_variables = {
  "client.ip": "192.168.1.100",
  "client.host": "api.example.com",
  "client.port": "443",
  "client.scheme": "https"
}
```

### **3. System Variables**

```javascript
flow_variables = {
  "system.time": 1640995200000,
  "system.time.year": "2024",
  "system.time.month": "01",
  "system.time.day": "08",
  "system.uuid": "550e8400-e29b-41d4-a716-446655440000",
  "messageid": "req-123-456"
}
```

### **4. Response Variables**

```javascript
flow_variables = {
  "response.status.code": 200,
  "response.reason.phrase": "OK",
  "response.header.content-type": "application/json",
  "response.content": "{\"result\": \"success\"}"
}
```

### **5. Custom Variables**

```javascript
// Set by policies
variables = {
  "user_id": "123",
  "user_role": "admin",
  "jwt_token": "eyJhbGc...",
  "validation_result": "passed",
  "user_profile": {
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

## 🔧 Variable Operations

### **Reading Variables**

```javascript
// In JavaScript policies
var userId = getVariable("user_id");              // Custom variable
var method = getVariable("request.verb");         // Flow variable
var authHeader = getVariable("request.header.authorization");

// In Condition policies
{
  "condition": "user_role == 'admin' and user_status == 'active'"
}

// In Service Callout (template substitution)
{
  "target_url": "https://api.example.com/users/{user_id}"
}
```

### **Writing Variables**

```javascript
// In JavaScript policies
setVariable("user_id", "123");
setVariable("user_validated", true);
setVariable("user_profile", {
  name: "John Doe",
  email: "john@example.com"
});

// Set response headers
setVariable("response.header.x-user-id", userId);
setVariable("response.header.x-request-time", Date.now());
```

### **Variable Substitution**

```javascript
// Template strings support variable substitution
{
  "message_template": "User {user_id} from {client.ip} accessed {request.path}",
  "target_url": "https://api.example.com/users/{user_id}/profile",
  "cache_key": "user_{user_id}_session_{session_id}"
}
```

## 🔗 Kong Integration

### **Variable Collection in Kong Plugin**

```lua
-- Kong plugin collects and maps variables
local function build_flow_variables()
  local flow_vars = {}
  
  -- Request variables
  flow_vars["request.verb"] = kong.request.get_method()
  flow_vars["request.path"] = kong.request.get_path()
  flow_vars["request.uri"] = kong.request.get_path_with_query()
  
  -- Headers
  local headers = kong.request.get_headers()
  for name, value in pairs(headers) do
    flow_vars["request.header." .. name:lower()] = value
  end
  
  -- Query parameters
  local query = kong.request.get_query()
  for name, value in pairs(query) do
    flow_vars["request.queryparam." .. name] = value
  end
  
  -- Client info
  flow_vars["client.ip"] = kong.client.get_ip()
  flow_vars["client.host"] = kong.request.get_host()
  
  -- System info
  flow_vars["system.time"] = ngx.now() * 1000
  flow_vars["messageid"] = kong.request.get_header("X-Request-ID")
  
  return flow_vars
end
```

### **Variable Persistence Across Policies**

```lua
-- Initialize variable context
kong.ctx.shared.apigee_variables = {}
kong.ctx.shared.flow_variables = build_flow_variables()

-- Execute Policy 1
local response1 = call_policy_service("javascript", {
  variables = kong.ctx.shared.apigee_variables,
  flow_variables = kong.ctx.shared.flow_variables
})

-- Merge variables from response
for k, v in pairs(response1.variables) do
  kong.ctx.shared.apigee_variables[k] = v
end

-- Execute Policy 2 with updated variables
local response2 = call_policy_service("jws_verify", {
  variables = kong.ctx.shared.apigee_variables,  -- Contains variables from Policy 1
  flow_variables = kong.ctx.shared.flow_variables
})
```

## 💡 Practical Examples

### **Example 1: Multi-Step Authentication**

```json
// Step 1: Extract token
{
  "policy_type": "javascript",
  "flow_variables": {
    "request.header.authorization": "Bearer eyJhbGc..."
  },
  "policy_config": {
    "script_content": "var auth = getVariable('request.header.authorization');\nvar token = auth.substring(7);\nsetVariable('jwt_token', token);"
  }
}

// Response 1
{
  "success": true,
  "variables": {
    "jwt_token": "eyJhbGc..."
  }
}

// Step 2: Verify token (uses jwt_token from Step 1)
{
  "policy_type": "jws_verify",
  "variables": {
    "jwt_token": "eyJhbGc..."  // From previous policy
  },
  "policy_config": {
    "token_source": "variable",
    "token_variable": "jwt_token"
  }
}

// Response 2
{
  "success": true,
  "variables": {
    "jws_payload": {
      "sub": "user123",
      "role": "admin"
    },
    "user_id": "user123",
    "user_role": "admin"
  }
}

// Step 3: Check authorization (uses user_role from Step 2)
{
  "policy_type": "assert_condition",
  "variables": {
    "user_id": "user123",
    "user_role": "admin"  // From previous policy
  },
  "policy_config": {
    "condition": "user_role == 'admin'"
  }
}
```

### **Example 2: User Profile Enrichment**

```json
// Step 1: Get user ID from JWT
{
  "policy_type": "jws_decode",
  "flow_variables": {
    "request.header.authorization": "Bearer eyJhbGc..."
  }
}

// Response: variables.user_id = "123"

// Step 2: Fetch user profile (uses user_id)
{
  "policy_type": "service_callout",
  "variables": {
    "user_id": "123"
  },
  "policy_config": {
    "target_url": "https://user-service.example.com/users/{user_id}",
    "response_variable": "user_profile"
  }
}

// Response: variables.user_profile = {...}

// Step 3: Add user info to response headers
{
  "policy_type": "javascript",
  "variables": {
    "user_profile": {
      "name": "John Doe",
      "email": "john@example.com"
    }
  },
  "policy_config": {
    "script_content": "var profile = getVariable('user_profile');\nsetVariable('response.header.x-user-name', profile.name);\nsetVariable('response.header.x-user-email', profile.email);"
  }
}
```

### **Example 3: Rate Limiting with Variables**

```json
// Step 1: Extract user identifier
{
  "policy_type": "javascript",
  "flow_variables": {
    "request.header.x-api-key": "key-abc-123"
  },
  "policy_config": {
    "script_content": "var apiKey = getVariable('request.header.x-api-key');\nsetVariable('rate_limit_key', 'rate_' + apiKey);"
  }
}

// Response: variables.rate_limit_key = "rate_key-abc-123"

// Step 2: Check rate limit
{
  "policy_type": "kvm_operations",
  "variables": {
    "rate_limit_key": "rate_key-abc-123"
  },
  "policy_config": {
    "operation": "get",
    "key": "{rate_limit_key}",
    "map_name": "rate_limits"
  }
}

// Response: variables.kvm_value = 45 (current count)

// Step 3: Validate limit
{
  "policy_type": "assert_condition",
  "variables": {
    "kvm_value": 45
  },
  "policy_config": {
    "condition": "kvm_value < 100",
    "failure_message": "Rate limit exceeded",
    "failure_status_code": 429
  }
}
```

## 🎯 Key Features

### ✅ **Complete Compatibility**
- All Apigee variable types supported
- Automatic variable mapping from Kong
- Variable persistence across policies

### ✅ **Flexible Access**
- Read flow variables (request.*, response.*, etc.)
- Write custom variables
- Template substitution support

### ✅ **Type Safety**
- String, number, boolean, object, array support
- Automatic type conversion
- Null/undefined handling

### ✅ **Performance**
- Variables cached in Kong context
- Efficient serialization/deserialization
- Minimal overhead

## 📊 Variable Debugging

### **Enable Variable Logging**

```json
{
  "policy_type": "message_logging",
  "policy_config": {
    "operation": "log",
    "log_level": "DEBUG",
    "message_template": "Variables: flow={flow_variables}, custom={variables}"
  }
}
```

### **Inspect Variable State**

```bash
# Add debug endpoint to microservice
curl -X POST http://localhost:8080/debug/variables \
  -H "Content-Type: application/json" \
  -d '{
    "flow_variables": {...},
    "variables": {...}
  }'
```

## 🚀 Summary

The microservice handles Apigee variables through:

1. **Two-tier system**: Flow variables (built-in) + Custom variables (user-defined)
2. **Automatic mapping**: Kong variables → Apigee format
3. **Variable persistence**: State maintained across policy executions
4. **Template substitution**: Variables in strings, URLs, messages
5. **Type support**: All JavaScript types (string, number, boolean, object, array)
6. **Kong integration**: Seamless variable collection and application

This provides **complete Apigee variable compatibility** for seamless policy migration! 🎯