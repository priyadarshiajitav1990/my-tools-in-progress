# Complete Architecture: Apigee Variables & Policy Execution

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           Client Application                             │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ HTTP Request
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                            Kong Gateway                                  │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │              Apigee Policy Kong Plugin                          │   │
│  │                                                                  │   │
│  │  1. Collect Variables                                           │   │
│  │     ├─ request.verb = "POST"                                    │   │
│  │     ├─ request.path = "/api/users"                              │   │
│  │     ├─ request.header.* = headers                               │   │
│  │     ├─ client.ip = "192.168.1.100"                              │   │
│  │     └─ system.time = timestamp                                  │   │
│  │                                                                  │   │
│  │  2. Initialize Variable Context                                 │   │
│  │     ├─ kong.ctx.shared.flow_variables = {...}                   │   │
│  │     └─ kong.ctx.shared.apigee_variables = {}                    │   │
│  │                                                                  │   │
│  │  3. Execute Policies Sequentially                               │   │
│  │     ├─ Policy 1 → Update variables                              │   │
│  │     ├─ Policy 2 → Use updated variables                         │   │
│  │     └─ Policy 3 → Final processing                              │   │
│  │                                                                  │   │
│  │  4. Apply Response                                              │   │
│  │     ├─ Add headers from variables                               │   │
│  │     ├─ Terminate or continue                                    │   │
│  │     └─ Return to Kong                                           │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                 │                                        │
│                                 │ HTTP POST /policies/{type}             │
│                                 ▼                                        │
└─────────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   Apigee Policy Microservice                             │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                    FastAPI Application                          │   │
│  │                                                                  │   │
│  │  ┌──────────────────────────────────────────────────────────┐ │   │
│  │  │              Request Validation                           │ │   │
│  │  │  - Validate PolicyRequest model                           │ │   │
│  │  │  - Check required fields                                  │ │   │
│  │  │  - Validate policy_type                                   │ │   │
│  │  └──────────────────────────────────────────────────────────┘ │   │
│  │                          ▼                                      │   │
│  │  ┌──────────────────────────────────────────────────────────┐ │   │
│  │  │              Handler Selection                            │ │   │
│  │  │  policy_handlers = {                                      │ │   │
│  │  │    'javascript': JavaScriptPolicyHandler(),               │ │   │
│  │  │    'jws_verify': JWSPolicyHandler(),                      │ │   │
│  │  │    'kvm_operations': KVMPolicyHandler(),                  │ │   │
│  │  │    ...                                                     │ │   │
│  │  │  }                                                         │ │   │
│  │  └──────────────────────────────────────────────────────────┘ │   │
│  │                          ▼                                      │   │
│  │  ┌──────────────────────────────────────────────────────────┐ │   │
│  │  │              Policy Execution                             │ │   │
│  │  │                                                            │ │   │
│  │  │  handler = policy_handlers[policy_type]                   │ │   │
│  │  │  response = await handler.execute(request)                │ │   │
│  │  │                                                            │ │   │
│  │  │  ┌──────────────────────────────────────────────────┐   │ │   │
│  │  │  │         Variable Context                          │   │ │   │
│  │  │  │                                                    │   │ │   │
│  │  │  │  Input Variables:                                 │   │ │   │
│  │  │  │  ├─ flow_variables (request.*, client.*, etc.)    │   │ │   │
│  │  │  │  └─ variables (custom variables)                  │   │ │   │
│  │  │  │                                                    │   │ │   │
│  │  │  │  Variable Operations:                             │   │ │   │
│  │  │  │  ├─ getVariable(name) → read                      │   │ │   │
│  │  │  │  ├─ setVariable(name, value) → write             │   │ │   │
│  │  │  │  └─ Template substitution                         │   │ │   │
│  │  │  │                                                    │   │ │   │
│  │  │  │  Output Variables:                                │   │ │   │
│  │  │  │  └─ Updated variables in response                 │   │ │   │
│  │  │  └──────────────────────────────────────────────────┘   │ │   │
│  │  └──────────────────────────────────────────────────────────┘ │   │
│  │                          ▼                                      │   │
│  │  ┌──────────────────────────────────────────────────────────┐ │   │
│  │  │              Response Generation                          │ │   │
│  │  │  {                                                         │ │   │
│  │  │    "success": true,                                       │ │   │
│  │  │    "variables": {...},  // Updated variables             │ │   │
│  │  │    "headers": {...},    // Response headers              │ │   │
│  │  │    "continue_processing": true,                          │ │   │
│  │  │    "execution_time_ms": 15.5                             │ │   │
│  │  │  }                                                         │ │   │
│  │  └──────────────────────────────────────────────────────────┘ │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                    Policy Handlers                              │   │
│  │                                                                  │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │   │
│  │  │  JavaScript  │  │  JWS Verify  │  │     KVM      │         │   │
│  │  │   Handler    │  │   Handler    │  │   Handler    │         │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘         │   │
│  │                                                                  │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │   │
│  │  │   Service    │  │  Condition   │  │    Entity    │         │   │
│  │  │   Callout    │  │   Handler    │  │   Handler    │         │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘         │   │
│  │                                                                  │   │
│  │  ... and 14 more handlers                                       │   │
│  └────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────────┐   │
│  │                    External Services                            │   │
│  │                                                                  │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │   │
│  │  │    Redis     │  │   Node.js    │  │     JVM      │         │   │
│  │  │  (KVM Store) │  │ (JS Runtime) │  │ (Java Exec)  │         │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘         │   │
│  └────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

## 🔄 Variable Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Variable Lifecycle                                │
└─────────────────────────────────────────────────────────────────────────┘

Step 1: Kong Collects Variables
┌────────────────────────────────────────┐
│  Kong Request Context                  │
│  ├─ HTTP Method: POST                  │
│  ├─ Path: /api/users                   │
│  ├─ Headers: {...}                     │
│  ├─ Query: {...}                       │
│  └─ Body: {...}                        │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Flow Variables (Apigee Format)       │
│  ├─ request.verb = "POST"              │
│  ├─ request.path = "/api/users"        │
│  ├─ request.header.* = {...}           │
│  ├─ client.ip = "192.168.1.100"        │
│  └─ system.time = 1640995200000        │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Custom Variables (Empty Initially)   │
│  variables = {}                        │
└────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

Step 2: Policy 1 Execution (JavaScript - Extract Token)
┌────────────────────────────────────────┐
│  Input to Microservice                 │
│  ├─ flow_variables: {...}              │
│  └─ variables: {}                      │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  JavaScript Execution                  │
│  var auth = getVariable(               │
│    'request.header.authorization'      │
│  );                                    │
│  var token = auth.substring(7);        │
│  setVariable('jwt_token', token);      │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Output from Microservice              │
│  variables: {                          │
│    jwt_token: "eyJhbGc..."             │
│  }                                     │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Kong Updates Context                  │
│  kong.ctx.shared.apigee_variables = { │
│    jwt_token: "eyJhbGc..."             │
│  }                                     │
└────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

Step 3: Policy 2 Execution (JWS Verify)
┌────────────────────────────────────────┐
│  Input to Microservice                 │
│  ├─ flow_variables: {...}              │
│  └─ variables: {                       │
│       jwt_token: "eyJhbGc..."          │
│     }                                  │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  JWS Verification                      │
│  - Extract token from variables        │
│  - Verify signature                    │
│  - Decode payload                      │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Output from Microservice              │
│  variables: {                          │
│    jwt_token: "eyJhbGc...",            │
│    jws_payload: {                      │
│      sub: "user123",                   │
│      role: "admin"                     │
│    },                                  │
│    user_id: "user123",                 │
│    user_role: "admin"                  │
│  }                                     │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Kong Updates Context                  │
│  kong.ctx.shared.apigee_variables = { │
│    jwt_token: "eyJhbGc...",            │
│    jws_payload: {...},                 │
│    user_id: "user123",                 │
│    user_role: "admin"                  │
│  }                                     │
└────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════

Step 4: Policy 3 Execution (Condition Check)
┌────────────────────────────────────────┐
│  Input to Microservice                 │
│  ├─ flow_variables: {...}              │
│  └─ variables: {                       │
│       user_id: "user123",              │
│       user_role: "admin"               │
│     }                                  │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Condition Evaluation                  │
│  condition: "user_role == 'admin'"     │
│  - Resolve user_role from variables    │
│  - Evaluate: "admin" == "admin"        │
│  - Result: true                        │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Output from Microservice              │
│  {                                     │
│    success: true,                      │
│    variables: {                        │
│      condition_result: true,           │
│      access_granted: true              │
│    },                                  │
│    continue_processing: true           │
│  }                                     │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Kong Final Context                    │
│  kong.ctx.shared.apigee_variables = { │
│    jwt_token: "eyJhbGc...",            │
│    user_id: "user123",                 │
│    user_role: "admin",                 │
│    condition_result: true,             │
│    access_granted: true                │
│  }                                     │
└────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│  Kong Continues to Upstream            │
│  - All variables preserved             │
│  - Can be used in response phase       │
└────────────────────────────────────────┘
```

## 📊 Variable Access Patterns

### **Pattern 1: Sequential Variable Building**

```
Policy 1: Extract Data
  Input:  flow_variables
  Output: variables.user_id = "123"

Policy 2: Enrich Data
  Input:  flow_variables + variables.user_id
  Output: variables.user_profile = {...}

Policy 3: Validate Data
  Input:  flow_variables + variables.user_profile
  Output: variables.validation_result = "passed"
```

### **Pattern 2: Conditional Execution**

```
Policy 1: Check User Type
  Input:  flow_variables
  Output: variables.user_type = "premium"

Policy 2: Apply Premium Logic (only if user_type == "premium")
  Input:  flow_variables + variables.user_type
  Output: variables.premium_features_enabled = true
```

### **Pattern 3: Variable Transformation**

```
Policy 1: Get Raw Data
  Input:  flow_variables
  Output: variables.raw_data = {...}

Policy 2: Transform Data
  Input:  variables.raw_data
  Output: variables.transformed_data = {...}

Policy 3: Store Result
  Input:  variables.transformed_data
  Output: variables.storage_key = "..."
```

## 🎯 Key Takeaways

### ✅ **Variable Handling Features**

1. **Two-Tier System**
   - Flow variables (Apigee built-in)
   - Custom variables (user-defined)

2. **Automatic Mapping**
   - Kong → Apigee format
   - All request/response data
   - System information

3. **Variable Persistence**
   - State maintained across policies
   - Variables accumulate through execution
   - Available in response phase

4. **Template Substitution**
   - Variables in URLs
   - Variables in messages
   - Variables in conditions

5. **Type Support**
   - String, number, boolean
   - Objects and arrays
   - Null/undefined handling

### ✅ **Integration Benefits**

1. **Seamless Migration**
   - 100% Apigee compatibility
   - No code changes needed
   - Drop-in replacement

2. **Performance**
   - Variables cached in Kong
   - Efficient serialization
   - Minimal overhead

3. **Debugging**
   - Variable logging
   - State inspection
   - Debug endpoints

4. **Flexibility**
   - Custom variable names
   - Complex data structures
   - Dynamic resolution

This architecture provides **complete Apigee variable compatibility** with seamless Kong integration! 🚀