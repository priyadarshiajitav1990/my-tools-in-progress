# Request Body Field - Complete Guide

## 🔍 Understanding the `body` Field

The `body` field in the microservice request contains **the original HTTP request body from the client**, NOT the policy configuration.

### **Two Different "Bodies"**

1. **Microservice Request Body** (JSON) - The entire payload sent to the microservice
2. **Original Client Request Body** (String) - The `body` field within that payload

## 📋 Complete Request Structure Breakdown

```json
{
  // ===== HTTP Context from Original Request =====
  "method": "POST",                    // Client's HTTP method
  "path": "/api/users",               // Client's request path
  "headers": {                        // Client's request headers
    "Content-Type": "application/json",
    "Authorization": "Bearer token123"
  },
  "query_params": {                   // Client's query parameters
    "limit": "10",
    "offset": "0"
  },
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",  // ⭐ CLIENT'S REQUEST BODY
  
  // ===== Policy Configuration =====
  "policy_name": "ValidateUser",       // Name of the policy to execute
  "policy_type": "javascript",         // Type of policy handler
  "policy_config": {                   // ⭐ POLICY-SPECIFIC CONFIGURATION
    "script_content": "function validate() {...}",
    "timeout_ms": 5000
  },
  
  // ===== Execution Context =====
  "variables": {                       // Context variables
    "user_id": "123",
    "api_version": "v1"
  },
  "flow_variables": {},                // Flow-specific variables
  
  // ===== Metadata =====
  "client_ip": "192.168.1.100",       // Client IP address
  "user_agent": "Mozilla/5.0...",     // Client user agent
  "request_id": "req-abc-123"         // Unique request ID
}
```

## 🎯 Real-World Examples

### **Example 1: User Registration**

**Original Client Request to Kong:**
```http
POST /api/users HTTP/1.1
Host: api.example.com
Content-Type: application/json
Authorization: Bearer token123

{
  "name": "John Doe",
  "email": "john@example.com",
  "age": 30
}
```

**Kong Calls Microservice:**
```json
{
  "method": "POST",
  "path": "/api/users",
  "headers": {
    "Content-Type": "application/json",
    "Authorization": "Bearer token123",
    "Host": "api.example.com"
  },
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\", \"age\": 30}",
  "policy_name": "ValidateUserRegistration",
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "var user = JSON.parse(request.body); if (!user.email || !user.name) { throw new Error('Missing required fields'); }"
  }
}
```

### **Example 2: XML to JSON Transformation**

**Original Client Request to Kong:**
```http
POST /api/convert HTTP/1.1
Host: api.example.com
Content-Type: application/xml

<?xml version="1.0"?>
<user>
  <id>123</id>
  <name>John Doe</name>
  <email>john@example.com</email>
</user>
```

**Kong Calls Microservice:**
```json
{
  "method": "POST",
  "path": "/api/convert",
  "headers": {
    "Content-Type": "application/xml",
    "Host": "api.example.com"
  },
  "body": "<?xml version=\"1.0\"?>\n<user>\n  <id>123</id>\n  <name>John Doe</name>\n  <email>john@example.com</email>\n</user>",
  "policy_name": "ConvertXMLToJSON",
  "policy_type": "xml_to_json",
  "policy_config": {
    "source": "request_body",
    "destination": "response_body",
    "pretty_print": true
  }
}
```

### **Example 3: GET Request (No Body)**

**Original Client Request to Kong:**
```http
GET /api/users/123?include=profile HTTP/1.1
Host: api.example.com
Authorization: Bearer token123
```

**Kong Calls Microservice:**
```json
{
  "method": "GET",
  "path": "/api/users/123",
  "headers": {
    "Authorization": "Bearer token123",
    "Host": "api.example.com"
  },
  "query_params": {
    "include": "profile"
  },
  "body": null,  // ⭐ No body for GET request
  "policy_name": "CheckUserAccess",
  "policy_type": "assert_condition",
  "policy_config": {
    "condition": "user_role == 'admin' or user_id == request.path.split('/')[3]",
    "failure_message": "Access denied"
  },
  "variables": {
    "user_id": "456",
    "user_role": "user"
  }
}
```

### **Example 4: Service Callout (Body Used in External Call)**

**Original Client Request to Kong:**
```http
POST /api/orders HTTP/1.1
Host: api.example.com
Content-Type: application/json

{
  "product_id": "prod-123",
  "quantity": 2,
  "user_id": "user-456"
}
```

**Kong Calls Microservice:**
```json
{
  "method": "POST",
  "path": "/api/orders",
  "headers": {
    "Content-Type": "application/json"
  },
  "body": "{\"product_id\": \"prod-123\", \"quantity\": 2, \"user_id\": \"user-456\"}",
  "policy_name": "ValidateInventory",
  "policy_type": "service_callout",
  "policy_config": {
    "target_url": "https://inventory-service.example.com/check",
    "target_method": "POST",
    "target_headers": {
      "Content-Type": "application/json",
      "X-API-Key": "inventory-key-123"
    },
    "target_body": "{\"product_id\": \"prod-123\", \"quantity\": 2}",  // ⭐ Different from request body
    "response_variable": "inventory_status"
  }
}
```

## 🔄 How Policies Use the Body Field

### **JavaScript Policy - Parsing and Validating**

```javascript
// Policy accesses the body through the request object
var requestBody = JSON.parse(request.body);

// Validate fields
if (!requestBody.email || !requestBody.name) {
  setVariable('validation_error', 'Missing required fields');
  throw new Error('Validation failed');
}

// Transform data
requestBody.email = requestBody.email.toLowerCase();
requestBody.created_at = new Date().toISOString();

// Update the body
request.body = JSON.stringify(requestBody);
```

### **Threat Protection Policy - Analyzing Body**

```json
{
  "method": "POST",
  "path": "/api/data",
  "body": "{\"user\": {\"profile\": {\"name\": \"John\", \"nested\": {\"deep\": \"value\"}}}}",
  "policy_type": "json_threat_protection",
  "policy_config": {
    "max_depth": 3,           // Check body nesting depth
    "max_string_length": 1000, // Check string lengths in body
    "max_object_entries": 50   // Check object size in body
  }
}
```

### **Data Transformation Policy - Converting Body**

```json
{
  "method": "POST",
  "path": "/api/convert",
  "body": "<?xml version=\"1.0\"?><user><name>John</name></user>",
  "policy_type": "xml_to_json",
  "policy_config": {
    "source": "request_body",  // ⭐ Transform the body field
    "destination": "response_body"
  }
}
```

## 🎨 Body Field Formats

### **JSON Body (Most Common)**
```json
{
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}"
}
```

### **XML Body**
```json
{
  "body": "<?xml version=\"1.0\"?>\n<user>\n  <name>John Doe</name>\n</user>"
}
```

### **Plain Text Body**
```json
{
  "body": "This is plain text content"
}
```

### **Form Data Body**
```json
{
  "body": "name=John+Doe&email=john%40example.com&age=30"
}
```

### **Empty/Null Body (GET, DELETE requests)**
```json
{
  "body": null
}
```

## 🔧 Kong Integration - Building the Request

### **Kong Plugin Example (Lua)**

```lua
-- Kong plugin that builds the microservice request
local function build_policy_request(policy_type, policy_config)
  -- Get original client request details
  local request_body = kong.request.get_raw_body()  -- ⭐ Original client body
  
  local policy_request = {
    -- Original request context
    method = kong.request.get_method(),
    path = kong.request.get_path(),
    headers = kong.request.get_headers(),
    query_params = kong.request.get_query(),
    body = request_body,  -- ⭐ Client's request body as string
    
    -- Policy configuration
    policy_name = policy_config.name,
    policy_type = policy_type,
    policy_config = policy_config,
    
    -- Context
    variables = kong.ctx.shared.variables or {},
    client_ip = kong.client.get_ip(),
    user_agent = kong.request.get_header("User-Agent"),
    request_id = kong.ctx.shared.request_id
  }
  
  return policy_request
end

-- Call microservice
local function call_policy_service(policy_type, policy_config)
  local httpc = require("resty.http").new()
  local cjson = require("cjson")
  
  local policy_request = build_policy_request(policy_type, policy_config)
  
  local res, err = httpc:request_uri(
    "http://apigee-policy-service:8080/policies/" .. policy_type,
    {
      method = "POST",
      body = cjson.encode(policy_request),  -- ⭐ Entire request as JSON
      headers = {
        ["Content-Type"] = "application/json"
      }
    }
  )
  
  return res
end
```

## 📊 Body Field vs Policy Config - Side by Side

### **Scenario: User Registration with Validation**

```json
{
  // ===== ORIGINAL CLIENT DATA =====
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\", \"password\": \"secret123\"}",
  
  // ===== POLICY CONFIGURATION =====
  "policy_config": {
    "script_content": "var user = JSON.parse(request.body); if (user.password.length < 8) throw new Error('Password too short');",
    "timeout_ms": 5000,
    "validation_rules": {
      "email_required": true,
      "name_min_length": 2,
      "password_min_length": 8
    }
  }
}
```

**Key Difference:**
- `body`: **What the client sent** (the data to process)
- `policy_config`: **How to process it** (the rules and logic)

## 🎯 Common Patterns

### **Pattern 1: Body Validation**
```json
{
  "body": "{\"email\": \"invalid-email\"}",
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "var data = JSON.parse(request.body); if (!data.email.includes('@')) throw new Error('Invalid email');"
  }
}
```

### **Pattern 2: Body Transformation**
```json
{
  "body": "<user><name>John</name></user>",
  "policy_type": "xml_to_json",
  "policy_config": {
    "source": "request_body",
    "destination": "response_body"
  }
}
```

### **Pattern 3: Body Enrichment**
```json
{
  "body": "{\"user_id\": \"123\"}",
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "var data = JSON.parse(request.body); data.timestamp = new Date().toISOString(); data.server = 'api-1'; request.body = JSON.stringify(data);"
  }
}
```

### **Pattern 4: Body-Based Routing**
```json
{
  "body": "{\"type\": \"premium\", \"amount\": 1000}",
  "policy_type": "assert_condition",
  "policy_config": {
    "condition": "JSON.parse(request.body).type == 'premium' and JSON.parse(request.body).amount > 500"
  }
}
```

## ⚠️ Important Notes

### **1. Body is Always a String**
```json
// ✅ CORRECT
{
  "body": "{\"name\": \"John\"}"  // JSON as string
}

// ❌ WRONG
{
  "body": {"name": "John"}  // Object, not string
}
```

### **2. Body Can Be Null**
```json
// ✅ CORRECT for GET/DELETE
{
  "method": "GET",
  "body": null
}
```

### **3. Body Encoding**
```json
// Special characters must be properly escaped
{
  "body": "{\"message\": \"Hello\\nWorld\"}"  // Newline escaped
}
```

### **4. Large Bodies**
```json
// For large bodies, consider:
// - Compression
// - Streaming
// - Size limits in policy_config
{
  "body": "...",  // Large content
  "policy_config": {
    "max_body_size": 1048576  // 1MB limit
  }
}
```

## 🚀 Quick Reference

| Field | Contains | Example |
|-------|----------|---------|
| `body` | Original client request body | `"{\"name\": \"John\"}"` |
| `policy_config` | Policy execution rules | `{"script": "...", "timeout": 5000}` |
| `headers` | Original client headers | `{"Authorization": "Bearer ..."}` |
| `variables` | Execution context data | `{"user_id": "123"}` |

**Remember:** The `body` field is the **data to process**, while `policy_config` defines **how to process it**!