# Plugin Execution Flow

## 🔄 How the Microservice Handles Plugin Execution

### **1. Request Reception & Routing**

```mermaid
graph TD
    A[Kong Gateway] -->|HTTP Request| B[Microservice]
    B --> C[FastAPI Router]
    C --> D{Policy Type?}
    D -->|javascript| E[JavaScript Handler]
    D -->|service-callout| F[Service Callout Handler]
    D -->|kvm-operations| G[KVM Handler]
    D -->|raise-fault| H[Raise Fault Handler]
    D -->|Other| I[Generic Handler]
```

### **2. Plugin Handler Architecture**

Each policy type has a dedicated handler that inherits from `BasePolicyHandler`:

```python
# Base Handler Pattern
class BasePolicyHandler(ABC):
    async def initialize(self) -> None:
        """Initialize handler resources"""
        
    async def execute(self, request: PolicyRequest) -> PolicyResponse:
        """Main execution method"""
        
    async def cleanup(self) -> None:
        """Cleanup handler resources"""

# Specific Handler Implementation
class JavaScriptPolicyHandler(BasePolicyHandler):
    async def _execute_policy(self, request: PolicyRequest) -> PolicyResponse:
        # JavaScript-specific execution logic
        return PolicyResponse(...)
```

### **3. Execution Pipeline**

```mermaid
sequenceDiagram
    participant Kong as Kong Gateway
    participant MS as Microservice
    participant Handler as Policy Handler
    participant External as External Service
    
    Kong->>MS: POST /policies/{type}
    MS->>MS: Validate Request
    MS->>Handler: Initialize (if needed)
    MS->>Handler: Execute Policy
    
    alt Policy needs external call
        Handler->>External: HTTP Request
        External-->>Handler: Response
    end
    
    Handler-->>MS: PolicyResponse
    MS->>MS: Update Metrics
    MS-->>Kong: HTTP Response
    
    alt Terminate Request
        Kong->>Kong: Stop Processing
    else Continue Processing
        Kong->>Kong: Next Plugin/Upstream
    end
```

### **4. Request Processing Flow**

#### **Step 1: Request Validation**
```python
# Automatic validation using Pydantic
class PolicyRequest(BaseModel):
    method: str = Field(..., description="HTTP method")
    path: str = Field(..., description="Request path")
    policy_name: str = Field(..., description="Name of the policy")
    policy_type: str = Field(..., description="Type of the policy")
    policy_config: Dict[str, Any] = Field(default_factory=dict)
    # ... other fields
```

#### **Step 2: Handler Selection**
```python
# Dynamic handler selection
policy_type = request.policy_type.lower().replace('-', '_')
handler = policy_handlers.get(policy_type)

if not handler:
    raise HTTPException(404, f"Policy handler not found: {policy_type}")
```

#### **Step 3: Policy Execution**
```python
# Standardized execution with timing and error handling
async def execute(self, request: PolicyRequest) -> PolicyResponse:
    start_time = time.time()
    
    try:
        # Validate request
        await self._validate_request(request)
        
        # Execute policy logic
        response = await self._execute_policy(request)
        
        # Add execution metadata
        response.execution_time_ms = (time.time() - start_time) * 1000
        response.policy_name = request.policy_name
        
        return response
        
    except Exception as e:
        # Return standardized error response
        return PolicyResponse(
            success=False,
            message=f"Policy execution failed: {str(e)}",
            terminate_request=True,
            execution_time_ms=(time.time() - start_time) * 1000
        )
```

### **5. Policy-Specific Execution Examples**

#### **JavaScript Policy Execution**
```python
async def _execute_javascript(self, request: PolicyRequest) -> PolicyResponse:
    # 1. Extract script content
    script_content = request.policy_config.get('script_content')
    
    # 2. Create execution context
    context = {
        'request': {
            'method': request.method,
            'path': request.path,
            'headers': request.headers,
            'body': request.body
        },
        'variables': request.variables
    }
    
    # 3. Create wrapper script with Apigee-like APIs
    wrapper_script = f"""
    const context = {json.dumps(context)};
    
    function getVariable(name) {{
        return context.variables[name];
    }}
    
    function setVariable(name, value) {{
        context.variables[name] = value;
    }}
    
    // User script
    {script_content}
    
    // Output result
    console.log(JSON.stringify(context));
    """
    
    # 4. Execute in Node.js subprocess
    process = await asyncio.create_subprocess_exec(
        'node', '-e', wrapper_script,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    # 5. Process results
    stdout, stderr = await process.communicate()
    result = json.loads(stdout.decode())
    
    return PolicyResponse(
        success=True,
        variables=result.get('variables', {}),
        message="Script executed successfully"
    )
```

#### **Service Callout Execution**
```python
async def _execute_service_callout(self, request: PolicyRequest) -> PolicyResponse:
    # 1. Extract callout configuration
    target_url = request.policy_config.get('target_url')
    target_method = request.policy_config.get('target_method', 'GET')
    timeout = request.policy_config.get('timeout_seconds', 30)
    
    # 2. Make HTTP call
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.request(
            method=target_method,
            url=target_url,
            headers=request.policy_config.get('target_headers', {}),
            content=request.policy_config.get('target_body')
        )
    
    # 3. Process response
    response_variable = request.policy_config.get('response_variable', 'callout_response')
    
    return PolicyResponse(
        success=True,
        variables={
            response_variable: response.json() if response.headers.get('content-type', '').startswith('application/json') else response.text,
            'callout_status_code': response.status_code
        },
        message="Service callout completed successfully"
    )
```

### **6. Response Processing & Flow Control**

#### **Success Response Handling**
```python
# Kong receives successful response
{
    "success": true,
    "continue_processing": true,    # Kong continues to next plugin
    "terminate_request": false,     # Don't stop the request
    "variables": {                  # Updated context variables
        "user_validated": true
    },
    "headers": {                    # Headers to add to response
        "X-Policy-Executed": "ValidateUser"
    }
}
```

#### **Error Response Handling**
```python
# Kong receives error response
{
    "success": false,
    "continue_processing": false,   # Kong stops processing
    "terminate_request": true,      # Terminate the request
    "status_code": 400,            # HTTP status to return
    "message": "Validation failed",
    "body": "{\"error\": \"Invalid input\"}"  # Response body
}
```

### **7. Integration Patterns**

#### **Pattern 1: Pre-Request Policy**
```lua
-- Kong plugin calls microservice before upstream
function plugin:access(conf)
    local policy_response = call_policy_service("javascript", conf.policy_config)
    
    if not policy_response.success then
        kong.response.exit(
            policy_response.status_code or 500,
            { message = policy_response.message }
        )
    end
    
    -- Continue processing
end
```

#### **Pattern 2: Post-Response Policy**
```lua
-- Kong plugin calls microservice after upstream response
function plugin:header_filter(conf)
    local response_body = kong.response.get_source()
    
    local policy_request = {
        method = kong.request.get_method(),
        path = kong.request.get_path(),
        body = response_body,
        policy_type = "data_transformation",
        policy_config = conf.transform_config
    }
    
    local policy_response = call_policy_service("xml-to-json", policy_request)
    
    if policy_response.success and policy_response.body then
        kong.response.set_source(policy_response.body)
        kong.response.set_header("Content-Type", "application/json")
    end
end
```

#### **Pattern 3: Conditional Policy Execution**
```lua
-- Execute policy only under certain conditions
function plugin:access(conf)
    local user_role = kong.request.get_header("X-User-Role")
    
    if user_role == "admin" then
        -- Skip policy for admin users
        return
    end
    
    local policy_response = call_policy_service("assert_condition", {
        condition = "user_status == 'active'",
        failure_message = "Account suspended"
    })
    
    if not policy_response.success then
        kong.response.exit(403, { message = policy_response.message })
    end
end
```

### **8. Performance Optimizations**

#### **Connection Pooling**
```python
# Reuse HTTP connections for external calls
class ServiceCalloutHandler(BasePolicyHandler):
    def __init__(self):
        super().__init__()
        self.http_client = None
    
    async def _initialize(self):
        self.http_client = httpx.AsyncClient(
            timeout=30.0,
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20)
        )
```

#### **Caching**
```python
# Cache frequently accessed data
class EntityHandler(BasePolicyHandler):
    def __init__(self):
        super().__init__()
        self.entity_cache = {}
        self.cache_ttl = 300  # 5 minutes
    
    async def _get_entity(self, entity_id):
        cache_key = f"entity:{entity_id}"
        
        # Check cache first
        if cache_key in self.entity_cache:
            cached_item = self.entity_cache[cache_key]
            if time.time() - cached_item['timestamp'] < self.cache_ttl:
                return cached_item['data']
        
        # Fetch from API and cache
        entity = await self._fetch_entity_from_api(entity_id)
        self.entity_cache[cache_key] = {
            'data': entity,
            'timestamp': time.time()
        }
        
        return entity
```

### **9. Monitoring & Observability**

#### **Metrics Collection**
```python
# Automatic metrics collection for each policy execution
from core.metrics import metrics

async def execute(self, request: PolicyRequest) -> PolicyResponse:
    start_time = time.time()
    
    try:
        response = await self._execute_policy(request)
        
        # Record successful execution
        metrics.record_policy_execution(
            policy_type=request.policy_type,
            execution_time=(time.time() - start_time) * 1000,
            success=True
        )
        
        return response
        
    except Exception as e:
        # Record failed execution
        metrics.record_policy_execution(
            policy_type=request.policy_type,
            execution_time=(time.time() - start_time) * 1000,
            success=False,
            error=str(e)
        )
        raise
```

#### **Health Checks**
```python
# Comprehensive health checking
@app.get("/health/detailed")
async def detailed_health_check():
    health_status = metrics.get_health_status()
    
    return {
        "status": health_status["status"],
        "handlers_loaded": len(policy_handlers),
        "available_policies": list(policy_handlers.keys()),
        "metrics": metrics.get_metrics(),
        "handlers_status": {
            name: "initialized" if handler.initialized else "not_initialized"
            for name, handler in policy_handlers.items()
        }
    }
```

### **10. Error Recovery & Resilience**

#### **Circuit Breaker Pattern**
```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    async def call(self, func, *args, **kwargs):
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.timeout:
                self.state = "HALF_OPEN"
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = await func(*args, **kwargs)
            if self.state == "HALF_OPEN":
                self.state = "CLOSED"
                self.failure_count = 0
            return result
            
        except Exception as e:
            self.failure_count += 1
            self.last_failure_time = time.time()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
            
            raise e
```

This comprehensive execution flow ensures that the microservice can handle any Apigee policy type reliably, with proper error handling, monitoring, and integration with Kong Gateway.