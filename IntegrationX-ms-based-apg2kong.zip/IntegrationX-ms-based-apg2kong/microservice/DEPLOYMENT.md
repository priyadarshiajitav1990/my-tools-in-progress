# Deployment Guide

## Quick Start (Docker - Recommended)

### 1. Prerequisites
- Docker and Docker Compose installed
- At least 2GB RAM available
- Ports 8080 and 6379 available

### 2. Deploy with Docker Compose

```bash
# Navigate to microservice directory
cd microservice

# Copy environment configuration
cp .env.example .env

# Edit configuration if needed
# nano .env

# Start all services
docker-compose up -d

# Check service status
docker-compose ps

# View logs
docker-compose logs -f apigee-policy-service
```

### 3. Verify Deployment

```bash
# Health check
curl http://localhost:8080/health

# List available policies
curl http://localhost:8080/policies

# Test a simple policy
curl -X POST http://localhost:8080/policies/raise-fault \
  -H "Content-Type: application/json" \
  -d '{
    "method": "GET",
    "path": "/test",
    "policy_name": "TestFault",
    "policy_type": "raise_fault",
    "policy_config": {
      "fault_code": "TEST_ERROR",
      "fault_string": "Test deployment",
      "status_code": 400
    }
  }'
```

## Manual Deployment

### 1. System Requirements

- **Python**: 3.11 or higher
- **Node.js**: 16+ (optional, for JavaScript policies)
- **Java**: 11+ (optional, for Java callouts)
- **Redis**: 6+ (optional, for KVM operations)

### 2. Installation Steps

```bash
# Install Python dependencies
pip install -r requirements.txt

# Install optional dependencies
# Node.js for JavaScript execution
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Java for Java callouts
sudo apt-get install openjdk-11-jre-headless

# Redis for KVM operations
sudo apt-get install redis-server
# OR use Docker: docker run -d -p 6379:6379 redis:7-alpine
```

### 3. Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit configuration
nano .env
```

Key settings to configure:

```bash
# Server settings
HOST=0.0.0.0
PORT=8080
DEBUG=false

# Redis connection (if using KVM policies)
REDIS_HOST=localhost
REDIS_PORT=6379

# Security
SECRET_KEY=your-secure-secret-key-here

# Performance tuning
MAX_CONCURRENT_REQUESTS=100
REQUEST_TIMEOUT=30
```

### 4. Start the Service

```bash
# Using the startup script (recommended)
python start.py

# OR using uvicorn directly
uvicorn main:app --host 0.0.0.0 --port 8080

# OR using the Makefile
make run
```

## Production Deployment

### Kubernetes Deployment

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apigee-policy-service
  labels:
    app: apigee-policy-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: apigee-policy-service
  template:
    metadata:
      labels:
        app: apigee-policy-service
    spec:
      containers:
      - name: apigee-policy-service
        image: apigee-policy-service:latest
        ports:
        - containerPort: 8080
        env:
        - name: REDIS_HOST
          value: "redis-service"
        - name: LOG_LEVEL
          value: "INFO"
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: apigee-policy-service
spec:
  selector:
    app: apigee-policy-service
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080
  type: LoadBalancer
```

### Docker Swarm Deployment

```yaml
# docker-stack.yml
version: '3.8'

services:
  apigee-policy-service:
    image: apigee-policy-service:latest
    ports:
      - "8080:8080"
    environment:
      - REDIS_HOST=redis
      - LOG_LEVEL=INFO
    deploy:
      replicas: 3
      resources:
        limits:
          memory: 512M
        reservations:
          memory: 256M
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
    networks:
      - apigee-network
    depends_on:
      - redis

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 256M
        reservations:
          memory: 128M
    networks:
      - apigee-network
    command: redis-server --appendonly yes

volumes:
  redis_data:

networks:
  apigee-network:
    driver: overlay
```

Deploy with:
```bash
docker stack deploy -c docker-stack.yml apigee-policies
```

## Integration with Kong Gateway

### 1. Add as Upstream Service

```bash
# Create upstream
curl -X POST http://kong-admin:8001/upstreams \
  --data "name=apigee-policy-service"

# Add target
curl -X POST http://kong-admin:8001/upstreams/apigee-policy-service/targets \
  --data "target=apigee-policy-service:8080"
```

### 2. Create Kong Service

```bash
curl -X POST http://kong-admin:8001/services \
  --data "name=apigee-policies" \
  --data "host=apigee-policy-service" \
  --data "port=8080" \
  --data "protocol=http"
```

### 3. Add Route for Policy Execution

```bash
curl -X POST http://kong-admin:8001/services/apigee-policies/routes \
  --data "paths[]=/policies" \
  --data "methods[]=POST"
```

### 4. Custom Kong Plugin Integration

Create a custom Kong plugin that:

1. Intercepts requests that need Apigee policy processing
2. Transforms the request into the microservice format
3. Calls the appropriate policy endpoint
4. Processes the response and continues or terminates the request

Example plugin structure:
```lua
-- kong/plugins/apigee-policy/handler.lua
local ApigeePolicy = {}

function ApigeePolicy:access(conf)
  -- Extract policy configuration
  local policy_request = {
    method = kong.request.get_method(),
    path = kong.request.get_path(),
    headers = kong.request.get_headers(),
    policy_name = conf.policy_name,
    policy_type = conf.policy_type,
    policy_config = conf.policy_config
  }
  
  -- Call microservice
  local http = require "resty.http"
  local httpc = http.new()
  
  local res, err = httpc:request_uri(
    "http://apigee-policy-service:8080/policies/" .. conf.policy_type,
    {
      method = "POST",
      body = cjson.encode(policy_request),
      headers = {
        ["Content-Type"] = "application/json"
      }
    }
  )
  
  -- Process response
  if res and res.status == 200 then
    local response_data = cjson.decode(res.body)
    if not response_data.success then
      kong.response.exit(
        response_data.status_code or 500,
        { message = response_data.message }
      )
    end
  end
end

return ApigeePolicy
```

## Monitoring and Observability

### Health Checks

The service provides multiple health check endpoints:

```bash
# Basic health check
curl http://localhost:8080/health

# Detailed health with metrics
curl http://localhost:8080/health/detailed

# Metrics only
curl http://localhost:8080/metrics
```

### Logging

Configure structured logging:

```bash
# Set log level
LOG_LEVEL=INFO

# Log format
LOG_FORMAT="%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Log to file
LOG_FILE=logs/apigee-policy-service.log
```

### Prometheus Integration

Add Prometheus metrics endpoint (future enhancement):

```python
# Add to requirements.txt
prometheus-client>=0.17.0

# Add to main.py
from prometheus_client import Counter, Histogram, generate_latest

policy_requests = Counter('policy_requests_total', 'Total policy requests', ['policy_type'])
policy_duration = Histogram('policy_duration_seconds', 'Policy execution time', ['policy_type'])

@app.get("/metrics/prometheus")
async def prometheus_metrics():
    return Response(generate_latest(), media_type="text/plain")
```

## Security Considerations

### Network Security

1. **Use HTTPS in production**:
   ```bash
   # Add SSL certificates
   uvicorn main:app --host 0.0.0.0 --port 8080 \
     --ssl-keyfile=key.pem --ssl-certfile=cert.pem
   ```

2. **Firewall configuration**:
   ```bash
   # Allow only necessary ports
   ufw allow 8080/tcp  # API port
   ufw allow 6379/tcp  # Redis (if external)
   ```

3. **Network isolation**:
   - Use Docker networks or Kubernetes network policies
   - Restrict access to Redis and other backend services

### Application Security

1. **Environment variables**:
   ```bash
   # Use strong secrets
   SECRET_KEY=$(openssl rand -hex 32)
   
   # Secure Redis if needed
   REDIS_PASSWORD=$(openssl rand -hex 16)
   ```

2. **Input validation**:
   - All inputs are validated using Pydantic models
   - Script execution is sandboxed with timeouts
   - File operations are restricted

3. **Resource limits**:
   ```bash
   # Configure limits
   MAX_CONCURRENT_REQUESTS=100
   JS_TIMEOUT=5000
   JAVA_TIMEOUT=10
   REQUEST_TIMEOUT=30
   ```

## Troubleshooting

### Common Issues

1. **Service won't start**:
   ```bash
   # Check logs
   docker-compose logs apigee-policy-service
   
   # Validate structure
   python validate_structure.py
   
   # Check dependencies
   make deps-check
   ```

2. **Redis connection issues**:
   ```bash
   # Test Redis connectivity
   redis-cli ping
   
   # Check Redis logs
   docker-compose logs redis
   ```

3. **Policy execution failures**:
   ```bash
   # Check detailed health
   curl http://localhost:8080/health/detailed
   
   # Review metrics
   curl http://localhost:8080/metrics
   ```

### Performance Tuning

1. **Increase concurrency**:
   ```bash
   MAX_CONCURRENT_REQUESTS=200
   ```

2. **Optimize timeouts**:
   ```bash
   JS_TIMEOUT=3000      # Reduce for faster failures
   REQUEST_TIMEOUT=15   # Reduce for faster responses
   ```

3. **Enable caching**:
   ```bash
   # Entity cache TTL
   ENTITY_CACHE_TTL=600  # 10 minutes
   ```

## Backup and Recovery

### Configuration Backup

```bash
# Backup configuration
cp .env .env.backup.$(date +%Y%m%d)

# Backup Docker volumes
docker run --rm -v apigee_redis_data:/data -v $(pwd):/backup \
  alpine tar czf /backup/redis_backup_$(date +%Y%m%d).tar.gz /data
```

### Service Recovery

```bash
# Restart services
docker-compose restart

# Full rebuild
docker-compose down
docker-compose build --no-cache
docker-compose up -d

# Check service health
curl http://localhost:8080/health
```

## Scaling

### Horizontal Scaling

```bash
# Scale with Docker Compose
docker-compose up -d --scale apigee-policy-service=3

# Scale with Kubernetes
kubectl scale deployment apigee-policy-service --replicas=5
```

### Load Balancing

Use a load balancer (nginx, HAProxy, or cloud load balancer) to distribute traffic across multiple instances.

Example nginx configuration:
```nginx
upstream apigee_policy_service {
    server apigee-policy-1:8080;
    server apigee-policy-2:8080;
    server apigee-policy-3:8080;
}

server {
    listen 80;
    location / {
        proxy_pass http://apigee_policy_service;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```