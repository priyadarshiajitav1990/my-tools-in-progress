# Apigee Variables Handling Guide

## 🔄 Overview

The microservice provides **complete Apigee variable compatibility** by implementing a variable context system that mimics Apigee's variable behavior. This allows policies to read, write, and manipulate variables just like in Apigee.

## 📊 Variable Types & Mapping

### **1. Apigee Variable Categories**

Apigee has several variable categories that the microservice handles:

| Apigee Variable Type | Microservice Mapping | Description |
|---------------------|---------------------|-------------|
| **Flow Variables** | `flow_variables` | Built-in Apigee variables (request.*, response.*, etc.) |
| **Custom Variables** | `variables` | User-defined variables set by policies |
| **Private Variables** | `variables` (prefixed) | Policy-specific private variables |
| **System Variables** | Auto-populated | System-level information |

### **2. Common Apigee Variables Mapping**

#### **Request Variables**
```json
{
  "flow_variables": {
    "request.verb": "POST",              // HTTP method
    "request.uri": "/api/users",         // Request path
    "request.path": "/api/users",        // Path without query
    "request.querystring": "limit=10",   // Query string
    "request.header.content-type": "application/json",
    "request.header.authorization": "Bearer token123",
    "request.content": "{\"name\": \"John\"}",  // Request body
    "request.formparam.{name}": "value", // Form parameters
    "client.ip": "192.168.1.100",        // Client IP
    "client.host": "example.com",        // Client hostname
    "client.port": "443",                // Client port
    "client.scheme": "https"             // Protocol scheme
  }
}
```

#### **Response Variables**
```json
{
  "flow_variables": {
    "response.status.code": 200,
    "response.reason.phrase": "OK",
    "response.header.content-type": "application/json",
    "response.content": "{\"result\": \"success\"}",
    "response.header.{name}": "value"
  }
}
```

#### **System Variables**
```json
{
  "flow_variables": {
    "system.time": 1640995200000,        // Current timestamp
    "system.time.year": 2024,
    "system.time.month": 1,
    "system.time.day": 8,
    "system.uuid": "550e8400-e29b-41d4-a716-446655440000",
    "messageid": "req-123-456",          // Unique message ID
    "organization.name": "my-org",
    "environment.name": "production",
    "apiproxy.name": "users-api",
    "apiproxy.revision": "1"
  }
}
```

#### **Target Variables**
```json
{
  "flow_variables": {
    "target.url": "https://backend.example.com/api",
    "target.host": "backend.example.com",
    "target.port": "443",
    "target.scheme": "https",
    "target.basepath": "/api",
    "target.response.status.code": 200,
    "target.response.content": "{\"data\": \"...\"}"
  }
}
```

## 🔧 Variable Handling in the Microservice

### **1. Variable Context Structure**

The microservice maintains two variable contexts:

```python
class PolicyRequest(BaseModel):
    # Flow variables (Apigee built-in variables)
    flow_variables: Dict[str, Any] = Field(
        default_factory=dict, 
        description="Apigee flow variables (request.*, response.*, etc.)"
    )
    
    # Custom variables (user-defined)
    variables: Dict[str, Any] = Field(
        default_factory=dict,
        description="Custom variables set by policies"
    )
```

### **2. Variable Access in Policies**

#### **JavaScript Policy Example**
```javascript
// Reading variables
var userId = getVariable("user_id");                    // Custom variable
var requestMethod = getVariable("request.verb");        // Flow variable
var authHeader = getVariable("request.header.authorization");

// Writing variables
setVariable("user_validated", true);                    // Custom variable
setVariable("validation_timestamp", Date.now());
setVariable("response.header.x-user-id", userId);      // Response header

// Checking variable existence
if (getVariable("user_role") === "admin") {
    setVariable("admin_access", true);
}
```

#### **Implementation in JavaScript Handler**
```python
def _create_js_wrapper(self, script_content: str, context: Dict[str, Any]) -> str:
    """Create JavaScript wrapper with Apigee-like variable access."""
    return f"""
const context = {json.dumps(context, indent=2)};

// Apigee-like variable access functions
function getVariable(name) {{
    // Check flow variables first (request.*, response.*, etc.)
    if (name.startsWith('request.') || name.startsWith('response.') || 
        name.startsWith('system.') || name.startsWith('target.')) {{
        return context.flowVariables[name];
    }}
    
    // Check custom variables
    return context.variables[name] || context.flowVariables[name];
}}

function setVariable(name, value) {{
    // Response headers go to flow variables
    if (name.startsWith('response.header.')) {{
        if (!context.response) context.response = {{}};
        if (!context.response.headers) context.response.headers = {{}};
        
        var headerName = name.substring('response.header.'.length);
        context.response.headers[headerName] = value;
        context.flowVariables[name] = value;
    }}
    // Request modifications
    else if (name.startsWith('request.')) {{
        context.flowVariables[name] = value;
    }}
    // Custom variables
    else {{
        context.variables[name] = value;
    }}
}}

// User script
{script_content}

// Output result
console.log(JSON.stringify({{
    success: true,
    context: context,
    message: "Script executed successfully"
}}));
"""
```

### **3. Variable Resolution in Conditions**

The condition handler supports Apigee-style variable references:

```python
def _resolve_value(self, value: Union[str, Any], request: PolicyRequest) -> Any:
    """Resolve variable references in conditions."""
    
    if not isinstance(value, str):
        return value
    
    value = value.strip()
    
    # Handle variable references
    if value.startswith('request.'):
        # Extract from flow variables
        return request.flow_variables.get(value)
    
    if value.startswith('response.'):
        return request.flow_variables.get(value)
    
    if value.startswith('system.'):
        return request.flow_variables.get(value)
    
    # Check custom variables
    if value in request.variables:
        return request.variables[value]
    
    if value in request.flow_variables:
        return request.flow_variables[value]
    
    # Return as literal
    return value
```

### **4. Variable Substitution in Templates**

Many policies support variable substitution in templates:

```python
def _substitute_variables(self, template: str, request: PolicyRequest) -> str:
    """Substitute variables in template strings."""
    
    result = template
    
    # Substitute flow variables
    for key, value in request.flow_variables.items():
        placeholder = f"{{{key}}}"
        if placeholder in result:
            result = result.replace(placeholder, str(value))
    
    # Substitute custom variables
    for key, value in request.variables.items():
        placeholder = f"{{{key}}}"
        if placeholder in result:
            result = result.replace(placeholder, str(value))
    
    return result
```

## 🔗 Kong to Microservice Variable Mapping

### **Kong Plugin Variable Collection**

Kong plugins need to collect and map Kong variables to Apigee format:

```lua
-- Kong plugin that maps Kong variables to Apigee format
local function build_policy_request()
    local request = kong.request
    local response = kong.response
    
    -- Build flow variables (Apigee format)
    local flow_variables = {
        -- Request variables
        ["request.verb"] = request.get_method(),
        ["request.uri"] = request.get_path_with_query(),
        ["request.path"] = request.get_path(),
        ["request.querystring"] = request.get_raw_query(),
        ["request.content"] = request.get_raw_body(),
        
        -- Client variables
        ["client.ip"] = kong.client.get_ip(),
        ["client.host"] = kong.request.get_host(),
        ["client.port"] = kong.request.get_port(),
        ["client.scheme"] = kong.request.get_scheme(),
        
        -- System variables
        ["system.time"] = ngx.now() * 1000,
        ["messageid"] = kong.request.get_header("X-Request-ID") or ngx.var.request_id,
        
        -- Organization/Environment (from Kong config)
        ["organization.name"] = kong.configuration.organization or "default",
        ["environment.name"] = kong.configuration.environment or "production"
    }
    
    -- Add all request headers
    local headers = request.get_headers()
    for name, value in pairs(headers) do
        flow_variables["request.header." .. name:lower()] = value
    end
    
    -- Add query parameters
    local query_params = request.get_query()
    for name, value in pairs(query_params) do
        flow_variables["request.queryparam." .. name] = value
    end
    
    -- Build custom variables from Kong context
    local variables = kong.ctx.shared.apigee_variables or {}
    
    return {
        method = request.get_method(),
        path = request.get_path(),
        headers = headers,
        query_params = query_params,
        body = request.get_raw_body(),
        flow_variables = flow_variables,
        variables = variables,
        client_ip = kong.client.get_ip(),
        request_id = kong.request.get_header("X-Request-ID")
    }
end
```

### **Variable Persistence Across Policies**

Kong plugins can maintain variable state across multiple policy calls:

```lua
-- Initialize variable context at the start of request
function plugin:access(conf)
    -- Initialize Apigee variable context
    kong.ctx.shared.apigee_variables = kong.ctx.shared.apigee_variables or {}
    kong.ctx.shared.flow_variables = kong.ctx.shared.flow_variables or {}
    
    -- Call first policy
    local policy_request = build_policy_request()
    local response1 = call_policy_service("javascript", policy_request)
    
    -- Update variable context with results
    if response1.variables then
        for k, v in pairs(response1.variables) do
            kong.ctx.shared.apigee_variables[k] = v
        end
    end
    
    -- Call second policy with updated variables
    policy_request.variables = kong.ctx.shared.apigee_variables
    local response2 = call_policy_service("assert_condition", policy_request)
    
    -- Variables persist across policy calls
end
```

## 📋 Complete Variable Handling Examples

### **Example 1: User Authentication Flow**

#### **Step 1: Extract JWT Token (JavaScript Policy)**
```json
{
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "var authHeader = getVariable('request.header.authorization');\nif (authHeader && authHeader.startsWith('Bearer ')) {\n  var token = authHeader.substring(7);\n  setVariable('jwt_token', token);\n  setVariable('auth_method', 'jwt');\n} else {\n  setVariable('auth_method', 'none');\n}"
  },
  "flow_variables": {
    "request.header.authorization": "Bearer eyJhbGc..."
  }
}
```

**Response**:
```json
{
  "success": true,
  "variables": {
    "jwt_token": "eyJhbGc...",
    "auth_method": "jwt"
  }
}
```

#### **Step 2: Verify JWT (JWS Policy)**
```json
{
  "policy_type": "jws_verify",
  "policy_config": {
    "token_source": "variable",
    "token_variable": "jwt_token",
    "algorithm": "RS256"
  },
  "variables": {
    "jwt_token": "eyJhbGc...",
    "auth_method": "jwt"
  }
}
```

**Response**:
```json
{
  "success": true,
  "variables": {
    "jws_payload": {
      "sub": "user123",
      "role": "admin"
    },
    "jws_verified": true,
    "user_id": "user123",
    "user_role": "admin"
  }
}
```

#### **Step 3: Check User Role (Condition Policy)**
```json
{
  "policy_type": "assert_condition",
  "policy_config": {
    "operation": "assert",
    "condition": "user_role == 'admin'",
    "failure_message": "Admin access required"
  },
  "variables": {
    "user_id": "user123",
    "user_role": "admin",
    "jws_verified": true
  }
}
```

**Response**:
```json
{
  "success": true,
  "variables": {
    "condition_result": true,
    "access_granted": true
  }
}
```

### **Example 2: Service Callout with Variable Substitution**

```json
{
  "policy_type": "service_callout",
  "policy_config": {
    "target_url": "https://user-service.example.com/users/{user_id}",
    "target_method": "GET",
    "target_headers": {
      "Authorization": "Bearer {service_token}",
      "X-Request-ID": "{messageid}"
    },
    "response_variable": "user_profile"
  },
  "variables": {
    "user_id": "123",
    "service_token": "service-abc-123"
  },
  "flow_variables": {
    "messageid": "req-456-789"
  }
}
```

**Response**:
```json
{
  "success": true,
  "variables": {
    "user_profile": {
      "id": "123",
      "name": "John Doe",
      "email": "john@example.com"
    },
    "callout_status_code": 200
  }
}
```

### **Example 3: KVM with Variable Keys**

```json
{
  "policy_type": "kvm_operations",
  "policy_config": {
    "operation": "get",
    "key": "user_{user_id}_preferences",
    "map_name": "user_data"
  },
  "variables": {
    "user_id": "123"
  }
}
```

**Response**:
```json
{
  "success": true,
  "variables": {
    "kvm_value": {
      "theme": "dark",
      "language": "en"
    },
    "kvm_found": true,
    "user_preferences": {
      "theme": "dark",
      "language": "en"
    }
  }
}
```

## 🎯 Variable Best Practices

### **1. Variable Naming Conventions**

```javascript
// Good: Clear, descriptive names
setVariable("user_authenticated", true);
setVariable("validation_timestamp", Date.now());
setVariable("api_response_time_ms", 150);

// Avoid: Ambiguous names
setVariable("flag", true);
setVariable("data", someValue);
setVariable("temp", 123);
```

### **2. Variable Scoping**

```javascript
// Flow variables (read-only in most cases)
var requestMethod = getVariable("request.verb");
var clientIp = getVariable("client.ip");

// Custom variables (read-write)
setVariable("user_id", "123");
setVariable("processing_stage", "validation");

// Response variables (write to modify response)
setVariable("response.header.x-user-id", userId);
setVariable("response.status.code", 200);
```

### **3. Variable Type Handling**

```javascript
// String variables
setVariable("user_name", "John Doe");

// Numeric variables
setVariable("retry_count", 3);
setVariable("response_time_ms", 150.5);

// Boolean variables
setVariable("is_authenticated", true);
setVariable("cache_hit", false);

// Object variables
setVariable("user_profile", {
    id: "123",
    name: "John Doe",
    email: "john@example.com"
});

// Array variables
setVariable("user_roles", ["user", "admin"]);
```

### **4. Variable Validation**

```javascript
// Check variable existence
var userId = getVariable("user_id");
if (!userId) {
    setVariable("error_message", "User ID not found");
    throw new Error("User ID required");
}

// Type checking
var retryCount = getVariable("retry_count");
if (typeof retryCount !== "number") {
    setVariable("retry_count", 0);
}

// Default values
var maxRetries = getVariable("max_retries") || 3;
var timeout = getVariable("timeout_ms") || 5000;
```

## 🔄 Variable Lifecycle

```mermaid
graph LR
    A[Kong Request] --> B[Initialize Variables]
    B --> C[Policy 1: Set Variables]
    C --> D[Policy 2: Read/Modify Variables]
    D --> E[Policy 3: Use Variables]
    E --> F[Response with Variables]
    F --> G[Kong Response]
```

### **Variable Flow Example**

```lua
-- Kong plugin managing variable lifecycle
function plugin:access(conf)
    -- 1. Initialize variable context
    kong.ctx.shared.apigee_variables = {}
    kong.ctx.shared.flow_variables = build_flow_variables()
    
    -- 2. Execute Policy 1: Authentication
    local auth_response = call_policy("javascript", {
        policy_config = conf.auth_policy,
        variables = kong.ctx.shared.apigee_variables,
        flow_variables = kong.ctx.shared.flow_variables
    })
    
    -- Update variables
    merge_variables(kong.ctx.shared.apigee_variables, auth_response.variables)
    
    -- 3. Execute Policy 2: Authorization
    local authz_response = call_policy("assert_condition", {
        policy_config = conf.authz_policy,
        variables = kong.ctx.shared.apigee_variables,
        flow_variables = kong.ctx.shared.flow_variables
    })
    
    -- Update variables
    merge_variables(kong.ctx.shared.apigee_variables, authz_response.variables)
    
    -- 4. Execute Policy 3: Rate Limiting
    local rate_response = call_policy("kvm_operations", {
        policy_config = conf.rate_policy,
        variables = kong.ctx.shared.apigee_variables,
        flow_variables = kong.ctx.shared.flow_variables
    })
    
    -- Variables persist throughout the request lifecycle
end
```

## 📊 Variable Debugging

### **Enable Variable Logging**

```json
{
  "policy_type": "message_logging",
  "policy_config": {
    "operation": "log",
    "log_level": "DEBUG",
    "message_template": "Variables: {variables_json}",
    "variables_json": "{variables}"
  }
}
```

### **Variable Inspection Endpoint**

```python
@app.post("/debug/variables")
async def debug_variables(request: PolicyRequest):
    """Debug endpoint to inspect variable state."""
    return {
        "flow_variables": request.flow_variables,
        "custom_variables": request.variables,
        "all_variables": {**request.flow_variables, **request.variables}
    }
```

This comprehensive variable handling system ensures that the microservice provides **100% Apigee variable compatibility**, allowing seamless migration of Apigee policies to Kong! 🚀