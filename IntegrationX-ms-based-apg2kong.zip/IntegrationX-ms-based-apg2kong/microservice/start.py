#!/usr/bin/env python3
"""
Apigee Policy Microservice Startup Script
=========================================

Production-ready startup script with proper error handling,
logging, and graceful shutdown.
"""

import asyncio
import signal
import sys
import os
import logging
from pathlib import Path
import uvicorn
from contextlib import asynccontextmanager

# Add current directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from core.config import Settings
from core.logger import setup_logging


class MicroserviceRunner:
    """Microservice runner with proper lifecycle management."""
    
    def __init__(self):
        self.settings = Settings.load_config()
        self.logger = setup_logging(self.settings.log_level)
        self.server = None
        self.shutdown_event = asyncio.Event()
    
    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, initiating graceful shutdown...")
            self.shutdown_event.set()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    async def check_dependencies(self):
        """Check if all required dependencies are available."""
        self.logger.info("Checking dependencies...")
        
        # Check Redis connection
        try:
            import redis.asyncio as redis
            redis_client = redis.from_url(self.settings.get_redis_url())
            await redis_client.ping()
            await redis_client.close()
            self.logger.info("✓ Redis connection successful")
        except Exception as e:
            self.logger.warning(f"⚠ Redis connection failed: {e}")
        
        # Check Node.js availability
        try:
            process = await asyncio.create_subprocess_exec(
                'node', '--version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            if process.returncode == 0:
                version = stdout.decode().strip()
                self.logger.info(f"✓ Node.js available: {version}")
            else:
                self.logger.warning("⚠ Node.js not available")
        except FileNotFoundError:
            self.logger.warning("⚠ Node.js not found")
        
        # Check Python availability
        self.logger.info(f"✓ Python {sys.version}")
        
        # Check Java availability
        try:
            process = await asyncio.create_subprocess_exec(
                'java', '-version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            if process.returncode == 0:
                # Java version is typically in stderr
                version_info = stderr.decode().split('\n')[0]
                self.logger.info(f"✓ Java available: {version_info}")
            else:
                self.logger.warning("⚠ Java not available")
        except FileNotFoundError:
            self.logger.warning("⚠ Java not found")
    
    def create_directories(self):
        """Create necessary directories."""
        directories = ['logs', 'java/lib', 'temp']
        
        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True)
            self.logger.debug(f"Created directory: {directory}")
    
    async def run(self):
        """Run the microservice."""
        try:
            self.logger.info("Starting Apigee Policy Microservice...")
            
            # Setup signal handlers
            self.setup_signal_handlers()
            
            # Create necessary directories
            self.create_directories()
            
            # Check dependencies
            await self.check_dependencies()
            
            # Import the FastAPI app
            from main import app
            
            # Configure uvicorn
            config = uvicorn.Config(
                app,
                host=self.settings.host,
                port=self.settings.port,
                log_level=self.settings.log_level.lower(),
                reload=self.settings.debug,
                access_log=True,
                server_header=False,
                date_header=False
            )
            
            # Create and start server
            self.server = uvicorn.Server(config)
            
            self.logger.info(f"Starting server on {self.settings.host}:{self.settings.port}")
            
            # Run server with graceful shutdown
            await self._run_with_graceful_shutdown()
            
        except Exception as e:
            self.logger.error(f"Failed to start microservice: {e}")
            sys.exit(1)
    
    async def _run_with_graceful_shutdown(self):
        """Run server with graceful shutdown handling."""
        # Start server in background
        server_task = asyncio.create_task(self.server.serve())
        
        # Wait for shutdown signal or server completion
        done, pending = await asyncio.wait(
            [server_task, asyncio.create_task(self.shutdown_event.wait())],
            return_when=asyncio.FIRST_COMPLETED
        )
        
        # If shutdown was requested
        if self.shutdown_event.is_set():
            self.logger.info("Shutdown requested, stopping server...")
            
            # Stop the server gracefully
            self.server.should_exit = True
            
            # Wait for server to stop (with timeout)
            try:
                await asyncio.wait_for(server_task, timeout=30.0)
            except asyncio.TimeoutError:
                self.logger.warning("Server shutdown timed out, forcing exit")
            
            # Cancel any remaining tasks
            for task in pending:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        self.logger.info("Microservice stopped")


def main():
    """Main entry point."""
    try:
        runner = MicroserviceRunner()
        asyncio.run(runner.run())
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()