# API Request/Response Examples

## 🔄 Standard Request/Response Format

### Base Request Structure

All policy requests follow this standard format:

```json
{
  "method": "string",              // HTTP method (GET, POST, etc.)
  "path": "string",                // Request path
  "headers": {},                   // Request headers
  "query_params": {},              // Query parameters
  "body": "string",                // Request body (optional)
  "policy_name": "string",         // Name of the policy
  "policy_type": "string",         // Type of policy to execute
  "policy_config": {},             // Policy-specific configuration
  "variables": {},                 // Context variables
  "flow_variables": {},            // Flow variables
  "client_ip": "string",           // Client IP (optional)
  "user_agent": "string",          // User agent (optional)
  "request_id": "string"           // Request ID (optional)
}
```

### Base Response Structure

All policy responses follow this standard format:

```json
{
  "success": boolean,              // Execution success flag
  "message": "string",             // Result message
  "status_code": number,           // HTTP status code (optional)
  "headers": {},                   // Headers to add/modify
  "body": "string",                // Response body (optional)
  "continue_processing": boolean,  // Continue request processing
  "terminate_request": boolean,    // Terminate request flag
  "variables": {},                 // Updated variables
  "execution_time_ms": number,     // Execution time
  "policy_name": "string"          // Policy name
}
```

## 📝 Policy-Specific Examples

### 1. JavaScript Policy

**Endpoint**: `POST /policies/javascript`

**Request**:
```json
{
  "method": "POST",
  "path": "/api/users",
  "headers": {
    "Content-Type": "application/json",
    "Authorization": "Bearer token123"
  },
  "body": "{\"name\": \"John Doe\", \"email\": \"john@example.com\"}",
  "policy_name": "ValidateUser",
  "policy_type": "javascript",
  "policy_config": {
    "script_content": "function validate(request) {\n  var body = JSON.parse(request.body);\n  if (!body.name || !body.email) {\n    setVariable('validation_error', 'Name and email required');\n    return false;\n  }\n  setVariable('user_validated', true);\n  return true;\n}",
    "timeout_ms": 5000
  },
  "variables": {
    "api_version": "v1"
  }
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "Script executed successfully",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "user_validated": true
  },
  "execution_time_ms": 23.5,
  "policy_name": "ValidateUser"
}
```

**Error Response**:
```json
{
  "success": false,
  "message": "Script execution failed: Name and email required",
  "status_code": 400,
  "continue_processing": false,
  "terminate_request": true,
  "variables": {
    "validation_error": "Name and email required"
  },
  "execution_time_ms": 15.2,
  "policy_name": "ValidateUser"
}
```

### 2. Service Callout Policy

**Endpoint**: `POST /policies/service-callout`

**Request**:
```json
{
  "method": "GET",
  "path": "/api/users/123",
  "headers": {
    "Authorization": "Bearer token123"
  },
  "policy_name": "GetUserProfile",
  "policy_type": "service_callout",
  "policy_config": {
    "target_url": "https://user-service.example.com/users/123",
    "target_method": "GET",
    "target_headers": {
      "Content-Type": "application/json",
      "X-API-Key": "service-key-123"
    },
    "timeout_seconds": 10,
    "response_variable": "user_profile"
  },
  "variables": {
    "user_id": "123"
  }
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "Service callout completed successfully",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "user_profile": {
      "id": "123",
      "name": "John Doe",
      "email": "john@example.com",
      "status": "active"
    },
    "callout_status_code": 200
  },
  "execution_time_ms": 156.7,
  "policy_name": "GetUserProfile"
}
```

### 3. KVM Operations Policy

**Endpoint**: `POST /policies/kvm-operations`

**Request**:
```json
{
  "method": "GET",
  "path": "/api/cache/user/123",
  "policy_name": "GetUserCache",
  "policy_type": "kvm_operations",
  "policy_config": {
    "operation": "get",
    "key": "user_123_profile",
    "map_name": "user_cache",
    "default_value": null
  },
  "variables": {
    "user_id": "123"
  }
}
```

**Success Response (Cache Hit)**:
```json
{
  "success": true,
  "message": "KVM operation completed successfully",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "kvm_value": {
      "name": "John Doe",
      "email": "john@example.com"
    },
    "kvm_found": true,
    "kvm_key": "user_123_profile"
  },
  "execution_time_ms": 5.2,
  "policy_name": "GetUserCache"
}
```

**Success Response (Cache Miss)**:
```json
{
  "success": true,
  "message": "KVM key not found",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "kvm_value": null,
    "kvm_found": false,
    "kvm_key": "user_123_profile"
  },
  "execution_time_ms": 3.1,
  "policy_name": "GetUserCache"
}
```

### 4. Raise Fault Policy

**Endpoint**: `POST /policies/raise-fault`

**Request**:
```json
{
  "method": "POST",
  "path": "/api/users",
  "policy_name": "ValidationError",
  "policy_type": "raise_fault",
  "policy_config": {
    "fault_code": "VALIDATION_FAILED",
    "fault_string": "User validation failed: {validation_error}",
    "status_code": 400,
    "response_headers": {
      "X-Error-Code": "VALIDATION_FAILED",
      "Content-Type": "application/json"
    },
    "response_body": "{\"error\": \"VALIDATION_FAILED\", \"message\": \"{validation_error}\"}"
  },
  "variables": {
    "validation_error": "Email format is invalid"
  }
}
```

**Response**:
```json
{
  "success": false,
  "message": "User validation failed: Email format is invalid",
  "status_code": 400,
  "headers": {
    "X-Error-Code": "VALIDATION_FAILED",
    "Content-Type": "application/json"
  },
  "body": "{\"error\": \"VALIDATION_FAILED\", \"message\": \"Email format is invalid\"}",
  "continue_processing": false,
  "terminate_request": true,
  "execution_time_ms": 2.1,
  "policy_name": "ValidationError"
}
```

### 5. JWS Verify Policy

**Endpoint**: `POST /policies/jws-verify`

**Request**:
```json
{
  "method": "GET",
  "path": "/api/protected",
  "headers": {
    "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "policy_name": "VerifyJWT",
  "policy_type": "jws_verify",
  "policy_config": {
    "operation": "verify",
    "token_source": "header",
    "header_name": "Authorization",
    "algorithm": "RS256",
    "verification_key": "-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----",
    "verify_expiration": true,
    "verify_issued_at": true
  }
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "JWS verification successful",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "jws_payload": {
      "sub": "user123",
      "iat": 1640995200,
      "exp": 1641081600,
      "scope": "read write"
    },
    "jws_verified": true,
    "jws_algorithm": "RS256"
  },
  "execution_time_ms": 12.3,
  "policy_name": "VerifyJWT"
}
```

**Error Response**:
```json
{
  "success": false,
  "message": "JWS verification failed: Token has expired",
  "status_code": 401,
  "continue_processing": false,
  "terminate_request": true,
  "execution_time_ms": 8.7,
  "policy_name": "VerifyJWT"
}
```

### 6. Condition Policy

**Endpoint**: `POST /policies/assert-condition`

**Request**:
```json
{
  "method": "GET",
  "path": "/api/admin/users",
  "headers": {
    "Authorization": "Bearer token123"
  },
  "policy_name": "CheckAdminAccess",
  "policy_type": "assert_condition",
  "policy_config": {
    "operation": "assert",
    "condition": "user_role == 'admin' and user_status == 'active'",
    "failure_message": "Access denied: Admin privileges required",
    "failure_status_code": 403
  },
  "variables": {
    "user_role": "user",
    "user_status": "active"
  }
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "Condition assertion passed",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "condition_result": true
  },
  "execution_time_ms": 1.5,
  "policy_name": "CheckAdminAccess"
}
```

**Failure Response**:
```json
{
  "success": false,
  "message": "Access denied: Admin privileges required",
  "status_code": 403,
  "continue_processing": false,
  "terminate_request": true,
  "variables": {
    "condition_result": false
  },
  "execution_time_ms": 1.2,
  "policy_name": "CheckAdminAccess"
}
```

### 7. Data Transformation Policy

**Endpoint**: `POST /policies/xml-to-json`

**Request**:
```json
{
  "method": "POST",
  "path": "/api/convert",
  "headers": {
    "Content-Type": "application/xml"
  },
  "body": "<?xml version=\"1.0\"?>\n<user>\n  <id>123</id>\n  <name>John Doe</name>\n  <email>john@example.com</email>\n</user>",
  "policy_name": "ConvertXMLToJSON",
  "policy_type": "xml_to_json",
  "policy_config": {
    "source": "request_body",
    "destination": "response_body",
    "pretty_print": true
  }
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "XML to JSON transformation completed",
  "headers": {
    "Content-Type": "application/json"
  },
  "body": "{\n  \"user\": {\n    \"id\": \"123\",\n    \"name\": \"John Doe\",\n    \"email\": \"john@example.com\"\n  }\n}",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "transformation_completed": true
  },
  "execution_time_ms": 8.4,
  "policy_name": "ConvertXMLToJSON"
}
```

### 8. Message Logging Policy

**Endpoint**: `POST /policies/message-logging`

**Request**:
```json
{
  "method": "POST",
  "path": "/api/users",
  "headers": {
    "Content-Type": "application/json"
  },
  "body": "{\"name\": \"John Doe\"}",
  "policy_name": "LogUserCreation",
  "policy_type": "message_logging",
  "policy_config": {
    "operation": "log",
    "log_level": "INFO",
    "log_file": "user_operations.log",
    "message_template": "User creation attempt: {method} {path} from {client_ip} - Body: {body}",
    "message": "User creation logged"
  },
  "client_ip": "192.168.1.100"
}
```

**Success Response**:
```json
{
  "success": true,
  "message": "Message logged successfully",
  "continue_processing": true,
  "terminate_request": false,
  "variables": {
    "message_logged": true,
    "log_file": "user_operations.log",
    "log_level": "INFO"
  },
  "execution_time_ms": 3.2,
  "policy_name": "LogUserCreation"
}
```

## 🔗 Kong Integration Examples

### Kong HTTP Service Plugin Configuration

```bash
# Add the microservice as an upstream
curl -X POST http://kong:8001/upstreams \
  --data "name=apigee-policy-service"

curl -X POST http://kong:8001/upstreams/apigee-policy-service/targets \
  --data "target=apigee-policy-service:8080"

# Create service
curl -X POST http://kong:8001/services \
  --data "name=apigee-policies" \
  --data "host=apigee-policy-service" \
  --data "port=8080"
```

### Custom Kong Plugin Integration

```lua
-- Example Kong plugin that calls the microservice
local http = require "resty.http"
local cjson = require "cjson"

local function call_policy_service(policy_type, policy_config)
  local httpc = http.new()
  
  local request_body = {
    method = kong.request.get_method(),
    path = kong.request.get_path(),
    headers = kong.request.get_headers(),
    query_params = kong.request.get_query(),
    body = kong.request.get_raw_body(),
    policy_name = policy_config.name,
    policy_type = policy_type,
    policy_config = policy_config,
    variables = kong.ctx.shared.variables or {},
    client_ip = kong.client.get_ip()
  }
  
  local res, err = httpc:request_uri(
    "http://apigee-policy-service:8080/policies/" .. policy_type,
    {
      method = "POST",
      body = cjson.encode(request_body),
      headers = {
        ["Content-Type"] = "application/json"
      }
    }
  )
  
  if res and res.status == 200 then
    local response = cjson.decode(res.body)
    
    -- Handle response
    if not response.success then
      kong.response.exit(
        response.status_code or 500,
        { message = response.message }
      )
    end
    
    -- Update variables
    if response.variables then
      kong.ctx.shared.variables = response.variables
    end
    
    -- Add headers
    if response.headers then
      for k, v in pairs(response.headers) do
        kong.response.set_header(k, v)
      end
    end
  end
end
```

## 📊 Error Handling

### Standard Error Response Format

```json
{
  "success": false,
  "message": "Error description",
  "status_code": 400,
  "continue_processing": false,
  "terminate_request": true,
  "execution_time_ms": 5.2,
  "policy_name": "PolicyName"
}
```

### Common Error Scenarios

1. **Policy Handler Not Found** (404):
```json
{
  "error": true,
  "status_code": 404,
  "message": "Policy handler not found for type: invalid_policy",
  "path": "/policies/invalid_policy"
}
```

2. **Validation Error** (422):
```json
{
  "error": true,
  "status_code": 422,
  "message": "Validation error",
  "details": [
    {
      "field": "policy_name",
      "message": "field required"
    }
  ]
}
```

3. **Internal Server Error** (500):
```json
{
  "error": true,
  "status_code": 500,
  "message": "Internal server error",
  "request_id": "req-123-456"
}
```

## 🎯 Best Practices

### Request Optimization
- Include only necessary headers and variables
- Use appropriate timeout values
- Provide meaningful policy names for debugging

### Response Handling
- Always check the `success` field
- Handle `terminate_request` flag appropriately
- Use `variables` for passing data between policies
- Monitor `execution_time_ms` for performance

### Error Recovery
- Implement retry logic for transient failures
- Use circuit breakers for external service calls
- Log policy execution results for debugging