#!/usr/bin/env python3
"""
Structure Validation Script
===========================

Validates the microservice structure without requiring external dependencies.
"""

import os
import sys
from pathlib import Path


def check_file_exists(file_path: str, description: str) -> bool:
    """Check if a file exists."""
    if Path(file_path).exists():
        print(f"✅ {description}: {file_path}")
        return True
    else:
        print(f"❌ {description}: {file_path} (missing)")
        return False


def check_directory_exists(dir_path: str, description: str) -> bool:
    """Check if a directory exists."""
    if Path(dir_path).is_dir():
        print(f"✅ {description}: {dir_path}")
        return True
    else:
        print(f"❌ {description}: {dir_path} (missing)")
        return False


def validate_python_syntax(file_path: str) -> bool:
    """Validate Python file syntax."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        compile(content, file_path, 'exec')
        print(f"✅ Syntax valid: {file_path}")
        return True
    except SyntaxError as e:
        print(f"❌ Syntax error in {file_path}: {e}")
        return False
    except Exception as e:
        print(f"⚠️  Could not validate {file_path}: {e}")
        return False


def main():
    """Main validation function."""
    print("🔍 Validating Apigee Policy Microservice Structure")
    print("=" * 50)
    
    all_good = True
    
    # Core files
    core_files = [
        ("main.py", "Main application file"),
        ("start.py", "Startup script"),
        ("requirements.txt", "Python dependencies"),
        ("Dockerfile", "Docker configuration"),
        ("docker-compose.yml", "Docker Compose configuration"),
        (".env.example", "Environment configuration example"),
        ("README.md", "Documentation"),
        ("Makefile", "Build automation"),
        ("pytest.ini", "Test configuration")
    ]
    
    print("\n📁 Core Files:")
    for file_path, description in core_files:
        if not check_file_exists(file_path, description):
            all_good = False
    
    # Core directories
    core_dirs = [
        ("core", "Core modules"),
        ("policies", "Policy handlers"),
        ("tests", "Test files")
    ]
    
    print("\n📂 Core Directories:")
    for dir_path, description in core_dirs:
        if not check_directory_exists(dir_path, description):
            all_good = False
    
    # Core module files
    core_module_files = [
        ("core/__init__.py", "Core package init"),
        ("core/config.py", "Configuration management"),
        ("core/logger.py", "Logging setup"),
        ("core/middleware.py", "Custom middleware"),
        ("core/models.py", "Data models"),
        ("core/metrics.py", "Metrics collection")
    ]
    
    print("\n🔧 Core Module Files:")
    for file_path, description in core_module_files:
        if not check_file_exists(file_path, description):
            all_good = False
    
    # Policy handler files
    policy_files = [
        ("policies/__init__.py", "Policies package init"),
        ("policies/base_handler.py", "Base policy handler"),
        ("policies/javascript_handler.py", "JavaScript policy handler"),
        ("policies/java_callout_handler.py", "Java callout handler"),
        ("policies/service_callout_handler.py", "Service callout handler"),
        ("policies/kvm_handler.py", "KVM operations handler"),
        ("policies/raise_fault_handler.py", "Raise fault handler"),
        ("policies/threat_protection_handler.py", "Threat protection handler"),
        ("policies/data_transformation_handler.py", "Data transformation handler"),
        ("policies/saml_handler.py", "SAML handler"),
        ("policies/jws_handler.py", "JWS handler"),
        ("policies/message_handler.py", "Message handler"),
        ("policies/condition_handler.py", "Condition handler"),
        ("policies/entity_handler.py", "Entity handler")
    ]
    
    print("\n🛡️  Policy Handler Files:")
    for file_path, description in policy_files:
        if not check_file_exists(file_path, description):
            all_good = False
    
    # Test files
    test_files = [
        ("tests/__init__.py", "Tests package init"),
        ("tests/test_main.py", "Main application tests"),
        ("tests/test_policies.py", "Policy handler tests")
    ]
    
    print("\n🧪 Test Files:")
    for file_path, description in test_files:
        if not check_file_exists(file_path, description):
            all_good = False
    
    # Validate Python syntax for key files
    python_files_to_validate = [
        "main.py",
        "start.py",
        "core/config.py",
        "core/models.py",
        "policies/base_handler.py"
    ]
    
    print("\n🐍 Python Syntax Validation:")
    for file_path in python_files_to_validate:
        if Path(file_path).exists():
            if not validate_python_syntax(file_path):
                all_good = False
    
    # Summary
    print("\n" + "=" * 50)
    if all_good:
        print("🎉 All checks passed! Microservice structure is complete.")
        print("\n📋 Next Steps:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Copy environment config: cp .env.example .env")
        print("3. Start the service: python start.py")
        print("4. Run tests: pytest")
        return 0
    else:
        print("⚠️  Some issues found. Please review the missing files above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())