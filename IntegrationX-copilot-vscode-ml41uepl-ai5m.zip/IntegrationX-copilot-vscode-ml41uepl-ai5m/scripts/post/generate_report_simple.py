#!/usr/bin/env python3
"""
Simple Migration Report Generator
"""

import json
from datetime import datetime

def generate_migration_report(api_data, migrated_plugins, validation_result):
    """Generate simple migration report"""
    report = {
        "migration_summary": {
            "api_name": api_data.get('api_name', 'unknown'),
            "migration_date": datetime.now().isoformat(),
            "total_policies": len(api_data.get('policies', [])),
            "total_plugins": sum(len(plugins) for plugins in migrated_plugins.values())
        },
        "plugin_breakdown": {
            "request": len(migrated_plugins.get('request', [])),
            "response": len(migrated_plugins.get('response', [])),
            "both": len(migrated_plugins.get('both', []))
        },
        "validation": validation_result
    }
    
    return report