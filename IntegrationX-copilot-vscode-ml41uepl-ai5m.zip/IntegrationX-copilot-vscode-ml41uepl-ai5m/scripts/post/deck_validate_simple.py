#!/usr/bin/env python3
"""
Simple Kong Configuration Validator
"""

def validate_kong_config(kong_config):
    """Simple Kong configuration validation"""
    validation_result = {
        "valid": True,
        "errors": [],
        "warnings": []
    }
    
    # Basic validation
    if not kong_config.get('services'):
        validation_result["errors"].append("No services defined")
        validation_result["valid"] = False
    
    if not kong_config.get('_format_version'):
        validation_result["warnings"].append("No format version specified")
    
    return validation_result