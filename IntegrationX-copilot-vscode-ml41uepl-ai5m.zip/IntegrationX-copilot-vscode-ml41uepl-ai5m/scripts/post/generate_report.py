import os
import logging
from jinja2 import Environment, FileSystemLoader
from datetime import datetime
import base64
from io import BytesIO

# Matplotlib is an optional dependency for generating charts.
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

from .report_data import ReportData

# Generates a bar chart for the summary section.
def create_summary_chart(apigee_counts, kong_counts):
    if not plt:
        logging.warning("Matplotlib not found, skipping chart generation. To enable charts, run 'pip install matplotlib'.")
        return None

    x = range(len(labels))
    width = 0.35

    fig, ax = plt.subplots()
    rects1 = ax.bar(x, apigee_values, width, label='Apigee')
    rects2 = ax.bar([p + width for p in x], kong_values, width, label='Kong')

    ax.set_ylabel('Count')
    ax.set_title('Apigee vs. Kong Entity Count')
    ax.set_xticks([p + width / 2 for p in x])
    ax.set_xticklabels(labels)
    ax.legend()

    # Save it to a temporary buffer.
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    # Encode the image to base64 to embed in HTML
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return image_base64

# Orchestrates the generation of the HTML report.
def generate_report():
    logging.info("--- Generating HTML Migration Report ---")
    report_data = ReportData()
    api_name = os.environ.get("api_name", "unknown-api")
    output_dir = os.environ.get("output_dir")

    if not output_dir:
        logging.error("Output directory not configured. Cannot generate report.")
        return

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_dir = os.path.join(project_root, "configs")
    
    # Prepare data for the template
    apigee_counts = {k: len(v) for k, v in report_data.apigee_entities.items()}
    kong_counts = {k: len(v) for k, v in report_data.kong_entities.items()}
    
    total_apigee = sum(apigee_counts.values())
    total_kong = sum(kong_counts.values())
    efficiency = (total_kong / total_apigee * 100) if total_apigee > 0 else 0

    template_data = {
        "api_name": api_name,
        "report_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_time_taken": f"{report_data.end_time - report_data.start_time:.2f}",
        "efficiency_score": f"{efficiency:.2f}",
        "apigee_counts": apigee_counts,
        "kong_counts": kong_counts,
        "mappings": report_data.mappings,
        "unmapped_entities": report_data.unmapped_entities,
        "summary_chart_base64": create_summary_chart(apigee_counts, kong_counts)
    }

    # Render the HTML template
    try:
        env = Environment(loader=FileSystemLoader(template_dir))
        template = env.get_template("report_template.html")
        html_out = template.render(template_data)
    except Exception as e:
        logging.error(f"Failed to render report template: {e}")
        return

    # Generate the HTML file
    try:
        report_filename = f"{api_name}-migration-report.html"
        # Create API-specific directory path
        api_output_dir = os.path.join(project_root, output_dir, api_name)
        os.makedirs(api_output_dir, exist_ok=True)
        report_path = os.path.join(api_output_dir, report_filename)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_out)
        logging.info(f"Successfully generated HTML report: {report_path}")
    except Exception as e:
        logging.error(f"Failed to write HTML report file: {e}")