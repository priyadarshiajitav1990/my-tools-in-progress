from collections import defaultdict

# A singleton class to hold all migration report data.
class ReportData:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ReportData, cls).__new__(cls)
            cls._instance.apigee_entities = defaultdict(list)
            cls._instance.kong_entities = defaultdict(list)
            cls._instance.mappings = []
            cls._instance.unmapped_entities = []
            cls._instance.start_time = 0
            cls._instance.end_time = 0
        return cls._instance

    def add_apigee_entity(self, entity_type, name):
        if name not in self.apigee_entities[entity_type]:
            self.apigee_entities[entity_type].append(name)

    def add_kong_entity(self, entity_type, name):
        if name not in self.kong_entities[entity_type]:
            self.kong_entities[entity_type].append(name)

    def add_mapping(self, apigee_type, apigee_name, kong_type, kong_name):
        self.mappings.append({
            "apigee_type": apigee_type,
            "apigee_name": apigee_name,
            "kong_type": kong_type,
            "kong_name": kong_name,
        })

    def add_unmapped_entity(self, entity_type, name, reason):
        self.unmapped_entities.append({
            "type": entity_type,
            "name": name,
            "reason": reason,
        })