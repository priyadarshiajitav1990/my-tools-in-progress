#!/usr/bin/env python3
"""
Enhanced Apigee to Kong Migration Tool
Production-ready migration with resource file conversion and advanced plugin mapping
"""

import sys
import os
import json
from pathlib import Path

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent / "scripts"))

from scripts.pre.extract_apigee_api import extract_apigee_api
from scripts.core.enhanced_policy_migration_simple import migrate_policies
from scripts.utils.resource_converter import ResourceConverter

def load_config():
    """Load configuration"""
    config_file = Path("configs/config.json")
    if config_file.exists():
        with open(config_file, 'r') as f:
            return json.load(f)
    return {}

def main():
    """Main migration workflow"""
    print("Enhanced Apigee to Kong Migration Tool")
    print("=" * 50)
    
    try:
        # Load configuration
        config = load_config()
        
        # Mock API data for testing
        api_data = {
            'api_name': 'test-api',
            'policies': [
                {'name': 'test-policy', 'policyType': 'AssertCondition', 'condition': 'request.method == "GET"'},
                {'name': 'auth-policy', 'policyType': 'VerifyAPIKey'},
                {'name': 'log-policy', 'policyType': 'DataCapture'}
            ],
            'resources': {},
            'target_url': 'http://backend.example.com',
            'paths': ['/api/v1'],
            'methods': ['GET', 'POST']
        }
        
        # Step 2: Enhanced Policy Migration
        print("Migrating policies with resource conversion...")
        migrated_plugins = migrate_policies(
            api_data.get('policies', []),
            api_data.get('resources', {}),
            api_data.get('api_name', 'unknown'),
            config
        )
        
        # Step 3: Generate Kong Configuration
        print("Generating Kong configuration...")
        kong_config = generate_kong_config(api_data, migrated_plugins, config)
        
        # Step 4: Save output
        api_name = api_data.get('api_name', 'unknown-api')
        output_dir = Path("output") / api_name
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"kong-{api_name}.json"
        with open(output_file, 'w') as f:
            json.dump(kong_config, f, indent=2)
        
        print("Migration completed successfully!")
        print(f"Output: {output_file}")
        print(f"Migrated {len(api_data['policies'])} policies")
        
        # Show summary
        total_plugins = sum(len(plugins) for plugins in migrated_plugins.values())
        print(f"Generated {total_plugins} Kong plugins")
        
    except Exception as e:
        print(f"Migration failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def generate_kong_config(api_data, migrated_plugins, config):
    """Generate Kong configuration from migrated data"""
    kong_config = {
        "_format_version": "3.0",
        "services": [{
            "name": api_data.get('api_name', 'migrated-api'),
            "url": api_data.get('target_url', 'http://backend.example.com'),
            "routes": [{
                "name": f"{api_data.get('api_name', 'migrated-api')}-route",
                "paths": api_data.get('paths', ['/api']),
                "methods": api_data.get('methods', ['GET', 'POST'])
            }],
            "plugins": []
        }]
    }
    
    # Add plugins to service
    all_plugins = []
    for flow in ['request', 'both', 'response']:
        all_plugins.extend(migrated_plugins.get(flow, []))
    
    kong_config["services"][0]["plugins"] = all_plugins
    
    return kong_config

if __name__ == "__main__":
    main()