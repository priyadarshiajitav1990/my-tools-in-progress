import os
import zipfile
import sys
import logging
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Any, Optional, List

# Finds a zip file in the input directory, derives and returns the API name and zip path.
def find_zip_and_get_api_name(project_root, input_dir_name):
    input_dir_path = os.path.join(project_root, input_dir_name)
    logging.info(f"Searching for zip files in '{input_dir_path}'...")

    if not os.path.isdir(input_dir_path):
        logging.error(f"Input directory '{input_dir_path}' not found.")
        return None, None

    for filename in os.listdir(input_dir_path):
        if filename.endswith(".zip"):
            print(f"Found zip file: {filename}")
            base_name = os.path.splitext(filename)[0]
            
            # Remove '_rev' and anything after it to get the api_name
            if '_rev' in base_name:
                api_name = base_name.split('_rev')[0]
            else:
                api_name = base_name

            logging.info(f"Derived API name: {api_name}")
            return os.path.join(input_dir_path, filename), api_name
            
    logging.warning("No zip file found in the input directory.")
    return None, None


# Creates a directory for the API and extracts the zip file into it.
def extract_zip_to_api_dir(project_root, zip_file_path, api_name, base_extract_dir_name):
    if not api_name or not zip_file_path:
        logging.error("Cannot extract, missing API name or zip file path.")
        return

    extract_path = os.path.join(project_root, base_extract_dir_name, api_name)
    logging.info(f"Creating directory: '{extract_path}'")
    os.makedirs(extract_path, exist_ok=True)

    logging.info(f"Extracting '{os.path.basename(zip_file_path)}' to '{extract_path}'...")
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    logging.info("Extraction complete.")
    return extract_path

def parse_apigee_proxy_xml(xml_file_path: str) -> Dict[str, Any]:
    """Parse Apigee proxy XML file and extract configuration"""
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
        
        proxy_data = {
            'name': root.get('name', 'unknown'),
            'revision': root.get('revision', '1'),
            'proxy_endpoints': [],
            'target_endpoints': [],
            'policies': [],
            'resources': {}
        }
        
        # Extract proxy endpoints
        for pe in root.findall('.//ProxyEndpoint'):
            proxy_data['proxy_endpoints'].append(pe.text)
        
        # Extract target endpoints
        for te in root.findall('.//TargetEndpoint'):
            proxy_data['target_endpoints'].append(te.text)
        
        # Extract policies
        for policy in root.findall('.//Policy'):
            proxy_data['policies'].append(policy.text)
        
        # Extract resources
        for resource in root.findall('.//Resource'):
            proxy_data['resources'][resource.text] = resource.text
        
        return proxy_data
        
    except Exception as e:
        logging.error(f"Error parsing proxy XML {xml_file_path}: {e}")
        return {}

def parse_policy_xml(policy_file_path: str) -> Dict[str, Any]:
    """Parse individual policy XML file"""
    try:
        tree = ET.parse(policy_file_path)
        root = tree.getroot()
        
        policy_data = {
            'name': root.get('name', os.path.basename(policy_file_path).replace('.xml', '')),
            'policyType': root.tag,
            'enabled': root.get('enabled', 'true').lower() == 'true',
            'config': {}
        }
        
        # Extract policy configuration
        for child in root:
            if child.tag not in ['DisplayName', 'FaultRules']:
                policy_data['config'][child.tag] = child.text or {}
        
        return policy_data
        
    except Exception as e:
        logging.error(f"Error parsing policy XML {policy_file_path}: {e}")
        return {}

def parse_endpoint_xml(endpoint_file_path: str) -> Dict[str, Any]:
    """Parse proxy or target endpoint XML file"""
    try:
        tree = ET.parse(endpoint_file_path)
        root = tree.getroot()
        
        endpoint_data = {
            'name': root.get('name', os.path.basename(endpoint_file_path).replace('.xml', '')),
            'flows': [],
            'target_url': None,
            'paths': [],
            'methods': []
        }
        
        # Extract flows
        for flow in root.findall('.//Flow'):
            flow_data = {
                'name': flow.get('name', 'default'),
                'condition': flow.findtext('Condition', ''),
                'request_policies': [],
                'response_policies': []
            }
            
            # Extract request policies
            request = flow.find('Request')
            if request is not None:
                for step in request.findall('Step'):
                    policy_name = step.findtext('Name')
                    if policy_name:
                        flow_data['request_policies'].append(policy_name)
            
            # Extract response policies
            response = flow.find('Response')
            if response is not None:
                for step in response.findall('Step'):
                    policy_name = step.findtext('Name')
                    if policy_name:
                        flow_data['response_policies'].append(policy_name)
            
            endpoint_data['flows'].append(flow_data)
        
        # Extract target URL (for target endpoints)
        target_url = root.findtext('.//URL')
        if target_url:
            endpoint_data['target_url'] = target_url
        
        # Extract paths and methods (for proxy endpoints)
        for path in root.findall('.//Path'):
            if path.text:
                endpoint_data['paths'].append(path.text)
        
        for verb in root.findall('.//Verb'):
            if verb.text:
                endpoint_data['methods'].append(verb.text)
        
        return endpoint_data
        
    except Exception as e:
        logging.error(f"Error parsing endpoint XML {endpoint_file_path}: {e}")
        return {}

def read_resource_file(resource_file_path: str) -> str:
    """Read resource file content"""
    try:
        with open(resource_file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        logging.error(f"Error reading resource file {resource_file_path}: {e}")
        return ""

def extract_apigee_api(zip_file_path: str) -> Optional[Dict[str, Any]]:
    """Extract and parse Apigee API from zip file"""
    try:
        # Derive API name from zip file
        zip_path = Path(zip_file_path)
        base_name = zip_path.stem
        
        if '_rev' in base_name:
            api_name = base_name.split('_rev')[0]
        else:
            api_name = base_name
        
        # Create temporary extraction directory
        project_root = zip_path.parent.parent
        extract_dir = project_root / "extracted-apigee-apis" / api_name
        extract_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract zip file
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        
        # Find and parse main proxy XML
        proxy_xml_files = list(extract_dir.glob("**/*.xml"))
        main_proxy_xml = None
        
        for xml_file in proxy_xml_files:
            if xml_file.name.endswith('.xml') and 'apiproxy' in xml_file.parent.name.lower():
                main_proxy_xml = xml_file
                break
        
        if not main_proxy_xml:
            # Look for any XML file that might be the main proxy
            for xml_file in proxy_xml_files:
                if api_name.lower() in xml_file.name.lower():
                    main_proxy_xml = xml_file
                    break
        
        if not main_proxy_xml and proxy_xml_files:
            main_proxy_xml = proxy_xml_files[0]
        
        if not main_proxy_xml:
            logging.error(f"No proxy XML file found in {zip_file_path}")
            return None
        
        # Parse main proxy configuration
        proxy_data = parse_apigee_proxy_xml(str(main_proxy_xml))
        if not proxy_data:
            logging.error(f"Failed to parse proxy XML from {zip_file_path}")
            return None
        
        # Build comprehensive API data
        api_data = {
            'api_name': api_name,
            'proxy_name': proxy_data.get('name', api_name),
            'revision': proxy_data.get('revision', '1'),
            'policies': [],
            'resources': {},
            'proxy_endpoints': [],
            'target_endpoints': [],
            'target_url': 'http://backend.example.com',
            'paths': ['/api'],
            'methods': ['GET', 'POST']
        }
        
        # Parse policies
        policies_dir = extract_dir / "policies"
        if policies_dir.exists():
            for policy_file in policies_dir.glob("*.xml"):
                policy_data = parse_policy_xml(str(policy_file))
                if policy_data:
                    api_data['policies'].append(policy_data)
        
        # Parse proxy endpoints
        proxies_dir = extract_dir / "proxies"
        if proxies_dir.exists():
            for endpoint_file in proxies_dir.glob("*.xml"):
                endpoint_data = parse_endpoint_xml(str(endpoint_file))
                if endpoint_data:
                    api_data['proxy_endpoints'].append(endpoint_data)
                    # Extract paths and methods from first proxy endpoint
                    if endpoint_data.get('paths'):
                        api_data['paths'] = endpoint_data['paths']
                    if endpoint_data.get('methods'):
                        api_data['methods'] = endpoint_data['methods']
        
        # Parse target endpoints
        targets_dir = extract_dir / "targets"
        if targets_dir.exists():
            for endpoint_file in targets_dir.glob("*.xml"):
                endpoint_data = parse_endpoint_xml(str(endpoint_file))
                if endpoint_data:
                    api_data['target_endpoints'].append(endpoint_data)
                    # Extract target URL from first target endpoint
                    if endpoint_data.get('target_url'):
                        api_data['target_url'] = endpoint_data['target_url']
        
        # Parse resources
        resources_dir = extract_dir / "resources"
        if resources_dir.exists():
            for resource_type_dir in resources_dir.iterdir():
                if resource_type_dir.is_dir():
                    for resource_file in resource_type_dir.rglob("*"):
                        if resource_file.is_file():
                            resource_key = f"{resource_type_dir.name}://{resource_file.name}"
                            api_data['resources'][resource_key] = read_resource_file(str(resource_file))
        
        # Ensure we have some default policies if none found
        if not api_data['policies']:
            api_data['policies'] = [
                {
                    'name': 'default-verify-api-key',
                    'policyType': 'VerifyAPIKey',
                    'enabled': True,
                    'config': {'APIKey': {'ref': 'request.header.x-api-key'}}
                }
            ]
        
        logging.info(f"Successfully extracted API: {api_name} with {len(api_data['policies'])} policies")
        return api_data
        
    except Exception as e:
        logging.error(f"Error extracting Apigee API from {zip_file_path}: {e}")
        return None

# Legacy function for backward compatibility
def extract_apigee_api_legacy():
    """Legacy extraction function using environment variables"""
    logging.info("--- Starting Apigee API Extraction ---")
    # Get config values from environment variables
    input_dir = os.environ.get("input_dir")
    extracted_api_dir = os.environ.get("extracted_api_dir")

    if not all([input_dir, extracted_api_dir]):
        logging.error("Missing required configuration (input_dir, extracted_api_dir).")
        return

    # Correctly calculate project root from scripts/pre/extract_apigee_api.py
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(os.path.dirname(current_dir))

    zip_path, api_name = find_zip_and_get_api_name(project_root, input_dir)

    if zip_path and api_name:
        # Set the derived api_name as an environment variable for other scripts to use
        os.environ['api_name'] = api_name
        logging.info(f"  - Set environment variable: api_name")
        extract_zip_to_api_dir(project_root, zip_path, api_name, extracted_api_dir)