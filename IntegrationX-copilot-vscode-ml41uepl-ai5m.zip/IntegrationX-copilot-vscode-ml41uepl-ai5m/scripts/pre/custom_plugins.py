#!/usr/bin/env python3
import os
import subprocess
import time
import json
import requests

PLUGIN_SRC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../customplugins'))
SSH_KEY = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../configs/coforge-ssh.pem'))
KONG_HOST = '44.213.128.41'
KONG_USER = 'ec2-user'
KONG_PLUGIN_DIR = '/usr/local/share/lua/5.1/kong/plugins'
KONG_SERVICE = 'kong'
KONG_ADMIN_API = 'http://44.213.128.41:8001'
COMMAND_TIMEOUT = 60

def run_ssh(cmd, check=True, capture_output=False):
    ssh_cmd = ['ssh', '-i', SSH_KEY, f'{KONG_USER}@{KONG_HOST}', cmd]
    try:
        return subprocess.run(ssh_cmd, check=check, capture_output=capture_output, text=True, timeout=COMMAND_TIMEOUT)
    except subprocess.TimeoutExpired:
        print(f"SSH command timed out: {' '.join(ssh_cmd)}")
        raise

def run_scp(src, dest):
    scp_cmd = ['scp', '-i', SSH_KEY, '-r', src, f'{KONG_USER}@{KONG_HOST}:{dest}']
    try:
        subprocess.run(scp_cmd, check=True, timeout=COMMAND_TIMEOUT)
    except subprocess.TimeoutExpired:
        print(f"SCP command timed out: {' '.join(scp_cmd)}")
        raise

def restart_kong():
    print("Restarting Kong...")
    run_ssh(f'sudo systemctl restart {KONG_SERVICE}')
    for _ in range(5):
        time.sleep(2)
        if kong_healthy():
            print("Kong is healthy.")
            return
    print("Kong did not become healthy after restart.")

def kong_healthy():
    try:
        r = requests.get(f'{KONG_ADMIN_API}/status', timeout=5)
        return r.status_code == 200 and r.json().get('database', {}).get('reachable', False)
    except Exception as e:
        print(f"Kong health check failed: {e}")
        return False

def get_kong_error_log():
    result = run_ssh('sudo tail -n 50 /usr/local/kong/logs/error.log', check=False, capture_output=True)
    return result.stdout if result.stdout else result.stderr
    
def check_plugin_available(plugin_name):
    try:
        r = requests.get(f'{KONG_ADMIN_API}/', timeout=5)
        if r.status_code == 200:
            available_plugins = r.json().get('plugins', {}).get('available_on_server', {})
            return plugin_name in available_plugins
    except Exception as e:
        print(f"Could not check for available plugins: {e}")
    return False

def luarocks_install(plugin_dir, plugin_name):
    plugin_name_lower = plugin_name.lower()
    rockspec_file = f'{plugin_name_lower}-1.0-1.rockspec'
    remote_dir = f'/tmp/{plugin_name_lower}'

    print(f"  - Cleaning up previous installations for {plugin_name_lower} on Kong node...")
    run_ssh(f'sudo rm -rf {remote_dir}')
    run_ssh(f'sudo rm -rf {KONG_PLUGIN_DIR}/{plugin_name_lower}', check=False)
    run_ssh(f'sudo luarocks remove {plugin_name_lower}', check=False)

    print(f"  - Copying plugin files to {remote_dir}...")
    run_ssh(f'mkdir -p {remote_dir}')
    run_scp(os.path.join(PLUGIN_SRC_DIR, plugin_dir), f'{KONG_USER}@{KONG_HOST}:/tmp/')
    # Rename folder on remote
    run_ssh(f'mv /tmp/{plugin_dir} {remote_dir}')

    print(f"  - Building and installing with LuaRocks...")
    # Find the rockspec file, assuming one exists
    rockspec_find_cmd = f'find {remote_dir} -name "kong-plugin-*.rockspec" -print -quit'
    rockspec_path = run_ssh(rockspec_find_cmd, capture_output=True).stdout.strip()
    run_ssh(f'cd {remote_dir} && sudo luarocks make {os.path.basename(rockspec_path)}')
    
    # Copy to Kong plugin dir and set ownership
    run_ssh(f'sudo cp -r {remote_dir}/* {KONG_PLUGIN_DIR}/{plugin_name_lower}/')
    run_ssh(f'sudo chown -R kong:kong {KONG_PLUGIN_DIR}/{plugin_name_lower}')

def luarocks_uninstall(plugin_name):
    plugin_name_lower = plugin_name.lower()
    run_ssh(f'sudo rm -rf {KONG_PLUGIN_DIR}/{plugin_name_lower}')
    run_ssh(f'sudo luarocks remove {plugin_name_lower}', check=False)

def main():
    print("Installing cjson dependency...")
    run_ssh('sudo luarocks install cjson', check=False)

    plugin_dirs = [d for d in os.listdir(PLUGIN_SRC_DIR) if os.path.isdir(os.path.join(PLUGIN_SRC_DIR, d))]
    passed = []
    failed = []
    
    # Get existing plugins from Kong config
    kong_conf_plugins = run_ssh("sudo grep -E '^\\s*plugins\\s*=' /etc/kong/kong.conf | sed 's/plugins\\s*=\\s*//'", capture_output=True).stdout.strip()
    enabled_plugins = set(p.strip() for p in kong_conf_plugins.split(','))

    for plugin_dir in plugin_dirs:
        # Assumes schema.lua contains the correct plugin name, e.g., "custom-assign-message"
        plugin_name = plugin_dir
        print(f'\n=== Deploying plugin: {plugin_name} ===')
        try:
            luarocks_install(plugin_dir, plugin_name)
            
            # Add plugin to Kong configuration if not already present
            if plugin_name not in enabled_plugins:
                print(f"  - Enabling '{plugin_name}' in kong.conf...")
                new_plugins_list = ",".join(list(enabled_plugins) + [plugin_name])
                run_ssh(f"sudo sed -i 's/^plugins = .*/plugins = {new_plugins_list}/' /etc/kong/kong.conf")
                enabled_plugins.add(plugin_name)

            restart_kong()

            if not kong_healthy():
                print(f'ERROR: Kong unhealthy after deploying {plugin_name}. Checking error log...')
                log = get_kong_error_log()
                print(log)
                failed.append(plugin_name)
                # Stop processing further plugins on failure
                break

            if check_plugin_available(plugin_name):
                print(f'SUCCESS: Plugin {plugin_name} is available on the server.')
                passed.append(plugin_name)
            else:
                print(f'FAILURE: Plugin {plugin_name} was deployed, but is not available on the server.')
                failed.append(plugin_name)
        except Exception as e:
            print(f'Exception during deployment of {plugin_name}: {e}')
            failed.append(plugin_name)
    
    print('\n=== Deployment Summary ===')
    print('Passed:', passed)
    print('Failed:', failed)

if __name__ == '__main__':
    main()
