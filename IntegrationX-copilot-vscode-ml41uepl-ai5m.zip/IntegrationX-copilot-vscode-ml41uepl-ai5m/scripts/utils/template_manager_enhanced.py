#!/usr/bin/env python3
"""
Enhanced Template Manager
Dynamic template loading and configuration for Kong plugins
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List
from jinja2 import Environment, FileSystemLoader, Template, TemplateNotFound

class EnhancedTemplateManager:
    def __init__(self, templates_dir: Path):
        self.logger = logging.getLogger(__name__)
        self.templates_dir = Path(templates_dir)
        self.custom_plugins_dir = self.templates_dir / "custom-plugins"
        
        # Initialize Jinja2 environment
        self.env = Environment(
            loader=FileSystemLoader([str(self.templates_dir), str(self.custom_plugins_dir)]),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Add custom filters
        self.env.filters['to_json'] = json.dumps
        self.env.filters['safe_string'] = self._safe_string_filter
        self.env.filters['indent_lua'] = self._indent_lua_filter
        
        # Template cache
        self._template_cache = {}
        
        # Load template configurations
        self._load_template_configs()
    
    def render_plugin_template(self, plugin_name: str, context: Dict[str, Any], api_flow: str = "both") -> Optional[Dict[str, Any]]:
        """Render plugin template with given context"""
        try:
            template_name = f"{plugin_name}.yml.j2"
            
            # Try to load template
            template = self._get_template(template_name)
            if not template:
                self.logger.warning(f"Template not found for plugin: {plugin_name}")
                return self._generate_basic_plugin_config(plugin_name, context, api_flow)
            
            # Enhance context with common variables
            enhanced_context = self._enhance_context(context, plugin_name, api_flow)
            
            # Render template
            rendered_yaml = template.render(**enhanced_context)
            
            # Parse YAML to dict
            import yaml
            plugin_config = yaml.safe_load(rendered_yaml)
            
            # Post-process configuration
            processed_config = self._post_process_config(plugin_config, plugin_name, enhanced_context)
            
            return processed_config
            
        except Exception as e:
            self.logger.error(f"Template rendering failed for {plugin_name}: {e}")
            return self._generate_basic_plugin_config(plugin_name, context, api_flow)
    
    def _get_template(self, template_name: str) -> Optional[Template]:
        """Get template from cache or load from file"""
        if template_name in self._template_cache:
            return self._template_cache[template_name]
        
        try:
            template = self.env.get_template(template_name)
            self._template_cache[template_name] = template
            return template
        except TemplateNotFound:
            # Try alternative template names
            alternatives = self._get_alternative_template_names(template_name)
            for alt_name in alternatives:
                try:
                    template = self.env.get_template(alt_name)
                    self._template_cache[template_name] = template
                    return template
                except TemplateNotFound:
                    continue
            
            return None
    
    def _get_alternative_template_names(self, template_name: str) -> List[str]:
        """Get alternative template names to try"""
        base_name = template_name.replace('.yml.j2', '')
        alternatives = []
        
        # Try with different naming conventions
        alternatives.append(f"{base_name.replace('-', '_')}.yml.j2")
        alternatives.append(f"{base_name.replace('_', '-')}.yml.j2")
        
        # Try generic templates
        if base_name.startswith('custom-'):
            alternatives.append("custom-plugin-generic.yml.j2")
        
        alternatives.append("generic-plugin.yml.j2")
        
        return alternatives
    
    def _enhance_context(self, context: Dict[str, Any], plugin_name: str, api_flow: str) -> Dict[str, Any]:
        """Enhance context with common variables and utilities"""
        enhanced = context.copy()
        
        # Add plugin metadata
        enhanced['plugin_name'] = plugin_name
        enhanced['api_flow'] = api_flow
        enhanced['is_custom_plugin'] = self._is_custom_plugin(plugin_name)
        
        # Add utility functions
        enhanced['utils'] = {
            'safe_value': self._safe_value,
            'format_list': self._format_list,
            'extract_value': self._extract_value,
            'convert_boolean': self._convert_boolean
        }
        
        # Add Kong-specific helpers
        enhanced['kong'] = {
            'version': context.get('kong_version', '3.13.0.0'),
            'enterprise': self._is_enterprise_version(context.get('kong_version', '')),
            'supports_plugin': lambda p: self._check_plugin_support(p, context.get('kong_version', ''))
        }
        
        # Add Apigee context mapping
        if 'policy' in context:
            enhanced['apigee'] = self._map_apigee_context(context['policy'])
        
        return enhanced
    
    def _post_process_config(self, config: Dict[str, Any], plugin_name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Post-process plugin configuration"""
        if not config:
            return config
        
        # Ensure required fields
        if 'name' not in config:
            config['name'] = plugin_name
        
        if 'config' not in config:
            config['config'] = {}
        
        # Clean up None values
        config = self._clean_none_values(config)
        
        # Apply plugin-specific post-processing
        config = self._apply_plugin_specific_processing(config, plugin_name, context)
        
        # Validate configuration
        config = self._validate_plugin_config(config, plugin_name)
        
        return config
    
    def _apply_plugin_specific_processing(self, config: Dict[str, Any], plugin_name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Apply plugin-specific post-processing"""
        plugin_config = config.get('config', {})
        
        if plugin_name == 'luascriptexecuter':
            # Ensure script is present
            if 'script' not in plugin_config or not plugin_config['script']:
                plugin_config['script'] = self._generate_default_lua_script(context)
            
            # Set default timeout
            if 'timeout' not in plugin_config:
                plugin_config['timeout'] = 30000
        
        elif plugin_name == 'rate-limiting-advanced':
            # Ensure required fields for advanced rate limiting
            if 'limit' not in plugin_config:
                plugin_config['limit'] = [100]
            if 'window_size' not in plugin_config:
                plugin_config['window_size'] = [60]
        
        elif plugin_name == 'oas-validation':
            # Ensure API spec is present
            if 'api_spec' not in plugin_config:
                plugin_config['api_spec'] = self._get_default_openapi_spec()
        
        elif plugin_name in ['xsltransform', 'soapvalidation']:
            # Handle XSLT and WSDL content
            if 'resource_content' in context:
                plugin_config['content'] = context['resource_content']
        
        return config
    
    def _validate_plugin_config(self, config: Dict[str, Any], plugin_name: str) -> Dict[str, Any]:
        """Validate and fix plugin configuration"""
        plugin_config = config.get('config', {})
        
        # Remove problematic fields
        problematic_fields = ['run_on_preflight']
        for field in problematic_fields:
            if field in plugin_config:
                del plugin_config[field]
        
        # Plugin-specific validation
        if plugin_name == 'oauth2':
            # Ensure at least one grant type is enabled
            grant_types = ['enable_authorization_code', 'enable_client_credentials', 
                          'enable_implicit_grant', 'enable_password_grant']
            if not any(plugin_config.get(gt) for gt in grant_types):
                plugin_config['enable_client_credentials'] = True
        
        elif plugin_name == 'rate-limiting':
            # Ensure at least one limit is set
            time_limits = ['second', 'minute', 'hour', 'day', 'month', 'year']
            if not any(k in plugin_config for k in time_limits):
                plugin_config['minute'] = 100
        
        elif plugin_name == 'acl':
            # Ensure allow or deny is set
            if 'allow' not in plugin_config and 'deny' not in plugin_config:
                plugin_config['allow'] = ['all']
        
        elif plugin_name == 'ip-restriction':
            # Ensure allow or deny is set
            if 'allow' not in plugin_config and 'deny' not in plugin_config:
                plugin_config['allow'] = ['0.0.0.0/0']
        
        return config
    
    def _generate_basic_plugin_config(self, plugin_name: str, context: Dict[str, Any], api_flow: str) -> Dict[str, Any]:
        """Generate basic plugin configuration when template is not available"""
        config = {
            'name': plugin_name,
            'config': {'enabled': True},
            'tags': [f"api:{context.get('api_name', 'unknown')}", "template-fallback"],
            'api_flow': api_flow
        }
        
        # Add basic configuration based on plugin type
        if plugin_name == 'luascriptexecuter':
            config['config']['script'] = self._generate_default_lua_script(context)
            config['config']['timeout'] = 30000
        elif plugin_name == 'rate-limiting':
            config['config']['minute'] = 100
        elif plugin_name == 'cors':
            config['config']['origins'] = ['*']
        elif plugin_name == 'key-auth':
            config['config']['key_names'] = ['apikey']
        elif plugin_name == 'basic-auth':
            config['config']['hide_credentials'] = True
        
        return config
    
    def _generate_default_lua_script(self, context: Dict[str, Any]) -> str:
        """Generate default Lua script"""
        policy_name = context.get('policy', {}).get('name', 'unknown')
        policy_type = context.get('policy', {}).get('policyType', 'Unknown')
        
        return f'''
-- Default Lua script for {policy_name} ({policy_type})
local function execute_policy()
    kong.log.info("Executing policy: {policy_name}")
    -- TODO: Implement {policy_type} logic
    return true
end

return execute_policy()
'''
    
    def _get_default_openapi_spec(self) -> str:
        """Get default OpenAPI specification"""
        return '''
openapi: 3.0.0
info:
  title: Default API
  version: 1.0.0
paths:
  /:
    get:
      responses:
        '200':
          description: OK
'''
    
    def _load_template_configs(self):
        """Load template configurations"""
        config_file = self.templates_dir / "template-config.json"
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    self.template_configs = json.load(f)
            except Exception as e:
                self.logger.warning(f"Failed to load template configs: {e}")
                self.template_configs = {}
        else:
            self.template_configs = {}
    
    def _is_custom_plugin(self, plugin_name: str) -> bool:
        """Check if plugin is a custom plugin"""
        custom_plugins = {
            'assertcondition', 'attribute', 'datacapture', 'extensioncallout',
            'flowcallout', 'custom-graphql', 'invalidate-cache', 'java-callout',
            'javascript', 'jsontoxml', 'keyvaluemapoperations', 'latencyanalysis',
            'luascriptexecuter', 'parsedialogflowrequest', 'publishmessage',
            'python', 'readpropertyset', 'resetquota', 'servicecallout',
            'setdialogflowresponse', 'setintegrationrequest', 'setoauthv2info',
            'soapvalidation', 'xsltransform'
        }
        return plugin_name in custom_plugins
    
    def _is_enterprise_version(self, version: str) -> bool:
        """Check if Kong version is enterprise"""
        return 'enterprise' in version.lower()
    
    def _check_plugin_support(self, plugin_name: str, version: str) -> bool:
        """Check if plugin is supported in given Kong version"""
        # Simplified version check - in real implementation, 
        # this would check against Kong's plugin compatibility matrix
        return True
    
    def _map_apigee_context(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        """Map Apigee policy context to template variables"""
        return {
            'policy_name': policy.get('name', ''),
            'policy_type': policy.get('policyType', ''),
            'enabled': policy.get('enabled', True),
            'continue_on_error': policy.get('continueOnError', False),
            'display_name': policy.get('displayName', ''),
            'config': policy.get('config', {}),
            'parsed_config': policy.get('parsed_config', {})
        }
    
    def _clean_none_values(self, obj: Any) -> Any:
        """Recursively remove None values from dict/list"""
        if isinstance(obj, dict):
            return {k: self._clean_none_values(v) for k, v in obj.items() if v is not None}
        elif isinstance(obj, list):
            return [self._clean_none_values(v) for v in obj if v is not None]
        else:
            return obj
    
    # Jinja2 custom filters
    def _safe_string_filter(self, value: Any) -> str:
        """Convert value to safe string"""
        if value is None:
            return ""
        return str(value)
    
    def _indent_lua_filter(self, code: str, spaces: int = 4) -> str:
        """Indent Lua code"""
        if not code:
            return ""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))
    
    # Utility functions for templates
    def _safe_value(self, value: Any, default: Any = None) -> Any:
        """Return value or default if None/empty"""
        return value if value is not None and value != "" else default
    
    def _format_list(self, value: Any) -> List[Any]:
        """Convert value to list format"""
        if isinstance(value, list):
            return value
        elif value is not None:
            return [value]
        else:
            return []
    
    def _extract_value(self, obj: Dict[str, Any], path: str, default: Any = None) -> Any:
        """Extract value from nested dict using dot notation"""
        keys = path.split('.')
        current = obj
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
        
        return current
    
    def _convert_boolean(self, value: Any) -> bool:
        """Convert value to boolean"""
        if isinstance(value, bool):
            return value
        elif isinstance(value, str):
            return value.lower() in ('true', '1', 'yes', 'on')
        elif isinstance(value, (int, float)):
            return bool(value)
        else:
            return False