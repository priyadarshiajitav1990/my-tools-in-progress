#!/usr/bin/env python3
"""
Enterprise Logger Configuration
Provides structured logging with multiple handlers and enterprise standards
"""

import os
import sys
import logging
import logging.handlers
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
import json

class EnterpriseLogger:
    def __init__(self, name: str = "apigee-kong-migration", config: Optional[Dict[str, Any]] = None):
        self.name = name
        self.config = config or {}
        self.log_dir = Path("logs")
        self.log_dir.mkdir(exist_ok=True)
        
        # Create logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(self._get_log_level())
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # Setup handlers
        self._setup_console_handler()
        self._setup_file_handler()
        self._setup_error_handler()
        self._setup_audit_handler()
        
        # Prevent duplicate logs
        self.logger.propagate = False
    
    def _get_log_level(self) -> int:
        """Get log level from config or environment"""
        level_str = (
            self.config.get('logging', {}).get('level') or
            os.environ.get('LOG_LEVEL', 'INFO')
        ).upper()
        
        return getattr(logging, level_str, logging.INFO)
    
    def _setup_console_handler(self):
        """Setup console handler with colored output"""
        if not self.config.get('logging', {}).get('console_enabled', True):
            return
        
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        # Colored formatter for console
        console_formatter = ColoredFormatter(
            fmt='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_formatter)
        
        self.logger.addHandler(console_handler)
    
    def _setup_file_handler(self):
        """Setup rotating file handler"""
        if not self.config.get('logging', {}).get('file_enabled', True):
            return
        
        log_file = self.log_dir / f"{self.name}_{datetime.now().strftime('%Y%m%d')}.log"
        
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=50 * 1024 * 1024,  # 50MB
            backupCount=10,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        
        # Structured formatter for file
        file_formatter = StructuredFormatter()
        file_handler.setFormatter(file_formatter)
        
        self.logger.addHandler(file_handler)
    
    def _setup_error_handler(self):
        """Setup separate error handler"""
        error_file = self.log_dir / f"{self.name}_errors_{datetime.now().strftime('%Y%m%d')}.log"
        
        error_handler = logging.handlers.RotatingFileHandler(
            error_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        
        error_formatter = StructuredFormatter()
        error_handler.setFormatter(error_formatter)
        
        self.logger.addHandler(error_handler)
    
    def _setup_audit_handler(self):
        """Setup audit trail handler"""
        audit_file = self.log_dir / f"{self.name}_audit_{datetime.now().strftime('%Y%m%d')}.log"
        
        audit_handler = logging.handlers.RotatingFileHandler(
            audit_file,
            maxBytes=100 * 1024 * 1024,  # 100MB
            backupCount=20,
            encoding='utf-8'
        )
        audit_handler.setLevel(logging.INFO)
        
        # Add audit filter
        audit_handler.addFilter(AuditFilter())
        
        audit_formatter = AuditFormatter()
        audit_handler.setFormatter(audit_formatter)
        
        self.logger.addHandler(audit_handler)
    
    def get_logger(self) -> logging.Logger:
        """Get configured logger instance"""
        return self.logger
    
    def log_migration_start(self, api_name: str, config: Dict[str, Any]):
        """Log migration start event"""
        self.logger.info(
            "Migration started",
            extra={
                'event_type': 'migration_start',
                'api_name': api_name,
                'config_summary': self._sanitize_config(config),
                'audit': True
            }
        )
    
    def log_migration_complete(self, api_name: str, stats: Dict[str, Any]):
        """Log migration completion event"""
        self.logger.info(
            "Migration completed",
            extra={
                'event_type': 'migration_complete',
                'api_name': api_name,
                'statistics': stats,
                'audit': True
            }
        )
    
    def log_policy_migration(self, policy_name: str, policy_type: str, 
                           plugin_name: str, success: bool):
        """Log policy migration event"""
        level = logging.INFO if success else logging.ERROR
        self.logger.log(
            level,
            f"Policy migration: {policy_name} -> {plugin_name}",
            extra={
                'event_type': 'policy_migration',
                'policy_name': policy_name,
                'policy_type': policy_type,
                'plugin_name': plugin_name,
                'success': success,
                'audit': True
            }
        )
    
    def log_consumer_impact(self, api_name: str, impact_level: str, 
                          breaking_changes: int, warnings: int):
        """Log consumer impact assessment"""
        self.logger.info(
            f"Consumer impact assessment: {impact_level}",
            extra={
                'event_type': 'consumer_impact',
                'api_name': api_name,
                'impact_level': impact_level,
                'breaking_changes': breaking_changes,
                'warnings': warnings,
                'audit': True
            }
        )
    
    def log_error_with_context(self, error: Exception, context: Dict[str, Any]):
        """Log error with additional context"""
        self.logger.error(
            f"Error occurred: {str(error)}",
            extra={
                'event_type': 'error',
                'error_type': type(error).__name__,
                'error_message': str(error),
                'context': context,
                'audit': True
            },
            exc_info=True
        )
    
    def _sanitize_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Remove sensitive information from config"""
        sanitized = config.copy()
        
        # Remove sensitive keys
        sensitive_keys = ['password', 'token', 'key', 'secret', 'credentials']
        
        def sanitize_dict(d):
            if isinstance(d, dict):
                return {
                    k: '***REDACTED***' if any(sens in k.lower() for sens in sensitive_keys)
                    else sanitize_dict(v)
                    for k, v in d.items()
                }
            elif isinstance(d, list):
                return [sanitize_dict(item) for item in d]
            else:
                return d
        
        return sanitize_dict(sanitized)

class ColoredFormatter(logging.Formatter):
    """Colored formatter for console output"""
    
    # Color codes
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m'       # Reset
    }
    
    def format(self, record):
        # Add color to level name
        level_color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        record.levelname = f"{level_color}{record.levelname}{self.COLORS['RESET']}"
        
        return super().format(record)

class StructuredFormatter(logging.Formatter):
    """Structured JSON formatter for file output"""
    
    def format(self, record):
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
            'thread': record.thread,
            'process': record.process
        }
        
        # Add extra fields
        if hasattr(record, '__dict__'):
            for key, value in record.__dict__.items():
                if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 
                              'pathname', 'filename', 'module', 'lineno', 
                              'funcName', 'created', 'msecs', 'relativeCreated',
                              'thread', 'threadName', 'processName', 'process',
                              'getMessage', 'exc_info', 'exc_text', 'stack_info']:
                    log_entry[key] = value
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry, default=str, ensure_ascii=False)

class AuditFormatter(logging.Formatter):
    """Audit trail formatter"""
    
    def format(self, record):
        audit_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'event_type': getattr(record, 'event_type', 'unknown'),
            'message': record.getMessage(),
            'user': os.environ.get('USER', 'system'),
            'hostname': os.environ.get('HOSTNAME', 'unknown'),
            'pid': record.process
        }
        
        # Add extra audit fields
        for key, value in record.__dict__.items():
            if key.startswith('audit_') or key in ['api_name', 'policy_name', 'plugin_name']:
                audit_entry[key] = value
        
        return json.dumps(audit_entry, default=str, ensure_ascii=False)

class AuditFilter(logging.Filter):
    """Filter for audit events"""
    
    def filter(self, record):
        return getattr(record, 'audit', False)

# Global logger instance
_enterprise_logger = None

def get_enterprise_logger(name: str = "apigee-kong-migration", 
                         config: Optional[Dict[str, Any]] = None) -> logging.Logger:
    """Get enterprise logger instance"""
    global _enterprise_logger
    
    if _enterprise_logger is None:
        _enterprise_logger = EnterpriseLogger(name, config)
    
    return _enterprise_logger.get_logger()

def setup_logging(config: Optional[Dict[str, Any]] = None) -> logging.Logger:
    """Setup enterprise logging configuration"""
    return get_enterprise_logger(config=config)

# Context manager for logging operations
class LoggingContext:
    def __init__(self, operation: str, **kwargs):
        self.operation = operation
        self.context = kwargs
        self.logger = get_enterprise_logger()
        self.start_time = None
    
    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.info(
            f"Starting operation: {self.operation}",
            extra={
                'event_type': 'operation_start',
                'operation': self.operation,
                'func_name': self.context.get('function'),
                'mod_name': self.context.get('module'),
                'audit': True
            }
        )
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = datetime.now() - self.start_time
        
        if exc_type is None:
            self.logger.info(
                f"Completed operation: {self.operation}",
                extra={
                    'event_type': 'operation_complete',
                    'operation': self.operation,
                    'duration_seconds': duration.total_seconds(),
                    'func_name': self.context.get('function'),
                    'mod_name': self.context.get('module'),
                    'audit': True
                }
            )
        else:
            self.logger.error(
                f"Failed operation: {self.operation}",
                extra={
                    'event_type': 'operation_failed',
                    'operation': self.operation,
                    'duration_seconds': duration.total_seconds(),
                    'error_type': exc_type.__name__,
                    'error_message': str(exc_val),
                    'func_name': self.context.get('function'),
                    'mod_name': self.context.get('module'),
                    'audit': True
                },
                exc_info=True
            )

# Decorator for logging function calls
def log_function_call(operation_name: str = None):
    """Decorator to log function calls"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            op_name = operation_name or f"{func.__module__}.{func.__name__}"
            
            with LoggingContext(op_name, function=func.__name__, mod_name=func.__module__):
                return func(*args, **kwargs)
        
        return wrapper
    return decorator