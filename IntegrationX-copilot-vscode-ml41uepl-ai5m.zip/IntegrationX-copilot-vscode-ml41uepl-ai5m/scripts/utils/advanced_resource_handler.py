#!/usr/bin/env python3
"""
Advanced Resource File Handler
Handles JS/Java/Python/JAR/WSDL/XSD/OAS files with conversion to Lua
"""

import os
import sys
import subprocess
import tempfile
import json
import logging
from pathlib import Path

class AdvancedResourceHandler:
    def __init__(self):
        self.base_dir = Path(__file__).parent.parent.parent
        self.java_converter = self.base_dir / "luaconverters" / "lua-converter-tool-main"
        self.python_converter = self.base_dir / "luaconverters" / "py-to-lua-main"
        self.logger = logging.getLogger(__name__)
        
    def process_resource_files(self, policy, resources):
        """Process all resource files for a policy"""
        processed_resources = {}
        
        # Check for various resource file references
        resource_refs = self._extract_resource_references(policy)
        
        for ref_type, ref_value in resource_refs.items():
            if ref_value in resources:
                content = resources[ref_value]
                processed = self._process_single_resource(ref_value, content, ref_type)
                processed_resources[ref_type] = processed
        
        return processed_resources
    
    def _extract_resource_references(self, policy):
        """Extract resource file references from policy"""
        refs = {}
        
        # Common resource reference patterns
        ref_patterns = {
            'resourceURL': 'script',
            'source': 'script', 
            'includeURL': 'include',
            'jarResource': 'jar',
            'wsdlResource': 'wsdl',
            'xsdResource': 'xsd',
            'oasResource': 'oas',
            'xslResource': 'xsl'
        }
        
        for pattern, ref_type in ref_patterns.items():
            if pattern in policy and policy[pattern]:
                refs[ref_type] = policy[pattern]
        
        return refs
    
    def _process_single_resource(self, file_path, content, resource_type):
        """Process a single resource file"""
        file_ext = Path(file_path).suffix.lower()
        
        try:
            if file_ext in ['.js', '.javascript']:
                return self._convert_javascript_to_lua(content, file_path)
            elif file_ext in ['.py', '.python']:
                return self._convert_python_to_lua(content, file_path)
            elif file_ext in ['.java']:
                return self._convert_java_to_lua(content, file_path)
            elif file_ext in ['.jar']:
                return self._handle_jar_file(content, file_path)
            elif file_ext in ['.wsdl', '.xsd']:
                return self._handle_xml_schema(content, file_path, resource_type)
            elif file_ext in ['.json', '.yaml', '.yml'] and 'oas' in file_path.lower():
                return self._handle_oas_spec(content, file_path)
            elif file_ext in ['.xsl', '.xslt']:
                return self._handle_xslt(content, file_path)
            else:
                return self._handle_generic_resource(content, file_path)
                
        except Exception as e:
            self.logger.error(f"Error processing resource {file_path}: {e}")
            return self._create_fallback_lua(content, file_path, str(e))
    
    def _convert_javascript_to_lua(self, js_content, file_path):
        """Convert JavaScript to Lua using lua-converter-tool"""
        try:
            jar_path = self._find_converter_jar()
            if not jar_path:
                return self._fallback_js_to_lua(js_content, file_path)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as temp_js:
                temp_js.write(js_content)
                temp_js_path = temp_js.name
            
            try:
                result = subprocess.run([
                    'java', '-jar', str(jar_path),
                    '--input', temp_js_path,
                    '--output-format', 'lua',
                    '--target', 'kong'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 and result.stdout.strip():
                    return self._enhance_lua_code(result.stdout, 'javascript', file_path)
                else:
                    return self._fallback_js_to_lua(js_content, file_path)
                    
            finally:
                os.unlink(temp_js_path)
                
        except Exception as e:
            self.logger.warning(f"JS conversion failed: {e}")
            return self._fallback_js_to_lua(js_content, file_path)
    
    def _convert_python_to_lua(self, py_content, file_path):
        """Convert Python to Lua using py-to-lua"""
        try:
            converter_path = self.python_converter / "py_to_lua"
            if not converter_path.exists():
                return self._fallback_py_to_lua(py_content, file_path)
            
            # Add converter to path temporarily
            sys.path.insert(0, str(self.python_converter))
            
            try:
                from py_to_lua import py_to_lua
                
                with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_py:
                    temp_py.write(py_content)
                    temp_py_path = temp_py.name
                
                try:
                    lua_code = py_to_lua.convert_file(temp_py_path)
                    return self._enhance_lua_code(lua_code, 'python', file_path)
                finally:
                    os.unlink(temp_py_path)
                    
            finally:
                sys.path.remove(str(self.python_converter))
                
        except Exception as e:
            self.logger.warning(f"Python conversion failed: {e}")
            return self._fallback_py_to_lua(py_content, file_path)
    
    def _convert_java_to_lua(self, java_content, file_path):
        """Convert Java to Lua using lua-converter-tool"""
        try:
            jar_path = self._find_converter_jar()
            if not jar_path:
                return self._fallback_java_to_lua(java_content, file_path)
            
            class_name = Path(file_path).stem
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.java', delete=False) as temp_java:
                temp_java.write(java_content)
                temp_java_path = temp_java.name
            
            try:
                result = subprocess.run([
                    'java', '-jar', str(jar_path),
                    '--input', temp_java_path,
                    '--output-format', 'lua',
                    '--class-name', class_name,
                    '--target', 'kong'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 and result.stdout.strip():
                    return self._enhance_lua_code(result.stdout, 'java', file_path)
                else:
                    return self._fallback_java_to_lua(java_content, file_path)
                    
            finally:
                os.unlink(temp_java_path)
                
        except Exception as e:
            self.logger.warning(f"Java conversion failed: {e}")
            return self._fallback_java_to_lua(java_content, file_path)
    
    def _handle_jar_file(self, jar_content, file_path):
        """Handle JAR files - create placeholder for now"""
        return f'''
-- JAR File: {file_path}
local function execute_jar_logic()
    -- JAR file processing placeholder
    -- TODO: Extract and process JAR contents
    kong.log.warn("JAR file processing not fully implemented: {file_path}")
    
    -- Basic JAR file handling
    local jar_name = "{Path(file_path).stem}"
    kong.ctx.shared.jar_resource = jar_name
    
    return true
end

return execute_jar_logic()
'''
    
    def _handle_xml_schema(self, xml_content, file_path, resource_type):
        """Handle WSDL/XSD files - inject directly into plugin config"""
        return f'''
-- {resource_type.upper()} Schema: {file_path}
local function load_xml_schema()
    local xml_content = [[
{xml_content}
]]
    
    -- Store schema in Kong context
    kong.ctx.shared.xml_schema = xml_content
    kong.ctx.shared.schema_type = "{resource_type}"
    kong.ctx.shared.schema_file = "{file_path}"
    
    return xml_content
end

return load_xml_schema()
'''
    
    def _handle_oas_spec(self, oas_content, file_path):
        """Handle OpenAPI Specification files"""
        return f'''
-- OpenAPI Specification: {file_path}
local function load_oas_spec()
    local oas_content = [[
{oas_content}
]]
    
    -- Store OAS spec in Kong context
    kong.ctx.shared.oas_spec = oas_content
    kong.ctx.shared.oas_file = "{file_path}"
    
    -- Parse OAS for validation
    local cjson = require "cjson.safe"
    local spec_data = cjson.decode(oas_content)
    
    if spec_data then
        kong.ctx.shared.oas_parsed = spec_data
        kong.log.info("OAS specification loaded successfully")
    end
    
    return oas_content
end

return load_oas_spec()
'''
    
    def _handle_xslt(self, xslt_content, file_path):
        """Handle XSLT transformation files"""
        return f'''
-- XSLT Transformation: {file_path}
local function load_xslt()
    local xslt_content = [[
{xslt_content}
]]
    
    -- Store XSLT in Kong context
    kong.ctx.shared.xslt_template = xslt_content
    kong.ctx.shared.xslt_file = "{file_path}"
    
    return xslt_content
end

return load_xslt()
'''
    
    def _enhance_lua_code(self, lua_code, source_type, file_path):
        """Enhance converted Lua code with Kong integration"""
        enhanced_code = f'''
-- Converted from {source_type}: {file_path}
-- Enhanced with Kong integration

local function execute_converted_logic()
    -- Kong context and utilities
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    local log = kong.log
    
    -- Original converted code
{self._indent_code(lua_code, 4)}
    
    -- Kong integration enhancements
    ctx.source_file = "{file_path}"
    ctx.source_type = "{source_type}"
    
    return true
end

return execute_converted_logic()
'''
        return enhanced_code
    
    def _indent_code(self, code, spaces):
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))
    
    def _find_converter_jar(self):
        """Find the lua converter JAR file"""
        jar_patterns = [
            self.java_converter / "target" / "*.jar",
            self.java_converter / "*.jar",
            self.java_converter / "build" / "*.jar"
        ]
        
        for pattern in jar_patterns:
            jar_files = list(pattern.parent.glob(pattern.name))
            if jar_files:
                return jar_files[0]
        
        return None
    
    def _fallback_js_to_lua(self, js_content, file_path):
        """Fallback JavaScript to Lua conversion"""
        return f'''
-- JavaScript Fallback Conversion: {file_path}
local function execute_js_fallback()
    -- Original JavaScript (commented)
    --[[
{js_content}
    --]]
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- Basic JS to Lua mappings
    local console = {{
        log = function(msg) kong.log.info(tostring(msg)) end,
        error = function(msg) kong.log.err(tostring(msg)) end
    }}
    
    -- TODO: Manual conversion required for complex JavaScript
    kong.log.warn("JavaScript fallback conversion used for: {file_path}")
    
    return true
end

return execute_js_fallback()
'''
    
    def _fallback_py_to_lua(self, py_content, file_path):
        """Fallback Python to Lua conversion"""
        return f'''
-- Python Fallback Conversion: {file_path}
local function execute_py_fallback()
    -- Original Python (commented)
    --[[
{py_content}
    --]]
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- TODO: Manual conversion required for complex Python
    kong.log.warn("Python fallback conversion used for: {file_path}")
    
    return true
end

return execute_py_fallback()
'''
    
    def _fallback_java_to_lua(self, java_content, file_path):
        """Fallback Java to Lua conversion"""
        class_name = Path(file_path).stem
        return f'''
-- Java Fallback Conversion: {file_path}
local function execute_java_fallback()
    -- Original Java (commented)
    --[[
{java_content}
    --]]
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- Java class simulation
    local {class_name} = {{}}
    
    -- TODO: Manual conversion required for complex Java
    kong.log.warn("Java fallback conversion used for: {file_path}")
    
    return true
end

return execute_java_fallback()
'''
    
    def _handle_generic_resource(self, content, file_path):
        """Handle generic resource files"""
        return f'''
-- Generic Resource: {file_path}
local function load_generic_resource()
    local content = [[
{content}
]]
    
    kong.ctx.shared.resource_content = content
    kong.ctx.shared.resource_file = "{file_path}"
    
    return content
end

return load_generic_resource()
'''
    
    def _create_fallback_lua(self, content, file_path, error_msg):
        """Create fallback Lua code when processing fails"""
        return f'''
-- Fallback Resource Handler: {file_path}
-- Error: {error_msg}
local function fallback_handler()
    kong.log.warn("Resource processing failed: {file_path}")
    kong.log.warn("Error: {error_msg}")
    
    -- Store raw content for manual processing
    kong.ctx.shared.raw_resource = [[
{content[:1000]}...
]]
    
    return true
end

return fallback_handler()
'''