#!/usr/bin/env python3
"""
Lua Code Generator
Generates Kong-compatible Lua code for Apigee policies
"""

import logging
from scripts.utils.apigee_variable_mapper import ApigeeVariableMapper

class LuaCodeGenerator:
    def __init__(self):
        self.variable_mapper = ApigeeVariableMapper()
        self.logger = logging.getLogger(__name__)
        
        # Policy-specific Lua templates
        self.policy_templates = {
            'AssertCondition': self._generate_assert_condition_lua,
            'VerifyAPIKey': self._generate_verify_apikey_lua,
            'BasicAuthentication': self._generate_basic_auth_lua,
            'RaiseFault': self._generate_raise_fault_lua,
            'AssignMessage': self._generate_assign_message_lua,
            'ServiceCallout': self._generate_service_callout_lua,
            'JavaScript': self._generate_javascript_lua,
            'PythonScript': self._generate_python_lua,
            'JavaCallout': self._generate_java_callout_lua,
            'JSONToXML': self._generate_json_to_xml_lua,
            'XMLToJSON': self._generate_xml_to_json_lua,
            'XSLTransform': self._generate_xsl_transform_lua,
            'DataCapture': self._generate_data_capture_lua,
            'Quota': self._generate_quota_lua,
            'SpikeArrest': self._generate_spike_arrest_lua
        }
    
    def generate_policy_lua(self, policy, processed_resources):
        """Generate Lua code for a specific policy"""
        policy_type = policy.get('policyType', 'Unknown')
        policy_name = policy.get('name', 'unknown')
        
        # Get policy-specific generator
        generator = self.policy_templates.get(policy_type, self._generate_generic_lua)
        
        try:
            lua_code = generator(policy, processed_resources)
            return self._wrap_lua_code(lua_code, policy_name, policy_type)
        except Exception as e:
            self.logger.error(f"Lua generation failed for {policy_name}: {e}")
            return self.generate_fallback_lua(policy, processed_resources)
    
    def generate_fallback_lua(self, policy, processed_resources):
        """Generate fallback Lua code"""
        policy_name = policy.get('name', 'unknown')
        policy_type = policy.get('policyType', 'Unknown')
        
        fallback_code = f'''
-- Fallback implementation for {policy_type}
local function execute_fallback()
    kong.log.warn("Using fallback implementation for policy: {policy_name}")
    kong.log.warn("Policy type: {policy_type}")
    
    -- Store policy info in context
    kong.ctx.shared.policy_name = "{policy_name}"
    kong.ctx.shared.policy_type = "{policy_type}"
    
    return true
end

return execute_fallback()
'''
        return fallback_code
    
    def _wrap_lua_code(self, code, policy_name, policy_type):
        """Wrap generated code with standard Kong integration"""
        wrapped_code = f'''
-- Generated Lua code for {policy_type}: {policy_name}
-- Kong Enterprise v3.13.0.0 compatible

local function execute_{policy_name.replace('-', '_').replace(' ', '_')}()
    -- Kong context and utilities
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    local log = kong.log
    
    -- Policy execution
    local success, result = pcall(function()
{self._indent_code(code, 8)}
    end)
    
    if not success then
        log.err("Policy execution failed: " .. tostring(result))
        return false
    end
    
    return result
end

return execute_{policy_name.replace('-', '_').replace(' ', '_')}()
'''
        return wrapped_code
    
    def _generate_assert_condition_lua(self, policy, processed_resources):
        """Generate Lua for AssertCondition policy"""
        condition = policy.get('condition', 'true')
        message = policy.get('message', 'Condition failed')
        continue_on_error = policy.get('continueOnError', False)
        
        # Map Apigee condition to Kong Lua
        lua_condition = self.variable_mapper.map_condition_expression(condition)
        
        return f'''
-- Assert Condition Logic
local condition_result = {lua_condition}

if not condition_result then
    log.err("Condition assertion failed: {condition}")
    
    if not {str(continue_on_error).lower()} then
        return kong.response.exit(400, {{
            message = "{message}",
            error = "condition_failed"
        }})
    else
        log.warn("Continuing despite condition failure")
    end
end

log.info("Condition assertion passed: {condition}")
return true
'''
    
    def _generate_verify_apikey_lua(self, policy, processed_resources):
        """Generate Lua for VerifyAPIKey policy"""
        return '''
-- API Key Verification Logic
local api_key = request.get_header("apikey") or request.get_query_arg("apikey")

if not api_key then
    return kong.response.exit(401, {
        message = "API key required",
        error = "missing_api_key"
    })
end

-- Store API key in context for downstream processing
ctx.api_key = api_key
ctx.authenticated = true

log.info("API key verification completed")
return true
'''
    
    def _generate_basic_auth_lua(self, policy, processed_resources):
        """Generate Lua for BasicAuthentication policy"""
        return '''
-- Basic Authentication Logic
local auth_header = request.get_header("authorization")

if not auth_header or not auth_header:match("^Basic ") then
    return kong.response.exit(401, {
        message = "Basic authentication required",
        error = "missing_basic_auth"
    })
end

-- Extract credentials
local credentials = auth_header:match("^Basic (.+)")
if credentials then
    ctx.basic_auth_credentials = credentials
    ctx.authenticated = true
    log.info("Basic authentication completed")
else
    return kong.response.exit(401, {
        message = "Invalid basic authentication format",
        error = "invalid_basic_auth"
    })
end

return true
'''
    
    def _generate_raise_fault_lua(self, policy, processed_resources):
        """Generate Lua for RaiseFault policy"""
        fault_code = policy.get('faultCode', '500')
        fault_string = policy.get('faultString', 'Internal Server Error')
        
        return f'''
-- Raise Fault Logic
log.warn("Raising fault: {fault_string}")

return kong.response.exit({fault_code}, {{
    message = "{fault_string}",
    error = "policy_fault"
}})
'''
    
    def _generate_assign_message_lua(self, policy, processed_resources):
        """Generate Lua for AssignMessage policy"""
        return '''
-- Assign Message Logic
local assign_to = "request"  -- or "response"

if assign_to == "request" then
    -- Modify request
    -- request.set_header("X-Custom-Header", "value")
    log.info("Request message assigned")
else
    -- Modify response
    -- response.set_header("X-Custom-Header", "value")
    log.info("Response message assigned")
end

return true
'''
    
    def _generate_service_callout_lua(self, policy, processed_resources):
        """Generate Lua for ServiceCallout policy"""
        url = policy.get('url', 'http://backend.example.com')
        method = policy.get('method', 'GET')
        timeout = policy.get('timeout', 30000)
        
        return f'''
-- Service Callout Logic
local http = require "resty.http"
local httpc = http.new()

httpc:set_timeout({timeout})

local res, err = httpc:request_uri("{url}", {{
    method = "{method}",
    headers = {{
        ["Content-Type"] = "application/json"
    }}
}})

if not res then
    log.err("Service callout failed: " .. tostring(err))
    return false
end

-- Store response in context
ctx.service_callout_response = res.body
ctx.service_callout_status = res.status

log.info("Service callout completed: " .. res.status)
return true
'''
    
    def _generate_javascript_lua(self, policy, processed_resources):
        """Generate Lua for JavaScript policy"""
        policy_name = policy.get('name', 'unknown')
        
        # Check if we have converted JavaScript code
        if policy_name in processed_resources and 'script' in processed_resources[policy_name]:
            js_lua_code = processed_resources[policy_name]['script']
            return f'''
-- JavaScript Policy Execution
{js_lua_code}
'''
        else:
            return '''
-- JavaScript Policy (Fallback)
log.warn("JavaScript code conversion not available")
-- TODO: Implement JavaScript logic in Lua
return true
'''
    
    def _generate_python_lua(self, policy, processed_resources):
        """Generate Lua for PythonScript policy"""
        policy_name = policy.get('name', 'unknown')
        
        # Check if we have converted Python code
        if policy_name in processed_resources and 'script' in processed_resources[policy_name]:
            py_lua_code = processed_resources[policy_name]['script']
            return f'''
-- Python Script Policy Execution
{py_lua_code}
'''
        else:
            return '''
-- Python Script Policy (Fallback)
log.warn("Python code conversion not available")
-- TODO: Implement Python logic in Lua
return true
'''
    
    def _generate_java_callout_lua(self, policy, processed_resources):
        """Generate Lua for JavaCallout policy"""
        class_name = policy.get('className', 'JavaCallout')
        
        return f'''
-- Java Callout Policy
log.warn("Java callout simulation for class: {class_name}")

-- Simulate Java execution
ctx.java_class = "{class_name}"
ctx.java_executed = true

-- TODO: Implement Java logic in Lua
return true
'''
    
    def _generate_json_to_xml_lua(self, policy, processed_resources):
        """Generate Lua for JSONToXML policy"""
        return '''
-- JSON to XML Conversion
local cjson = require "cjson.safe"

local body = request.get_raw_body()
if body then
    local json_data = cjson.decode(body)
    if json_data then
        -- Simple JSON to XML conversion
        local xml_body = "<root>"
        for k, v in pairs(json_data) do
            xml_body = xml_body .. "<" .. k .. ">" .. tostring(v) .. "</" .. k .. ">"
        end
        xml_body = xml_body .. "</root>"
        
        -- Set converted body
        ctx.converted_body = xml_body
        log.info("JSON to XML conversion completed")
    end
end

return true
'''
    
    def _generate_xml_to_json_lua(self, policy, processed_resources):
        """Generate Lua for XMLToJSON policy"""
        return '''
-- XML to JSON Conversion
local cjson = require "cjson.safe"

local body = request.get_raw_body()
if body then
    -- Simple XML to JSON conversion (basic implementation)
    local json_data = {xml_content = body}
    local json_body = cjson.encode(json_data)
    
    -- Set converted body
    ctx.converted_body = json_body
    log.info("XML to JSON conversion completed")
end

return true
'''
    
    def _generate_xsl_transform_lua(self, policy, processed_resources):
        """Generate Lua for XSLTransform policy"""
        policy_name = policy.get('name', 'unknown')
        
        # Check if we have XSLT template
        if policy_name in processed_resources and 'xsl' in processed_resources[policy_name]:
            return f'''
-- XSLT Transformation
local xslt_template = ctx.xslt_template or "<!-- XSLT template not loaded -->"

-- Store XSLT info in context
ctx.xslt_applied = true
log.info("XSLT transformation applied")

return true
'''
        else:
            return '''
-- XSLT Transformation (Fallback)
log.warn("XSLT template not available")
-- TODO: Implement XSLT transformation
return true
'''
    
    def _generate_data_capture_lua(self, policy, processed_resources):
        """Generate Lua for DataCapture policy"""
        return '''
-- Data Capture Logic
local capture_data = {
    timestamp = os.time(),
    method = request.get_method(),
    path = request.get_path(),
    headers = request.get_headers(),
    query = request.get_query()
}

-- Store captured data
ctx.captured_data = capture_data
log.info("Data capture completed")

return true
'''
    
    def _generate_quota_lua(self, policy, processed_resources):
        """Generate Lua for Quota policy"""
        allow = policy.get('allow', 100)
        interval = policy.get('interval', 1)
        time_unit = policy.get('timeUnit', 'minute')
        
        return f'''
-- Quota Policy Logic
local quota_key = "quota_" .. (ctx.api_key or "anonymous")
local current_count = kong.cache:get(quota_key) or 0

if current_count >= {allow} then
    return kong.response.exit(429, {{
        message = "Quota exceeded",
        error = "quota_exceeded"
    }})
end

-- Increment quota
kong.cache:set(quota_key, current_count + 1, {interval * 60})
log.info("Quota check passed: " .. current_count + 1 .. "/{allow}")

return true
'''
    
    def _generate_spike_arrest_lua(self, policy, processed_resources):
        """Generate Lua for SpikeArrest policy"""
        rate = policy.get('rate', '10ps')
        
        return f'''
-- Spike Arrest Logic
local rate_limit = "{rate}"
local current_time = os.time()

-- Simple spike arrest implementation
local key = "spike_arrest_" .. current_time
local count = kong.cache:get(key) or 0

if count > 10 then  -- Based on rate
    return kong.response.exit(429, {{
        message = "Rate limit exceeded",
        error = "spike_arrest"
    }})
end

kong.cache:set(key, count + 1, 1)
log.info("Spike arrest check passed")

return true
'''
    
    def _generate_generic_lua(self, policy, processed_resources):
        """Generate generic Lua for unknown policy types"""
        policy_type = policy.get('policyType', 'Unknown')
        
        return f'''
-- Generic Policy Implementation
log.info("Executing generic policy: {policy_type}")

-- Store policy configuration in context
ctx.policy_config = policy_config or {{}}

-- TODO: Implement {policy_type} specific logic
return true
'''
    
    def _indent_code(self, code, spaces):
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))