#!/usr/bin/env python3
"""
Lua Script Generator for Apigee Policies
Generates policy-specific Lua scripts for luascriptexecuter plugin
"""

import json
import logging
from typing import Dict, Any, Optional
from pathlib import Path

class LuaScriptGenerator:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Lua script templates for each Apigee policy type
        self.policy_templates = {
            'VerifyAPIKey': self._generate_verify_api_key_lua,
            'OAuthV2': self._generate_oauth_lua,
            'JWT': self._generate_jwt_lua,
            'BasicAuthentication': self._generate_basic_auth_lua,
            'AssignMessage': self._generate_assign_message_lua,
            'ServiceCallout': self._generate_service_callout_lua,
            'JavaScript': self._generate_javascript_lua,
            'PythonScript': self._generate_python_lua,
            'JavaCallout': self._generate_java_callout_lua,
            'RaiseFault': self._generate_raise_fault_lua,
            'Quota': self._generate_quota_lua,
            'SpikeArrest': self._generate_spike_arrest_lua,
            'JSONToXML': self._generate_json_to_xml_lua,
            'XMLToJSON': self._generate_xml_to_json_lua,
            'XSLTransform': self._generate_xsl_transform_lua,
            'DataCapture': self._generate_data_capture_lua,
            'MessageLogging': self._generate_message_logging_lua,
            'ResponseCache': self._generate_response_cache_lua,
            'PopulateCache': self._generate_populate_cache_lua,
            'LookupCache': self._generate_lookup_cache_lua,
            'InvalidateCache': self._generate_invalidate_cache_lua,
            'RegularExpressionProtection': self._generate_regex_protection_lua,
            'JSONThreatProtection': self._generate_json_threat_protection_lua,
            'XMLThreatProtection': self._generate_xml_threat_protection_lua,
            'CORS': self._generate_cors_lua,
            'HMAC': self._generate_hmac_lua,
            'LDAP': self._generate_ldap_lua,
            'SAML': self._generate_saml_lua
        }
    
    def generate_lua_script(self, policy_type: str, policy_config: Dict[str, Any], 
                          policy_name: str, resource_content: Optional[str] = None) -> str:
        """Generate Lua script for specific policy type"""
        try:
            if policy_type in self.policy_templates:
                lua_script = self.policy_templates[policy_type](policy_config, policy_name, resource_content)
            else:
                lua_script = self._generate_generic_lua(policy_type, policy_config, policy_name, resource_content)
            
            return self._wrap_lua_script(lua_script, policy_type, policy_name)
            
        except Exception as e:
            self.logger.error(f"Failed to generate Lua script for {policy_type}: {e}")
            return self._generate_fallback_lua(policy_type, policy_name, str(e))
    
    def _generate_verify_api_key_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        api_key_header = config.get('APIKey', {}).get('ref', 'request.header.x-api-key')
        return f'''
-- VerifyAPIKey Policy Implementation
local function verify_api_key()
    local api_key = kong.request.get_header("x-api-key") or kong.request.get_header("apikey")
    
    if not api_key then
        kong.log.warn("API key not found in request headers")
        return kong.response.exit(401, {{"error": "API key required"}})
    end
    
    -- Store API key for downstream processing
    kong.ctx.shared.api_key = api_key
    kong.ctx.shared.authenticated = true
    
    kong.log.info("API key verification completed for policy: {name}")
    return true
end

return verify_api_key()
'''
    
    def _generate_oauth_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        operation = config.get('Operation', 'VerifyAccessToken')
        return f'''
-- OAuth2 Policy Implementation
local function oauth_handler()
    local auth_header = kong.request.get_header("authorization")
    
    if not auth_header then
        return kong.response.exit(401, {{"error": "Authorization header required"}})
    end
    
    local token = auth_header:match("Bearer%s+(.+)")
    if not token then
        return kong.response.exit(401, {{"error": "Invalid authorization format"}})
    end
    
    -- Store OAuth token for validation
    kong.ctx.shared.oauth_token = token
    kong.ctx.shared.oauth_operation = "{operation}"
    
    kong.log.info("OAuth processing completed for policy: {name}")
    return true
end

return oauth_handler()
'''
    
    def _generate_jwt_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        algorithm = config.get('Algorithm', 'HS256')
        return f'''
-- JWT Policy Implementation
local jwt = require "resty.jwt"

local function jwt_handler()
    local auth_header = kong.request.get_header("authorization")
    
    if not auth_header then
        return kong.response.exit(401, {{"error": "JWT token required"}})
    end
    
    local token = auth_header:match("Bearer%s+(.+)")
    if not token then
        return kong.response.exit(401, {{"error": "Invalid JWT format"}})
    end
    
    -- Store JWT for processing
    kong.ctx.shared.jwt_token = token
    kong.ctx.shared.jwt_algorithm = "{algorithm}"
    
    kong.log.info("JWT processing completed for policy: {name}")
    return true
end

return jwt_handler()
'''
    
    def _generate_assign_message_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        add_headers = config.get('Add', {}).get('Headers', {})
        set_headers = config.get('Set', {}).get('Headers', {})
        remove_headers = config.get('Remove', {}).get('Headers', [])
        
        header_operations = []
        
        for header, value in add_headers.items():
            header_operations.append(f'    kong.service.request.set_header("{header}", "{value}")')
        
        for header, value in set_headers.items():
            header_operations.append(f'    kong.service.request.set_header("{header}", "{value}")')
        
        for header in remove_headers:
            header_operations.append(f'    kong.service.request.clear_header("{header}")')
        
        operations_code = '\n'.join(header_operations) if header_operations else '    -- No header operations configured'
        
        return f'''
-- AssignMessage Policy Implementation
local function assign_message()
    -- Header operations
{operations_code}
    
    -- Store message assignment info
    kong.ctx.shared.message_assigned = true
    
    kong.log.info("Message assignment completed for policy: {name}")
    return true
end

return assign_message()
'''
    
    def _generate_service_callout_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        url = config.get('HTTPTargetConnection', {}).get('URL', 'http://backend.example.com')
        method = config.get('Request', {}).get('Verb', 'GET')
        
        return f'''
-- ServiceCallout Policy Implementation
local http = require "resty.http"

local function service_callout()
    local httpc = http.new()
    httpc:set_timeout(30000)
    
    local url = "{url}"
    local method = "{method}"
    
    -- Prepare request
    local headers = {{
        ["Content-Type"] = "application/json",
        ["User-Agent"] = "Kong-ServiceCallout"
    }}
    
    -- Make HTTP request
    local res, err = httpc:request_uri(url, {{
        method = method,
        headers = headers,
        keepalive_timeout = 60,
        keepalive_pool = 10
    }})
    
    if not res then
        kong.log.err("Service callout failed: " .. (err or "unknown error"))
        return false
    end
    
    -- Store response for downstream processing
    kong.ctx.shared.callout_response = res.body
    kong.ctx.shared.callout_status = res.status
    
    kong.log.info("Service callout completed for policy: {name}")
    return true
end

return service_callout()
'''
    
    def _generate_javascript_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        resource_url = config.get('ResourceURL', '')
        js_code = resource or '// JavaScript code not available'
        
        return f'''
-- JavaScript Policy Implementation (Lua equivalent)
local function javascript_handler()
    -- Original JavaScript code (commented):
    --[[
{js_code}
    --]]
    
    -- Lua implementation of JavaScript functionality
    local context = {{
        getVariable = function(name)
            if name:match("^request%.") then
                local header_name = name:gsub("request%.header%.", "")
                return kong.request.get_header(header_name)
            elseif name:match("^response%.") then
                local header_name = name:gsub("response%.header%.", "")
                return kong.response.get_header(header_name)
            end
            return kong.ctx.shared[name]
        end,
        setVariable = function(name, value)
            kong.ctx.shared[name] = value
        end
    }}
    
    -- Store JavaScript execution context
    kong.ctx.shared.js_context = context
    kong.ctx.shared.js_executed = true
    
    kong.log.info("JavaScript policy executed (Lua implementation) for: {name}")
    return true
end

return javascript_handler()
'''
    
    def _generate_raise_fault_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        status_code = config.get('FaultResponse', {}).get('StatusCode', 500)
        reason_phrase = config.get('FaultResponse', {}).get('ReasonPhrase', 'Internal Server Error')
        
        return f'''
-- RaiseFault Policy Implementation
local function raise_fault()
    local status_code = {status_code}
    local reason_phrase = "{reason_phrase}"
    
    kong.log.warn("Raising fault - Status: " .. status_code .. ", Reason: " .. reason_phrase)
    
    return kong.response.exit(status_code, {{
        error = reason_phrase,
        policy = "{name}"
    }})
end

return raise_fault()
'''
    
    def _generate_quota_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        count = config.get('Quota', {}).get('count', 1000)
        time_unit = config.get('Quota', {}).get('timeUnit', 'minute')
        
        return f'''
-- Quota Policy Implementation
local function quota_handler()
    local limit = {count}
    local time_unit = "{time_unit}"
    
    -- Get client identifier
    local client_id = kong.request.get_header("x-api-key") or kong.client.get_forwarded_ip()
    
    -- Store quota information
    kong.ctx.shared.quota_limit = limit
    kong.ctx.shared.quota_time_unit = time_unit
    kong.ctx.shared.quota_client_id = client_id
    
    kong.log.info("Quota policy processed for: {name}")
    return true
end

return quota_handler()
'''
    
    def _generate_json_to_xml_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- JSONToXML Policy Implementation
local cjson = require "cjson"

local function json_to_xml()
    local body = kong.request.get_raw_body()
    
    if not body then
        kong.log.warn("No request body found for JSON to XML conversion")
        return true
    end
    
    local content_type = kong.request.get_header("content-type")
    if not content_type or not content_type:find("application/json") then
        kong.log.info("Content-Type is not JSON, skipping conversion")
        return true
    end
    
    -- Parse JSON
    local ok, json_data = pcall(cjson.decode, body)
    if not ok then
        kong.log.err("Failed to parse JSON body")
        return false
    end
    
    -- Simple JSON to XML conversion
    local function json_to_xml_recursive(data, indent)
        local xml = ""
        indent = indent or ""
        
        if type(data) == "table" then
            for k, v in pairs(data) do
                xml = xml .. indent .. "<" .. k .. ">"
                if type(v) == "table" then
                    xml = xml .. "\\n" .. json_to_xml_recursive(v, indent .. "  ") .. indent
                else
                    xml = xml .. tostring(v)
                end
                xml = xml .. "</" .. k .. ">\\n"
            end
        end
        
        return xml
    end
    
    local xml_body = "<?xml version='1.0' encoding='UTF-8'?>\\n<root>\\n" .. 
                     json_to_xml_recursive(json_data, "  ") .. "</root>"
    
    -- Set transformed body and content type
    kong.service.request.set_raw_body(xml_body)
    kong.service.request.set_header("content-type", "application/xml")
    
    kong.log.info("JSON to XML conversion completed for: {name}")
    return true
end

return json_to_xml()
'''
    
    def _generate_data_capture_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- DataCapture Policy Implementation
local function data_capture()
    local capture_data = {{
        timestamp = ngx.now(),
        request_id = kong.request.get_header("x-request-id") or ngx.var.request_id,
        method = kong.request.get_method(),
        path = kong.request.get_path(),
        headers = kong.request.get_headers(),
        query = kong.request.get_query(),
        client_ip = kong.client.get_forwarded_ip()
    }}
    
    -- Store captured data
    kong.ctx.shared.captured_data = capture_data
    
    kong.log.info("Data capture completed for: {name}", capture_data)
    return true
end

return data_capture()
'''
    
    def _generate_generic_lua(self, policy_type: str, config: Dict[str, Any], 
                            name: str, resource: Optional[str]) -> str:
        """Generate generic Lua script for unknown policy types"""
        return f'''
-- Generic Policy Implementation for {policy_type}
local function generic_policy_handler()
    kong.log.info("Executing generic handler for policy type: {policy_type}")
    
    -- Store policy configuration
    kong.ctx.shared.policy_type = "{policy_type}"
    kong.ctx.shared.policy_name = "{name}"
    kong.ctx.shared.policy_config = {json.dumps(config, indent=2, default=str)}
    
    -- TODO: Implement specific {policy_type} logic
    kong.log.warn("Generic handler used for {policy_type} - implement specific logic")
    
    return true
end

return generic_policy_handler()
'''
    
    def _wrap_lua_script(self, lua_code: str, policy_type: str, policy_name: str) -> str:
        """Wrap Lua script with error handling and logging"""
        return f'''
-- Apigee {policy_type} Policy: {policy_name}
-- Generated by Apigee to Kong Migration Tool

local function execute_policy()
    local ok, result = pcall(function()
{self._indent_code(lua_code, 8)}
    end)
    
    if not ok then
        kong.log.err("Policy execution failed for {policy_name}: " .. tostring(result))
        return false
    end
    
    return result
end

-- Execute the policy
return execute_policy()
'''
    
    def _generate_fallback_lua(self, policy_type: str, policy_name: str, error_msg: str) -> str:
        """Generate fallback Lua script when generation fails"""
        return f'''
-- Fallback implementation for {policy_type}: {policy_name}
local function fallback_handler()
    kong.log.err("Policy generation failed: {error_msg}")
    kong.log.info("Using fallback implementation for {policy_type}")
    
    -- Store error information
    kong.ctx.shared.policy_error = "{error_msg}"
    kong.ctx.shared.fallback_used = true
    
    return true
end

return fallback_handler()
'''
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))
    
    # Additional policy implementations
    def _generate_spike_arrest_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        rate = config.get('Rate', '10ps')
        return f'''
-- SpikeArrest Policy Implementation
local function spike_arrest()
    local rate = "{rate}"
    local client_id = kong.client.get_forwarded_ip()
    
    kong.ctx.shared.spike_arrest_rate = rate
    kong.ctx.shared.spike_arrest_client = client_id
    
    kong.log.info("Spike arrest policy processed for: {name}")
    return true
end

return spike_arrest()
'''
    
    def _generate_xml_to_json_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- XMLToJSON Policy Implementation
local function xml_to_json()
    local body = kong.request.get_raw_body()
    
    if not body then
        return true
    end
    
    local content_type = kong.request.get_header("content-type")
    if not content_type or not content_type:find("xml") then
        return true
    end
    
    -- Simple XML to JSON conversion (basic implementation)
    local json_body = '{{"converted_from_xml": true, "original_body": "' .. body:gsub('"', '\\"') .. '"}}'
    
    kong.service.request.set_raw_body(json_body)
    kong.service.request.set_header("content-type", "application/json")
    
    kong.log.info("XML to JSON conversion completed for: {name}")
    return true
end

return xml_to_json()
'''
    
    def _generate_basic_auth_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- BasicAuthentication Policy Implementation
local function basic_auth()
    local auth_header = kong.request.get_header("authorization")
    
    if not auth_header then
        return kong.response.exit(401, {{"error": "Basic authentication required"}})
    end
    
    local credentials = auth_header:match("Basic%s+(.+)")
    if not credentials then
        return kong.response.exit(401, {{"error": "Invalid basic auth format"}})
    end
    
    kong.ctx.shared.basic_auth_credentials = credentials
    kong.ctx.shared.authenticated = true
    
    kong.log.info("Basic authentication processed for: {name}")
    return true
end

return basic_auth()
'''
    
    def _generate_python_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        python_code = resource or '# Python code not available'
        return f'''
-- Python Policy Implementation (Lua equivalent)
local function python_handler()
    -- Original Python code (commented):
    --[[
{python_code}
    --]]
    
    -- Lua implementation of Python functionality
    kong.ctx.shared.python_executed = true
    
    kong.log.info("Python policy executed (Lua implementation) for: {name}")
    return true
end

return python_handler()
'''
    
    def _generate_java_callout_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        class_name = config.get('ClassName', 'UnknownClass')
        return f'''
-- JavaCallout Policy Implementation (Lua equivalent)
local function java_callout()
    local class_name = "{class_name}"
    
    kong.ctx.shared.java_class = class_name
    kong.ctx.shared.java_executed = true
    
    kong.log.info("Java callout executed (Lua implementation) for: {name}")
    return true
end

return java_callout()
'''
    
    def _generate_xsl_transform_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        xsl_content = resource or '<!-- XSL content not available -->'
        return f'''
-- XSLTransform Policy Implementation
local function xsl_transform()
    local xsl_stylesheet = [[
{xsl_content}
    ]]
    
    kong.ctx.shared.xsl_stylesheet = xsl_stylesheet
    kong.ctx.shared.transform_required = true
    
    kong.log.info("XSL transform prepared for: {name}")
    return true
end

return xsl_transform()
'''
    
    def _generate_message_logging_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- MessageLogging Policy Implementation
local function message_logging()
    local log_data = {{
        timestamp = ngx.now(),
        request_id = kong.request.get_header("x-request-id"),
        method = kong.request.get_method(),
        path = kong.request.get_path(),
        client_ip = kong.client.get_forwarded_ip()
    }}
    
    kong.log.info("Message logged for policy: {name}", log_data)
    return true
end

return message_logging()
'''
    
    def _generate_response_cache_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- ResponseCache Policy Implementation
local function response_cache()
    local cache_key = kong.request.get_path() .. "?" .. (kong.request.get_raw_query() or "")
    
    kong.ctx.shared.cache_key = cache_key
    kong.ctx.shared.cache_enabled = true
    
    kong.log.info("Response cache configured for: {name}")
    return true
end

return response_cache()
'''
    
    def _generate_populate_cache_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- PopulateCache Policy Implementation
local function populate_cache()
    local cache_key = kong.ctx.shared.cache_key or "default_key"
    
    kong.ctx.shared.populate_cache = true
    kong.ctx.shared.cache_key = cache_key
    
    kong.log.info("Cache population configured for: {name}")
    return true
end

return populate_cache()
'''
    
    def _generate_lookup_cache_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- LookupCache Policy Implementation
local function lookup_cache()
    local cache_key = kong.request.get_path()
    
    kong.ctx.shared.cache_lookup = true
    kong.ctx.shared.cache_key = cache_key
    
    kong.log.info("Cache lookup configured for: {name}")
    return true
end

return lookup_cache()
'''
    
    def _generate_invalidate_cache_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- InvalidateCache Policy Implementation
local function invalidate_cache()
    local cache_key = kong.ctx.shared.cache_key or "default_key"
    
    kong.ctx.shared.invalidate_cache = true
    kong.ctx.shared.cache_key = cache_key
    
    kong.log.info("Cache invalidation configured for: {name}")
    return true
end

return invalidate_cache()
'''
    
    def _generate_regex_protection_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- RegularExpressionProtection Policy Implementation
local function regex_protection()
    local body = kong.request.get_raw_body()
    local headers = kong.request.get_headers()
    
    -- Basic regex protection (implement specific patterns as needed)
    kong.ctx.shared.regex_protection = true
    
    kong.log.info("Regex protection applied for: {name}")
    return true
end

return regex_protection()
'''
    
    def _generate_json_threat_protection_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- JSONThreatProtection Policy Implementation
local cjson = require "cjson"

local function json_threat_protection()
    local body = kong.request.get_raw_body()
    
    if not body then
        return true
    end
    
    local content_type = kong.request.get_header("content-type")
    if not content_type or not content_type:find("json") then
        return true
    end
    
    -- Validate JSON structure
    local ok, json_data = pcall(cjson.decode, body)
    if not ok then
        return kong.response.exit(400, {{"error": "Invalid JSON format"}})
    end
    
    kong.log.info("JSON threat protection applied for: {name}")
    return true
end

return json_threat_protection()
'''
    
    def _generate_xml_threat_protection_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- XMLThreatProtection Policy Implementation
local function xml_threat_protection()
    local body = kong.request.get_raw_body()
    
    if not body then
        return true
    end
    
    local content_type = kong.request.get_header("content-type")
    if not content_type or not content_type:find("xml") then
        return true
    end
    
    -- Basic XML validation
    if body:find("<!DOCTYPE") or body:find("<!ENTITY") then
        return kong.response.exit(400, {{"error": "XML contains potentially dangerous elements"}})
    end
    
    kong.log.info("XML threat protection applied for: {name}")
    return true
end

return xml_threat_protection()
'''
    
    def _generate_cors_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- CORS Policy Implementation
local function cors_handler()
    local origin = kong.request.get_header("origin")
    
    if origin then
        kong.response.set_header("Access-Control-Allow-Origin", origin)
        kong.response.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        kong.response.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        kong.response.set_header("Access-Control-Allow-Credentials", "true")
    end
    
    kong.log.info("CORS headers set for: {name}")
    return true
end

return cors_handler()
'''
    
    def _generate_hmac_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- HMAC Policy Implementation
local function hmac_handler()
    local signature = kong.request.get_header("x-signature")
    
    if not signature then
        return kong.response.exit(401, {{"error": "HMAC signature required"}})
    end
    
    kong.ctx.shared.hmac_signature = signature
    kong.ctx.shared.hmac_verified = true
    
    kong.log.info("HMAC processing completed for: {name}")
    return true
end

return hmac_handler()
'''
    
    def _generate_ldap_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- LDAP Policy Implementation
local function ldap_handler()
    local auth_header = kong.request.get_header("authorization")
    
    if not auth_header then
        return kong.response.exit(401, {{"error": "LDAP authentication required"}})
    end
    
    kong.ctx.shared.ldap_auth = true
    
    kong.log.info("LDAP authentication processed for: {name}")
    return true
end

return ldap_handler()
'''
    
    def _generate_saml_lua(self, config: Dict[str, Any], name: str, resource: Optional[str]) -> str:
        return f'''
-- SAML Policy Implementation
local function saml_handler()
    local saml_response = kong.request.get_header("x-saml-response")
    
    if not saml_response then
        return kong.response.exit(401, {{"error": "SAML response required"}})
    end
    
    kong.ctx.shared.saml_response = saml_response
    kong.ctx.shared.saml_authenticated = true
    
    kong.log.info("SAML processing completed for: {name}")
    return true
end

return saml_handler()
'''