#!/usr/bin/env python3
"""
Consumer Impact Validator
Ensures API consumers are not impacted during Apigee to Kong migration
"""

import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

class ConsumerImpactValidator:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Critical API contract elements that must be preserved
        self.critical_elements = {
            'request_path_patterns': [],
            'request_methods': [],
            'request_headers': [],
            'request_parameters': [],
            'response_status_codes': [],
            'response_headers': [],
            'response_content_types': [],
            'authentication_methods': [],
            'rate_limiting_rules': []
        }
    
    def validate_migration_impact(self, apigee_config: Dict[str, Any], 
                                kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate that migration preserves API consumer contract"""
        
        validation_result = {
            'consumer_impact': 'NONE',
            'breaking_changes': [],
            'warnings': [],
            'recommendations': [],
            'contract_preserved': True
        }
        
        try:
            # Extract API contracts from both configurations
            apigee_contract = self._extract_apigee_contract(apigee_config)
            kong_contract = self._extract_kong_contract(kong_config)
            
            # Validate critical elements
            self._validate_request_routing(apigee_contract, kong_contract, validation_result)
            self._validate_authentication(apigee_contract, kong_contract, validation_result)
            self._validate_rate_limiting(apigee_contract, kong_contract, validation_result)
            self._validate_request_transformation(apigee_contract, kong_contract, validation_result)
            self._validate_response_transformation(apigee_contract, kong_contract, validation_result)
            self._validate_error_handling(apigee_contract, kong_contract, validation_result)
            
            # Determine overall impact
            if validation_result['breaking_changes']:
                validation_result['consumer_impact'] = 'HIGH'
                validation_result['contract_preserved'] = False
            elif validation_result['warnings']:
                validation_result['consumer_impact'] = 'LOW'
            
            self.logger.info(f"Consumer impact validation completed: {validation_result['consumer_impact']}")
            
        except Exception as e:
            self.logger.error(f"Consumer impact validation failed: {e}")
            validation_result['consumer_impact'] = 'UNKNOWN'
            validation_result['contract_preserved'] = False
            validation_result['breaking_changes'].append(f"Validation error: {e}")
        
        return validation_result
    
    def _extract_apigee_contract(self, apigee_config: Dict[str, Any]) -> Dict[str, Any]:
        """Extract API contract from Apigee configuration"""
        contract = {
            'paths': [],
            'methods': [],
            'auth_policies': [],
            'rate_limits': [],
            'transformations': [],
            'error_responses': []
        }
        
        # Extract from proxy endpoints
        for proxy in apigee_config.get('proxy_endpoints', []):
            # Extract paths and methods
            base_path = proxy.get('base_path', '')
            contract['paths'].append(base_path)
            
            for flow in proxy.get('flows', []):
                condition = flow.get('condition', '')
                if 'request.verb' in condition:
                    method = self._extract_method_from_condition(condition)
                    if method:
                        contract['methods'].append(method)
        
        # Extract from policies
        for policy in apigee_config.get('policies', []):
            policy_type = policy.get('policyType', '')
            
            if policy_type in ['VerifyAPIKey', 'OAuthV2', 'JWT', 'BasicAuthentication']:
                contract['auth_policies'].append(policy_type)
            elif policy_type in ['Quota', 'SpikeArrest']:
                contract['rate_limits'].append(policy)
            elif policy_type in ['AssignMessage', 'JSONToXML', 'XMLToJSON']:
                contract['transformations'].append(policy)
            elif policy_type == 'RaiseFault':
                contract['error_responses'].append(policy)
        
        return contract
    
    def _extract_kong_contract(self, kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Extract API contract from Kong configuration"""
        contract = {
            'paths': [],
            'methods': [],
            'auth_plugins': [],
            'rate_limits': [],
            'transformations': [],
            'error_responses': []
        }
        
        # Extract from routes
        for route in kong_config.get('routes', []):
            contract['paths'].extend(route.get('paths', []))
            contract['methods'].extend(route.get('methods', []))
        
        # Extract from plugins
        for plugin in kong_config.get('plugins', []):
            plugin_name = plugin.get('name', '')
            
            if plugin_name in ['key-auth', 'oauth2', 'jwt', 'basic-auth']:
                contract['auth_plugins'].append(plugin_name)
            elif plugin_name in ['rate-limiting', 'rate-limiting-advanced']:
                contract['rate_limits'].append(plugin)
            elif plugin_name in ['request-transformer', 'response-transformer']:
                contract['transformations'].append(plugin)
            elif plugin_name == 'request-termination':
                contract['error_responses'].append(plugin)
        
        return contract
    
    def _validate_request_routing(self, apigee_contract: Dict[str, Any], 
                                kong_contract: Dict[str, Any], 
                                validation_result: Dict[str, Any]):
        """Validate request routing preservation"""
        
        # Check path preservation
        apigee_paths = set(apigee_contract.get('paths', []))
        kong_paths = set(kong_contract.get('paths', []))
        
        missing_paths = apigee_paths - kong_paths
        if missing_paths:
            validation_result['breaking_changes'].append(
                f"Missing request paths in Kong: {list(missing_paths)}"
            )
        
        # Check method preservation
        apigee_methods = set(apigee_contract.get('methods', []))
        kong_methods = set(kong_contract.get('methods', []))
        
        missing_methods = apigee_methods - kong_methods
        if missing_methods:
            validation_result['breaking_changes'].append(
                f"Missing HTTP methods in Kong: {list(missing_methods)}"
            )
        
        # Add recommendation for path normalization
        if apigee_paths != kong_paths:
            validation_result['recommendations'].append(
                "Verify path matching behavior between Apigee and Kong"
            )
    
    def _validate_authentication(self, apigee_contract: Dict[str, Any], 
                               kong_contract: Dict[str, Any], 
                               validation_result: Dict[str, Any]):
        """Validate authentication method preservation"""
        
        apigee_auth = apigee_contract.get('auth_policies', [])
        kong_auth = kong_contract.get('auth_plugins', [])
        
        # Map Apigee auth to Kong auth
        auth_mapping = {
            'VerifyAPIKey': 'key-auth',
            'OAuthV2': 'oauth2',
            'JWT': 'jwt',
            'BasicAuthentication': 'basic-auth'
        }
        
        expected_kong_auth = [auth_mapping.get(auth, auth) for auth in apigee_auth]
        
        for expected_auth in expected_kong_auth:
            if expected_auth not in kong_auth:
                validation_result['breaking_changes'].append(
                    f"Missing authentication method: {expected_auth}"
                )
        
        # Check for multiple auth methods
        if len(kong_auth) > 1:
            validation_result['warnings'].append(
                "Multiple authentication plugins detected - verify consumer compatibility"
            )
    
    def _validate_rate_limiting(self, apigee_contract: Dict[str, Any], 
                              kong_contract: Dict[str, Any], 
                              validation_result: Dict[str, Any]):
        """Validate rate limiting preservation"""
        
        apigee_limits = apigee_contract.get('rate_limits', [])
        kong_limits = kong_contract.get('rate_limits', [])
        
        if len(apigee_limits) != len(kong_limits):
            validation_result['warnings'].append(
                f"Rate limiting policy count mismatch: Apigee({len(apigee_limits)}) vs Kong({len(kong_limits)})"
            )
        
        # Validate rate limit values
        for apigee_limit in apigee_limits:
            if apigee_limit.get('policyType') == 'Quota':
                quota_config = apigee_limit.get('config', {})
                expected_limit = quota_config.get('count', 0)
                
                # Find corresponding Kong rate limit
                matching_kong_limit = None
                for kong_limit in kong_limits:
                    kong_config = kong_limit.get('config', {})
                    if kong_config.get('minute', 0) == expected_limit:
                        matching_kong_limit = kong_limit
                        break
                
                if not matching_kong_limit:
                    validation_result['warnings'].append(
                        f"Rate limit value mismatch for quota: {expected_limit}"
                    )
    
    def _validate_request_transformation(self, apigee_contract: Dict[str, Any], 
                                       kong_contract: Dict[str, Any], 
                                       validation_result: Dict[str, Any]):
        """Validate request transformation preservation"""
        
        apigee_transforms = [t for t in apigee_contract.get('transformations', []) 
                           if self._affects_request(t)]
        kong_transforms = [t for t in kong_contract.get('transformations', []) 
                         if t.get('name') == 'request-transformer']
        
        if len(apigee_transforms) > 0 and len(kong_transforms) == 0:
            validation_result['breaking_changes'].append(
                "Request transformations not migrated - may break client requests"
            )
        
        # Validate specific transformations
        for transform in apigee_transforms:
            if transform.get('policyType') == 'AssignMessage':
                self._validate_assign_message_transform(transform, kong_transforms, validation_result)
    
    def _validate_response_transformation(self, apigee_contract: Dict[str, Any], 
                                        kong_contract: Dict[str, Any], 
                                        validation_result: Dict[str, Any]):
        """Validate response transformation preservation"""
        
        apigee_transforms = [t for t in apigee_contract.get('transformations', []) 
                           if self._affects_response(t)]
        kong_transforms = [t for t in kong_contract.get('transformations', []) 
                         if t.get('name') == 'response-transformer']
        
        if len(apigee_transforms) > 0 and len(kong_transforms) == 0:
            validation_result['breaking_changes'].append(
                "Response transformations not migrated - may break client expectations"
            )
    
    def _validate_error_handling(self, apigee_contract: Dict[str, Any], 
                               kong_contract: Dict[str, Any], 
                               validation_result: Dict[str, Any]):
        """Validate error handling preservation"""
        
        apigee_errors = apigee_contract.get('error_responses', [])
        kong_errors = kong_contract.get('error_responses', [])
        
        for apigee_error in apigee_errors:
            if apigee_error.get('policyType') == 'RaiseFault':
                fault_config = apigee_error.get('config', {})
                expected_status = fault_config.get('statusCode', 500)
                
                # Check if Kong has corresponding error handling
                matching_kong_error = None
                for kong_error in kong_errors:
                    kong_config = kong_error.get('config', {})
                    if kong_config.get('status_code', 500) == expected_status:
                        matching_kong_error = kong_error
                        break
                
                if not matching_kong_error:
                    validation_result['warnings'].append(
                        f"Custom error response not migrated: HTTP {expected_status}"
                    )
    
    def _affects_request(self, transformation: Dict[str, Any]) -> bool:
        """Check if transformation affects request"""
        policy_type = transformation.get('policyType', '')
        if policy_type == 'AssignMessage':
            config = transformation.get('config', {})
            return 'request' in str(config).lower()
        return False
    
    def _affects_response(self, transformation: Dict[str, Any]) -> bool:
        """Check if transformation affects response"""
        policy_type = transformation.get('policyType', '')
        if policy_type == 'AssignMessage':
            config = transformation.get('config', {})
            return 'response' in str(config).lower()
        return policy_type in ['JSONToXML', 'XMLToJSON']
    
    def _validate_assign_message_transform(self, apigee_transform: Dict[str, Any], 
                                         kong_transforms: List[Dict[str, Any]], 
                                         validation_result: Dict[str, Any]):
        """Validate AssignMessage transformation"""
        config = apigee_transform.get('config', {})
        
        # Check for header modifications
        if 'headers' in config:
            headers_preserved = False
            for kong_transform in kong_transforms:
                kong_config = kong_transform.get('config', {})
                if 'add' in kong_config or 'replace' in kong_config:
                    headers_preserved = True
                    break
            
            if not headers_preserved:
                validation_result['breaking_changes'].append(
                    "Header modifications not preserved in Kong configuration"
                )
    
    def _extract_method_from_condition(self, condition: str) -> Optional[str]:
        """Extract HTTP method from Apigee condition"""
        import re
        match = re.search(r'request\.verb\s*=\s*"([^"]+)"', condition)
        return match.group(1) if match else None
    
    def generate_consumer_compatibility_report(self, validation_result: Dict[str, Any]) -> str:
        """Generate consumer compatibility report"""
        
        report = []
        report.append("# API Consumer Compatibility Report")
        report.append("=" * 50)
        report.append("")
        
        # Overall impact
        impact = validation_result.get('consumer_impact', 'UNKNOWN')
        contract_preserved = validation_result.get('contract_preserved', False)
        
        report.append(f"**Overall Consumer Impact:** {impact}")
        report.append(f"**API Contract Preserved:** {'✓ Yes' if contract_preserved else '✗ No'}")
        report.append("")
        
        # Breaking changes
        breaking_changes = validation_result.get('breaking_changes', [])
        if breaking_changes:
            report.append("## ⚠️ Breaking Changes")
            for change in breaking_changes:
                report.append(f"- {change}")
            report.append("")
        
        # Warnings
        warnings = validation_result.get('warnings', [])
        if warnings:
            report.append("## ⚡ Warnings")
            for warning in warnings:
                report.append(f"- {warning}")
            report.append("")
        
        # Recommendations
        recommendations = validation_result.get('recommendations', [])
        if recommendations:
            report.append("## 💡 Recommendations")
            for rec in recommendations:
                report.append(f"- {rec}")
            report.append("")
        
        # Consumer testing checklist
        report.append("## 🧪 Consumer Testing Checklist")
        report.append("- [ ] Verify all API endpoints are accessible")
        report.append("- [ ] Test authentication with existing credentials")
        report.append("- [ ] Validate request/response formats")
        report.append("- [ ] Check rate limiting behavior")
        report.append("- [ ] Test error response formats")
        report.append("- [ ] Verify custom headers are preserved")
        report.append("")
        
        return "\n".join(report)