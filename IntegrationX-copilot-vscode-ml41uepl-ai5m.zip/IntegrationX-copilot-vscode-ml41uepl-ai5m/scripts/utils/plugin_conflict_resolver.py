#!/usr/bin/env python3
"""
Plugin Conflict Resolver
Handles plugin conflicts, deduplication, and optimization
"""

import logging
from collections import defaultdict

class PluginConflictResolver:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Plugin compatibility matrix
        self.incompatible_plugins = {
            'rate-limiting': ['rate-limiting-advanced'],
            'request-transformer': ['request-transformer-advanced'],
            'response-transformer': ['response-transformer-advanced'],
            'proxy-cache': ['proxy-cache-advanced']
        }
        
        # Plugin preference order (higher number = higher preference)
        self.plugin_preferences = {
            'rate-limiting-advanced': 2,
            'rate-limiting': 1,
            'request-transformer-advanced': 2,
            'request-transformer': 1,
            'response-transformer-advanced': 2,
            'response-transformer': 1,
            'proxy-cache-advanced': 2,
            'proxy-cache': 1
        }
    
    def resolve_conflicts(self, plugin_configs):
        """Resolve conflicts between plugins"""
        # Group plugins by name
        grouped_plugins = defaultdict(list)
        for config in plugin_configs:
            plugin_name = config['name']
            grouped_plugins[plugin_name].append(config)
        
        resolved_configs = []
        
        # Process each plugin group
        for plugin_name, configs in grouped_plugins.items():
            if len(configs) > 1:
                # Merge duplicate plugins
                merged_config = self._merge_duplicate_plugins(configs)
                resolved_configs.append(merged_config)
            else:
                resolved_configs.append(configs[0])
        
        # Resolve incompatible plugins
        final_configs = self._resolve_incompatible_plugins(resolved_configs)
        
        return final_configs
    
    def _merge_duplicate_plugins(self, configs):
        """Merge multiple configurations of the same plugin"""
        base_config = configs[0].copy()
        
        # Merge configurations
        for config in configs[1:]:
            # Merge config section
            if 'config' in config:
                base_config['config'].update(config['config'])
            
            # Merge tags
            if 'tags' in config:
                base_config.setdefault('tags', []).extend(config['tags'])
            
            # Use highest priority
            if config.get('priority', 0) > base_config.get('priority', 0):
                base_config['priority'] = config['priority']
        
        # Remove duplicate tags
        if 'tags' in base_config:
            base_config['tags'] = list(set(base_config['tags']))
        
        self.logger.info(f"Merged {len(configs)} instances of {base_config['name']}")
        return base_config
    
    def _resolve_incompatible_plugins(self, configs):
        """Resolve incompatible plugin combinations"""
        plugin_names = [config['name'] for config in configs]
        resolved_configs = []
        excluded_plugins = set()
        
        for config in configs:
            plugin_name = config['name']
            
            if plugin_name in excluded_plugins:
                continue
            
            # Check for incompatible plugins
            incompatible = self.incompatible_plugins.get(plugin_name, [])
            conflicts = [p for p in incompatible if p in plugin_names]
            
            if conflicts:
                # Choose preferred plugin
                all_conflicting = [plugin_name] + conflicts
                preferred = max(all_conflicting, key=lambda x: self.plugin_preferences.get(x, 0))
                
                if preferred == plugin_name:
                    resolved_configs.append(config)
                    excluded_plugins.update(conflicts)
                    self.logger.info(f"Chose {plugin_name} over {conflicts}")
                else:
                    excluded_plugins.add(plugin_name)
            else:
                resolved_configs.append(config)
        
        return resolved_configs