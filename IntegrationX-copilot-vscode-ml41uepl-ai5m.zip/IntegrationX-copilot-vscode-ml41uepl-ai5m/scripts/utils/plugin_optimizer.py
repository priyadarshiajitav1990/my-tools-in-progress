#!/usr/bin/env python3
"""
Plugin Optimizer
Handles plugin deduplication, conflict resolution, and optimization
"""

from collections import defaultdict

class PluginOptimizer:
    def __init__(self):
        self.plugin_priorities = {
            'ip-restriction': 1000, 'cors': 2000, 'key-auth': 3000, 'basic-auth': 3000,
            'oauth2': 3000, 'jwt': 3000, 'rate-limiting': 4000, 'rate-limiting-advanced': 4000,
            'request-validator': 5000, 'assertcondition': 6000, 'attribute': 6000,
            'request-transformer': 7000, 'servicecallout': 8000, 'luascriptexecuter': 9000,
            'response-transformer': 10000, 'datacapture': 11000, 'http-log': 12000
        }
    
    def optimize_plugins(self, plugin_configs):
        """Optimize plugin configurations"""
        optimized = {'request': [], 'response': [], 'both': []}
        
        # Merge duplicate plugins
        merged_configs = self._merge_duplicate_plugins(plugin_configs)
        
        # Resolve conflicts
        resolved_configs = self._resolve_conflicts(merged_configs)
        
        # Organize by flow
        for plugin_name, configs in resolved_configs.items():
            for config in configs:
                flow = config.get('api_flow', 'both')
                if flow in optimized:
                    optimized[flow].append(config)
        
        return optimized
    
    def _merge_duplicate_plugins(self, plugin_configs):
        """Merge duplicate plugin configurations"""
        merged = {}
        
        for plugin_name, configs in plugin_configs.items():
            if len(configs) > 1:
                # Merge configurations
                base_config = configs[0].copy()
                for config in configs[1:]:
                    base_config['config'].update(config.get('config', {}))
                    if 'tags' in config:
                        base_config.setdefault('tags', []).extend(config['tags'])
                merged[plugin_name] = [base_config]
            else:
                merged[plugin_name] = configs
        
        return merged
    
    def _resolve_conflicts(self, plugin_configs):
        """Resolve plugin conflicts"""
        # Prefer built-in plugins over custom ones
        resolved = {}
        
        for plugin_name, configs in plugin_configs.items():
            if plugin_name.startswith('custom-') or plugin_name in ['luascriptexecuter']:
                # Check if there's a built-in alternative
                builtin_alternative = self._find_builtin_alternative(plugin_name)
                if builtin_alternative and builtin_alternative in plugin_configs:
                    continue  # Skip custom plugin if built-in exists
            
            resolved[plugin_name] = configs
        
        return resolved
    
    def _find_builtin_alternative(self, custom_plugin):
        """Find built-in alternative for custom plugin"""
        alternatives = {
            'assertcondition': 'request-termination',
            'datacapture': 'http-log',
            'servicecallout': 'request-callout',
            'jsontoxml': 'request-transformer-advanced'
        }
        return alternatives.get(custom_plugin)