#!/usr/bin/env python3
"""
Resource File Converter
Converts JS/Java/Python files to Lua scripts using available converters
"""

import os
import sys
import subprocess
import json
import tempfile
from pathlib import Path

class ResourceConverter:
    def __init__(self):
        self.base_dir = Path(__file__).parent.parent
        self.java_converter = self.base_dir / "luaconverters" / "lua-converter-tool-main"
        self.python_converter = self.base_dir / "luaconverters" / "py-to-lua-main"
        
    def convert_javascript_to_lua(self, js_content, resource_name="script"):
        """Convert JavaScript content to Lua"""
        try:
            jar_path = self.java_converter / "target" / "lua-converter-tool-1.0.jar"
            if not jar_path.exists():
                # Try to find jar file
                jar_files = list(self.java_converter.glob("**/*.jar"))
                if jar_files:
                    jar_path = jar_files[0]
                else:
                    return self._fallback_js_to_lua(js_content)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as temp_js:
                temp_js.write(js_content)
                temp_js_path = temp_js.name
            
            try:
                result = subprocess.run([
                    'java', '-jar', str(jar_path), 
                    '--input', temp_js_path,
                    '--output-format', 'lua'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    return result.stdout
                else:
                    return self._fallback_js_to_lua(js_content)
                    
            finally:
                os.unlink(temp_js_path)
                
        except Exception as e:
            print(f"JS conversion error: {e}")
            return self._fallback_js_to_lua(js_content)
    
    def convert_python_to_lua(self, py_content, resource_name="script"):
        """Convert Python content to Lua"""
        try:
            converter_path = self.python_converter / "py_to_lua"
            if not converter_path.exists():
                return self._fallback_py_to_lua(py_content)
            
            sys.path.insert(0, str(self.python_converter))
            from py_to_lua import py_to_lua
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_py:
                temp_py.write(py_content)
                temp_py_path = temp_py.name
            
            try:
                lua_code = py_to_lua.convert_file(temp_py_path)
                return lua_code
            finally:
                os.unlink(temp_py_path)
                
        except Exception as e:
            print(f"Python conversion error: {e}")
            return self._fallback_py_to_lua(py_content)
    
    def convert_java_to_lua(self, java_content, class_name="JavaClass"):
        """Convert Java content to Lua"""
        try:
            jar_path = self.java_converter / "target" / "lua-converter-tool-1.0.jar"
            if not jar_path.exists():
                jar_files = list(self.java_converter.glob("**/*.jar"))
                if jar_files:
                    jar_path = jar_files[0]
                else:
                    return self._fallback_java_to_lua(java_content, class_name)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.java', delete=False) as temp_java:
                temp_java.write(java_content)
                temp_java_path = temp_java.name
            
            try:
                result = subprocess.run([
                    'java', '-jar', str(jar_path),
                    '--input', temp_java_path,
                    '--output-format', 'lua',
                    '--class-name', class_name
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    return result.stdout
                else:
                    return self._fallback_java_to_lua(java_content, class_name)
                    
            finally:
                os.unlink(temp_java_path)
                
        except Exception as e:
            print(f"Java conversion error: {e}")
            return self._fallback_java_to_lua(java_content, class_name)
    
    def _fallback_js_to_lua(self, js_content):
        """Fallback JavaScript to Lua conversion"""
        lua_template = f'''
-- Converted from JavaScript
local function execute_js_logic()
    -- Original JavaScript code (commented):
    --[[
{js_content}
    --]]
    
    -- Basic JS to Lua mappings
    local console = {{
        log = function(msg) kong.log.info(tostring(msg)) end
    }}
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- TODO: Implement JavaScript logic in Lua
    kong.log.warn("JavaScript code needs manual conversion to Lua")
    
    return true
end

return execute_js_logic()
'''
        return lua_template
    
    def _fallback_py_to_lua(self, py_content):
        """Fallback Python to Lua conversion"""
        lua_template = f'''
-- Converted from Python
local function execute_python_logic()
    -- Original Python code (commented):
    --[[
{py_content}
    --]]
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- TODO: Implement Python logic in Lua
    kong.log.warn("Python code needs manual conversion to Lua")
    
    return true
end

return execute_python_logic()
'''
        return lua_template
    
    def _fallback_java_to_lua(self, java_content, class_name):
        """Fallback Java to Lua conversion"""
        lua_template = f'''
-- Converted from Java class: {class_name}
local function execute_java_logic()
    -- Original Java code (commented):
    --[[
{java_content}
    --]]
    
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- TODO: Implement Java logic in Lua
    kong.log.warn("Java code needs manual conversion to Lua")
    
    return true
end

return execute_java_logic()
'''
        return lua_template
    
    def convert_resource_file(self, file_path, content):
        """Convert resource file based on extension"""
        file_ext = Path(file_path).suffix.lower()
        file_name = Path(file_path).stem
        
        if file_ext in ['.js', '.javascript']:
            return self.convert_javascript_to_lua(content, file_name)
        elif file_ext in ['.py', '.python']:
            return self.convert_python_to_lua(content, file_name)
        elif file_ext in ['.java']:
            return self.convert_java_to_lua(content, file_name)
        elif file_ext in ['.jar']:
            # For JAR files, create a placeholder
            return f'''
-- JAR file: {file_path}
-- TODO: Extract and convert JAR contents to Lua
local function execute_jar_logic()
    kong.log.warn("JAR file conversion not implemented: {file_path}")
    return true
end

return execute_jar_logic()
'''
        else:
            return f'''
-- Unsupported file type: {file_ext}
-- File: {file_path}
local function execute_unknown_logic()
    kong.log.warn("Unsupported resource file type: {file_ext}")
    return true
end

return execute_unknown_logic()
'''

def main():
    converter = ResourceConverter()
    
    # Test conversions
    js_code = '''
    function processRequest() {
        var method = request.verb;
        if (method === "GET") {
            response.content = "GET request processed";
        }
        return true;
    }
    processRequest();
    '''
    
    py_code = '''
def process_request():
    method = flow.getVariable("request.verb")
    if method == "GET":
        flow.setVariable("response.content", "GET request processed")
    return True

process_request()
    '''
    
    java_code = '''
public class RequestProcessor {
    public boolean execute() {
        String method = messageContext.getVariable("request.verb");
        if ("GET".equals(method)) {
            messageContext.setVariable("response.content", "GET request processed");
        }
        return true;
    }
}
    '''
    
    print("Testing JavaScript conversion:")
    print(converter.convert_javascript_to_lua(js_code))
    
    print("\nTesting Python conversion:")
    print(converter.convert_python_to_lua(py_code))
    
    print("\nTesting Java conversion:")
    print(converter.convert_java_to_lua(java_code, "RequestProcessor"))

if __name__ == "__main__":
    main()