#!/usr/bin/env python3
"""
Enhanced Plugin Conflict Resolver
Handles plugin conflicts, merges configurations, and optimizes plugin usage
"""

import logging
from typing import Dict, List, Any, Optional
from collections import defaultdict

class EnhancedPluginConflictResolver:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Plugin compatibility matrix
        self.plugin_alternatives = {
            'rate-limiting': ['rate-limiting-advanced'],
            'request-transformer': ['request-transformer-advanced'],
            'response-transformer': ['response-transformer-advanced'],
            'proxy-cache': ['proxy-cache-advanced'],
            'statsd': ['statsd-advanced'],
            'ldap-auth': ['ldap-auth-advanced']
        }
        
        # Plugins that can have multiple instances
        self.multi_instance_plugins = {
            'luascriptexecuter', 'pre-function', 'post-function',
            'http-log', 'file-log', 'kafka-log', 'tcp-log', 'udp-log'
        }
        
        # Plugin execution priorities
        self.plugin_priorities = {
            'ip-restriction': 100, 'cors': 200, 'key-auth': 300, 'basic-auth': 300,
            'oauth2': 300, 'jwt': 300, 'hmac-auth': 300, 'ldap-auth': 300,
            'rate-limiting': 400, 'rate-limiting-advanced': 400,
            'request-validator': 500, 'oas-validation': 500,
            'assertcondition': 600, 'attribute': 600, 'readpropertyset': 600,
            'request-transformer': 700, 'request-transformer-advanced': 700,
            'servicecallout': 800, 'extensioncallout': 800, 'flowcallout': 800,
            'javascript': 850, 'python': 850, 'java-callout': 850,
            'luascriptexecuter': 900, 'pre-function': 900, 'post-function': 1100,
            'response-transformer': 1000, 'response-transformer-advanced': 1000,
            'datacapture': 1100, 'http-log': 1200, 'file-log': 1200
        }
    
    def resolve_plugin_conflicts(self, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Resolve conflicts between plugins and optimize configuration"""
        try:
            # Group plugins by name and flow
            grouped_plugins = self._group_plugins(plugins)
            
            # Resolve conflicts for each plugin type
            resolved_plugins = []
            for plugin_name, plugin_group in grouped_plugins.items():
                if plugin_name in self.multi_instance_plugins:
                    # Handle multi-instance plugins (merge if needed)
                    resolved = self._handle_multi_instance_plugins(plugin_name, plugin_group, api_name)
                else:
                    # Handle single-instance plugins (merge or choose best)
                    resolved = self._handle_single_instance_plugins(plugin_name, plugin_group, api_name)
                
                resolved_plugins.extend(resolved)
            
            # Apply plugin ordering
            ordered_plugins = self._apply_plugin_ordering(resolved_plugins)
            
            self.logger.info(f"Resolved {len(plugins)} plugins to {len(ordered_plugins)} optimized plugins")
            return ordered_plugins
            
        except Exception as e:
            self.logger.error(f"Plugin conflict resolution failed: {e}")
            return plugins  # Return original plugins as fallback
    
    def _group_plugins(self, plugins: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """Group plugins by name for conflict resolution"""
        grouped = defaultdict(list)
        for plugin in plugins:
            plugin_name = plugin.get('name', 'unknown')
            grouped[plugin_name].append(plugin)
        return dict(grouped)
    
    def _handle_multi_instance_plugins(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Handle plugins that can have multiple instances"""
        if plugin_name == 'luascriptexecuter':
            return self._merge_lua_script_plugins(plugins, api_name)
        elif plugin_name in ['pre-function', 'post-function']:
            return self._merge_function_plugins(plugin_name, plugins, api_name)
        elif plugin_name.endswith('-log'):
            return self._optimize_logging_plugins(plugin_name, plugins, api_name)
        else:
            # For other multi-instance plugins, keep separate but optimize
            return self._optimize_multi_instance_plugins(plugin_name, plugins, api_name)
    
    def _handle_single_instance_plugins(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Handle plugins that can only have one instance"""
        if len(plugins) == 1:
            return plugins
        
        # Check if we can upgrade to advanced version
        advanced_plugin = self._try_upgrade_to_advanced(plugin_name, plugins)
        if advanced_plugin:
            return [advanced_plugin]
        
        # Merge configurations if possible
        merged_plugin = self._merge_plugin_configurations(plugin_name, plugins, api_name)
        if merged_plugin:
            return [merged_plugin]
        
        # Choose the best plugin based on priority and completeness
        best_plugin = self._choose_best_plugin(plugins)
        self.logger.warning(f"Multiple {plugin_name} plugins found, keeping the most complete one")
        return [best_plugin]
    
    def _merge_lua_script_plugins(self, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Merge multiple LuaScriptExecuter plugins into one"""
        if len(plugins) <= 1:
            return plugins
        
        merged_script = "-- Merged Lua Scripts\\n\\n"
        all_tags = set()
        all_configs = []
        
        for i, plugin in enumerate(plugins):
            script_code = plugin.get('config', {}).get('script', '')
            if script_code:
                merged_script += f"-- Script {i+1}: {plugin.get('tags', ['unknown'])[1] if len(plugin.get('tags', [])) > 1 else 'unknown'}\\n"
                merged_script += f"local function execute_script_{i+1}()\\n"
                merged_script += self._indent_code(script_code, 4)
                merged_script += f"\\nend\\n\\n"
            
            # Collect tags and configs
            all_tags.update(plugin.get('tags', []))
            all_configs.append(plugin.get('config', {}))
        
        # Add execution wrapper
        merged_script += "-- Execute all scripts\\n"
        for i in range(len(plugins)):
            merged_script += f"execute_script_{i+1}()\\n"
        
        # Create merged plugin
        merged_config = self._merge_configs(all_configs)
        merged_config['script'] = merged_script
        
        merged_plugin = {
            'name': 'luascriptexecuter',
            'config': merged_config,
            'tags': list(all_tags) + [f"api:{api_name}", "merged-scripts"],
            'api_flow': plugins[0].get('api_flow', 'both'),
            'priority': self.plugin_priorities.get('luascriptexecuter', 900)
        }
        
        self.logger.info(f"Merged {len(plugins)} LuaScriptExecuter plugins into one")
        return [merged_plugin]
    
    def _merge_function_plugins(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Merge pre-function or post-function plugins"""
        if len(plugins) <= 1:
            return plugins
        
        merged_functions = []
        all_tags = set()
        
        for plugin in plugins:
            config = plugin.get('config', {})
            for phase in ['certificate', 'rewrite', 'access', 'header_filter', 'body_filter', 'log']:
                if phase in config and config[phase]:
                    if isinstance(config[phase], list):
                        merged_functions.extend(config[phase])
                    else:
                        merged_functions.append(config[phase])
            
            all_tags.update(plugin.get('tags', []))
        
        if not merged_functions:
            return plugins[:1]  # Return first plugin if no functions found
        
        # Create merged plugin
        merged_plugin = {
            'name': plugin_name,
            'config': {
                'access' if plugin_name == 'pre-function' else 'header_filter': merged_functions
            },
            'tags': list(all_tags) + [f"api:{api_name}", "merged-functions"],
            'api_flow': plugins[0].get('api_flow', 'request' if plugin_name == 'pre-function' else 'response'),
            'priority': self.plugin_priorities.get(plugin_name, 900)
        }
        
        self.logger.info(f"Merged {len(plugins)} {plugin_name} plugins into one")
        return [merged_plugin]
    
    def _optimize_logging_plugins(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Optimize logging plugins by merging similar configurations"""
        if len(plugins) <= 1:
            return plugins
        
        # Group by similar configurations
        config_groups = defaultdict(list)
        for plugin in plugins:
            config_key = self._get_config_signature(plugin.get('config', {}))
            config_groups[config_key].append(plugin)
        
        optimized_plugins = []
        for config_group in config_groups.values():
            if len(config_group) == 1:
                optimized_plugins.extend(config_group)
            else:
                # Merge similar configurations
                merged_plugin = self._merge_similar_logging_configs(plugin_name, config_group, api_name)
                optimized_plugins.append(merged_plugin)
        
        self.logger.info(f"Optimized {len(plugins)} {plugin_name} plugins to {len(optimized_plugins)}")
        return optimized_plugins
    
    def _try_upgrade_to_advanced(self, plugin_name: str, plugins: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Try to upgrade basic plugin to advanced version"""
        if plugin_name not in self.plugin_alternatives:
            return None
        
        advanced_name = self.plugin_alternatives[plugin_name][0]
        
        # Merge all configurations into advanced plugin
        merged_config = {}
        all_tags = set()
        
        for plugin in plugins:
            config = plugin.get('config', {})
            merged_config.update(config)
            all_tags.update(plugin.get('tags', []))
        
        # Convert basic config to advanced config
        advanced_config = self._convert_to_advanced_config(plugin_name, merged_config)
        
        advanced_plugin = {
            'name': advanced_name,
            'config': advanced_config,
            'tags': list(all_tags) + ["upgraded-to-advanced"],
            'api_flow': plugins[0].get('api_flow', 'both'),
            'priority': self.plugin_priorities.get(advanced_name, 500)
        }
        
        self.logger.info(f"Upgraded {plugin_name} to {advanced_name}")
        return advanced_plugin
    
    def _merge_plugin_configurations(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> Optional[Dict[str, Any]]:
        """Merge configurations of similar plugins"""
        try:
            merged_config = {}
            all_tags = set()
            
            for plugin in plugins:
                config = plugin.get('config', {})
                
                # Merge configurations based on plugin type
                if plugin_name in ['request-transformer', 'request-transformer-advanced']:
                    merged_config = self._merge_transformer_configs(merged_config, config)
                elif plugin_name in ['response-transformer', 'response-transformer-advanced']:
                    merged_config = self._merge_transformer_configs(merged_config, config)
                elif plugin_name in ['rate-limiting', 'rate-limiting-advanced']:
                    merged_config = self._merge_rate_limiting_configs(merged_config, config)
                else:
                    # Generic merge
                    merged_config.update(config)
                
                all_tags.update(plugin.get('tags', []))
            
            merged_plugin = {
                'name': plugin_name,
                'config': merged_config,
                'tags': list(all_tags) + [f"api:{api_name}", "merged-config"],
                'api_flow': plugins[0].get('api_flow', 'both'),
                'priority': self.plugin_priorities.get(plugin_name, 500)
            }
            
            return merged_plugin
            
        except Exception as e:
            self.logger.error(f"Config merge failed for {plugin_name}: {e}")
            return None
    
    def _merge_transformer_configs(self, base_config: Dict[str, Any], new_config: Dict[str, Any]) -> Dict[str, Any]:
        """Merge transformer plugin configurations"""
        merged = base_config.copy()
        
        for action in ['add', 'remove', 'replace', 'append']:
            if action in new_config:
                if action not in merged:
                    merged[action] = {}
                
                for target in ['headers', 'querystring', 'body']:
                    if target in new_config[action]:
                        if target not in merged[action]:
                            merged[action][target] = []
                        
                        if isinstance(new_config[action][target], list):
                            merged[action][target].extend(new_config[action][target])
                        else:
                            merged[action][target].append(new_config[action][target])
        
        return merged
    
    def _merge_rate_limiting_configs(self, base_config: Dict[str, Any], new_config: Dict[str, Any]) -> Dict[str, Any]:
        """Merge rate limiting configurations (use most restrictive)"""
        merged = base_config.copy()
        
        for time_unit in ['second', 'minute', 'hour', 'day', 'month', 'year']:
            if time_unit in new_config:
                if time_unit not in merged:
                    merged[time_unit] = new_config[time_unit]
                else:
                    # Use the more restrictive limit (lower value)
                    merged[time_unit] = min(merged[time_unit], new_config[time_unit])
        
        # Merge other config options
        for key, value in new_config.items():
            if key not in ['second', 'minute', 'hour', 'day', 'month', 'year']:
                merged[key] = value
        
        return merged
    
    def _choose_best_plugin(self, plugins: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Choose the best plugin from a list based on completeness and priority"""
        def plugin_score(plugin):
            config = plugin.get('config', {})
            score = len(config)  # More configuration = higher score
            
            # Bonus for advanced plugins
            if 'advanced' in plugin.get('name', ''):
                score += 10
            
            # Bonus for plugins with tags
            if plugin.get('tags'):
                score += len(plugin['tags'])
            
            return score
        
        return max(plugins, key=plugin_score)
    
    def _apply_plugin_ordering(self, plugins: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Apply proper plugin execution ordering"""
        def get_priority(plugin):
            return plugin.get('priority', self.plugin_priorities.get(plugin.get('name', ''), 500))
        
        return sorted(plugins, key=get_priority)
    
    def _convert_to_advanced_config(self, basic_plugin: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Convert basic plugin config to advanced plugin config"""
        if basic_plugin == 'rate-limiting':
            # Convert to rate-limiting-advanced format
            advanced_config = config.copy()
            if 'limit' not in advanced_config and any(k in config for k in ['second', 'minute', 'hour', 'day']):
                # Convert time-based limits to advanced format
                limits = []
                window_sizes = []
                for time_unit, multiplier in [('second', 1), ('minute', 60), ('hour', 3600), ('day', 86400)]:
                    if time_unit in config:
                        limits.append(config[time_unit])
                        window_sizes.append(multiplier)
                
                if limits:
                    advanced_config['limit'] = limits
                    advanced_config['window_size'] = window_sizes
            
            return advanced_config
        
        return config
    
    def _get_config_signature(self, config: Dict[str, Any]) -> str:
        """Get a signature for configuration to group similar configs"""
        import json
        try:
            # Create a simplified signature
            signature_data = {}
            for key, value in config.items():
                if isinstance(value, (str, int, bool)):
                    signature_data[key] = value
                elif isinstance(value, (list, dict)):
                    signature_data[key] = str(type(value).__name__)
            
            return json.dumps(signature_data, sort_keys=True)
        except:
            return str(hash(str(config)))
    
    def _merge_similar_logging_configs(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> Dict[str, Any]:
        """Merge similar logging plugin configurations"""
        base_plugin = plugins[0]
        merged_config = base_plugin.get('config', {}).copy()
        all_tags = set()
        
        for plugin in plugins:
            all_tags.update(plugin.get('tags', []))
        
        # Add merged indicator to tags
        all_tags.add("merged-logging")
        
        return {
            'name': plugin_name,
            'config': merged_config,
            'tags': list(all_tags),
            'api_flow': base_plugin.get('api_flow', 'both'),
            'priority': self.plugin_priorities.get(plugin_name, 1200)
        }
    
    def _optimize_multi_instance_plugins(self, plugin_name: str, plugins: List[Dict[str, Any]], api_name: str) -> List[Dict[str, Any]]:
        """Optimize multi-instance plugins without merging"""
        # For now, just return as-is but could add optimization logic
        return plugins
    
    def _merge_configs(self, configs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Merge multiple configurations"""
        merged = {}
        for config in configs:
            for key, value in config.items():
                if key not in merged:
                    merged[key] = value
                elif isinstance(value, dict) and isinstance(merged[key], dict):
                    merged[key].update(value)
                elif isinstance(value, list) and isinstance(merged[key], list):
                    merged[key].extend(value)
                else:
                    merged[key] = value  # Override with latest value
        
        return merged
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\\n'.join(indent + line for line in code.split('\\n'))