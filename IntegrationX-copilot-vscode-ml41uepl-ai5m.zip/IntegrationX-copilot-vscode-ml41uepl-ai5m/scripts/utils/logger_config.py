import logging
import sys

# Configures the root logger for the application.
def setup_logging():
    # Create a handler that prints to stdout
    handler = logging.StreamHandler(sys.stdout)
    # Set a formatter to make the logs readable
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    # Get the root logger and add the handler
    logging.basicConfig(level=logging.INFO, handlers=[handler])