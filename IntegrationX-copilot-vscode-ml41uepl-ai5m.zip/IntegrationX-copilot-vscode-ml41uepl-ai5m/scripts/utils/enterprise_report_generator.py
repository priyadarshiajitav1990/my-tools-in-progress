#!/usr/bin/env python3
"""
Enterprise Report Generator
Generates colorful, professional reports with charts and graphs
"""

import json
import base64
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

class EnterpriseReportGenerator:
    """Enterprise-grade report generator with charts and styling"""
    
    def __init__(self):
        self.report_style = self._get_interactive_report_css()
        self.chart_colors = [
            '#2E86AB', '#A23B72', '#F18F01', '#C73E1D', 
            '#6A994E', '#577590', '#F8961E', '#90323D'
        ]
    
    def generate_migration_report(self, migration_results: List[Dict[str, Any]], 
                                overall_summary_stats: Dict[str, Any]) -> str:
        """Generate comprehensive migration report with charts"""
        
        # Prepare data for JavaScript embedding
        js_migration_data = json.dumps(self._prepare_js_migration_data(migration_results, overall_summary_stats), indent=2)
        js_tool_documentation = json.dumps(self._get_tool_documentation(), indent=2)
        js_custom_plugins_data = json.dumps(self._get_custom_plugins_data(), indent=2)
        
        # Generate HTML report
        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apigee to Kong Migration Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>{self._get_interactive_report_css()}</style>
</head>
<body>
    <div class="main-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>Migration Tool</h2>
                <p>v2.0 Enterprise</p>
            </div>
            <ul class="sidebar-nav" id="sidebarNav">
                <li><a href="#dashboard" class="nav-link active">Dashboard</a></li>
                <li class="api-links-header" style="padding: 15px 20px 5px; color: #95a5a6; font-size: 0.8em; text-transform: uppercase;">Migrated APIs</li>
                <!-- API links will be injected here -->
                <li class="nav-divider" style="height: 1px; background: #34495e; margin: 10px 0;"></li>
                <li><a href="#documentation" class="nav-link">Documentation</a></li>
                <li><a href="#plugins" class="nav-link">Custom Plugins</a></li>
            </ul>
        </nav>

        <main class="content" id="mainContent">
            <!-- Pages will be injected here -->
        </main>
    </div>

    <script>
        const migrationData = {js_migration_data};
        const toolDocumentation = {js_tool_documentation};
        const customPluginsData = {js_custom_plugins_data};

        {self._get_interactive_report_js()}
    </script>
</body>
</html>
"""
        return html_content
    def _get_interactive_report_js(self) -> str:

    def _get_interactive_report_js(self) -> str:
        """Returns the JavaScript for the interactive HTML report."""
        return """
        function renderDashboard() {
            const totalAPIs = migrationData.migration_summary.total_apis;
            const successful = migrationData.migration_summary.successful_migrations;
            const failed = migrationData.migration_summary.failed_migrations;
            const totalPolicies = migrationData.overall_statistics.policies_migrated + (migrationData.overall_statistics.entities_skipped || 0);
            const efficiency = totalPolicies > 0 ? (migrationData.overall_statistics.policies_migrated / totalPolicies * 100).toFixed(1) : 'N/A';

            return `
                <div class="page active" id="dashboard">
                    <div class="page-header"><h1>Migration Dashboard</h1></div>
                    <div class="card">
                        <h2>Auto-Refresh Settings</h2>
                        <div style="display: flex; align-items: center; gap: 15px; margin-top: 15px;">
                            <input type="checkbox" id="autoRefreshToggle">
                            <label for="autoRefreshToggle">Enable Auto-Refresh</label>
                            <input type="number" id="refreshInterval" value="5" min="0.1" step="0.1" style="width: 80px; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <label for="refreshInterval">minutes</label>
                            <button id="saveRefreshSettings" style="padding: 8px 15px; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;">Save Settings</button>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Executive Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${totalAPIs}</h3><p>APIs Processed</p></div>
                            <div class="metric-card"><h3>${successful}</h3><p>Successful</p></div>
                            <div class="metric-card"><h3>${failed}</h3><p>Failed</p></div>
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Tool Efficiency</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Migration Results</h2>
                        <div class="table-container">
                            <table>
                                <thead><tr><th>API Name</th><th>Status</th><th>Policies Migrated</th><th>Plugins Generated</th></tr></thead>
                                <tbody>
                                    ${migrationData.api_results.map(api => `
                                        <tr>
                                            <td><a href="#${api.api_name}" class="nav-link" data-target="${api.api_name}">${api.api_name}</a></td>
                                            <td><span class="status-badge ${api.status === 'SUCCESS' ? 'status-success' : 'status-failed'}">${api.status}</span></td>
                                            <td>${(api.statistics || {}).policies_processed || 0}</td>
                                            <td>${(api.statistics || {}).plugins_generated || 0}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderApiPage(api) {
            const stats = api.statistics || {};
            const totalPolicies = (stats.policies_processed || 0) + (stats.policies_skipped || 0);
            const efficiency = totalPolicies > 0 ? ((stats.policies_processed || 0) / totalPolicies * 100).toFixed(1) : 'N/A';
            const kongConfig = api.kong_config || { services: [], routes: [], plugins: [] };

            return `
                <div class="page" id="${api.api_name}">
                    <div class="page-header"><h1>API: ${api.api_name}</h1></div>
                    <div class="card">
                        <h2>Migration Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Migration Efficiency</p></div>
                            <div class="metric-card"><h3>${kongConfig.services.length}</h3><p>Services Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.routes.length}</h3><p>Routes Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.plugins.length}</h3><p>Plugins Created</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Entity Migration Mapping</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Kong Entity</th><th>Status</th></tr></thead>
                                <tbody>
                                    ${kongConfig.services.length > 0 ? `<tr><td>API Proxy: ${api.api_name}</td><td>Service: ${kongConfig.services[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.routes.length > 0 ? `<tr><td>Base Path</td><td>Route: ${kongConfig.routes[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.plugins.map(p => `<tr><td>Policy (various)</td><td>Plugin: ${p.name}</td><td><span class="status-badge status-success">Created</span></td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <div class="card">
                        <h2>Migration Failures & Skipped Entities</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Reason</th></tr></thead>
                                <tbody>
                                    ${(stats.policies_skipped || 0) === 0 ? '<tr><td colspan="2">No entities were skipped or failed to migrate.</td></tr>' : '<!-- Skipped items here -->'}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Detailed Logs</h2>
                        <div class="log-panel">${api.logs || 'No detailed logs available for this API.'}</div>
                    </div>
                </div>
            `;
        }

        function renderDocumentationPage() {
            return `
                <div class="page" id="documentation">
                    <div class="page-header"><h1>Tool Documentation</h1></div>
                    <div class="card">
                        <h2>Key Features</h2>
                        <ul>${toolDocumentation.features.map(f => `<li>${f}</li>`).join('')}</ul>
                    </div>
                    <div class="card">
                        <h2>Project Structure</h2>
                        <p>This table outlines the key files in the migration tool and their purpose.</p>
                        <div class="table-container" style="margin-top:15px;">
                            <table>
                                <thead><tr><th>File / Folder</th><th>Description & Complexity Handling</th></tr></thead>
                                <tbody>
                                    ${toolDocumentation.structure.map(s => `<tr><td><code>${s.file}</code></td><td>${s.description}</td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderPluginsPage() {
            return `
                <div class="page" id="plugins">
                    <div class="page-header"><h1>Custom Plugins Guide</h1></div>
                    ${customPluginsData.map(p => `
                        <div class="card">
                            <h2>${p.name}</h2>
                            <p>${p.functionality}</p>
                            <h3 style="margin-top:20px;">YAML Configuration</h3>
                            <pre class="code-block"><code>${p.yaml.trim()}</code></pre>
                            <h3 style="margin-top:20px;">Example Use Case</h3>
                            <p>${p.example}</p>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Auto-refresh logic
        let autoRefreshTimer;
        let autoRefreshEnabled = false;
        let refreshIntervalMinutes = 5; // Default to 5 minutes

        function saveAutoRefreshSettings() {
            localStorage.setItem('autoRefreshEnabled', autoRefreshEnabled);
            localStorage.setItem('refreshIntervalMinutes', refreshIntervalMinutes);
        }

        function loadAutoRefreshSettings() {
            const storedEnabled = localStorage.getItem('autoRefreshEnabled');
            const storedInterval = localStorage.getItem('refreshIntervalMinutes');

            if (storedEnabled !== null) {
                autoRefreshEnabled = JSON.parse(storedEnabled);
            }
            if (storedInterval !== null) {
                refreshIntervalMinutes = parseFloat(storedInterval);
            }

            document.getElementById('autoRefreshToggle').checked = autoRefreshEnabled;
            document.getElementById('refreshInterval').value = refreshIntervalMinutes;
        }

        function startAutoRefresh() {
            stopAutoRefresh(); // Clear any existing timer
            if (autoRefreshEnabled && refreshIntervalMinutes > 0) {
                const intervalMilliseconds = refreshIntervalMinutes * 60 * 1000;
                autoRefreshTimer = setTimeout(() => {
                    location.reload();
                }, intervalMilliseconds);
                console.log(`Auto-refresh enabled: page will refresh in ${refreshIntervalMinutes} minutes.`);
            } else {
                console.log('Auto-refresh is disabled or interval is invalid.');
            }
        }

        function stopAutoRefresh() {
            if (autoRefreshTimer) {
                clearTimeout(autoRefreshTimer);
                autoRefreshTimer = null;
                console.log('Auto-refresh stopped.');
            }
        }

        function applyAutoRefreshSettings() {
            autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
            const newInterval = parseFloat(document.getElementById('refreshInterval').value);
            if (!isNaN(newInterval) && newInterval > 0) {
                refreshIntervalMinutes = newInterval;
            } else {
                alert('Please enter a valid refresh interval (e.g., 5, 0.5).');
                document.getElementById('refreshInterval').value = refreshIntervalMinutes; // Revert to last valid
                return;
            }
            saveAutoRefreshSettings();
            startAutoRefresh();
            alert(`Auto-refresh settings saved. Enabled: ${autoRefreshEnabled}, Interval: ${refreshIntervalMinutes} minutes.`);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const sidebarNav = document.getElementById('sidebarNav');
            const mainContent = document.getElementById('mainContent');

            // Inject API links
            const apiLinksHeader = sidebarNav.querySelector('.api-links-header');
            migrationData.api_results.forEach(api => {
                const li = document.createElement('li');
                li.innerHTML = `<a href="#${api.api_name}" class="nav-link">${api.api_name}</a>`;
                apiLinksHeader.insertAdjacentElement('afterend', li);
            });

            // Inject pages
            mainContent.innerHTML += renderDashboard();
            migrationData.api_results.forEach(api => {
                mainContent.innerHTML += renderApiPage(api);
            });
            mainContent.innerHTML += renderDocumentationPage();
            mainContent.innerHTML += renderPluginsPage();

            // Navigation logic
            function handleNavigation() {
                const hash = window.location.hash || '#dashboard';
                const targetId = hash.substring(1);

                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.toggle('active', link.hash === hash || link.dataset.target === targetId);
                });
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.toggle('active', page.id === targetId);
                });
            }

            document.body.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    window.location.hash = e.target.hash || e.target.dataset.target;
                }
            });
            
            window.addEventListener('hashchange', handleNavigation);
            handleNavigation(); // Initial load

            // Setup auto-refresh only on dashboard
            if (document.getElementById('dashboard')) {
                loadAutoRefreshSettings();
                startAutoRefresh(); // Start timer on load

                document.getElementById('saveRefreshSettings').addEventListener('click', applyAutoRefreshSettings);
                document.getElementById('autoRefreshToggle').addEventListener('change', () => {
                    autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
                    saveAutoRefreshSettings();
                    startAutoRefresh(); // Restart timer with new enabled state
                });
            }
        });
        """

    def _get_interactive_report_js(self) -> str:
        """Returns the JavaScript for the interactive HTML report."""
        return """
        function renderDashboard() {
            const totalAPIs = migrationData.migration_summary.total_apis;
            const successful = migrationData.migration_summary.successful_migrations;
            const failed = migrationData.migration_summary.failed_migrations;
            const totalPolicies = migrationData.overall_statistics.policies_migrated + (migrationData.overall_statistics.entities_skipped || 0);
            const efficiency = totalPolicies > 0 ? (migrationData.overall_statistics.policies_migrated / totalPolicies * 100).toFixed(1) : 'N/A';

            return `
                <div class="page active" id="dashboard">
                    <div class="page-header"><h1>Migration Dashboard</h1></div>
                    <div class="card">
                        <h2>Auto-Refresh Settings</h2>
                        <div style="display: flex; align-items: center; gap: 15px; margin-top: 15px;">
                            <input type="checkbox" id="autoRefreshToggle">
                            <label for="autoRefreshToggle">Enable Auto-Refresh</label>
                            <input type="number" id="refreshInterval" value="5" min="0.1" step="0.1" style="width: 80px; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <label for="refreshInterval">minutes</label>
                            <button id="saveRefreshSettings" style="padding: 8px 15px; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;">Save Settings</button>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Executive Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${totalAPIs}</h3><p>APIs Processed</p></div>
                            <div class="metric-card"><h3>${successful}</h3><p>Successful</p></div>
                            <div class="metric-card"><h3>${failed}</h3><p>Failed</p></div>
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Tool Efficiency</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Migration Results</h2>
                        <div class="table-container">
                            <table>
                                <thead><tr><th>API Name</th><th>Status</th><th>Policies Migrated</th><th>Plugins Generated</th></tr></thead>
                                <tbody>
                                    ${migrationData.api_results.map(api => `
                                        <tr>
                                            <td><a href="#${api.api_name}" class="nav-link" data-target="${api.api_name}">${api.api_name}</a></td>
                                            <td><span class="status-badge ${api.status === 'SUCCESS' ? 'status-success' : 'status-failed'}">${api.status}</span></td>
                                            <td>${(api.statistics || {}).policies_processed || 0}</td>
                                            <td>${(api.statistics || {}).plugins_generated || 0}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderApiPage(api) {
            const stats = api.statistics || {};
            const totalPolicies = (stats.policies_processed || 0) + (stats.policies_skipped || 0);
            const efficiency = totalPolicies > 0 ? ((stats.policies_processed || 0) / totalPolicies * 100).toFixed(1) : 'N/A';
            const kongConfig = api.kong_config || { services: [], routes: [], plugins: [] };

            return `
                <div class="page" id="${api.api_name}">
                    <div class="page-header"><h1>API: ${api.api_name}</h1></div>
                    <div class="card">
                        <h2>Migration Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Migration Efficiency</p></div>
                            <div class="metric-card"><h3>${kongConfig.services.length}</h3><p>Services Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.routes.length}</h3><p>Routes Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.plugins.length}</h3><p>Plugins Created</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Entity Migration Mapping</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Kong Entity</th><th>Status</th></tr></thead>
                                <tbody>
                                    ${kongConfig.services.length > 0 ? `<tr><td>API Proxy: ${api.api_name}</td><td>Service: ${kongConfig.services[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.routes.length > 0 ? `<tr><td>Base Path</td><td>Route: ${kongConfig.routes[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.plugins.map(p => `<tr><td>Policy (various)</td><td>Plugin: ${p.name}</td><td><span class="status-badge status-success">Created</span></td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <div class="card">
                        <h2>Migration Failures & Skipped Entities</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Reason</th></tr></thead>
                                <tbody>
                                    ${(stats.policies_skipped || 0) === 0 ? '<tr><td colspan="2">No entities were skipped or failed to migrate.</td></tr>' : '<!-- Skipped items here -->'}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Detailed Logs</h2>
                        <div class="log-panel">${api.logs || 'No detailed logs available for this API.'}</div>
                    </div>
                </div>
            `;
        }

        function renderDocumentationPage() {
            return `
                <div class="page" id="documentation">
                    <div class="page-header"><h1>Tool Documentation</h1></div>
                    <div class="card">
                        <h2>Key Features</h2>
                        <ul>${toolDocumentation.features.map(f => `<li>${f}</li>`).join('')}</ul>
                    </div>
                    <div class="card">
                        <h2>Project Structure</h2>
                        <p>This table outlines the key files in the migration tool and their purpose.</p>
                        <div class="table-container" style="margin-top:15px;">
                            <table>
                                <thead><tr><th>File / Folder</th><th>Description & Complexity Handling</th></tr></thead>
                                <tbody>
                                    ${toolDocumentation.structure.map(s => `<tr><td><code>${s.file}</code></td><td>${s.description}</td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderPluginsPage() {
            return `
                <div class="page" id="plugins">
                    <div class="page-header"><h1>Custom Plugins Guide</h1></div>
                    ${customPluginsData.map(p => `
                        <div class="card">
                            <h2>${p.name}</h2>
                            <p>${p.functionality}</p>
                            <h3 style="margin-top:20px;">YAML Configuration</h3>
                            <pre class="code-block"><code>${p.yaml.trim()}</code></pre>
                            <h3 style="margin-top:20px;">Example Use Case</h3>
                            <p>${p.example}</p>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Auto-refresh logic
        let autoRefreshTimer;
        let autoRefreshEnabled = false;
        let refreshIntervalMinutes = 5; // Default to 5 minutes

        function saveAutoRefreshSettings() {
            localStorage.setItem('autoRefreshEnabled', autoRefreshEnabled);
            localStorage.setItem('refreshIntervalMinutes', refreshIntervalMinutes);
        }

        function loadAutoRefreshSettings() {
            const storedEnabled = localStorage.getItem('autoRefreshEnabled');
            const storedInterval = localStorage.getItem('refreshIntervalMinutes');

            if (storedEnabled !== null) {
                autoRefreshEnabled = JSON.parse(storedEnabled);
            }
            if (storedInterval !== null) {
                refreshIntervalMinutes = parseFloat(storedInterval);
            }

            document.getElementById('autoRefreshToggle').checked = autoRefreshEnabled;
            document.getElementById('refreshInterval').value = refreshIntervalMinutes;
        }

        function startAutoRefresh() {
            stopAutoRefresh(); // Clear any existing timer
            if (autoRefreshEnabled && refreshIntervalMinutes > 0) {
                const intervalMilliseconds = refreshIntervalMinutes * 60 * 1000;
                autoRefreshTimer = setTimeout(() => {
                    location.reload();
                }, intervalMilliseconds);
                console.log(`Auto-refresh enabled: page will refresh in ${refreshIntervalMinutes} minutes.`);
            } else {
                console.log('Auto-refresh is disabled or interval is invalid.');
            }
        }

        function stopAutoRefresh() {
            if (autoRefreshTimer) {
                clearTimeout(autoRefreshTimer);
                autoRefreshTimer = null;
                console.log('Auto-refresh stopped.');
            }
        }

        function applyAutoRefreshSettings() {
            autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
            const newInterval = parseFloat(document.getElementById('refreshInterval').value);
            if (!isNaN(newInterval) && newInterval > 0) {
                refreshIntervalMinutes = newInterval;
            } else {
                alert('Please enter a valid refresh interval (e.g., 5, 0.5).');
                document.getElementById('refreshInterval').value = refreshIntervalMinutes; // Revert to last valid
                return;
            }
            saveAutoRefreshSettings();
            startAutoRefresh();
            alert(`Auto-refresh settings saved. Enabled: ${autoRefreshEnabled}, Interval: ${refreshIntervalMinutes} minutes.`);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const sidebarNav = document.getElementById('sidebarNav');
            const mainContent = document.getElementById('mainContent');

            // Inject API links
            const apiLinksHeader = sidebarNav.querySelector('.api-links-header');
            migrationData.api_results.forEach(api => {
                const li = document.createElement('li');
                li.innerHTML = `<a href="#${api.api_name}" class="nav-link">${api.api_name}</a>`;
                apiLinksHeader.insertAdjacentElement('afterend', li);
            });

            // Inject pages
            mainContent.innerHTML += renderDashboard();
            migrationData.api_results.forEach(api => {
                mainContent.innerHTML += renderApiPage(api);
            });
            mainContent.innerHTML += renderDocumentationPage();
            mainContent.innerHTML += renderPluginsPage();

            // Navigation logic
            function handleNavigation() {
                const hash = window.location.hash || '#dashboard';
                const targetId = hash.substring(1);

                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.toggle('active', link.hash === hash || link.dataset.target === targetId);
                });
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.toggle('active', page.id === targetId);
                });
            }

            document.body.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    window.location.hash = e.target.hash || e.target.dataset.target;
                }
            });
            
            window.addEventListener('hashchange', handleNavigation);
            handleNavigation(); // Initial load

            // Setup auto-refresh only on dashboard
            if (document.getElementById('dashboard')) {
                loadAutoRefreshSettings();
                startAutoRefresh(); // Start timer on load

                document.getElementById('saveRefreshSettings').addEventListener('click', applyAutoRefreshSettings);
                document.getElementById('autoRefreshToggle').addEventListener('change', () => {
                    autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
                    saveAutoRefreshSettings();
                    startAutoRefresh(); // Restart timer with new enabled state
                });
            }
        });
        """

    def _get_interactive_report_js(self) -> str:
        """Returns the JavaScript for the interactive HTML report."""
        return """
        function renderDashboard() {
            const totalAPIs = migrationData.migration_summary.total_apis;
            const successful = migrationData.migration_summary.successful_migrations;
            const failed = migrationData.migration_summary.failed_migrations;
            const totalPolicies = migrationData.overall_statistics.policies_migrated + (migrationData.overall_statistics.entities_skipped || 0);
            const efficiency = totalPolicies > 0 ? (migrationData.overall_statistics.policies_migrated / totalPolicies * 100).toFixed(1) : 'N/A';

            return `
                <div class="page active" id="dashboard">
                    <div class="page-header"><h1>Migration Dashboard</h1></div>
                    <div class="card">
                        <h2>Auto-Refresh Settings</h2>
                        <div style="display: flex; align-items: center; gap: 15px; margin-top: 15px;">
                            <input type="checkbox" id="autoRefreshToggle">
                            <label for="autoRefreshToggle">Enable Auto-Refresh</label>
                            <input type="number" id="refreshInterval" value="5" min="0.1" step="0.1" style="width: 80px; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                            <label for="refreshInterval">minutes</label>
                            <button id="saveRefreshSettings" style="padding: 8px 15px; background-color: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;">Save Settings</button>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Executive Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${totalAPIs}</h3><p>APIs Processed</p></div>
                            <div class="metric-card"><h3>${successful}</h3><p>Successful</p></div>
                            <div class="metric-card"><h3>${failed}</h3><p>Failed</p></div>
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Tool Efficiency</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Migration Results</h2>
                        <div class="table-container">
                            <table>
                                <thead><tr><th>API Name</th><th>Status</th><th>Policies Migrated</th><th>Plugins Generated</th></tr></thead>
                                <tbody>
                                    ${migrationData.api_results.map(api => `
                                        <tr>
                                            <td><a href="#${api.api_name}" class="nav-link" data-target="${api.api_name}">${api.api_name}</a></td>
                                            <td><span class="status-badge ${api.status === 'SUCCESS' ? 'status-success' : 'status-failed'}">${api.status}</span></td>
                                            <td>${api.statistics.policies_processed || 0}</td>
                                            <td>${api.statistics.plugins_generated || 0}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderApiPage(api) {
            const stats = api.statistics || {};
            const totalPolicies = (stats.policies_processed || 0) + (stats.policies_skipped || 0);
            const efficiency = totalPolicies > 0 ? ((stats.policies_processed || 0) / totalPolicies * 100).toFixed(1) : 'N/A';
            const kongConfig = api.kong_config || { services: [], routes: [], plugins: [] };

            return `
                <div class="page" id="${api.api_name}">
                    <div class="page-header"><h1>API: ${api.api_name}</h1></div>
                    <div class="card">
                        <h2>Migration Summary</h2>
                        <div class="grid-container" style="margin-top: 20px;">
                            <div class="metric-card"><h3>${efficiency}%</h3><p>Migration Efficiency</p></div>
                            <div class="metric-card"><h3>${kongConfig.services.length}</h3><p>Services Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.routes.length}</h3><p>Routes Created</p></div>
                            <div class="metric-card"><h3>${kongConfig.plugins.length}</h3><p>Plugins Created</p></div>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Entity Migration Mapping</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Kong Entity</th><th>Status</th></tr></thead>
                                <tbody>
                                    ${kongConfig.services.length > 0 ? `<tr><td>API Proxy: ${api.api_name}</td><td>Service: ${kongConfig.services[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.routes.length > 0 ? `<tr><td>Base Path</td><td>Route: ${kongConfig.routes[0].name}</td><td><span class="status-badge status-success">Created</span></td></tr>` : ''}
                                    ${kongConfig.plugins.map(p => `<tr><td>Policy (various)</td><td>Plugin: ${p.name}</td><td><span class="status-badge status-success">Created</span></td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <div class="card">
                        <h2>Migration Failures & Skipped Entities</h2>
                        <div class="table-container">
                             <table>
                                <thead><tr><th>Apigee Entity</th><th>Reason</th></tr></thead>
                                <tbody>
                                    ${(stats.policies_skipped || 0) === 0 ? '<tr><td colspan="2">No entities were skipped or failed to migrate.</td></tr>' : '<!-- Skipped items here -->'}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card">
                        <h2>Detailed Logs</h2>
                        <div class="log-panel">${api.logs || 'No detailed logs available for this API.'}</div>
                    </div>
                </div>
            `;
        }

        function renderDocumentationPage() {
            return `
                <div class="page" id="documentation">
                    <div class="page-header"><h1>Tool Documentation</h1></div>
                    <div class="card">
                        <h2>Key Features</h2>
                        <ul>${toolDocumentation.features.map(f => `<li>${f}</li>`).join('')}</ul>
                    </div>
                    <div class="card">
                        <h2>Project Structure</h2>
                        <p>This table outlines the key files in the migration tool and their purpose.</p>
                        <div class="table-container" style="margin-top:15px;">
                            <table>
                                <thead><tr><th>File / Folder</th><th>Description & Complexity Handling</th></tr></thead>
                                <tbody>
                                    ${toolDocumentation.structure.map(s => `<tr><td><code>${s.file}</code></td><td>${s.description}</td></tr>`).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        function renderPluginsPage() {
            return `
                <div class="page" id="plugins">
                    <div class="page-header"><h1>Custom Plugins Guide</h1></div>
                    ${customPluginsData.map(p => `
                        <div class="card">
                            <h2>${p.name}</h2>
                            <p>${p.functionality}</p>
                            <h3 style="margin-top:20px;">YAML Configuration</h3>
                            <pre class="code-block"><code>${p.yaml.trim()}</code></pre>
                            <h3 style="margin-top:20px;">Example Use Case</h3>
                            <p>${p.example}</p>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Auto-refresh logic
        let autoRefreshTimer;
        let autoRefreshEnabled = false;
        let refreshIntervalMinutes = 5; // Default to 5 minutes

        function saveAutoRefreshSettings() {
            localStorage.setItem('autoRefreshEnabled', autoRefreshEnabled);
            localStorage.setItem('refreshIntervalMinutes', refreshIntervalMinutes);
        }

        function loadAutoRefreshSettings() {
            const storedEnabled = localStorage.getItem('autoRefreshEnabled');
            const storedInterval = localStorage.getItem('refreshIntervalMinutes');

            if (storedEnabled !== null) {
                autoRefreshEnabled = JSON.parse(storedEnabled);
            }
            if (storedInterval !== null) {
                refreshIntervalMinutes = parseFloat(storedInterval);
            }

            document.getElementById('autoRefreshToggle').checked = autoRefreshEnabled;
            document.getElementById('refreshInterval').value = refreshIntervalMinutes;
        }

        function startAutoRefresh() {
            stopAutoRefresh(); // Clear any existing timer
            if (autoRefreshEnabled && refreshIntervalMinutes > 0) {
                const intervalMilliseconds = refreshIntervalMinutes * 60 * 1000;
                autoRefreshTimer = setTimeout(() => {
                    location.reload();
                }, intervalMilliseconds);
                console.log(`Auto-refresh enabled: page will refresh in ${refreshIntervalMinutes} minutes.`);
            } else {
                console.log('Auto-refresh is disabled or interval is invalid.');
            }
        }

        function stopAutoRefresh() {
            if (autoRefreshTimer) {
                clearTimeout(autoRefreshTimer);
                autoRefreshTimer = null;
                console.log('Auto-refresh stopped.');
            }
        }

        function applyAutoRefreshSettings() {
            autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
            const newInterval = parseFloat(document.getElementById('refreshInterval').value);
            if (!isNaN(newInterval) && newInterval > 0) {
                refreshIntervalMinutes = newInterval;
            } else {
                alert('Please enter a valid refresh interval (e.g., 5, 0.5).');
                document.getElementById('refreshInterval').value = refreshIntervalMinutes; // Revert to last valid
                return;
            }
            saveAutoRefreshSettings();
            startAutoRefresh();
            alert(`Auto-refresh settings saved. Enabled: ${autoRefreshEnabled}, Interval: ${refreshIntervalMinutes} minutes.`);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const sidebarNav = document.getElementById('sidebarNav');
            const mainContent = document.getElementById('mainContent');

            // Inject API links
            const apiLinksHeader = sidebarNav.querySelector('.api-links-header');
            migrationData.api_results.forEach(api => {
                const li = document.createElement('li');
                li.innerHTML = `<a href="#${api.api_name}" class="nav-link">${api.api_name}</a>`;
                apiLinksHeader.insertAdjacentElement('afterend', li);
            });

            // Inject pages
            mainContent.innerHTML += renderDashboard();
            migrationData.api_results.forEach(api => {
                mainContent.innerHTML += renderApiPage(api);
            });
            mainContent.innerHTML += renderDocumentationPage();
            mainContent.innerHTML += renderPluginsPage();

            // Navigation logic
            function handleNavigation() {
                const hash = window.location.hash || '#dashboard';
                const targetId = hash.substring(1);

                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.toggle('active', link.hash === hash || link.dataset.target === targetId);
                });
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.toggle('active', page.id === targetId);
                });
            }

            document.body.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    window.location.hash = e.target.hash || e.target.dataset.target;
                }
            });
            
            window.addEventListener('hashchange', handleNavigation);
            handleNavigation(); // Initial load

            // Setup auto-refresh only on dashboard
            if (document.getElementById('dashboard')) {
                loadAutoRefreshSettings();
                startAutoRefresh(); // Start timer on load

                document.getElementById('saveRefreshSettings').addEventListener('click', applyAutoRefreshSettings);
                document.getElementById('autoRefreshToggle').addEventListener('change', () => {
                    autoRefreshEnabled = document.getElementById('autoRefreshToggle').checked;
                    saveAutoRefreshSettings();
                    startAutoRefresh(); // Restart timer with new enabled state
                });
            }
        });
        """