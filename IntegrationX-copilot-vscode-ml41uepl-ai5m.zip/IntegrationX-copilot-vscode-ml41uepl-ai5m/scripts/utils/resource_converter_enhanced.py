#!/usr/bin/env python3
"""
Enhanced Resource Converter
Converts JavaScript, Java, Python, and other resource files to Lua scripts
"""

import os
import json
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional, List

class EnhancedResourceConverter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.project_root = Path(__file__).parent.parent.parent
        self.lua_converter_jar = self.project_root / "luaconverters" / "lua-converter-tool-main" / "target" / "lua-converter-tool-1.0.0-jar-with-dependencies.jar"
        self.py_to_lua_path = self.project_root / "luaconverters" / "py-to-lua-main"
        
    def convert_resource_to_lua(self, resource_url: str, resource_content: str, policy_type: str = "") -> Optional[str]:
        """Convert resource file to Lua script based on file type"""
        try:
            if not resource_content or not resource_content.strip():
                return self._generate_placeholder_lua(resource_url, policy_type)
            
            # Determine file type from URL
            file_type = self._determine_file_type(resource_url)
            
            if file_type == "javascript":
                return self._convert_javascript_to_lua(resource_content, resource_url)
            elif file_type == "java":
                return self._convert_java_to_lua(resource_content, resource_url)
            elif file_type == "python":
                return self._convert_python_to_lua(resource_content, resource_url)
            elif file_type == "xslt":
                return self._handle_xslt_content(resource_content, resource_url)
            elif file_type == "wsdl":
                return self._handle_wsdl_content(resource_content, resource_url)
            elif file_type == "openapi":
                return self._handle_openapi_content(resource_content, resource_url)
            else:
                return self._generate_generic_lua(resource_content, resource_url, policy_type)
                
        except Exception as e:
            self.logger.error(f"Resource conversion failed for {resource_url}: {e}")
            return self._generate_fallback_lua(resource_url, policy_type, str(e))
    
    def _determine_file_type(self, resource_url: str) -> str:
        """Determine file type from resource URL"""
        url_lower = resource_url.lower()
        
        if url_lower.startswith("jsc://") or url_lower.endswith(".js"):
            return "javascript"
        elif url_lower.startswith("java://") or url_lower.endswith(".java") or url_lower.endswith(".jar"):
            return "java"
        elif url_lower.startswith("py://") or url_lower.endswith(".py"):
            return "python"
        elif url_lower.endswith(".xsl") or url_lower.endswith(".xslt"):
            return "xslt"
        elif url_lower.endswith(".wsdl"):
            return "wsdl"
        elif url_lower.endswith(".yaml") or url_lower.endswith(".yml") or "openapi" in url_lower:
            return "openapi"
        else:
            return "unknown"
    
    def _convert_javascript_to_lua(self, js_content: str, resource_url: str) -> str:
        """Convert JavaScript to Lua using the Java converter tool"""
        try:
            if not self.lua_converter_jar.exists():
                self.logger.warning(f"Lua converter JAR not found at {self.lua_converter_jar}")
                return self._generate_js_fallback_lua(js_content, resource_url)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as temp_js:
                temp_js.write(js_content)
                temp_js_path = temp_js.name
            
            try:
                # Run the Java converter
                result = subprocess.run([
                    'java', '-jar', str(self.lua_converter_jar),
                    '--input', temp_js_path,
                    '--type', 'javascript'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 and result.stdout.strip():
                    lua_code = result.stdout.strip()
                    return self._wrap_lua_code(lua_code, resource_url, "JavaScript")
                else:
                    self.logger.warning(f"JS to Lua conversion failed: {result.stderr}")
                    return self._generate_js_fallback_lua(js_content, resource_url)
                    
            finally:
                os.unlink(temp_js_path)
                
        except Exception as e:
            self.logger.error(f"JavaScript conversion error: {e}")
            return self._generate_js_fallback_lua(js_content, resource_url)
    
    def _convert_python_to_lua(self, py_content: str, resource_url: str) -> str:
        """Convert Python to Lua using the py-to-lua tool"""
        try:
            if not self.py_to_lua_path.exists():
                self.logger.warning(f"Python to Lua converter not found at {self.py_to_lua_path}")
                return self._generate_py_fallback_lua(py_content, resource_url)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp_py:
                temp_py.write(py_content)
                temp_py_path = temp_py.name
            
            try:
                # Run the Python converter
                result = subprocess.run([
                    'python', '-m', 'py_to_lua', temp_py_path
                ], capture_output=True, text=True, timeout=30, cwd=str(self.py_to_lua_path))
                
                if result.returncode == 0 and result.stdout.strip():
                    lua_code = result.stdout.strip()
                    return self._wrap_lua_code(lua_code, resource_url, "Python")
                else:
                    self.logger.warning(f"Python to Lua conversion failed: {result.stderr}")
                    return self._generate_py_fallback_lua(py_content, resource_url)
                    
            finally:
                os.unlink(temp_py_path)
                
        except Exception as e:
            self.logger.error(f"Python conversion error: {e}")
            return self._generate_py_fallback_lua(py_content, resource_url)
    
    def _convert_java_to_lua(self, java_content: str, resource_url: str) -> str:
        """Convert Java to Lua using the Java converter tool"""
        try:
            if not self.lua_converter_jar.exists():
                self.logger.warning(f"Lua converter JAR not found at {self.lua_converter_jar}")
                return self._generate_java_fallback_lua(java_content, resource_url)
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.java', delete=False) as temp_java:
                temp_java.write(java_content)
                temp_java_path = temp_java.name
            
            try:
                # Run the Java converter
                result = subprocess.run([
                    'java', '-jar', str(self.lua_converter_jar),
                    '--input', temp_java_path,
                    '--type', 'java'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 and result.stdout.strip():
                    lua_code = result.stdout.strip()
                    return self._wrap_lua_code(lua_code, resource_url, "Java")
                else:
                    self.logger.warning(f"Java to Lua conversion failed: {result.stderr}")
                    return self._generate_java_fallback_lua(java_content, resource_url)
                    
            finally:
                os.unlink(temp_java_path)
                
        except Exception as e:
            self.logger.error(f"Java conversion error: {e}")
            return self._generate_java_fallback_lua(java_content, resource_url)
    
    def _handle_xslt_content(self, xslt_content: str, resource_url: str) -> str:
        """Handle XSLT content for XSLTransform plugin"""
        return f'''
-- XSLT Content from {resource_url}
local xslt_content = [[
{xslt_content}
]]

local function apply_xslt_transform()
    local body = kong.request.get_raw_body()
    if body then
        -- Store XSLT content for plugin use
        kong.ctx.shared.xslt_stylesheet = xslt_content
        kong.ctx.shared.transform_required = true
    end
    return true
end

return apply_xslt_transform()
'''
    
    def _handle_wsdl_content(self, wsdl_content: str, resource_url: str) -> str:
        """Handle WSDL content for SOAP validation"""
        return f'''
-- WSDL Content from {resource_url}
local wsdl_content = [[
{wsdl_content}
]]

local function validate_soap_request()
    local content_type = kong.request.get_header("content-type")
    if content_type and content_type:find("soap") then
        kong.ctx.shared.wsdl_schema = wsdl_content
        kong.ctx.shared.soap_validation_required = true
    end
    return true
end

return validate_soap_request()
'''
    
    def _handle_openapi_content(self, openapi_content: str, resource_url: str) -> str:
        """Handle OpenAPI content for OAS validation"""
        return f'''
-- OpenAPI Specification from {resource_url}
local openapi_spec = [[
{openapi_content}
]]

local function setup_oas_validation()
    kong.ctx.shared.openapi_spec = openapi_spec
    kong.ctx.shared.oas_validation_required = true
    return true
end

return setup_oas_validation()
'''
    
    def _wrap_lua_code(self, lua_code: str, resource_url: str, source_type: str) -> str:
        """Wrap converted Lua code with Kong-specific context"""
        return f'''
-- Converted from {source_type}: {resource_url}
local function execute_converted_code()
    local kong = kong
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- Converted code starts here
{self._indent_code(lua_code, 4)}
    -- Converted code ends here
    
    return true
end

return execute_converted_code()
'''
    
    def _generate_js_fallback_lua(self, js_content: str, resource_url: str) -> str:
        """Generate fallback Lua for JavaScript content"""
        return f'''
-- JavaScript Fallback: {resource_url}
local function javascript_fallback()
    kong.log.warn("JavaScript conversion not available, using fallback")
    
    -- Original JavaScript (commented):
    --[[
{js_content}
    --]]
    
    -- Basic JavaScript-like operations in Lua
    local context = {{
        getVariable = function(name)
            return kong.ctx.shared[name] or kong.request.get_header(name:gsub("request%.header%.", ""))
        end,
        setVariable = function(name, value)
            kong.ctx.shared[name] = value
        end
    }}
    
    -- TODO: Implement JavaScript logic in Lua
    kong.log.info("JavaScript policy executed via fallback")
    return true
end

return javascript_fallback()
'''
    
    def _generate_py_fallback_lua(self, py_content: str, resource_url: str) -> str:
        """Generate fallback Lua for Python content"""
        return f'''
-- Python Fallback: {resource_url}
local function python_fallback()
    kong.log.warn("Python conversion not available, using fallback")
    
    -- Original Python (commented):
    --[[
{py_content}
    --]]
    
    -- Basic Python-like operations in Lua
    local request = kong.request
    local response = kong.response
    
    -- TODO: Implement Python logic in Lua
    kong.log.info("Python policy executed via fallback")
    return true
end

return python_fallback()
'''
    
    def _generate_java_fallback_lua(self, java_content: str, resource_url: str) -> str:
        """Generate fallback Lua for Java content"""
        return f'''
-- Java Fallback: {resource_url}
local function java_fallback()
    kong.log.warn("Java conversion not available, using fallback")
    
    -- Original Java (commented):
    --[[
{java_content}
    --]]
    
    -- Basic Java-like operations in Lua
    local request = kong.request
    local response = kong.response
    
    -- TODO: Implement Java logic in Lua
    kong.log.info("Java policy executed via fallback")
    return true
end

return java_fallback()
'''
    
    def _generate_generic_lua(self, content: str, resource_url: str, policy_type: str) -> str:
        """Generate generic Lua for unknown content types"""
        return f'''
-- Generic Resource: {resource_url} (Policy: {policy_type})
local function generic_resource_handler()
    -- Resource content (as string):
    local resource_content = [[
{content}
]]
    
    kong.ctx.shared.resource_content = resource_content
    kong.log.info("Generic resource handler executed for {policy_type}")
    return true
end

return generic_resource_handler()
'''
    
    def _generate_placeholder_lua(self, resource_url: str, policy_type: str) -> str:
        """Generate placeholder Lua for empty resources"""
        return f'''
-- Placeholder for empty resource: {resource_url}
local function placeholder_handler()
    kong.log.info("Placeholder handler for {policy_type} policy")
    -- TODO: Implement {policy_type} logic
    return true
end

return placeholder_handler()
'''
    
    def _generate_fallback_lua(self, resource_url: str, policy_type: str, error_msg: str) -> str:
        """Generate fallback Lua when conversion fails"""
        return f'''
-- Fallback handler for {resource_url}
local function fallback_handler()
    kong.log.error("Resource conversion failed: {error_msg}")
    kong.log.info("Executing fallback for {policy_type} policy")
    -- TODO: Implement {policy_type} fallback logic
    return true
end

return fallback_handler()
'''
    
    def _indent_code(self, code: str, spaces: int) -> str:
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))