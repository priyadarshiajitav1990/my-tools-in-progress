import json
import os
import logging

def load_and_set_env_variables():
    """
    Loads configuration from configs/config.json and sets environment variables.
    """
    # Get the project root directory
    # This script is located at scripts/utils/config_loader.py
    # Root is ../../
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(os.path.dirname(current_dir))
    
    config_path = os.path.join(project_root, "configs", "config.json")

    if not os.path.exists(config_path):
        logging.error(f"Configuration file 'config.json' not found in the 'configs' directory at {config_path}.")
        logging.error("Please copy 'config.example.json' to 'config.json' and fill in your environment details.")
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    logging.info(f"Loading configurations from {config_path}...")

    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
            
        for key, value in config.items():
            os.environ[key] = str(value)
            
    except Exception as e:
        logging.error(f"Failed to load configuration: {e}")
        raise