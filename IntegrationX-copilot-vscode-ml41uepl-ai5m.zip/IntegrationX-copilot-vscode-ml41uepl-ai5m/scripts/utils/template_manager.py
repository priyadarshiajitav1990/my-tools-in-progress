#!/usr/bin/env python3
"""
Template Manager
Handles dynamic template loading and rendering
"""

import os
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, Template

class TemplateManager:
    def __init__(self, templates_dir):
        self.templates_dir = Path(templates_dir)
        self.env = Environment(loader=FileSystemLoader(str(self.templates_dir)))
    
    def template_exists(self, template_name):
        """Check if template exists"""
        return (self.templates_dir / template_name).exists()
    
    def load_template(self, template_name):
        """Load template content"""
        template_path = self.templates_dir / template_name
        if template_path.exists():
            with open(template_path, 'r') as f:
                return f.read()
        return None
    
    def render_template(self, template_name, context):
        """Render template with context"""
        try:
            template = self.env.get_template(template_name)
            return template.render(**context)
        except Exception as e:
            print(f"Template rendering error: {e}")
            return None