#!/usr/bin/env python3
"""
Apigee Variable Mapper
Maps Apigee variables to Kong variables and expressions
"""

import json
import re
from pathlib import Path

class ApigeeVariableMapper:
    def __init__(self):
        self.base_dir = Path(__file__).parent.parent.parent
        self.var_mappings = self._load_variable_mappings()
    
    def _load_variable_mappings(self):
        """Load Apigee to Kong variable mappings"""
        mapper_file = self.base_dir / "mappers" / "apigee-to-kong-var-mappers.json"
        try:
            with open(mapper_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return self._get_default_mappings()
    
    def _get_default_mappings(self):
        """Get default variable mappings"""
        return {
            "variable_map": {
                "request.verb": "kong.request.get_method()",
                "request.uri": "kong.request.get_path()",
                "request.querystring": "kong.request.get_raw_query()",
                "request.header.": "kong.request.get_header('",
                "response.status.code": "kong.response.get_status()",
                "response.header.": "kong.response.get_header('",
                "flow.": "kong.ctx.shared.",
                "environment.": "os.getenv('",
                "system.timestamp": "os.time()",
                "message.content": "kong.request.get_raw_body()",
                "request.content": "kong.request.get_raw_body()",
                "response.content": "kong.response.get_raw_body()"
            },
            "operator_map": {
                "=": "==",
                "!=": "~=",
                "Matches": "string.match",
                "MatchesPath": "string.match",
                "JavaRegex": "string.match"
            },
            "pattern_map": [
                {
                    "pattern": r"request\.header\.([^\\s]+)",
                    "replacement": r"kong.request.get_header('\1')"
                },
                {
                    "pattern": r"response\.header\.([^\\s]+)",
                    "replacement": r"kong.response.get_header('\1')"
                },
                {
                    "pattern": r"request\.queryparam\.([^\\s]+)",
                    "replacement": r"kong.request.get_query_arg('\1')"
                },
                {
                    "pattern": r"flow\.([^\\s]+)",
                    "replacement": r"kong.ctx.shared.\1"
                }
            ]
        }
    
    def map_variables(self, config):
        """Map Apigee variables in configuration to Kong variables"""
        if isinstance(config, dict):
            mapped_config = {}
            for key, value in config.items():
                mapped_config[key] = self.map_variables(value)
            return mapped_config
        elif isinstance(config, list):
            return [self.map_variables(item) for item in config]
        elif isinstance(config, str):
            return self._map_string_variables(config)
        else:
            return config
    
    def _map_string_variables(self, text):
        """Map variables in a string"""
        if not text:
            return text
        
        mapped_text = text
        
        # Apply pattern mappings first (regex replacements)
        for pattern_map in self.var_mappings.get("pattern_map", []):
            pattern = pattern_map["pattern"]
            replacement = pattern_map["replacement"]
            mapped_text = re.sub(pattern, replacement, mapped_text)
        
        # Apply simple variable mappings
        for apigee_var, kong_var in self.var_mappings.get("variable_map", {}).items():
            if apigee_var.endswith('.'):
                # Handle prefix mappings like "request.header."
                continue
            mapped_text = mapped_text.replace(apigee_var, kong_var)
        
        # Apply operator mappings
        for apigee_op, kong_op in self.var_mappings.get("operator_map", {}).items():
            mapped_text = mapped_text.replace(f" {apigee_op} ", f" {kong_op} ")
        
        return mapped_text
    
    def map_condition_expression(self, condition):
        """Map Apigee condition expression to Kong Lua"""
        if not condition:
            return "true"
        
        # Map variables
        mapped_condition = self._map_string_variables(condition)
        
        # Convert to Lua-compatible syntax
        lua_condition = self._convert_to_lua_syntax(mapped_condition)
        
        return lua_condition
    
    def _convert_to_lua_syntax(self, expression):
        """Convert expression to Lua syntax"""
        # Handle common patterns
        lua_expr = expression
        
        # Convert string comparisons
        lua_expr = re.sub(r'(\w+)\s*==\s*"([^"]+)"', r'\1 == "\2"', lua_expr)
        lua_expr = re.sub(r'(\w+)\s*~=\s*"([^"]+)"', r'\1 ~= "\2"', lua_expr)
        
        # Handle function calls that need closing parentheses
        lua_expr = re.sub(r"kong\.request\.get_header\('([^']+)'", r"kong.request.get_header('\1')", lua_expr)
        lua_expr = re.sub(r"kong\.response\.get_header\('([^']+)'", r"kong.response.get_header('\1')", lua_expr)
        
        return lua_expr