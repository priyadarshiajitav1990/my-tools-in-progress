#!/usr/bin/env python3
"""
Project Cleanup Script
Removes unwanted files and organizes the project structure for production
"""

import os
import shutil
import logging
from pathlib import Path
from typing import List, Set

class ProjectCleanup:
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.logger = logging.getLogger(__name__)
        self.setup_logging()
        
        # Files and directories to remove
        self.files_to_remove = {
            # Temporary files
            '*.tmp', '*.temp', '*.bak', '*.backup',
            # Python cache
            '__pycache__', '*.pyc', '*.pyo', '*.pyd',
            # IDE files
            '.vscode', '.idea', '*.swp', '*.swo',
            # OS files
            '.DS_Store', 'Thumbs.db', 'desktop.ini',
            # Build artifacts
            '*.egg-info', 'build', 'dist',
            # Test artifacts
            '.pytest_cache', '.coverage', 'htmlcov',
            # Logs (except in logs directory)
            '*.log'
        }
        
        # Directories to preserve
        self.preserve_dirs = {
            'old-files-backups',  # Explicitly preserve as requested
            'logs',
            'input',
            'output',
            'configs',
            'scripts',
            'templates',
            'mappers',
            'luaconverters',
            'customplugins',
            'extracted-apigee-apis'
        }
        
        # Files to preserve in root
        self.preserve_root_files = {
            'start.py',
            'start_enhanced.py',
            'test_migration_tool.py',
            'cleanup_project.py',
            'README.md',
            'setup.py',
            'requirements.txt'
        }
    
    def setup_logging(self):
        """Setup logging for cleanup operations"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
    
    def run_cleanup(self) -> bool:
        """Run the complete cleanup process"""
        self.logger.info("Starting project cleanup...")
        
        try:
            # Remove unwanted files and directories
            self._remove_unwanted_files()
            
            # Organize directory structure
            self._organize_directories()
            
            # Clean up duplicate files
            self._remove_duplicates()
            
            # Validate project structure
            self._validate_structure()
            
            self.logger.info("Project cleanup completed successfully!")
            return True
            
        except Exception as e:
            self.logger.error(f"Cleanup failed: {e}")
            return False
    
    def _remove_unwanted_files(self):
        """Remove unwanted files and directories"""
        self.logger.info("Removing unwanted files...")
        
        removed_count = 0
        
        for root, dirs, files in os.walk(self.project_root):
            root_path = Path(root)
            
            # Skip preserved directories
            if any(preserve_dir in root_path.parts for preserve_dir in self.preserve_dirs):
                continue
            
            # Remove unwanted directories
            dirs_to_remove = []
            for dir_name in dirs:
                if self._should_remove_item(dir_name):
                    dir_path = root_path / dir_name
                    if dir_path.name not in self.preserve_dirs:
                        dirs_to_remove.append(dir_name)
                        try:
                            shutil.rmtree(dir_path)
                            self.logger.info(f"Removed directory: {dir_path}")
                            removed_count += 1
                        except Exception as e:
                            self.logger.warning(f"Failed to remove directory {dir_path}: {e}")
            
            # Remove from dirs list to prevent walking into them
            for dir_name in dirs_to_remove:
                dirs.remove(dir_name)
            
            # Remove unwanted files
            for file_name in files:
                if self._should_remove_item(file_name):
                    file_path = root_path / file_name
                    
                    # Don't remove preserved root files
                    if root_path == self.project_root and file_name in self.preserve_root_files:
                        continue
                    
                    try:
                        file_path.unlink()
                        self.logger.info(f"Removed file: {file_path}")
                        removed_count += 1
                    except Exception as e:
                        self.logger.warning(f"Failed to remove file {file_path}: {e}")
        
        self.logger.info(f"Removed {removed_count} unwanted items")
    
    def _should_remove_item(self, item_name: str) -> bool:
        """Check if an item should be removed"""
        import fnmatch
        
        for pattern in self.files_to_remove:
            if fnmatch.fnmatch(item_name, pattern):
                return True
        
        return False
    
    def _organize_directories(self):
        """Organize directory structure"""
        self.logger.info("Organizing directory structure...")
        
        # Ensure required directories exist
        required_dirs = [
            'scripts/core',
            'scripts/pre',
            'scripts/post',
            'scripts/utils',
            'templates/custom-plugins',
            'configs',
            'mappers',
            'logs',
            'input',
            'output'
        ]
        
        for dir_path in required_dirs:
            full_path = self.project_root / dir_path
            full_path.mkdir(parents=True, exist_ok=True)
            self.logger.info(f"Ensured directory exists: {full_path}")
        
        # Move misplaced files to correct locations
        self._move_misplaced_files()
    
    def _move_misplaced_files(self):
        """Move misplaced files to correct locations"""
        # Define file movements
        movements = [
            # Move any Python files in root that should be in scripts
            ('*.py', 'scripts/', lambda f: f.name.startswith('test_') or f.name.endswith('_test.py')),
        ]
        
        # Implementation would go here if needed
        pass
    
    def _remove_duplicates(self):
        """Remove duplicate files"""
        self.logger.info("Checking for duplicate files...")
        
        # Find potential duplicates by comparing file sizes and names
        file_registry = {}
        duplicates_found = 0
        
        for root, dirs, files in os.walk(self.project_root):
            # Skip preserved directories
            if 'old-files-backups' in root:
                continue
            
            for file_name in files:
                file_path = Path(root) / file_name
                
                if file_path.is_file():
                    try:
                        file_size = file_path.stat().st_size
                        key = (file_name, file_size)
                        
                        if key in file_registry:
                            # Potential duplicate found
                            original_path = file_registry[key]
                            
                            # Compare content to confirm duplicate
                            if self._files_are_identical(original_path, file_path):
                                # Keep the one in the more appropriate location
                                if self._should_keep_file(original_path, file_path):
                                    file_path.unlink()
                                    self.logger.info(f"Removed duplicate: {file_path}")
                                else:
                                    original_path.unlink()
                                    file_registry[key] = file_path
                                    self.logger.info(f"Removed duplicate: {original_path}")
                                
                                duplicates_found += 1
                        else:
                            file_registry[key] = file_path
                    
                    except Exception as e:
                        self.logger.warning(f"Error processing file {file_path}: {e}")
        
        self.logger.info(f"Removed {duplicates_found} duplicate files")
    
    def _files_are_identical(self, file1: Path, file2: Path) -> bool:
        """Check if two files are identical"""
        try:
            if file1.stat().st_size != file2.stat().st_size:
                return False
            
            with open(file1, 'rb') as f1, open(file2, 'rb') as f2:
                return f1.read() == f2.read()
        
        except Exception:
            return False
    
    def _should_keep_file(self, file1: Path, file2: Path) -> bool:
        """Determine which file to keep when duplicates are found"""
        # Prefer files in more appropriate locations
        priority_dirs = ['scripts', 'templates', 'configs', 'mappers']
        
        file1_priority = self._get_directory_priority(file1, priority_dirs)
        file2_priority = self._get_directory_priority(file2, priority_dirs)
        
        return file1_priority <= file2_priority
    
    def _get_directory_priority(self, file_path: Path, priority_dirs: List[str]) -> int:
        """Get priority score for a file based on its directory"""
        for i, priority_dir in enumerate(priority_dirs):
            if priority_dir in str(file_path):
                return i
        return len(priority_dirs)  # Lowest priority
    
    def _validate_structure(self):
        """Validate the final project structure"""
        self.logger.info("Validating project structure...")
        
        # Check required files exist
        required_files = [
            'start.py',
            'configs/config.json',
            'configs/requirements.txt',
            'mappers/policy-to-plugin-mapper.json',
            'scripts/core/policy_migration.py'
        ]
        
        missing_files = []
        for file_path in required_files:
            full_path = self.project_root / file_path
            if not full_path.exists():
                missing_files.append(file_path)
        
        if missing_files:
            self.logger.warning(f"Missing required files: {missing_files}")
        else:
            self.logger.info("All required files are present")
        
        # Check directory structure
        required_dirs = [
            'scripts/core',
            'scripts/pre', 
            'scripts/post',
            'scripts/utils',
            'templates',
            'configs',
            'mappers'
        ]
        
        missing_dirs = []
        for dir_path in required_dirs:
            full_path = self.project_root / dir_path
            if not full_path.exists():
                missing_dirs.append(dir_path)
        
        if missing_dirs:
            self.logger.warning(f"Missing required directories: {missing_dirs}")
        else:
            self.logger.info("All required directories are present")
        
        # Generate structure report
        self._generate_structure_report()
    
    def _generate_structure_report(self):
        """Generate a report of the final project structure"""
        report_path = self.project_root / "PROJECT_STRUCTURE.md"
        
        with open(report_path, 'w') as f:
            f.write("# Project Structure\\n\\n")
            f.write("This document describes the final project structure after cleanup.\\n\\n")
            
            f.write("## Directory Structure\\n\\n")
            f.write("```\\n")
            
            # Generate tree structure
            self._write_directory_tree(f, self.project_root, "", set())
            
            f.write("```\\n\\n")
            
            f.write("## Key Components\\n\\n")
            f.write("- **start.py**: Main entry point for the migration tool\\n")
            f.write("- **scripts/**: Core migration logic and utilities\\n")
            f.write("- **templates/**: Jinja2 templates for Kong plugin configuration\\n")
            f.write("- **configs/**: Configuration files and requirements\\n")
            f.write("- **mappers/**: Policy to plugin mapping configurations\\n")
            f.write("- **luaconverters/**: Tools for converting JS/Java/Python to Lua\\n")
            f.write("- **old-files-backups/**: Preserved backup files (not modified)\\n")
        
        self.logger.info(f"Generated structure report: {report_path}")
    
    def _write_directory_tree(self, f, directory: Path, prefix: str, visited: Set[Path]):
        """Write directory tree to file"""
        if directory in visited:
            return
        visited.add(directory)
        
        try:
            items = sorted(directory.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
            
            for i, item in enumerate(items):
                is_last = i == len(items) - 1
                current_prefix = "└── " if is_last else "├── "
                f.write(f"{prefix}{current_prefix}{item.name}")
                
                if item.is_dir():
                    f.write("/\\n")
                    next_prefix = prefix + ("    " if is_last else "│   ")
                    self._write_directory_tree(f, item, next_prefix, visited)
                else:
                    f.write("\\n")
        
        except PermissionError:
            f.write(f"{prefix}[Permission Denied]\\n")

def main():
    """Main cleanup function"""
    cleanup = ProjectCleanup()
    success = cleanup.run_cleanup()
    
    if success:
        print("\\n🧹 Project cleanup completed successfully!")
        print("The migration tool is now organized and ready for production use.")
    else:
        print("\\n❌ Project cleanup encountered some issues.")
        print("Please review the logs and fix any problems manually.")
    
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())