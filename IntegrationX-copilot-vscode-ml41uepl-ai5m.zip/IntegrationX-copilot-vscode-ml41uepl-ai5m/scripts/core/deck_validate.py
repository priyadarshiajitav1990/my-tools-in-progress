import os
import logging
import subprocess

def validations():
    logging.info("--- Starting Deck Validations ---")
    
    api_name = os.environ.get("api_name")
    output_dir = os.environ.get("output_dir")
    deck_addr = os.environ.get("deck_addr")
    deck_key = os.environ.get("deck_key")
    skip_gateway_validation = os.environ.get("deck_skip_gateway_validation", "false").lower() == "true"
    
    if not all([api_name, output_dir]):
        logging.error("Missing required configuration for deck validation.")
        return False

    # Ensure 3 levels up to reach project root from scripts/core/
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # Create API-specific directory path
    api_output_dir = os.path.join(project_root, output_dir, api_name)
    kong_yaml_path = os.path.join(api_output_dir, f"kong-{api_name}.yml")
    
    if not os.path.exists(kong_yaml_path):
        logging.error(f"Kong YAML file not found at '{kong_yaml_path}'. Cannot run validation.")
        return False

    try:
        # 1. File Validation
        cmd = ["deck", "file", "validate", kong_yaml_path]
        logging.info(f"Executing command: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            logging.error(f"Deck file validation failed:\n{result.stderr}\n{result.stdout}")
            return False
        logging.info("Deck file validation successful.")

        # 2. Gateway Validation
        if skip_gateway_validation:
            logging.info("Skipping gateway validation.")
            return True

        if not deck_addr:
            logging.warning("Skipping gateway validation: 'deck_addr' not provided.")
            return True

        cmd = ["deck", "gateway", "validate", kong_yaml_path, "--kong-addr", deck_addr]
        
        if deck_key and deck_key.upper() != "NA":
            cmd.extend(["--headers", f"kong-admin-token:{deck_key}"])

        logging.info(f"Executing command: {' '.join(cmd)}")
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            logging.error(f"Deck gateway validation failed:\n{result.stderr}\n{result.stdout}")
            return False
            
        logging.info("Deck gateway validation successful.")
        return True

    except FileNotFoundError:
        logging.warning("decK CLI is not installed or not in PATH. Skipping validation.")
        return True