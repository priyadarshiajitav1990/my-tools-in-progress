#!/usr/bin/env python3
"""
Enhanced Policy Migration Engine
Production-ready policy to plugin migration with advanced features
"""

import os
import json
import logging
import yaml
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict

from ..utils.resource_converter_enhanced import EnhancedResourceConverter
from ..utils.plugin_conflict_resolver_enhanced import EnhancedPluginConflictResolver
from ..utils.template_manager_enhanced import EnhancedTemplateManager

class EnhancedPolicyMigrationEngine:
    def __init__(self, project_root: Path, config: Dict[str, Any]):
        self.logger = logging.getLogger(__name__)
        self.project_root = Path(project_root)
        self.config = config
        
        # Initialize components
        self.resource_converter = EnhancedResourceConverter()
        self.conflict_resolver = EnhancedPluginConflictResolver()
        self.template_manager = EnhancedTemplateManager(self.project_root / "templates")
        
        # Load mappers
        self.policy_mapper = self._load_policy_mapper()
        self.variable_mapper = self._load_variable_mapper()
        
        # Plugin execution order for before/after relationships
        self.plugin_execution_order = {
            'request': [
                'ip-restriction', 'cors', 'key-auth', 'basic-auth', 'oauth2', 'jwt', 'hmac-auth',
                'rate-limiting', 'rate-limiting-advanced', 'request-validator', 'oas-validation',
                'assertcondition', 'attribute', 'readpropertyset',
                'request-transformer', 'request-transformer-advanced',
                'servicecallout', 'extensioncallout', 'flowcallout',
                'javascript', 'python', 'java-callout', 'luascriptexecuter', 'pre-function'
            ],
            'response': [
                'response-transformer', 'response-transformer-advanced',
                'jsontoxml', 'xsltransform', 'setdialogflowresponse',
                'datacapture', 'http-log', 'file-log', 'kafka-log',
                'post-function', 'luascriptexecuter'
            ]
        }
        
        # Migration statistics
        self.stats = {
            'policies_processed': 0,
            'plugins_generated': 0,
            'resources_converted': 0,
            'conflicts_resolved': 0,
            'fallbacks_used': 0,
            'errors': []
        }
    
    def migrate_policies_for_entity(self, entity_type: str, entity_name: str, entity_root, 
                                  output_data: Dict[str, Any], api_name: str, 
                                  policies_path: str, report_data=None) -> bool:
        """Migrate policies for a specific entity (proxy or target endpoint)"""
        try:
            self.logger.info(f"Migrating policies for {entity_type}: {entity_name}")
            
            # Extract policies from entity flows
            policies_info = self._extract_policies_from_flows(entity_root, policies_path)
            
            if not policies_info:
                self.logger.info(f"No policies found for {entity_type}: {entity_name}")
                return True
            
            # Process each flow
            for flow_info in policies_info:
                flow_name = flow_info['flow_name']
                flow_phase = flow_info['flow_phase']
                policies = flow_info['policies']
                
                self.logger.info(f"Processing {flow_phase} flow '{flow_name}' with {len(policies)} policies")
                
                # Migrate policies to plugins
                plugins = self._migrate_policies_to_plugins(policies, api_name, flow_phase)
                
                # Resolve conflicts and optimize
                optimized_plugins = self.conflict_resolver.resolve_plugin_conflicts(plugins, api_name)
                
                # Apply ordering based on Apigee policy order
                ordered_plugins = self._apply_apigee_ordering(optimized_plugins, policies, flow_phase)
                
                # Attach plugins to Kong entities
                self._attach_plugins_to_entities(
                    ordered_plugins, entity_type, entity_name, output_data, api_name, report_data
                )
                
                self.stats['plugins_generated'] += len(ordered_plugins)
                self.stats['conflicts_resolved'] += len(plugins) - len(optimized_plugins)
            
            self.stats['policies_processed'] += sum(len(flow['policies']) for flow in policies_info)
            return True
            
        except Exception as e:
            error_msg = f"Policy migration failed for {entity_type} {entity_name}: {e}"
            self.logger.error(error_msg)
            self.stats['errors'].append(error_msg)
            return False
    
    def _extract_policies_from_flows(self, entity_root, policies_path: str) -> List[Dict[str, Any]]:
        """Extract policies from entity flows"""
        import xml.etree.ElementTree as ET
        
        flows_info = []
        
        # Process PreFlow
        pre_flow = entity_root.find('PreFlow')
        if pre_flow is not None:
            flows_info.extend(self._process_flow_element(pre_flow, "PreFlow", policies_path))
        
        # Process conditional flows
        flows_container = entity_root.find('Flows')
        if flows_container is not None:
            for flow in flows_container.findall('Flow'):
                flow_name = flow.get('name', 'UnnamedFlow')
                flows_info.extend(self._process_flow_element(flow, flow_name, policies_path))
        
        # Process PostFlow
        post_flow = entity_root.find('PostFlow')
        if post_flow is not None:
            flows_info.extend(self._process_flow_element(post_flow, "PostFlow", policies_path))
        
        return flows_info
    
    def _process_flow_element(self, flow_element, flow_name: str, policies_path: str) -> List[Dict[str, Any]]:
        """Process a single flow element"""
        flows_info = []
        
        # Process Request phase
        request_element = flow_element.find('Request')
        if request_element is not None:
            policies = self._extract_policies_from_phase(request_element, policies_path)
            if policies:
                flows_info.append({
                    'flow_name': flow_name,
                    'flow_phase': 'request',
                    'policies': policies
                })
        
        # Process Response phase
        response_element = flow_element.find('Response')
        if response_element is not None:
            policies = self._extract_policies_from_phase(response_element, policies_path)
            if policies:
                flows_info.append({
                    'flow_name': flow_name,
                    'flow_phase': 'response',
                    'policies': policies
                })
        
        return flows_info
    
    def _extract_policies_from_phase(self, phase_element, policies_path: str) -> List[Dict[str, Any]]:
        """Extract policies from a phase (Request/Response)"""
        import xml.etree.ElementTree as ET
        
        policies = []
        
        for step in phase_element.findall('Step'):
            policy_name_element = step.find('Name')
            condition_element = step.find('Condition')
            
            if policy_name_element is None:
                continue
            
            policy_name = policy_name_element.text
            condition = condition_element.text if condition_element is not None else None
            
            # Load policy XML
            policy_file = os.path.join(policies_path, f"{policy_name}.xml")
            if not os.path.exists(policy_file):
                self.logger.warning(f"Policy file not found: {policy_file}")
                continue
            
            try:
                tree = ET.parse(policy_file)
                policy_root = tree.getroot()
                policy_type = policy_root.tag
                
                # Convert XML to dict
                policy_data = self._xml_to_dict(policy_root)
                policy_data['_policy_name'] = policy_name
                policy_data['_policy_type'] = policy_type
                policy_data['_condition'] = condition
                
                # Load resource files if any
                resource_files = self._extract_resource_files(policy_data, policies_path)
                if resource_files:
                    policy_data['_resource_files'] = resource_files
                
                policies.append(policy_data)
                
            except ET.ParseError as e:
                self.logger.warning(f"Failed to parse policy {policy_name}: {e}")
                continue
        
        return policies
    
    def _extract_resource_files(self, policy_data: Dict[str, Any], policies_path: str) -> Dict[str, str]:
        """Extract resource files referenced by policy"""
        resource_files = {}
        
        # Common resource file references
        resource_keys = ['resourceURL', 'source', 'includeURL', 'jarResource', 'scriptFile']
        
        for key in resource_keys:
            if key in policy_data and policy_data[key]:
                resource_url = policy_data[key]
                resource_content = self._load_resource_file(resource_url, policies_path)
                if resource_content:
                    resource_files[resource_url] = resource_content
        
        return resource_files
    
    def _load_resource_file(self, resource_url: str, policies_path: str) -> Optional[str]:
        """Load resource file content"""
        try:
            # Handle different resource URL formats
            if resource_url.startswith('jsc://'):
                filename = resource_url.replace('jsc://', '') + '.js'
            elif resource_url.startswith('java://'):
                filename = resource_url.replace('java://', '') + '.java'
            elif resource_url.startswith('py://'):
                filename = resource_url.replace('py://', '') + '.py'
            else:
                filename = resource_url
            
            # Look for resource file in various locations
            search_paths = [
                os.path.join(policies_path, '..', 'resources', 'jsc', filename),
                os.path.join(policies_path, '..', 'resources', 'java', filename),
                os.path.join(policies_path, '..', 'resources', 'py', filename),
                os.path.join(policies_path, '..', 'resources', filename),
                os.path.join(policies_path, filename)
            ]
            
            for file_path in search_paths:
                if os.path.exists(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        return f.read()
            
            self.logger.warning(f"Resource file not found: {resource_url}")
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to load resource file {resource_url}: {e}")
            return None
    
    def _migrate_policies_to_plugins(self, policies: List[Dict[str, Any]], api_name: str, flow_phase: str) -> List[Dict[str, Any]]:
        """Migrate policies to Kong plugins"""
        plugins = []
        
        for policy in policies:
            try:
                policy_plugins = self._migrate_single_policy(policy, api_name, flow_phase)
                plugins.extend(policy_plugins)
            except Exception as e:
                self.logger.error(f"Failed to migrate policy {policy.get('_policy_name', 'unknown')}: {e}")
                # Create fallback plugin
                fallback_plugin = self._create_fallback_plugin(policy, api_name, flow_phase)
                plugins.append(fallback_plugin)
                self.stats['fallbacks_used'] += 1
        
        return plugins
    
    def _migrate_single_policy(self, policy: Dict[str, Any], api_name: str, flow_phase: str) -> List[Dict[str, Any]]:
        """Migrate a single policy to Kong plugins"""
        policy_type = policy.get('_policy_type', 'Unknown')
        policy_name = policy.get('_policy_name', 'unknown')
        
        # Get plugin mappings for this policy type
        mappings = self.policy_mapper.get(policy_type, [])
        
        if not mappings:
            self.logger.warning(f"No mapping found for policy type: {policy_type}")
            return [self._create_fallback_plugin(policy, api_name, flow_phase)]
        
        plugins = []
        
        for mapping in mappings:
            plugin_name = mapping['plugin_name']
            mapped_flow = mapping['api_flow']
            
            # Check if plugin is applicable for current flow
            if mapped_flow != 'both' and mapped_flow != flow_phase:
                continue
            
            try:
                # Convert resource files to Lua if needed
                lua_code = None
                if plugin_name == 'luascriptexecuter' or '_resource_files' in policy:
                    lua_code = self._convert_resources_to_lua(policy, policy_type)
                    self.stats['resources_converted'] += len(policy.get('_resource_files', {}))
                
                # Create plugin configuration
                plugin_config = self._create_plugin_config(
                    plugin_name, policy, api_name, flow_phase, lua_code
                )
                
                if plugin_config:
                    plugins.append(plugin_config)
                
            except Exception as e:
                self.logger.error(f"Failed to create plugin {plugin_name} for policy {policy_name}: {e}")
                continue
        
        # If no plugins were created, create fallback
        if not plugins:
            plugins.append(self._create_fallback_plugin(policy, api_name, flow_phase))
            self.stats['fallbacks_used'] += 1
        
        return plugins
    
    def _convert_resources_to_lua(self, policy: Dict[str, Any], policy_type: str) -> Optional[str]:
        """Convert resource files to Lua code"""
        resource_files = policy.get('_resource_files', {})
        
        if not resource_files:
            return None
        
        lua_scripts = []
        
        for resource_url, resource_content in resource_files.items():
            lua_code = self.resource_converter.convert_resource_to_lua(
                resource_url, resource_content, policy_type
            )
            if lua_code:
                lua_scripts.append(lua_code)
        
        if lua_scripts:
            # Combine multiple Lua scripts
            combined_script = "-- Combined Resource Scripts\\n\\n"
            for i, script in enumerate(lua_scripts):
                combined_script += f"-- Resource Script {i+1}\\n"
                combined_script += script + "\\n\\n"
            
            return combined_script
        
        return None
    
    def _create_plugin_config(self, plugin_name: str, policy: Dict[str, Any], 
                            api_name: str, flow_phase: str, lua_code: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Create plugin configuration using templates"""
        try:
            # Prepare template context
            context = {
                'policy': policy,
                'api_name': api_name,
                'flow_phase': flow_phase,
                'kong_version': self.config.get('kong_version', '3.13.0.0'),
                'lua_code': lua_code
            }
            
            # Add resource content if available
            if '_resource_files' in policy:
                context['resource_files'] = policy['_resource_files']
                # For plugins that need direct content injection
                if plugin_name in ['xsltransform', 'soapvalidation', 'oas-validation']:
                    context['resource_content'] = list(policy['_resource_files'].values())[0]
            
            # Render plugin template
            plugin_config = self.template_manager.render_plugin_template(
                plugin_name, context, flow_phase
            )
            
            if plugin_config:
                # Add metadata
                plugin_config['tags'] = plugin_config.get('tags', [])
                plugin_config['tags'].extend([
                    f"api:{api_name}",
                    f"policy:{policy.get('_policy_name', 'unknown')}",
                    f"type:{policy.get('_policy_type', 'Unknown')}"
                ])
                
                # Add condition if present
                if policy.get('_condition'):
                    plugin_config['_apigee_condition'] = policy['_condition']
                
                # Set execution order
                plugin_config['_execution_order'] = self._get_plugin_execution_order(plugin_name, flow_phase)
            
            return plugin_config
            
        except Exception as e:
            self.logger.error(f"Failed to create plugin config for {plugin_name}: {e}")
            return None
    
    def _create_fallback_plugin(self, policy: Dict[str, Any], api_name: str, flow_phase: str) -> Dict[str, Any]:
        """Create fallback LuaScriptExecuter plugin"""
        policy_name = policy.get('_policy_name', 'unknown')
        policy_type = policy.get('_policy_type', 'Unknown')
        
        # Generate fallback Lua code
        lua_code = f'''
-- Fallback implementation for {policy_name} ({policy_type})
local function execute_fallback_policy()
    kong.log.warn("Using fallback implementation for policy: {policy_name}")
    
    -- Policy configuration (as comment):
    --[[
    Policy Type: {policy_type}
    Policy Name: {policy_name}
    Configuration: {json.dumps(policy, indent=2, default=str)}
    --]]
    
    -- TODO: Implement {policy_type} logic
    kong.log.info("Fallback policy executed: {policy_name}")
    return true
end

return execute_fallback_policy()
'''
        
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': lua_code,
                'enabled': True,
                'timeout': 30000
            },
            'tags': [
                f"api:{api_name}",
                f"policy:{policy_name}",
                f"type:{policy_type}",
                "fallback"
            ],
            'api_flow': flow_phase,
            '_execution_order': 999,
            '_is_fallback': True
        }
    
    def _apply_apigee_ordering(self, plugins: List[Dict[str, Any]], 
                             original_policies: List[Dict[str, Any]], flow_phase: str) -> List[Dict[str, Any]]:
        """Apply Apigee policy ordering to Kong plugins"""
        # Create mapping from policy names to their original order
        policy_order = {
            policy.get('_policy_name', ''): i 
            for i, policy in enumerate(original_policies)
        }
        
        # Sort plugins based on original Apigee policy order
        def get_sort_key(plugin):
            # First, try to match by policy name in tags
            for tag in plugin.get('tags', []):
                if tag.startswith('policy:'):
                    policy_name = tag.replace('policy:', '')
                    if policy_name in policy_order:
                        return (policy_order[policy_name], plugin.get('_execution_order', 500))
            
            # Fallback to plugin execution order
            return (999, plugin.get('_execution_order', 500))
        
        sorted_plugins = sorted(plugins, key=get_sort_key)
        
        # Add before/after relationships for Kong
        for i, plugin in enumerate(sorted_plugins):
            if i > 0:
                prev_plugin = sorted_plugins[i-1]
                plugin['after'] = [prev_plugin['name']]
            
            if i < len(sorted_plugins) - 1:
                next_plugin = sorted_plugins[i+1]
                plugin['before'] = [next_plugin['name']]
        
        return sorted_plugins
    
    def _attach_plugins_to_entities(self, plugins: List[Dict[str, Any]], entity_type: str, 
                                  entity_name: str, output_data: Dict[str, Any], 
                                  api_name: str, report_data=None):
        """Attach plugins to Kong entities"""
        for plugin in plugins:
            try:
                if entity_type == "service":
                    self._attach_to_service(plugin, entity_name, output_data, api_name)
                else:
                    self._attach_to_routes(plugin, entity_name, output_data, api_name)
                
                # Report mapping
                if report_data:
                    policy_name = next((tag.replace('policy:', '') for tag in plugin.get('tags', []) 
                                      if tag.startswith('policy:')), 'unknown')
                    report_data.add_mapping(
                        f"Policy ({plugin.get('type', 'Unknown')})",
                        policy_name,
                        f"Plugin ({plugin.get('api_flow', 'both')})",
                        f"{plugin['name']} (on {entity_type} '{entity_name}')"
                    )
                
            except Exception as e:
                self.logger.error(f"Failed to attach plugin {plugin['name']} to {entity_type} {entity_name}: {e}")
    
    def _attach_to_service(self, plugin: Dict[str, Any], service_name: str, 
                         output_data: Dict[str, Any], api_name: str):
        """Attach plugin to Kong service"""
        full_service_name = f"srv-{api_name}-{service_name}"
        
        # Find the service
        service = next((s for s in output_data.get('services', []) 
                       if s['name'] == full_service_name), None)
        
        if service:
            if 'plugins' not in service:
                service['plugins'] = []
            
            # Clean plugin config for attachment
            clean_plugin = self._clean_plugin_for_attachment(plugin)
            service['plugins'].append(clean_plugin)
            
            self.logger.info(f"Attached plugin {plugin['name']} to service {full_service_name}")
        else:
            self.logger.warning(f"Service {full_service_name} not found for plugin attachment")
    
    def _attach_to_routes(self, plugin: Dict[str, Any], proxy_name: str, 
                        output_data: Dict[str, Any], api_name: str):
        """Attach plugin to Kong routes"""
        route_prefix = f"rt-{api_name}-{proxy_name}-"
        attached_count = 0
        
        for route in output_data.get('routes', []):
            if route['name'].startswith(route_prefix):
                if 'plugins' not in route:
                    route['plugins'] = []
                
                # Clean plugin config for attachment
                clean_plugin = self._clean_plugin_for_attachment(plugin)
                route['plugins'].append(clean_plugin)
                attached_count += 1
        
        if attached_count > 0:
            self.logger.info(f"Attached plugin {plugin['name']} to {attached_count} routes for proxy {proxy_name}")
        else:
            self.logger.warning(f"No routes found for proxy {proxy_name} to attach plugin {plugin['name']}")
    
    def _clean_plugin_for_attachment(self, plugin: Dict[str, Any]) -> Dict[str, Any]:
        """Clean plugin configuration for Kong attachment"""
        clean_plugin = {
            'name': plugin['name'],
            'config': plugin.get('config', {}),
            'enabled': plugin.get('enabled', True)
        }
        
        # Add tags if present
        if 'tags' in plugin:
            clean_plugin['tags'] = plugin['tags']
        
        # Add ordering if present
        if 'before' in plugin:
            clean_plugin['before'] = plugin['before']
        if 'after' in plugin:
            clean_plugin['after'] = plugin['after']
        
        return clean_plugin
    
    def _get_plugin_execution_order(self, plugin_name: str, flow_phase: str) -> int:
        """Get plugin execution order"""
        order_list = self.plugin_execution_order.get(flow_phase, [])
        try:
            return order_list.index(plugin_name)
        except ValueError:
            return 500  # Default order for unknown plugins
    
    def _load_policy_mapper(self) -> Dict[str, List[Dict[str, str]]]:
        """Load policy to plugin mapper"""
        mapper_file = self.project_root / "mappers" / "policy-to-plugin-mapper.json"
        try:
            with open(mapper_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"Failed to load policy mapper: {e}")
            return {}
    
    def _load_variable_mapper(self) -> Dict[str, Any]:
        """Load variable mapper"""
        mapper_file = self.project_root / "mappers" / "apigee-to-kong-var-mappers.json"
        try:
            with open(mapper_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"Failed to load variable mapper: {e}")
            return {}
    
    def _xml_to_dict(self, element) -> Dict[str, Any]:
        """Convert XML element to dictionary"""
        result = {}
        
        # Add attributes
        if element.attrib:
            result.update(element.attrib)
        
        # Add text content
        if element.text and element.text.strip():
            if len(element) == 0:
                return element.text.strip()
            result['text'] = element.text.strip()
        
        # Add child elements
        for child in element:
            child_data = self._xml_to_dict(child)
            if child.tag in result:
                if not isinstance(result[child.tag], list):
                    result[child.tag] = [result[child.tag]]
                result[child.tag].append(child_data)
            else:
                result[child.tag] = child_data
        
        return result
    
    def get_migration_stats(self) -> Dict[str, Any]:
        """Get migration statistics"""
        return self.stats.copy()