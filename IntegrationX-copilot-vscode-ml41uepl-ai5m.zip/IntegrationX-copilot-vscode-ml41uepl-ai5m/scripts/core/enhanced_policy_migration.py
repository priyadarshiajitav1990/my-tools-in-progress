#!/usr/bin/env python3
"""
Enhanced Policy Migration
Advanced policy to plugin mapping with resource file handling and template generation
"""

import os
import json
import yaml
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, Template
import xml.etree.ElementTree as ET
from collections import defaultdict
import re

from .resource_converter import ResourceConverter
from .template_manager import TemplateManager
from .plugin_optimizer import PluginOptimizer

class EnhancedPolicyMigration:
    def __init__(self, config):
        self.config = config
        self.base_dir = Path(__file__).parent.parent.parent
        self.templates_dir = self.base_dir / "templates"
        self.mappers_dir = self.base_dir / "mappers"
        
        # Load mappers
        self.policy_mapper = self._load_policy_mapper()
        self.var_mapper = self._load_var_mapper()
        
        # Initialize components
        self.resource_converter = ResourceConverter()
        self.template_manager = TemplateManager(self.templates_dir)
        self.plugin_optimizer = PluginOptimizer()
        
        # Plugin execution order
        self.plugin_order = {
            'request': [
                'ip-restriction', 'cors', 'key-auth', 'basic-auth', 'oauth2', 'jwt',
                'rate-limiting', 'rate-limiting-advanced', 'request-validator',
                'assertcondition', 'attribute', 'readpropertyset',
                'request-transformer', 'request-transformer-advanced',
                'servicecallout', 'extensioncallout', 'flowcallout',
                'javascript', 'python', 'java-callout', 'luascriptexecuter',
                'pre-function', 'LuaScriptExecuter'
            ],
            'response': [
                'response-transformer', 'response-transformer-advanced',
                'jsontoxml', 'xsltransform', 'setdialogflowresponse',
                'datacapture', 'http-log', 'file-log', 'kafka-log',
                'post-function', 'LuaScriptExecuter'
            ]
        }
    
    def _load_policy_mapper(self):
        """Load policy to plugin mapper"""
        mapper_file = self.mappers_dir / "policy-to-plugin-mapper.json"
        with open(mapper_file, 'r') as f:
            return json.load(f)
    
    def _load_var_mapper(self):
        """Load variable mapper"""
        mapper_file = self.mappers_dir / "apigee-to-kong-var-mappers.json"
        with open(mapper_file, 'r') as f:
            return json.load(f)
    
    def migrate_policies(self, policies, resources, api_name):
        """Migrate Apigee policies to Kong plugins"""
        migrated_plugins = {
            'request': [],
            'response': [],
            'both': []
        }
        
        lua_scripts = []
        plugin_configs = {}
        
        for policy in policies:
            try:
                plugins = self._migrate_single_policy(policy, resources, api_name)
                
                for plugin in plugins:
                    flow = plugin.get('api_flow', 'both')
                    if flow in migrated_plugins:
                        migrated_plugins[flow].append(plugin)
                    
                    # Store plugin config for optimization
                    plugin_name = plugin['name']
                    if plugin_name not in plugin_configs:
                        plugin_configs[plugin_name] = []
                    plugin_configs[plugin_name].append(plugin)
                    
            except Exception as e:
                print(f"Error migrating policy {policy.get('name', 'unknown')}: {e}")
                # Create fallback LuaScriptExecuter
                fallback_plugin = self._create_fallback_plugin(policy, api_name)
                migrated_plugins['both'].append(fallback_plugin)
        
        # Optimize plugins (merge duplicates, resolve conflicts)
        optimized_plugins = self.plugin_optimizer.optimize_plugins(plugin_configs)
        
        # Apply ordering
        ordered_plugins = self._apply_plugin_ordering(optimized_plugins)
        
        return ordered_plugins
    
    def _migrate_single_policy(self, policy, resources, api_name):
        """Migrate a single policy to Kong plugins"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        policy_name = policy.get('name', '')
        
        if policy_type not in self.policy_mapper:
            # Create custom LuaScriptExecuter for unknown policies
            return [self._create_lua_script_plugin(policy, resources, api_name)]
        
        mapped_plugins = self.policy_mapper[policy_type]
        result_plugins = []
        
        for plugin_mapping in mapped_plugins:
            plugin_name = plugin_mapping['plugin_name']
            api_flow = plugin_mapping['api_flow']
            
            # Check if it's a custom plugin
            if plugin_name in self._get_custom_plugins():
                plugin_config = self._generate_custom_plugin_config(
                    plugin_name, policy, resources, api_name, api_flow
                )
            elif plugin_name == 'LuaScriptExecuter':
                plugin_config = self._create_lua_script_plugin(policy, resources, api_name)
            else:
                plugin_config = self._generate_builtin_plugin_config(
                    plugin_name, policy, resources, api_name, api_flow
                )
            
            if plugin_config:
                result_plugins.append(plugin_config)
        
        return result_plugins
    
    def _generate_custom_plugin_config(self, plugin_name, policy, resources, api_name, api_flow):
        """Generate configuration for custom plugins"""
        try:
            # Load template
            template_content = self.template_manager.load_template(f"{plugin_name}.yml.j2")
            
            # Extract policy configuration
            policy_config = self._extract_policy_config(policy, resources)
            
            # Map variables
            mapped_config = self._map_variables(policy_config)
            
            # Generate plugin configuration
            template = Template(template_content)
            rendered_config = template.render(config=mapped_config)
            
            # Parse YAML
            plugin_config = yaml.safe_load(rendered_config)
            
            # Add metadata
            plugin_config['tags'] = [f"api:{api_name}", f"policy:{policy.get('name', '')}"]
            plugin_config['api_flow'] = api_flow
            
            # Handle resource files
            if 'resourceURL' in policy or 'source' in policy:
                lua_code = self._process_resource_files(policy, resources)
                if lua_code and plugin_name == 'LuaScriptExecuter':
                    plugin_config['config']['script'] = lua_code
            
            return plugin_config
            
        except Exception as e:
            print(f"Error generating custom plugin config for {plugin_name}: {e}")
            return self._create_fallback_plugin(policy, api_name)
    
    def _generate_builtin_plugin_config(self, plugin_name, policy, resources, api_name, api_flow):
        """Generate configuration for built-in Kong plugins"""
        try:
            # Load template if exists
            template_file = f"{plugin_name}.yml.j2"
            if self.template_manager.template_exists(template_file):
                template_content = self.template_manager.load_template(template_file)
                template = Template(template_content)
                
                policy_config = self._extract_policy_config(policy, resources)
                mapped_config = self._map_variables(policy_config)
                
                rendered_config = template.render(config=mapped_config)
                plugin_config = yaml.safe_load(rendered_config)
            else:
                # Create basic configuration
                plugin_config = {
                    'name': plugin_name,
                    'config': self._create_basic_config(plugin_name, policy)
                }
            
            # Add metadata
            plugin_config['tags'] = [f"api:{api_name}", f"policy:{policy.get('name', '')}"]
            plugin_config['api_flow'] = api_flow
            
            return plugin_config
            
        except Exception as e:
            print(f"Error generating builtin plugin config for {plugin_name}: {e}")
            return None
    
    def _create_lua_script_plugin(self, policy, resources, api_name):
        """Create LuaScriptExecuter plugin for complex policies"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        policy_name = policy.get('name', '')
        
        # Generate Lua code
        lua_code = self._generate_lua_code(policy, resources)
        
        plugin_config = {
            'name': 'luascriptexecuter',
            'config': {
                'script': lua_code,
                'enabled': True,
                'timeout': 5000,
                'phase': 'access'
            },
            'tags': [f"api:{api_name}", f"policy:{policy_name}", f"type:{policy_type}"],
            'api_flow': 'both'
        }
        
        return plugin_config
    
    def _generate_lua_code(self, policy, resources):
        """Generate Lua code for policy"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        policy_name = policy.get('name', '')
        
        # Check for resource files
        resource_code = ""
        if 'resourceURL' in policy:
            resource_url = policy['resourceURL']
            if resource_url in resources:
                resource_content = resources[resource_url]
                resource_code = self.resource_converter.convert_resource_file(
                    resource_url, resource_content
                )
        
        # Generate base Lua code
        base_lua = f'''
-- Policy: {policy_name} (Type: {policy_type})
local function execute_policy()
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    -- Policy configuration
    local config = {{}}
    
{resource_code}
    
    -- Policy-specific logic
    kong.log.info("Executing policy: {policy_name}")
    
    return true
end

return execute_policy()
'''
        
        return base_lua
    
    def _process_resource_files(self, policy, resources):
        """Process resource files and convert to Lua"""
        resource_files = []
        
        # Check for various resource file references
        for key in ['resourceURL', 'source', 'includeURL', 'jarResource']:
            if key in policy and policy[key]:
                resource_url = policy[key]
                if resource_url in resources:
                    resource_content = resources[resource_url]
                    lua_code = self.resource_converter.convert_resource_file(
                        resource_url, resource_content
                    )
                    resource_files.append(lua_code)
        
        if resource_files:
            return "\n\n".join(resource_files)
        
        return None
    
    def _extract_policy_config(self, policy, resources):
        """Extract configuration from policy XML/JSON"""
        config = {}
        
        # Handle XML policies
        if isinstance(policy.get('content'), str) and policy['content'].strip().startswith('<'):
            try:
                root = ET.fromstring(policy['content'])
                config = self._xml_to_dict(root)
            except ET.ParseError:
                pass
        
        # Handle JSON policies
        elif isinstance(policy.get('config'), dict):
            config = policy['config']
        
        # Extract common fields
        for field in ['name', 'displayName', 'enabled', 'continueOnError']:
            if field in policy:
                config[field] = policy[field]
        
        return config
    
    def _xml_to_dict(self, element):
        """Convert XML element to dictionary"""
        result = {}
        
        # Add attributes
        if element.attrib:
            result.update(element.attrib)
        
        # Add text content
        if element.text and element.text.strip():
            if len(element) == 0:
                return element.text.strip()
            result['text'] = element.text.strip()
        
        # Add child elements
        for child in element:
            child_data = self._xml_to_dict(child)
            if child.tag in result:
                if not isinstance(result[child.tag], list):
                    result[child.tag] = [result[child.tag]]
                result[child.tag].append(child_data)
            else:
                result[child.tag] = child_data
        
        return result
    
    def _map_variables(self, config):
        """Map Apigee variables to Kong variables"""
        if not isinstance(config, dict):
            return config
        
        mapped_config = {}
        for key, value in config.items():
            if isinstance(value, str):
                # Apply variable mappings
                for apigee_var, kong_var in self.var_mapper.get('variable_map', {}).items():
                    value = value.replace(apigee_var, kong_var)
                mapped_config[key] = value
            elif isinstance(value, dict):
                mapped_config[key] = self._map_variables(value)
            elif isinstance(value, list):
                mapped_config[key] = [self._map_variables(item) if isinstance(item, dict) else item for item in value]
            else:
                mapped_config[key] = value
        
        return mapped_config
    
    def _get_custom_plugins(self):
        """Get list of custom plugins"""
        return [
            'assertcondition', 'attribute', 'datacapture', 'extensioncallout',
            'flowcallout', 'custom-graphql', 'invalidate-cache', 'java-callout',
            'javascript', 'jsontoxml', 'keyvaluemapoperations', 'latencyanalysis',
            'luascriptexecuter', 'parsedialogflowrequest', 'publishmessage',
            'python', 'readpropertyset', 'resetquota', 'servicecallout',
            'setdialogflowresponse', 'setintegrationrequest', 'setoauthv2info',
            'soapvalidation', 'xsltransform'
        ]
    
    def _create_basic_config(self, plugin_name, policy):
        """Create basic configuration for built-in plugins"""
        basic_configs = {
            'rate-limiting': {'minute': 100},
            'cors': {'origins': ['*']},
            'key-auth': {'key_names': ['apikey']},
            'basic-auth': {'hide_credentials': True},
            'jwt': {'key_claim_name': 'iss'},
            'oauth2': {'scopes': ['read']},
            'request-transformer': {'add': {'headers': []}},
            'response-transformer': {'add': {'headers': []}},
            'http-log': {'http_endpoint': 'http://localhost:8080/log'},
            'file-log': {'path': '/var/log/kong/access.log'}
        }
        
        return basic_configs.get(plugin_name, {'enabled': True})
    
    def _apply_plugin_ordering(self, plugins):
        """Apply plugin execution ordering"""
        ordered_plugins = {'request': [], 'response': [], 'both': []}
        
        for flow in ['request', 'response', 'both']:
            flow_plugins = plugins.get(flow, [])
            
            # Sort by predefined order
            def get_order(plugin):
                plugin_name = plugin.get('name', '')
                order_list = self.plugin_order.get(flow, [])
                try:
                    return order_list.index(plugin_name)
                except ValueError:
                    return len(order_list)  # Put unknown plugins at the end
            
            ordered_plugins[flow] = sorted(flow_plugins, key=get_order)
        
        return ordered_plugins
    
    def _create_fallback_plugin(self, policy, api_name):
        """Create fallback plugin for failed migrations"""
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': f'''
-- Fallback for policy: {policy.get('name', 'unknown')}
kong.log.warn("Policy migration fallback: {policy.get('policyType', 'unknown')}")
return true
''',
                'enabled': True
            },
            'tags': [f"api:{api_name}", "fallback"],
            'api_flow': 'both'
        }

def migrate_policies(policies, resources, api_name, config):
    """Main function to migrate policies"""
    migrator = EnhancedPolicyMigration(config)
    return migrator.migrate_policies(policies, resources, api_name)