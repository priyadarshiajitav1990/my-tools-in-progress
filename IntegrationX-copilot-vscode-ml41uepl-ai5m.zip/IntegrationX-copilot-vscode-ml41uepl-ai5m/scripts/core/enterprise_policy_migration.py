#!/usr/bin/env python3
"""
Enterprise Policy Migration Engine
Production-ready policy to plugin migration with advanced features
"""

import os
import json
import logging
from pathlib import Path
from collections import defaultdict, OrderedDict
import xml.etree.ElementTree as ET

from scripts.utils.advanced_resource_handler import AdvancedResourceHandler
from scripts.utils.plugin_conflict_resolver import PluginConflictResolver
from scripts.utils.apigee_variable_mapper import ApigeeVariableMapper
from scripts.utils.lua_code_generator import LuaCodeGenerator

class EnterprisePolicyMigration:
    def __init__(self, config):
        self.config = config
        self.base_dir = Path(__file__).parent.parent.parent
        self.mappers_dir = self.base_dir / "mappers"
        self.templates_dir = self.base_dir / "templates"
        
        # Initialize components
        self.resource_handler = AdvancedResourceHandler()
        self.conflict_resolver = PluginConflictResolver()
        self.variable_mapper = ApigeeVariableMapper()
        self.lua_generator = LuaCodeGenerator()
        
        # Load mappers
        self.policy_mapper = self._load_policy_mapper()
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Plugin execution priorities
        self.plugin_priorities = {
            'ip-restriction': 100, 'cors': 200, 'key-auth': 300, 'basic-auth': 300,
            'oauth2': 300, 'jwt': 300, 'rate-limiting': 400, 'rate-limiting-advanced': 400,
            'request-validator': 500, 'assertcondition': 600, 'attribute': 600,
            'request-transformer': 700, 'servicecallout': 800, 'luascriptexecuter': 900,
            'response-transformer': 1000, 'datacapture': 1100, 'http-log': 1200
        }
    
    def migrate_policies(self, policies, resources, api_name):
        """Main policy migration function"""
        self.logger.info(f"Starting policy migration for API: {api_name}")
        
        try:
            # Step 1: Process and validate policies
            validated_policies = self._validate_policies(policies)
            
            # Step 2: Process resource files
            processed_resources = self._process_all_resources(validated_policies, resources)
            
            # Step 3: Generate plugin configurations
            plugin_configs = self._generate_plugin_configs(validated_policies, processed_resources, api_name)
            
            # Step 4: Resolve conflicts and optimize
            optimized_configs = self.conflict_resolver.resolve_conflicts(plugin_configs)
            
            # Step 5: Apply ordering and finalize
            final_configs = self._apply_plugin_ordering(optimized_configs, api_name)
            
            self.logger.info(f"Successfully migrated {len(policies)} policies to {len(final_configs)} plugins")
            return final_configs
            
        except Exception as e:
            self.logger.error(f"Policy migration failed: {e}")
            # Return fallback configuration
            return self._create_fallback_migration(policies, api_name)
    
    def _validate_policies(self, policies):
        """Validate and normalize policy configurations"""
        validated = []
        
        for policy in policies:
            try:
                # Ensure required fields
                if not policy.get('name'):
                    policy['name'] = f"policy_{len(validated)}"
                
                if not policy.get('policyType') and not policy.get('type'):
                    policy['policyType'] = 'Unknown'
                
                # Normalize policy type
                policy_type = policy.get('policyType') or policy.get('type')
                policy['policyType'] = policy_type
                
                # Extract configuration from XML if present
                if 'content' in policy and policy['content'].strip().startswith('<'):
                    policy['parsed_config'] = self._parse_xml_config(policy['content'])
                
                validated.append(policy)
                
            except Exception as e:
                self.logger.warning(f"Policy validation failed for {policy.get('name', 'unknown')}: {e}")
                # Add as-is for fallback processing
                validated.append(policy)
        
        return validated
    
    def _process_all_resources(self, policies, resources):
        """Process all resource files for all policies"""
        processed_resources = {}
        
        for policy in policies:
            policy_name = policy.get('name', 'unknown')
            try:
                policy_resources = self.resource_handler.process_resource_files(policy, resources)
                if policy_resources:
                    processed_resources[policy_name] = policy_resources
                    
            except Exception as e:
                self.logger.error(f"Resource processing failed for policy {policy_name}: {e}")
        
        return processed_resources
    
    def _generate_plugin_configs(self, policies, processed_resources, api_name):
        """Generate Kong plugin configurations"""
        plugin_configs = []
        lua_scripts = []
        
        for policy in policies:
            policy_name = policy.get('name', 'unknown')
            policy_type = policy.get('policyType', 'Unknown')
            
            try:
                # Get plugin mappings for this policy type
                mappings = self.policy_mapper.get(policy_type, [])
                
                if not mappings:
                    # Create fallback luascriptexecuter
                    fallback_config = self._create_fallback_plugin(policy, processed_resources, api_name)
                    plugin_configs.append(fallback_config)
                    continue
                
                # Process each mapping
                for mapping in mappings:
                    plugin_name = mapping['plugin_name']
                    api_flow = mapping['api_flow']
                    
                    if plugin_name == 'luascriptexecuter':
                        # Generate Lua script plugin
                        lua_config = self._create_lua_script_plugin(policy, processed_resources, api_name)
                        lua_scripts.append(lua_config)
                    elif self._is_custom_plugin(plugin_name):
                        # Generate custom plugin config
                        custom_config = self._generate_custom_plugin_config(
                            plugin_name, policy, processed_resources, api_name, api_flow
                        )
                        if custom_config:
                            plugin_configs.append(custom_config)
                    else:
                        # Generate built-in plugin config
                        builtin_config = self._generate_builtin_plugin_config(
                            plugin_name, policy, processed_resources, api_name, api_flow
                        )
                        if builtin_config:
                            plugin_configs.append(builtin_config)
                
            except Exception as e:
                self.logger.error(f"Plugin generation failed for policy {policy_name}: {e}")
                # Create fallback
                fallback_config = self._create_fallback_plugin(policy, processed_resources, api_name)
                plugin_configs.append(fallback_config)
        
        # Merge multiple luascriptexecuter plugins if needed
        if len(lua_scripts) > 1:
            merged_lua = self._merge_lua_scripts(lua_scripts, api_name)
            plugin_configs.append(merged_lua)
        elif lua_scripts:
            plugin_configs.extend(lua_scripts)
        
        return plugin_configs
    
    def _create_lua_script_plugin(self, policy, processed_resources, api_name):
        """Create luascriptexecuter plugin with generated Lua code"""
        policy_name = policy.get('name', 'unknown')
        policy_type = policy.get('policyType', 'Unknown')
        
        # Generate Lua code based on policy type and resources
        lua_code = self.lua_generator.generate_policy_lua(policy, processed_resources)
        
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': lua_code,
                'enabled': True,
                'timeout': 30000,
                'phase': self._determine_execution_phase(policy_type)
            },
            'tags': [f"api:{api_name}", f"policy:{policy_name}", f"type:{policy_type}"],
            'api_flow': 'both',
            'priority': self.plugin_priorities.get('luascriptexecuter', 900)
        }
    
    def _generate_custom_plugin_config(self, plugin_name, policy, processed_resources, api_name, api_flow):
        """Generate configuration for custom plugins"""
        try:
            # Load template if available
            template_path = self.templates_dir / f"{plugin_name}.yml.j2"
            
            base_config = {
                'name': plugin_name,
                'config': {'enabled': True},
                'tags': [f"api:{api_name}", f"policy:{policy.get('name', '')}"],
                'api_flow': api_flow,
                'priority': self.plugin_priorities.get(plugin_name, 600)
            }
            
            # Add policy-specific configuration
            policy_config = self._extract_policy_configuration(policy)
            mapped_config = self.variable_mapper.map_variables(policy_config)
            
            # Merge configurations
            base_config['config'].update(mapped_config)
            
            # Add resource file content if available
            policy_name = policy.get('name', '')
            if policy_name in processed_resources:
                resource_data = processed_resources[policy_name]
                if 'script' in resource_data:
                    base_config['config']['script'] = resource_data['script']
            
            return base_config
            
        except Exception as e:
            self.logger.error(f"Custom plugin config generation failed for {plugin_name}: {e}")
            return None
    
    def _generate_builtin_plugin_config(self, plugin_name, policy, processed_resources, api_name, api_flow):
        """Generate configuration for built-in Kong plugins"""
        try:
            base_config = {
                'name': plugin_name,
                'config': self._get_default_plugin_config(plugin_name),
                'tags': [f"api:{api_name}", f"policy:{policy.get('name', '')}"],
                'api_flow': api_flow,
                'priority': self.plugin_priorities.get(plugin_name, 500)
            }
            
            # Map policy configuration to plugin configuration
            policy_config = self._extract_policy_configuration(policy)
            mapped_config = self._map_policy_to_plugin_config(plugin_name, policy_config)
            
            if mapped_config:
                base_config['config'].update(mapped_config)
            
            return base_config
            
        except Exception as e:
            self.logger.error(f"Built-in plugin config generation failed for {plugin_name}: {e}")
            return None
    
    def _merge_lua_scripts(self, lua_scripts, api_name):
        """Merge multiple luascriptexecuter plugins into one"""
        merged_script = "-- Merged Lua Scripts\n\n"
        all_tags = []
        
        for i, script_config in enumerate(lua_scripts):
            script_code = script_config['config']['script']
            merged_script += f"-- Script {i+1}: {script_config['tags'][1] if len(script_config['tags']) > 1 else 'unknown'}\n"
            merged_script += f"local function execute_script_{i+1}()\n"
            merged_script += self._indent_code(script_code, 4)
            merged_script += f"\nend\n\n"
            all_tags.extend(script_config.get('tags', []))
        
        # Add execution wrapper
        merged_script += "-- Execute all scripts\n"
        for i in range(len(lua_scripts)):
            merged_script += f"execute_script_{i+1}()\n"
        
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': merged_script,
                'enabled': True,
                'timeout': 30000,
                'phase': 'access'
            },
            'tags': list(set(all_tags)) + [f"api:{api_name}", "merged-scripts"],
            'api_flow': 'both',
            'priority': self.plugin_priorities.get('luascriptexecuter', 900)
        }
    
    def _apply_plugin_ordering(self, plugin_configs, api_name):
        """Apply proper plugin execution ordering"""
        # Sort by priority
        sorted_configs = sorted(plugin_configs, key=lambda x: x.get('priority', 500))
        
        # Group by API flow
        grouped_configs = {
            'request': [],
            'response': [],
            'both': []
        }
        
        for config in sorted_configs:
            flow = config.get('api_flow', 'both')
            if flow in grouped_configs:
                grouped_configs[flow].append(config)
        
        return grouped_configs
    
    def _create_fallback_plugin(self, policy, processed_resources, api_name):
        """Create fallback plugin for failed migrations"""
        policy_name = policy.get('name', 'unknown')
        policy_type = policy.get('policyType', 'Unknown')
        
        fallback_lua = self.lua_generator.generate_fallback_lua(policy, processed_resources)
        
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': fallback_lua,
                'enabled': True,
                'timeout': 30000
            },
            'tags': [f"api:{api_name}", f"policy:{policy_name}", "fallback"],
            'api_flow': 'both',
            'priority': 999
        }
    
    def _create_fallback_migration(self, policies, api_name):
        """Create fallback migration when everything fails"""
        fallback_configs = {
            'request': [],
            'response': [],
            'both': []
        }
        
        # Create single luascriptexecuter with all policies
        all_policies_lua = "-- Fallback migration for all policies\n\n"
        
        for policy in policies:
            policy_name = policy.get('name', 'unknown')
            policy_type = policy.get('policyType', 'Unknown')
            
            all_policies_lua += f'''
-- Policy: {policy_name} (Type: {policy_type})
local function execute_{policy_name.replace('-', '_')}()
    kong.log.warn("Fallback execution for policy: {policy_name}")
    -- TODO: Implement {policy_type} logic
    return true
end
execute_{policy_name.replace('-', '_')}()

'''
        
        fallback_plugin = {
            'name': 'luascriptexecuter',
            'config': {
                'script': all_policies_lua,
                'enabled': True,
                'timeout': 30000
            },
            'tags': [f"api:{api_name}", "fallback-migration"],
            'api_flow': 'both',
            'priority': 999
        }
        
        fallback_configs['both'].append(fallback_plugin)
        return fallback_configs
    
    # Helper methods
    def _load_policy_mapper(self):
        """Load policy to plugin mapper"""
        mapper_file = self.mappers_dir / "policy-to-plugin-mapper.json"
        with open(mapper_file, 'r') as f:
            return json.load(f)
    
    def _parse_xml_config(self, xml_content):
        """Parse XML policy configuration"""
        try:
            root = ET.fromstring(xml_content)
            return self._xml_to_dict(root)
        except ET.ParseError as e:
            self.logger.warning(f"XML parsing failed: {e}")
            return {}
    
    def _xml_to_dict(self, element):
        """Convert XML element to dictionary"""
        result = {}
        
        # Add attributes
        if element.attrib:
            result.update(element.attrib)
        
        # Add text content
        if element.text and element.text.strip():
            if len(element) == 0:
                return element.text.strip()
            result['text'] = element.text.strip()
        
        # Add child elements
        for child in element:
            child_data = self._xml_to_dict(child)
            if child.tag in result:
                if not isinstance(result[child.tag], list):
                    result[child.tag] = [result[child.tag]]
                result[child.tag].append(child_data)
            else:
                result[child.tag] = child_data
        
        return result
    
    def _is_custom_plugin(self, plugin_name):
        """Check if plugin is a custom plugin"""
        custom_plugins = [
            'assertcondition', 'attribute', 'datacapture', 'extensioncallout',
            'flowcallout', 'custom-graphql', 'invalidate-cache', 'java-callout',
            'javascript', 'jsontoxml', 'keyvaluemapoperations', 'latencyanalysis',
            'luascriptexecuter', 'parsedialogflowrequest', 'publishmessage',
            'python', 'readpropertyset', 'resetquota', 'servicecallout',
            'setdialogflowresponse', 'setintegrationrequest', 'setoauthv2info',
            'soapvalidation', 'xsltransform'
        ]
        return plugin_name in custom_plugins
    
    def _extract_policy_configuration(self, policy):
        """Extract configuration from policy"""
        config = {}
        
        # Get parsed XML config if available
        if 'parsed_config' in policy:
            config.update(policy['parsed_config'])
        
        # Get direct config
        if 'config' in policy:
            config.update(policy['config'])
        
        # Get common fields
        for field in ['name', 'enabled', 'continueOnError', 'displayName']:
            if field in policy:
                config[field] = policy[field]
        
        return config
    
    def _get_default_plugin_config(self, plugin_name):
        """Get default configuration for built-in plugins"""
        defaults = {
            'rate-limiting': {'minute': 100, 'policy': 'local'},
            'cors': {'origins': ['*'], 'methods': ['GET', 'POST']},
            'key-auth': {'key_names': ['apikey']},
            'basic-auth': {'hide_credentials': True},
            'jwt': {'key_claim_name': 'iss'},
            'oauth2': {'scopes': ['read'], 'mandatory_scope': True},
            'request-transformer': {'add': {'headers': []}},
            'response-transformer': {'add': {'headers': []}},
            'http-log': {'http_endpoint': 'http://localhost:8080/log'},
            'file-log': {'path': '/var/log/kong/access.log'},
            'request-validator': {'body_schema': '{}'},
            'proxy-cache-advanced': {'cache_ttl': 300}
        }
        
        return defaults.get(plugin_name, {'enabled': True})
    
    def _map_policy_to_plugin_config(self, plugin_name, policy_config):
        """Map policy configuration to plugin configuration"""
        # This would contain specific mapping logic for each plugin
        # For now, return basic mapping
        mapped = {}
        
        if plugin_name == 'rate-limiting' and 'quota' in policy_config:
            mapped['minute'] = policy_config.get('quota', 100)
        elif plugin_name == 'cors' and 'origins' in policy_config:
            mapped['origins'] = policy_config.get('origins', ['*'])
        
        return mapped
    
    def _determine_execution_phase(self, policy_type):
        """Determine Kong execution phase for policy type"""
        request_phases = ['VerifyAPIKey', 'BasicAuthentication', 'JWT', 'OAuth', 'RaiseFault']
        response_phases = ['AssignMessage', 'JSONToXML', 'XMLToJSON']
        
        if policy_type in request_phases:
            return 'access'
        elif policy_type in response_phases:
            return 'header_filter'
        else:
            return 'access'
    
    def _indent_code(self, code, spaces):
        """Indent code by specified spaces"""
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in code.split('\n'))

def migrate_policies_enterprise(policies, resources, api_name, config):
    """Main function for enterprise policy migration"""
    migrator = EnterprisePolicyMigration(config)
    return migrator.migrate_policies(policies, resources, api_name)