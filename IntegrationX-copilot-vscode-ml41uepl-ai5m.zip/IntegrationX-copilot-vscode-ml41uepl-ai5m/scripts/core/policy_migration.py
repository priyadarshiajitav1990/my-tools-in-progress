import os
import logging
import json
from pathlib import Path

from .policy_migration_enhanced import EnhancedPolicyMigrationEngine

def migrate_policies(report_data=None):
    """
    Enhanced policy migration using the new migration engine
    """
    logging.info("--- Starting Enhanced Policy Migration ---")
    
    # Get configuration
    api_name = os.environ.get("api_name")
    extracted_api_dir = os.environ.get("extracted_api_dir")
    output_dir = os.environ.get("output_dir")
    
    if not all([api_name, extracted_api_dir, output_dir]):
        logging.error("Missing required configuration for policy migration. Skipping.")
        return
    
    # Load configuration
    project_root = Path(__file__).parent.parent.parent
    config_file = project_root / "configs" / "config.json"
    
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
    except Exception as e:
        logging.warning(f"Failed to load config: {e}, using defaults")
        config = {"kong": {"version": "3.13.0.0"}, "migration": {}}
    
    # Initialize enhanced migration engine
    migration_engine = EnhancedPolicyMigrationEngine(project_root, config)
    
    # Paths
    api_base_path = project_root / extracted_api_dir / api_name / "apiproxy"
    policies_path = str(api_base_path / "policies")
    proxies_path = api_base_path / "proxies"
    targets_path = api_base_path / "targets"
    
    # Create API-specific output directory
    api_output_dir = project_root / output_dir / api_name
    api_output_dir.mkdir(parents=True, exist_ok=True)
    output_path = api_output_dir / f"kong-{api_name}.yml"
    
    # Load existing Kong YAML
    try:
        import yaml
        with open(output_path, 'r') as f:
            output_data = yaml.safe_load(f) or {}
    except FileNotFoundError:
        logging.error(f"Kong YAML file not found at '{output_path}'. Cannot migrate policies.")
        return
    
    success = True
    
    # Migrate policies from Target Endpoints (attach to Services)
    if targets_path.exists():
        import xml.etree.ElementTree as ET
        for target_file in targets_path.glob("*.xml"):
            entity_name = target_file.stem
            try:
                tree = ET.parse(target_file)
                root = tree.getroot()
                
                result = migration_engine.migrate_policies_for_entity(
                    "service", entity_name, root, output_data, 
                    api_name, policies_path, report_data
                )
                if not result:
                    success = False
                    
            except Exception as e:
                logging.error(f"Failed to process target endpoint {entity_name}: {e}")
                success = False
    
    # Migrate policies from Proxy Endpoints (attach to Routes)
    if proxies_path.exists():
        import xml.etree.ElementTree as ET
        for proxy_file in proxies_path.glob("*.xml"):
            entity_name = proxy_file.stem
            try:
                tree = ET.parse(proxy_file)
                root = tree.getroot()
                
                result = migration_engine.migrate_policies_for_entity(
                    "route", entity_name, root, output_data, 
                    api_name, policies_path, report_data
                )
                if not result:
                    success = False
                    
            except Exception as e:
                logging.error(f"Failed to process proxy endpoint {entity_name}: {e}")
                success = False
    
    # Write updated configuration
    try:
        import yaml
        with open(output_path, 'w') as f:
            yaml.dump(output_data, f, sort_keys=False, indent=2)
        
        logging.info(f"Enhanced policy migration completed. Updated Kong configuration: {output_path}")
        
        # Log migration statistics
        stats = migration_engine.get_migration_stats()
        logging.info(f"Migration Statistics:")
        logging.info(f"  - Policies processed: {stats['policies_processed']}")
        logging.info(f"  - Plugins generated: {stats['plugins_generated']}")
        logging.info(f"  - Resources converted: {stats['resources_converted']}")
        logging.info(f"  - Conflicts resolved: {stats['conflicts_resolved']}")
        logging.info(f"  - Fallbacks used: {stats['fallbacks_used']}")
        
        if stats['errors']:
            logging.warning(f"  - Errors encountered: {len(stats['errors'])}")
            for error in stats['errors'][:5]:  # Show first 5 errors
                logging.warning(f"    - {error}")
        
        # Generate unused policies report
        _generate_unused_policies_report(api_base_path, api_output_dir, api_name)
        
    except Exception as e:
        logging.error(f"Failed to save updated configuration: {e}")
        success = False
    
    if success:
        logging.info("Enhanced policy migration completed successfully")
    else:
        logging.warning("Enhanced policy migration completed with some errors")

def _generate_unused_policies_report(api_base_path: Path, output_dir: Path, api_name: str):
    """Generate report of unused policies"""
    try:
        policies_path = api_base_path / "policies"
        if not policies_path.exists():
            return
        
        # Get all policy files
        all_policies = set(f.stem for f in policies_path.glob("*.xml"))
        
        # Get used policies from flows
        used_policies = set()
        
        # Check proxy endpoints
        proxies_path = api_base_path / "proxies"
        if proxies_path.exists():
            used_policies.update(_extract_used_policies_from_endpoints(proxies_path))
        
        # Check target endpoints
        targets_path = api_base_path / "targets"
        if targets_path.exists():
            used_policies.update(_extract_used_policies_from_endpoints(targets_path))
        
        # Find unused policies
        unused_policies = sorted(all_policies - used_policies)
        
        # Write report
        report_path = output_dir / f"unused_policies_{api_name}.txt"
        with open(report_path, 'w') as f:
            if unused_policies:
                f.write("Unused Apigee policies (not attached in any flow):\n")
                for policy in unused_policies:
                    f.write(f"- {policy}\n")
                logging.info(f"Found {len(unused_policies)} unused policies")
            else:
                f.write("All Apigee policies are used in flows.\n")
                logging.info("All Apigee policies are used in flows")
        
    except Exception as e:
        logging.error(f"Failed to generate unused policies report: {e}")

def _extract_used_policies_from_endpoints(endpoints_path: Path) -> set:
    """Extract used policy names from endpoint files"""
    import xml.etree.ElementTree as ET
    
    used_policies = set()
    
    for endpoint_file in endpoints_path.glob("*.xml"):
        try:
            tree = ET.parse(endpoint_file)
            root = tree.getroot()
            
            # Find all Step/Name elements
            for step in root.findall('.//Step'):
                name_elem = step.find('Name')
                if name_elem is not None and name_elem.text:
                    used_policies.add(name_elem.text)
                    
        except Exception as e:
            logging.warning(f"Failed to parse endpoint file {endpoint_file}: {e}")
    
    return used_policies