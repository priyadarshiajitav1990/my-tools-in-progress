#!/usr/bin/env python3
"""
Enhanced Policy Migration (Simplified)
Advanced policy to plugin mapping with resource file handling
"""

import os
import json
from pathlib import Path
from collections import defaultdict
import xml.etree.ElementTree as ET

class EnhancedPolicyMigration:
    def __init__(self, config):
        self.config = config
        self.base_dir = Path(__file__).parent.parent.parent
        self.mappers_dir = self.base_dir / "mappers"
        
        # Load mappers
        self.policy_mapper = self._load_policy_mapper()
        self.var_mapper = self._load_var_mapper()
        
        # Plugin execution order
        self.plugin_order = {
            'request': [
                'ip-restriction', 'cors', 'key-auth', 'basic-auth', 'oauth2', 'jwt',
                'rate-limiting', 'rate-limiting-advanced', 'request-validator',
                'assertcondition', 'attribute', 'readpropertyset',
                'request-transformer', 'request-transformer-advanced',
                'servicecallout', 'extensioncallout', 'flowcallout',
                'javascript', 'python', 'java-callout', 'luascriptexecuter'
            ],
            'response': [
                'response-transformer', 'response-transformer-advanced',
                'jsontoxml', 'xsltransform', 'setdialogflowresponse',
                'datacapture', 'http-log', 'file-log', 'kafka-log', 'luascriptexecuter'
            ]
        }
    
    def _load_policy_mapper(self):
        """Load policy to plugin mapper"""
        mapper_file = self.mappers_dir / "policy-to-plugin-mapper.json"
        with open(mapper_file, 'r') as f:
            return json.load(f)
    
    def _load_var_mapper(self):
        """Load variable mapper"""
        mapper_file = self.mappers_dir / "apigee-to-kong-var-mappers.json"
        with open(mapper_file, 'r') as f:
            return json.load(f)
    
    def migrate_policies(self, policies, resources, api_name):
        """Migrate Apigee policies to Kong plugins"""
        migrated_plugins = {
            'request': [],
            'response': [],
            'both': []
        }
        
        for policy in policies:
            try:
                plugins = self._migrate_single_policy(policy, resources, api_name)
                for plugin in plugins:
                    flow = plugin.get('api_flow', 'both')
                    if flow in migrated_plugins:
                        migrated_plugins[flow].append(plugin)
                        
            except Exception as e:
                print(f"Error migrating policy {policy.get('name', 'unknown')}: {e}")
                # Create fallback plugin
                fallback_plugin = self._create_fallback_plugin(policy, api_name)
                migrated_plugins['both'].append(fallback_plugin)
        
        return migrated_plugins
    
    def _migrate_single_policy(self, policy, resources, api_name):
        """Migrate a single policy to Kong plugins"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        
        if policy_type not in self.policy_mapper:
            return [self._create_lua_script_plugin(policy, resources, api_name)]
        
        mapped_plugins = self.policy_mapper[policy_type]
        result_plugins = []
        
        # Use first available plugin mapping
        plugin_mapping = mapped_plugins[0]
        plugin_name = plugin_mapping['plugin_name']
        api_flow = plugin_mapping['api_flow']
        
        if plugin_name in self._get_custom_plugins():
            plugin_config = self._generate_custom_plugin_config(
                plugin_name, policy, resources, api_name, api_flow
            )
        else:
            plugin_config = self._generate_builtin_plugin_config(
                plugin_name, policy, resources, api_name, api_flow
            )
        
        if plugin_config:
            result_plugins.append(plugin_config)
        
        return result_plugins
    
    def _generate_custom_plugin_config(self, plugin_name, policy, resources, api_name, api_flow):
        """Generate configuration for custom plugins"""
        config = {
            'name': plugin_name,
            'config': {'enabled': True},
            'tags': [f"api:{api_name}", f"policy:{policy.get('name', '')}"],
            'api_flow': api_flow
        }
        
        # Add policy-specific configuration
        if plugin_name == 'assertcondition':
            config['config'].update({
                'condition': policy.get('condition', 'true'),
                'message': policy.get('message', 'Condition failed'),
                'continueOnError': policy.get('continueOnError', False)
            })
        elif plugin_name == 'datacapture':
            config['config'].update({
                'log_path': '/var/log/kong/datacapture.log'
            })
        elif plugin_name == 'servicecallout':
            config['config'].update({
                'url': policy.get('url', 'http://backend.example.com'),
                'method': policy.get('method', 'GET'),
                'timeout': policy.get('timeout', 30000)
            })
        
        return config
    
    def _generate_builtin_plugin_config(self, plugin_name, policy, resources, api_name, api_flow):
        """Generate configuration for built-in Kong plugins"""
        config = {
            'name': plugin_name,
            'config': self._create_basic_config(plugin_name, policy),
            'tags': [f"api:{api_name}", f"policy:{policy.get('name', '')}"],
            'api_flow': api_flow
        }
        
        return config
    
    def _create_lua_script_plugin(self, policy, resources, api_name):
        """Create luascriptexecuter plugin for complex policies"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        policy_name = policy.get('name', '')
        
        # Generate Lua code
        lua_code = self._generate_lua_code(policy, resources)
        
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': lua_code,
                'enabled': True,
                'timeout': 5000
            },
            'tags': [f"api:{api_name}", f"policy:{policy_name}", f"type:{policy_type}"],
            'api_flow': 'both'
        }
    
    def _generate_lua_code(self, policy, resources):
        """Generate Lua code for policy"""
        policy_type = policy.get('policyType', policy.get('type', ''))
        policy_name = policy.get('name', '')
        
        lua_code = f'''
-- Policy: {policy_name} (Type: {policy_type})
local function execute_policy()
    local request = kong.request
    local response = kong.response
    local ctx = kong.ctx.shared
    
    kong.log.info("Executing policy: {policy_name}")
    
    -- TODO: Implement {policy_type} logic
    
    return true
end

return execute_policy()
'''
        
        return lua_code
    
    def _get_custom_plugins(self):
        """Get list of custom plugins"""
        return [
            'assertcondition', 'attribute', 'datacapture', 'extensioncallout',
            'flowcallout', 'custom-graphql', 'invalidate-cache', 'java-callout',
            'javascript', 'jsontoxml', 'keyvaluemapoperations', 'latencyanalysis',
            'luascriptexecuter', 'parsedialogflowrequest', 'publishmessage',
            'python', 'readpropertyset', 'resetquota', 'servicecallout',
            'setdialogflowresponse', 'setintegrationrequest', 'setoauthv2info',
            'soapvalidation', 'xsltransform'
        ]
    
    def _create_basic_config(self, plugin_name, policy):
        """Create basic configuration for built-in plugins"""
        basic_configs = {
            'rate-limiting': {'minute': 100},
            'cors': {'origins': ['*']},
            'key-auth': {'key_names': ['apikey']},
            'basic-auth': {'hide_credentials': True},
            'jwt': {'key_claim_name': 'iss'},
            'oauth2': {'scopes': ['read']},
            'request-transformer': {'add': {'headers': []}},
            'response-transformer': {'add': {'headers': []}},
            'http-log': {'http_endpoint': 'http://localhost:8080/log'},
            'file-log': {'path': '/var/log/kong/access.log'}
        }
        
        return basic_configs.get(plugin_name, {'enabled': True})
    
    def _create_fallback_plugin(self, policy, api_name):
        """Create fallback plugin for failed migrations"""
        return {
            'name': 'luascriptexecuter',
            'config': {
                'script': f'''
-- Fallback for policy: {policy.get('name', 'unknown')}
kong.log.warn("Policy migration fallback: {policy.get('policyType', 'unknown')}")
return true
''',
                'enabled': True
            },
            'tags': [f"api:{api_name}", "fallback"],
            'api_flow': 'both'
        }

def migrate_policies(policies, resources, api_name, config):
    """Main function to migrate policies"""
    migrator = EnhancedPolicyMigration(config)
    return migrator.migrate_policies(policies, resources, api_name)