"""
Tests for complex Python constructs in Python-to-Lua converter.
"""
from py_to_lua.parser import PythonParser
from py_to_lua.ast_transformer import ASTTransformer
from py_to_lua.lua_generator import LuaGenerator

def test_lambda():
    source = 'f = lambda x: x + 1'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'function(x) return (x + 1) end' in lua_code

def test_list_comp():
    source = '[x*x for x in range(5)]'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- list comprehension' in lua_code

def test_dict_comp():
    source = '{x: x*x for x in range(5)}'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- dict comprehension' in lua_code

def test_with():
    source = 'with open("foo.txt") as f:\n    data = f.read()'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- with statement' in lua_code

def test_try_except():
    source = 'try:\n    x = 1\nexcept Exception as e:\n    x = 2'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- try/except/finally' in lua_code

def test_yield():
    source = 'def gen():\n    yield 1'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'coroutine.yield' in lua_code

def test_decorator():
    source = '@decorator\ndef foo():\n    pass'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert 'foo = decorator(foo)' in lua_code

def test_async():
    source = 'async def foo():\n    await bar()'
    parser = PythonParser()
    tree = parser.parse(source)
    generator = LuaGenerator()
    lua_code = generator.generate(tree)
    assert '-- async function' in lua_code and '-- await not supported' in lua_code

if __name__ == "__main__":
    test_lambda()
    test_list_comp()
    test_dict_comp()
    test_with()
    test_try_except()
    test_yield()
    test_decorator()
    test_async()
    print("All complex tests passed.")
