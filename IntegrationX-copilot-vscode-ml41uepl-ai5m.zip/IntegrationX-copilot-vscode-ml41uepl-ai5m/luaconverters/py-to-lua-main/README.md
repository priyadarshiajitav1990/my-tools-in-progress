## Standard Library Stubs

The tool provides a Lua module `py_to_lua_stdlib_stubs.lua` with stubs for common Python standard library modules:
- math, os, sys, random (with basic functions)

To use these in your Lua output, add this line at the top of your generated Lua script:

```lua
require('py_to_lua.py_to_lua_stdlib_stubs')
```
# Python to Lua Converter

A production-standard tool to convert Python code to Lua.

## Features
- Parses Python source code using the built-in `ast` module
- Transforms Python AST to an intermediate representation
- Generates Lua code from the AST
- CLI for file conversion (with output file option)
- Basic and complex tests included

## Usage

```bash
python -m py_to_lua.cli <python_file.py> [--output <lua_file.lua>]
```

## Example

Given a file `example.py`:
```python
42
```

Run:
```bash
python -m py_to_lua.cli example.py
```

Output:
```
42
```

## Testing

```bash
python tests.py
python tests_complex.py
python tests_module_api.py
```

## Polyfills for Python Built-ins

The tool provides a Lua module `py_to_lua_polyfills.lua` with polyfills for common Python built-ins:
- enumerate, zip, range, map, filter, any, all, sum, min, max

To use these in your Lua output, add this line at the top of your generated Lua script:

```lua
require('py_to_lua.py_to_lua_polyfills')
```

## Limitations

- Most Python features are supported. Unsupported features are commented or emulated in the generated Lua code.
- Decorators, context managers, async/await, and generators are emulated where possible, but may not match Python semantics exactly.
- Some advanced Python modules and dynamic features may not translate directly.
- Error handling and edge cases are handled gracefully, but manual review of output is recommended for complex scripts.

## Advanced Example

```bash
python -m py_to_lua.cli complex_script.py --output complex_script.lua
```

## Project Structure
- `py_to_lua/parser.py`: Python source parser
- `py_to_lua/ast_transformer.py`: AST transformer
- `py_to_lua/lua_generator.py`: Lua code generator
- `py_to_lua/cli.py`: CLI entry point
- `tests.py`: Basic tests