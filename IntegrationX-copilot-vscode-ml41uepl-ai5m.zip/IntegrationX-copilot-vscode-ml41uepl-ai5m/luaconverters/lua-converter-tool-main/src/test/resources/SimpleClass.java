public class SimpleClass {
    private int x;
    public SimpleClass() { x = 0; }
    public void setX(int x) { this.x = x; }
    public int getX() { return x; }
}