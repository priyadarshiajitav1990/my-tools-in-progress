def foo(a):
    if a > 0:
        for i in range(a):
            pass
    else:
        while a < 10:
            a += 1
foo(5)
