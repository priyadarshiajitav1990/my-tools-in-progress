// Enterprise Demo API - Request Validation
// Complex JavaScript for request validation and transformation

function validateRequest() {
    try {
        var method = context.getVariable("request.verb");
        var path = context.getVariable("proxy.pathsuffix");
        var contentType = context.getVariable("request.header.content-type");
        var userAgent = context.getVariable("request.header.user-agent");
        
        // Log request details
        print("Processing request: " + method + " " + path);
        
        // Validate HTTP method
        var allowedMethods = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"];
        if (allowedMethods.indexOf(method) === -1) {
            context.setVariable("request.validation.error", "Invalid HTTP method");
            context.setVariable("request.validation.status", "failed");
            return false;
        }
        
        // Path-specific validation
        if (path.indexOf("/users") === 0) {
            validateUserRequest(method, path, contentType);
        } else if (path.indexOf("/orders") === 0) {
            validateOrderRequest(method, path, contentType);
        } else if (path.indexOf("/admin") === 0) {
            validateAdminRequest(method, path);
        }
        
        // User-Agent validation for mobile endpoints
        if (path.indexOf("/mobile") === 0) {
            if (!userAgent || userAgent.indexOf("Mobile") === -1) {
                context.setVariable("request.validation.warning", "Non-mobile user agent detected");
            }
        }
        
        // Set validation success
        context.setVariable("request.validation.status", "passed");
        context.setVariable("request.validation.timestamp", new Date().toISOString());
        
        return true;
        
    } catch (error) {
        context.setVariable("request.validation.error", "Validation script error: " + error.message);
        context.setVariable("request.validation.status", "error");
        return false;
    }
}

function validateUserRequest(method, path, contentType) {
    if (method === "POST" || method === "PUT") {
        if (!contentType || contentType.indexOf("application/json") === -1) {
            context.setVariable("request.validation.error", "Content-Type must be application/json for user operations");
            throw new Error("Invalid content type");
        }
        
        // Validate request body for user operations
        var requestBody = context.getVariable("request.content");
        if (requestBody) {
            try {
                var userData = JSON.parse(requestBody);
                if (method === "POST" && (!userData.email || !userData.name)) {
                    throw new Error("Missing required fields: email, name");
                }
                
                // Email validation
                if (userData.email && !isValidEmail(userData.email)) {
                    throw new Error("Invalid email format");
                }
                
                // Set processed user data
                context.setVariable("request.user.validated", "true");
                context.setVariable("request.user.email", userData.email);
                
            } catch (parseError) {
                context.setVariable("request.validation.error", "Invalid JSON in request body");
                throw parseError;
            }
        }
    }
    
    // Extract user ID from path for GET/PUT/DELETE operations
    var userIdMatch = path.match(/\/users\/([^\/]+)/);
    if (userIdMatch && userIdMatch[1]) {
        var userId = userIdMatch[1];
        if (!isValidUserId(userId)) {
            context.setVariable("request.validation.error", "Invalid user ID format");
            throw new Error("Invalid user ID");
        }
        context.setVariable("request.user.id", userId);
    }
}

function validateOrderRequest(method, path, contentType) {
    if (method === "POST" || method === "PUT") {
        if (!contentType || contentType.indexOf("application/json") === -1) {
            context.setVariable("request.validation.error", "Content-Type must be application/json for order operations");
            throw new Error("Invalid content type");
        }
        
        var requestBody = context.getVariable("request.content");
        if (requestBody) {
            try {
                var orderData = JSON.parse(requestBody);
                if (method === "POST" && (!orderData.customerId || !orderData.items)) {
                    throw new Error("Missing required fields: customerId, items");
                }
                
                // Validate order items
                if (orderData.items && Array.isArray(orderData.items)) {
                    for (var i = 0; i < orderData.items.length; i++) {
                        var item = orderData.items[i];
                        if (!item.productId || !item.quantity || item.quantity <= 0) {
                            throw new Error("Invalid item at index " + i);
                        }
                    }
                }
                
                context.setVariable("request.order.validated", "true");
                context.setVariable("request.order.customerId", orderData.customerId);
                
            } catch (parseError) {
                context.setVariable("request.validation.error", "Invalid order data");
                throw parseError;
            }
        }
    }
}

function validateAdminRequest(method, path) {
    // Admin requests require special validation
    var adminToken = context.getVariable("request.header.x-admin-token");
    if (!adminToken) {
        context.setVariable("request.validation.error", "Admin token required");
        throw new Error("Missing admin token");
    }
    
    // Validate admin permissions
    var operation = method + " " + path;
    context.setVariable("request.admin.operation", operation);
    context.setVariable("request.admin.validated", "true");
}

function isValidEmail(email) {
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidUserId(userId) {
    // User ID should be alphanumeric and 3-50 characters
    var userIdRegex = /^[a-zA-Z0-9]{3,50}$/;
    return userIdRegex.test(userId);
}

// Execute validation
validateRequest();