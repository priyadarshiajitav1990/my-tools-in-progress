// Enterprise Demo API - Response Processing
// Complex JavaScript for response transformation and enhancement

function processResponse() {
    try {
        var responseCode = context.getVariable("response.status.code");
        var contentType = context.getVariable("response.header.content-type");
        var method = context.getVariable("request.verb");
        var path = context.getVariable("proxy.pathsuffix");
        
        print("Processing response: " + responseCode + " for " + method + " " + path);
        
        // Add standard response headers
        context.setVariable("response.header.X-API-Version", "1.0");
        context.setVariable("response.header.X-Response-Time", new Date().toISOString());
        context.setVariable("response.header.X-Request-ID", context.getVariable("messageid"));
        
        // Process successful responses
        if (responseCode >= 200 && responseCode < 300) {
            processSuccessResponse(method, path, contentType);
        } else if (responseCode >= 400 && responseCode < 500) {
            processClientErrorResponse(responseCode);
        } else if (responseCode >= 500) {
            processServerErrorResponse(responseCode);
        }
        
        // Add CORS headers if needed
        var origin = context.getVariable("request.header.origin");
        if (origin) {
            context.setVariable("response.header.Access-Control-Allow-Origin", origin);
            context.setVariable("response.header.Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            context.setVariable("response.header.Access-Control-Allow-Headers", "Content-Type, Authorization, X-API-Key");
        }
        
        // Set processing status
        context.setVariable("response.processing.status", "completed");
        context.setVariable("response.processing.timestamp", new Date().toISOString());
        
        return true;
        
    } catch (error) {
        context.setVariable("response.processing.error", "Response processing error: " + error.message);
        return false;
    }
}

function processSuccessResponse(method, path, contentType) {
    var responseContent = context.getVariable("response.content");
    
    if (contentType && contentType.indexOf("application/json") !== -1 && responseContent) {
        try {
            var responseData = JSON.parse(responseContent);
            
            // Add metadata to response
            responseData._metadata = {
                timestamp: new Date().toISOString(),
                version: "1.0",
                requestId: context.getVariable("messageid"),
                processingTime: calculateProcessingTime()
            };
            
            // Path-specific response processing
            if (path.indexOf("/users") === 0) {
                processUserResponse(responseData, method);
            } else if (path.indexOf("/orders") === 0) {
                processOrderResponse(responseData, method);
            }
            
            // Update response content
            context.setVariable("response.content", JSON.stringify(responseData, null, 2));
            
        } catch (parseError) {
            print("Warning: Could not parse response JSON: " + parseError.message);
        }
    }
    
    // Add cache headers for GET requests
    if (method === "GET") {
        context.setVariable("response.header.Cache-Control", "public, max-age=300");
        context.setVariable("response.header.ETag", generateETag(responseContent));
    }
}

function processUserResponse(responseData, method) {
    if (method === "GET") {
        // Add user-specific metadata
        if (responseData.users && Array.isArray(responseData.users)) {
            responseData._metadata.totalUsers = responseData.users.length;
            
            // Sanitize user data (remove sensitive fields)
            responseData.users = responseData.users.map(function(user) {
                delete user.password;
                delete user.ssn;
                return user;
            });
        } else if (responseData.id) {
            // Single user response
            delete responseData.password;
            delete responseData.ssn;
            responseData._metadata.userType = responseData.role || "standard";
        }
    } else if (method === "POST") {
        // Add creation metadata
        responseData._metadata.created = true;
        responseData._metadata.location = "/users/" + responseData.id;
        context.setVariable("response.header.Location", responseData._metadata.location);
    }
}

function processOrderResponse(responseData, method) {
    if (method === "GET") {
        if (responseData.orders && Array.isArray(responseData.orders)) {
            responseData._metadata.totalOrders = responseData.orders.length;
            
            // Calculate total value
            var totalValue = 0;
            responseData.orders.forEach(function(order) {
                if (order.total) {
                    totalValue += parseFloat(order.total);
                }
            });
            responseData._metadata.totalValue = totalValue;
        }
    } else if (method === "POST") {
        // Add order creation metadata
        responseData._metadata.orderCreated = true;
        responseData._metadata.estimatedDelivery = calculateDeliveryDate();
        
        // Set order confirmation header
        context.setVariable("response.header.X-Order-Confirmation", responseData.orderNumber || responseData.id);
    }
}

function processClientErrorResponse(responseCode) {
    var errorResponse = {
        error: {
            code: responseCode,
            message: getErrorMessage(responseCode),
            timestamp: new Date().toISOString(),
            requestId: context.getVariable("messageid")
        }
    };
    
    // Add validation errors if available
    var validationError = context.getVariable("request.validation.error");
    if (validationError) {
        errorResponse.error.details = validationError;
    }
    
    context.setVariable("response.content", JSON.stringify(errorResponse, null, 2));
    context.setVariable("response.header.Content-Type", "application/json");
}

function processServerErrorResponse(responseCode) {
    var errorResponse = {
        error: {
            code: responseCode,
            message: "Internal server error",
            timestamp: new Date().toISOString(),
            requestId: context.getVariable("messageid"),
            support: "Please contact support with this request ID"
        }
    };
    
    context.setVariable("response.content", JSON.stringify(errorResponse, null, 2));
    context.setVariable("response.header.Content-Type", "application/json");
}

function calculateProcessingTime() {
    var startTime = context.getVariable("client.received.start.timestamp");
    var currentTime = new Date().getTime();
    return currentTime - parseInt(startTime);
}

function generateETag(content) {
    // Simple ETag generation based on content hash
    var hash = 0;
    if (content) {
        for (var i = 0; i < content.length; i++) {
            var char = content.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
    }
    return '"' + Math.abs(hash).toString(16) + '"';
}

function calculateDeliveryDate() {
    var deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + 3); // 3 days from now
    return deliveryDate.toISOString().split('T')[0]; // Return date only
}

function getErrorMessage(code) {
    var messages = {
        400: "Bad Request - Invalid request format",
        401: "Unauthorized - Authentication required",
        403: "Forbidden - Insufficient permissions",
        404: "Not Found - Resource not found",
        405: "Method Not Allowed - HTTP method not supported",
        409: "Conflict - Resource already exists",
        422: "Unprocessable Entity - Validation failed",
        429: "Too Many Requests - Rate limit exceeded"
    };
    
    return messages[code] || "Client error occurred";
}

// Execute response processing
processResponse();