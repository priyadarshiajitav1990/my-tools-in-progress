// Enterprise Demo API - Data Processor
// Java class for complex data processing operations

package com.enterprise;

import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;

import java.util.*;
import java.util.regex.Pattern;
import java.text.SimpleDateFormat;
import java.security.MessageDigest;

public class DataProcessor implements Execution {
    
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$");
    
    private static final SimpleDateFormat ISO_DATE_FORMAT = 
        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    
    @Override
    public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {
        try {
            String mode = getProperty("mode", "process");
            String requestContent = messageContext.getVariable("request.content");
            String method = messageContext.getVariable("request.verb");
            String path = messageContext.getVariable("proxy.pathsuffix");
            
            // Log processing start
            System.out.println("DataProcessor: Processing " + method + " " + path + " in mode: " + mode);
            
            // Process based on mode
            switch (mode.toLowerCase()) {
                case "validate":
                    return validateData(messageContext, requestContent);
                case "transform":
                    return transformData(messageContext, requestContent);
                case "enrich":
                    return enrichData(messageContext, requestContent);
                default:
                    return processData(messageContext, requestContent);
            }
            
        } catch (Exception e) {
            messageContext.setVariable("java.processor.error", e.getMessage());
            System.err.println("DataProcessor error: " + e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
    
    private ExecutionResult processData(MessageContext messageContext, String content) {
        try {
            // Set processing metadata
            messageContext.setVariable("java.processor.executed", "true");
            messageContext.setVariable("java.processor.timestamp", ISO_DATE_FORMAT.format(new Date()));
            messageContext.setVariable("java.processor.class", this.getClass().getSimpleName());
            
            // Process content if available
            if (content != null && !content.trim().isEmpty()) {
                // Calculate content hash
                String contentHash = calculateHash(content);
                messageContext.setVariable("java.processor.content.hash", contentHash);
                messageContext.setVariable("java.processor.content.size", String.valueOf(content.length()));
                
                // Analyze content type
                String contentType = analyzeContentType(content);
                messageContext.setVariable("java.processor.content.type", contentType);
                
                // Perform content-specific processing
                if ("json".equals(contentType)) {
                    processJsonContent(messageContext, content);
                } else if ("xml".equals(contentType)) {
                    processXmlContent(messageContext, content);
                }
            }
            
            // Set success indicators
            messageContext.setVariable("java.processor.status", "success");
            messageContext.setVariable("java.processor.result", "Data processed successfully");
            
            return ExecutionResult.SUCCESS;
            
        } catch (Exception e) {
            messageContext.setVariable("java.processor.status", "error");
            messageContext.setVariable("java.processor.error", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
    
    private ExecutionResult validateData(MessageContext messageContext, String content) {
        List<String> validationErrors = new ArrayList<>();
        
        try {
            if (content == null || content.trim().isEmpty()) {
                validationErrors.add("Request content is empty");
            } else {
                // Validate JSON structure if content appears to be JSON
                if (content.trim().startsWith("{") || content.trim().startsWith("[")) {
                    validateJsonStructure(content, validationErrors);
                }
                
                // Validate email addresses in content
                validateEmailAddresses(content, validationErrors);
                
                // Validate data size
                if (content.length() > 1048576) { // 1MB limit
                    validationErrors.add("Request content exceeds size limit");
                }
            }
            
            // Set validation results
            messageContext.setVariable("java.validator.errors.count", String.valueOf(validationErrors.size()));
            if (!validationErrors.isEmpty()) {
                messageContext.setVariable("java.validator.errors", String.join("; ", validationErrors));
                messageContext.setVariable("java.validator.status", "failed");
                return ExecutionResult.ABORT;
            } else {
                messageContext.setVariable("java.validator.status", "passed");
                return ExecutionResult.SUCCESS;
            }
            
        } catch (Exception e) {
            messageContext.setVariable("java.validator.status", "error");
            messageContext.setVariable("java.validator.error", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
    
    private ExecutionResult transformData(MessageContext messageContext, String content) {
        try {
            if (content != null && !content.trim().isEmpty()) {
                // Transform content based on type
                String transformedContent = content;
                
                // Add transformation metadata
                Map<String, Object> metadata = new HashMap<>();
                metadata.put("originalSize", content.length());
                metadata.put("transformedAt", ISO_DATE_FORMAT.format(new Date()));
                metadata.put("transformationType", "java-processor");
                
                // Simple transformation: add metadata wrapper for JSON
                if (content.trim().startsWith("{")) {
                    transformedContent = addJsonMetadata(content, metadata);
                }
                
                // Set transformed content
                messageContext.setVariable("request.content", transformedContent);
                messageContext.setVariable("java.transformer.applied", "true");
                messageContext.setVariable("java.transformer.type", "metadata-wrapper");
            }
            
            return ExecutionResult.SUCCESS;
            
        } catch (Exception e) {
            messageContext.setVariable("java.transformer.error", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
    
    private ExecutionResult enrichData(MessageContext messageContext, String content) {
        try {
            // Add enrichment data
            messageContext.setVariable("java.enricher.timestamp", ISO_DATE_FORMAT.format(new Date()));
            messageContext.setVariable("java.enricher.requestId", UUID.randomUUID().toString());
            messageContext.setVariable("java.enricher.processor", "DataProcessor-v1.0");
            
            // Calculate processing metrics
            long startTime = System.currentTimeMillis();
            
            // Simulate some processing
            Thread.sleep(10); // Small delay to simulate processing
            
            long processingTime = System.currentTimeMillis() - startTime;
            messageContext.setVariable("java.enricher.processingTime", String.valueOf(processingTime));
            
            // Add client information
            String clientIp = messageContext.getVariable("client.ip");
            String userAgent = messageContext.getVariable("request.header.user-agent");
            
            if (clientIp != null) {
                messageContext.setVariable("java.enricher.client.ip", clientIp);
                messageContext.setVariable("java.enricher.client.hash", calculateHash(clientIp));
            }
            
            if (userAgent != null) {
                messageContext.setVariable("java.enricher.client.userAgent", userAgent);
                messageContext.setVariable("java.enricher.client.isMobile", 
                    userAgent.toLowerCase().contains("mobile") ? "true" : "false");
            }
            
            return ExecutionResult.SUCCESS;
            
        } catch (Exception e) {
            messageContext.setVariable("java.enricher.error", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
    
    private void processJsonContent(MessageContext messageContext, String content) {
        try {
            // Simple JSON processing - count braces and brackets
            int braceCount = content.length() - content.replace("{", "").length();
            int bracketCount = content.length() - content.replace("[", "").length();
            
            messageContext.setVariable("java.processor.json.braces", String.valueOf(braceCount));
            messageContext.setVariable("java.processor.json.brackets", String.valueOf(bracketCount));
            messageContext.setVariable("java.processor.json.estimated.objects", String.valueOf(braceCount / 2));
            messageContext.setVariable("java.processor.json.estimated.arrays", String.valueOf(bracketCount / 2));
            
        } catch (Exception e) {
            messageContext.setVariable("java.processor.json.error", e.getMessage());
        }
    }
    
    private void processXmlContent(MessageContext messageContext, String content) {
        try {
            // Simple XML processing - count tags
            int tagCount = content.split("<[^/!?]").length - 1;
            messageContext.setVariable("java.processor.xml.tags", String.valueOf(tagCount));
            
        } catch (Exception e) {
            messageContext.setVariable("java.processor.xml.error", e.getMessage());
        }
    }
    
    private String analyzeContentType(String content) {
        String trimmed = content.trim();
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return "json";
        } else if (trimmed.startsWith("<")) {
            return "xml";
        } else {
            return "text";
        }
    }
    
    private void validateJsonStructure(String content, List<String> errors) {
        // Simple JSON validation - check balanced braces and brackets
        int braceBalance = 0;
        int bracketBalance = 0;
        boolean inString = false;
        boolean escaped = false;
        
        for (char c : content.toCharArray()) {
            if (escaped) {
                escaped = false;
                continue;
            }
            
            if (c == '\\') {
                escaped = true;
                continue;
            }
            
            if (c == '"' && !escaped) {
                inString = !inString;
                continue;
            }
            
            if (!inString) {
                if (c == '{') braceBalance++;
                else if (c == '}') braceBalance--;
                else if (c == '[') bracketBalance++;
                else if (c == ']') bracketBalance--;
            }
        }
        
        if (braceBalance != 0) {
            errors.add("Unbalanced braces in JSON content");
        }
        if (bracketBalance != 0) {
            errors.add("Unbalanced brackets in JSON content");
        }
    }
    
    private void validateEmailAddresses(String content, List<String> errors) {
        // Find potential email addresses and validate them
        String[] words = content.split("\\s+");
        for (String word : words) {
            if (word.contains("@")) {
                if (!EMAIL_PATTERN.matcher(word).matches()) {
                    errors.add("Invalid email format found: " + word);
                }
            }
        }
    }
    
    private String addJsonMetadata(String jsonContent, Map<String, Object> metadata) {
        // Simple metadata addition - wrap original content
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"_metadata\": {\n");
        
        boolean first = true;
        for (Map.Entry<String, Object> entry : metadata.entrySet()) {
            if (!first) sb.append(",\n");
            sb.append("    \"").append(entry.getKey()).append("\": ");
            if (entry.getValue() instanceof String) {
                sb.append("\"").append(entry.getValue()).append("\"");
            } else {
                sb.append(entry.getValue());
            }
            first = false;
        }
        
        sb.append("\n  },\n");
        sb.append("  \"data\": ").append(jsonContent).append("\n");
        sb.append("}");
        
        return sb.toString();
    }
    
    private String calculateHash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "hash-error";
        }
    }
    
    private String getProperty(String name, String defaultValue) {
        // In a real implementation, this would get properties from the policy configuration
        return defaultValue;
    }
}