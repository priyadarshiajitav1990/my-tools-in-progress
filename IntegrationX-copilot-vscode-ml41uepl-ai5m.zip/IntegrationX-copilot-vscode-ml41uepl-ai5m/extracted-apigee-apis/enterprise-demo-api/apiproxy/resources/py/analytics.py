# Enterprise Demo API - Python Analytics
# Complex Python script for advanced analytics and data processing

import json
import time
import hashlib
import re
from datetime import datetime, timedelta

def process_analytics():
    """Main analytics processing function"""
    try:
        # Get request context
        method = flow.getVariable("request.verb")
        path = flow.getVariable("proxy.pathsuffix")
        client_id = flow.getVariable("verifyapikey.VAK-VerifyAPIKey.client_id")
        response_code = flow.getVariable("response.status.code")
        
        print(f"Processing analytics for: {method} {path}")
        
        # Initialize analytics data
        analytics_data = {
            "timestamp": datetime.now().isoformat(),
            "request_id": flow.getVariable("messageid"),
            "client_id": client_id,
            "method": method,
            "path": path,
            "response_code": int(response_code) if response_code else 0,
            "processing_time": calculate_processing_time(),
            "user_agent": flow.getVariable("request.header.user-agent"),
            "ip_address": flow.getVariable("client.ip")
        }
        
        # Perform path-specific analytics
        if "/users" in path:
            process_user_analytics(analytics_data)
        elif "/orders" in path:
            process_order_analytics(analytics_data)
        elif "/admin" in path:
            process_admin_analytics(analytics_data)
        
        # Calculate metrics
        calculate_performance_metrics(analytics_data)
        
        # Detect patterns and anomalies
        detect_usage_patterns(analytics_data)
        
        # Generate insights
        generate_insights(analytics_data)
        
        # Store analytics data in flow variables
        flow.setVariable("analytics.data", json.dumps(analytics_data))
        flow.setVariable("analytics.processed", "true")
        flow.setVariable("analytics.timestamp", analytics_data["timestamp"])
        
        # Set response headers for analytics
        flow.setVariable("response.header.X-Analytics-ID", analytics_data["request_id"])
        flow.setVariable("response.header.X-Processing-Time", str(analytics_data["processing_time"]))
        
        return True
        
    except Exception as e:
        error_msg = f"Analytics processing error: {str(e)}"
        print(error_msg)
        flow.setVariable("analytics.error", error_msg)
        flow.setVariable("analytics.processed", "false")
        return False

def process_user_analytics(analytics_data):
    """Process user-specific analytics"""
    path = analytics_data["path"]
    method = analytics_data["method"]
    
    analytics_data["category"] = "user_management"
    
    if method == "GET":
        if "/users/" in path and path.count("/") == 2:
            analytics_data["operation"] = "get_user_profile"
            analytics_data["resource_type"] = "single_user"
        else:
            analytics_data["operation"] = "list_users"
            analytics_data["resource_type"] = "user_collection"
    elif method == "POST":
        analytics_data["operation"] = "create_user"
        analytics_data["resource_type"] = "user_creation"
    elif method == "PUT":
        analytics_data["operation"] = "update_user"
        analytics_data["resource_type"] = "user_modification"
    elif method == "DELETE":
        analytics_data["operation"] = "delete_user"
        analytics_data["resource_type"] = "user_deletion"
    
    # Extract user ID if present
    user_id_match = re.search(r'/users/([^/]+)', path)
    if user_id_match:
        user_id = user_id_match.group(1)
        analytics_data["user_id"] = user_id
        analytics_data["user_id_hash"] = hashlib.md5(user_id.encode()).hexdigest()[:8]

def process_order_analytics(analytics_data):
    """Process order-specific analytics"""
    path = analytics_data["path"]
    method = analytics_data["method"]
    
    analytics_data["category"] = "order_management"
    
    if method == "GET":
        if "/orders/" in path and path.count("/") == 2:
            analytics_data["operation"] = "get_order_details"
            analytics_data["resource_type"] = "single_order"
        else:
            analytics_data["operation"] = "list_orders"
            analytics_data["resource_type"] = "order_collection"
    elif method == "POST":
        analytics_data["operation"] = "create_order"
        analytics_data["resource_type"] = "order_creation"
        
        # Analyze order data if available
        request_content = flow.getVariable("request.content")
        if request_content:
            try:
                order_data = json.loads(request_content)
                analytics_data["order_items_count"] = len(order_data.get("items", []))
                analytics_data["order_customer_id"] = order_data.get("customerId")
            except:
                pass
    
    # Extract order ID if present
    order_id_match = re.search(r'/orders/([^/]+)', path)
    if order_id_match:
        order_id = order_id_match.group(1)
        analytics_data["order_id"] = order_id
        analytics_data["order_id_hash"] = hashlib.md5(order_id.encode()).hexdigest()[:8]

def process_admin_analytics(analytics_data):
    """Process admin-specific analytics"""
    analytics_data["category"] = "admin_operations"
    analytics_data["security_level"] = "high"
    analytics_data["requires_audit"] = True
    
    # Admin operations require special tracking
    admin_token = flow.getVariable("request.header.x-admin-token")
    if admin_token:
        analytics_data["admin_token_hash"] = hashlib.sha256(admin_token.encode()).hexdigest()[:16]
    
    analytics_data["operation"] = f"admin_{analytics_data['method'].lower()}"

def calculate_processing_time():
    """Calculate request processing time"""
    try:
        start_time = flow.getVariable("client.received.start.timestamp")
        current_time = int(time.time() * 1000)
        if start_time:
            return current_time - int(start_time)
        return 0
    except:
        return 0

def calculate_performance_metrics(analytics_data):
    """Calculate performance metrics"""
    processing_time = analytics_data["processing_time"]
    
    # Categorize performance
    if processing_time < 100:
        analytics_data["performance_category"] = "excellent"
    elif processing_time < 500:
        analytics_data["performance_category"] = "good"
    elif processing_time < 1000:
        analytics_data["performance_category"] = "acceptable"
    else:
        analytics_data["performance_category"] = "slow"
    
    # Calculate performance score (0-100)
    max_acceptable_time = 2000  # 2 seconds
    performance_score = max(0, 100 - (processing_time / max_acceptable_time * 100))
    analytics_data["performance_score"] = min(100, performance_score)

def detect_usage_patterns(analytics_data):
    """Detect usage patterns and anomalies"""
    current_hour = datetime.now().hour
    
    # Determine usage pattern based on time
    if 9 <= current_hour <= 17:
        analytics_data["usage_pattern"] = "business_hours"
    elif 18 <= current_hour <= 22:
        analytics_data["usage_pattern"] = "evening_peak"
    elif 23 <= current_hour or current_hour <= 5:
        analytics_data["usage_pattern"] = "night_usage"
    else:
        analytics_data["usage_pattern"] = "morning_ramp"
    
    # Detect potential anomalies
    anomalies = []
    
    # Check for unusual response codes
    response_code = analytics_data["response_code"]
    if response_code >= 500:
        anomalies.append("server_error")
    elif response_code == 429:
        anomalies.append("rate_limit_exceeded")
    elif response_code == 401:
        anomalies.append("authentication_failure")
    
    # Check for slow responses
    if analytics_data["processing_time"] > 5000:  # 5 seconds
        anomalies.append("slow_response")
    
    # Check for unusual paths
    path = analytics_data["path"]
    if len(path) > 200:
        anomalies.append("unusually_long_path")
    
    if anomalies:
        analytics_data["anomalies"] = anomalies
        analytics_data["requires_investigation"] = True

def generate_insights(analytics_data):
    """Generate actionable insights"""
    insights = []
    
    # Performance insights
    if analytics_data["performance_category"] == "slow":
        insights.append("Consider optimizing this endpoint for better performance")
    
    # Usage insights
    if analytics_data["category"] == "admin_operations":
        insights.append("Admin operation detected - ensure proper audit logging")
    
    # Security insights
    if analytics_data.get("anomalies"):
        insights.append("Anomalous behavior detected - review security logs")
    
    # Business insights
    if analytics_data["category"] == "order_management" and analytics_data["method"] == "POST":
        insights.append("New order created - update inventory and analytics")
    
    if insights:
        analytics_data["insights"] = insights
    
    # Generate recommendations
    recommendations = []
    
    if analytics_data["performance_score"] < 70:
        recommendations.append("Implement caching for this endpoint")
    
    if analytics_data.get("requires_investigation"):
        recommendations.append("Schedule detailed analysis of this request pattern")
    
    if recommendations:
        analytics_data["recommendations"] = recommendations

# Execute analytics processing
process_analytics()