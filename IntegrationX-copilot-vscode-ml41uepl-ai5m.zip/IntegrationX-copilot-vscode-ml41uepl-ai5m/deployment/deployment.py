#!/usr/bin/env python3
"""
Deck Deployment Module
Deploys Kong configurations using deck CLI with API-specific tags
"""

import os
import json
import subprocess
import logging
from pathlib import Path
from typing import Dict, Any, List

class DeckDeploymentManager:
    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.kong_admin_url = config.get('kong', {}).get('admin_api', 'http://localhost:8001')
        self.kong_admin_token = config.get('kong', {}).get('admin_token')
        
    def deploy_api_configuration(self, api_name: str, kong_config: Dict[str, Any], 
                                output_dir: Path) -> Dict[str, Any]:
        """Deploy Kong configuration for specific API using deck"""
        
        try:
            self.logger.info(f"Starting deck deployment for API: {api_name}")
            
            if not self._check_deck_installation():
                self.logger.warning("Deck CLI not found, skipping deployment")
                return {'status': 'SKIPPED', 'reason': 'Deck CLI not available'}
            
            deck_config = self._prepare_deck_config(api_name, kong_config)
            deck_file = self._create_deck_file(api_name, deck_config, output_dir)
            
            validation_result = self._validate_deck_config(deck_file)
            if not validation_result['valid']:
                raise RuntimeError(f"Deck validation failed: {validation_result['errors']}")
            
            deployment_result = self._deploy_with_deck(api_name, deck_file)
            verification_result = self._verify_deployment(api_name)
            
            return {
                'status': 'SUCCESS',
                'api_name': api_name,
                'deck_file': str(deck_file),
                'validation': validation_result,
                'deployment': deployment_result,
                'verification': verification_result
            }
            
        except Exception as e:
            self.logger.error(f"Deck deployment failed for API {api_name}: {e}")
            return {'status': 'FAILED', 'api_name': api_name, 'error': str(e)}
    
    def _check_deck_installation(self) -> bool:
        """Check if deck CLI is installed"""
        try:
            result = subprocess.run(['deck', 'version'], capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except:
            return False
    
    def _prepare_deck_config(self, api_name: str, kong_config: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare Kong configuration for deck deployment"""
        deck_config = kong_config.copy()
        for entity_type in ['services', 'routes', 'plugins', 'upstreams']:
            for entity in deck_config.get(entity_type, []):
                entity.setdefault('tags', [])
        
        return deck_config
    
    def _create_deck_file(self, api_name: str, deck_config: Dict[str, Any], output_dir: Path) -> Path:
        """Create deck configuration file"""
        deck_file = output_dir / f"deck-{api_name}.yml"

        # Create a clean version for deck by removing non-standard top-level keys
        clean_deck_config = deck_config.copy()
        clean_deck_config.pop('_info', None)
        clean_deck_config.pop('_comment', None)
        
        try:
            import yaml
            with open(deck_file, 'w') as f:
                yaml.dump(clean_deck_config, f, default_flow_style=False, indent=2)
        except ImportError:
            deck_file = output_dir / f"deck-{api_name}.json"
            with open(deck_file, 'w') as f:
                json.dump(clean_deck_config, f, indent=2)
        
        return deck_file
    
    def _validate_deck_config(self, deck_file: Path) -> Dict[str, Any]:
        """Validate deck configuration"""
        try:
            cmd = ['deck', 'file', 'validate', str(deck_file)]
            if self.kong_admin_url:
                cmd.extend(['--kong-addr', self.kong_admin_url])
            if self.kong_admin_token:
                cmd.extend(['--headers', f'Kong-Admin-Token:{self.kong_admin_token}'])

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            return {
                'valid': result.returncode == 0,
                'errors': result.stderr if result.returncode != 0 else None,
                'output': result.stdout
            }
        except Exception as e:
            return {'valid': False, 'errors': str(e)}
    
    def _deploy_with_deck(self, api_name: str, deck_file: Path) -> Dict[str, Any]:
        """Deploy configuration using deck sync"""
        try:
            migration_tag = f"migration-id-{api_name}"
            cmd = [
                'deck', 'gateway', 'sync',
                str(deck_file),
                '--select-tag', migration_tag,
                '--skip-consumers'
            ]

            if self.kong_admin_url:
                cmd.extend(['--kong-addr', self.kong_admin_url])
            if self.kong_admin_token:
                cmd.extend(['--headers', f'kong-admin-token:{self.kong_admin_token}'])
            
            self.logger.info(f"Executing deck command: {' '.join(cmd)}")
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            
            return {
                'success': result.returncode == 0,
                'error': result.stderr if result.returncode != 0 else None,
                'output': result.stdout
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _verify_deployment(self, api_name: str) -> Dict[str, Any]:
        """Verify deployment by checking deployed entities"""
        try:
            verification_results = {
                'services': {'count': 0, 'entities': []},
                'routes': {'count': 0, 'entities': []},
                'plugins': {'count': 0, 'entities': []}
            }
            
            return {'verified': True, 'results': verification_results}
        except Exception as e:
            return {'verified': False, 'error': str(e)}