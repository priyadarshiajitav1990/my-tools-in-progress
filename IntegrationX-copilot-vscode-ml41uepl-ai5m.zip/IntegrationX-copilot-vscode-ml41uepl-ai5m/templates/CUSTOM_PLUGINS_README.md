# Custom Plugin Templates for Kong Enterprise

This directory contains Jinja2 templates for all 24 custom plugins migrated from Apigee to Kong Enterprise.

## Template Usage

Each template follows the Kong plugin configuration format with Jinja2 templating for dynamic values:

```yaml
name: plugin-name
config:
  parameter: {{ config.parameter | default("default_value") }}
```

## Available Custom Plugin Templates

### 1. assertcondition.yml.j2
- **Purpose**: Condition assertion and validation
- **Key Config**: condition, message, continueOnError
- **Apigee Equivalent**: AssertCondition policy

### 2. attribute.yml.j2
- **Purpose**: Attribute management and variable setting
- **Key Config**: attributes array with name/value pairs
- **Apigee Equivalent**: Attribute policy

### 3. datacapture.yml.j2
- **Purpose**: Request/response data capture and logging
- **Key Config**: log_path, capture settings for headers/body
- **Apigee Equivalent**: DataCapture policy

### 4. extensioncallout.yml.j2
- **Purpose**: gRPC extension service callouts
- **Key Config**: grpc_server, configurations, flow_variables
- **Apigee Equivalent**: ExtensionCallout policy

### 5. flowcallout.yml.j2
- **Purpose**: Flow and shared flow execution
- **Key Config**: flow_name, shared_flow, async, variables
- **Apigee Equivalent**: FlowCallout policy

### 6. custom-graphql.yml.j2
- **Purpose**: GraphQL query processing and validation
- **Key Config**: schema_path, max_query_depth, introspection
- **Apigee Equivalent**: Custom GraphQL policy

### 7. invalidate-cache.yml.j2
- **Purpose**: Cache invalidation operations
- **Key Config**: cache_key, purge_method, scope
- **Apigee Equivalent**: InvalidateCache policy

### 8. java-callout.yml.j2
- **Purpose**: Java class execution and callouts
- **Key Config**: class_name, jar_resource, properties
- **Apigee Equivalent**: JavaCallout policy

### 9. javascript.yml.j2
- **Purpose**: JavaScript code execution
- **Key Config**: source, resource_url, timeout, variables
- **Apigee Equivalent**: JavaScript policy

### 10. jsontoxml.yml.j2
- **Purpose**: JSON to XML transformation
- **Key Config**: source, output_variable, root_element
- **Apigee Equivalent**: JSONToXML policy

### 11. keyvaluemapoperations.yml.j2
- **Purpose**: Key-value map operations (get/put/delete)
- **Key Config**: map_identifier, operations, scope
- **Apigee Equivalent**: KeyValueMapOperations policy

### 12. latencyanalysis.yml.j2
- **Purpose**: Request latency analysis and monitoring
- **Key Config**: threshold_ms, percentiles, window_size
- **Apigee Equivalent**: Custom latency analysis

### 13. luascriptexecuter.yml.j2
- **Purpose**: Lua script execution
- **Key Config**: script, resource_url, phase, variables
- **Apigee Equivalent**: Custom Lua execution

### 14. parsedialogflowrequest.yml.j2
- **Purpose**: Google Dialogflow request parsing
- **Key Config**: intent_variable, parameters_variable, language_code
- **Apigee Equivalent**: Custom Dialogflow integration

### 15. publishmessage.yml.j2
- **Purpose**: Message publishing to message brokers
- **Key Config**: topic, broker_url, message_format, async
- **Apigee Equivalent**: MessageLogging/PublishMessage policy

### 16. python.yml.j2
- **Purpose**: Python script execution
- **Key Config**: script, resource_url, timeout, variables
- **Apigee Equivalent**: Python policy

### 17. readpropertyset.yml.j2
- **Purpose**: Property set reading and variable assignment
- **Key Config**: property_set_name, properties, scope
- **Apigee Equivalent**: ReadPropertySet policy

### 18. resetquota.yml.j2
- **Purpose**: Quota reset operations
- **Key Config**: quota_name, identifier, reset_type
- **Apigee Equivalent**: ResetQuota policy

### 19. servicecallout.yml.j2
- **Purpose**: External service callouts
- **Key Config**: url, method, timeout, headers, response_variable
- **Apigee Equivalent**: ServiceCallout policy

### 20. setdialogflowresponse.yml.j2
- **Purpose**: Google Dialogflow response setting
- **Key Config**: fulfillment_text, intent_name, parameters
- **Apigee Equivalent**: Custom Dialogflow response

### 21. setintegrationrequest.yml.j2
- **Purpose**: Integration request configuration
- **Key Config**: integration_name, request_variable, headers
- **Apigee Equivalent**: Custom integration setup

### 22. setoauthv2info.yml.j2
- **Purpose**: OAuth v2 information setting
- **Key Config**: access_token_variable, client_id_variable, scope_variable
- **Apigee Equivalent**: SetOAuthV2Info policy

### 23. soapvalidation.yml.j2
- **Purpose**: SOAP message validation
- **Key Config**: wsdl_url, schema_validation, soap_version
- **Apigee Equivalent**: SOAPMessageValidation policy

### 24. xsltransform.yml.j2
- **Purpose**: XSLT transformation
- **Key Config**: xsl_source, source, output_variable, parameters
- **Apigee Equivalent**: XSLTransform policy

## Template Variables

All templates support the following common patterns:

- `{{ config.parameter | default("default_value") }}` - Parameter with default
- `{% for item in config.array %}` - Array iteration
- `{{ config.nested.parameter }}` - Nested configuration
- Comments with `#` for documentation

## Usage Example

```yaml
# Using the assertcondition template
name: assertcondition
config:
  condition: "request.verb = 'GET'"
  message: "Only GET requests allowed"
  continueOnError: false
  enabled: true
```

## Integration with Kong

These templates are designed to work with:
- Kong Enterprise v3.13.0.0+
- Kong Admin API
- Kong Deck (decK) for declarative configuration
- Kong Manager UI

All templates follow Kong's plugin configuration schema and can be used directly in Kong's declarative configuration files.