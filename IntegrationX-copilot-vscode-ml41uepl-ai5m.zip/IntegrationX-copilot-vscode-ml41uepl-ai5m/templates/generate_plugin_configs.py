#!/usr/bin/env python3
"""
Kong Custom Plugin Template Generator
Generates Kong plugin configurations from Jinja2 templates
"""

import os
import json
from jinja2 import Environment, FileSystemLoader

class KongPluginTemplateGenerator:
    def __init__(self, templates_dir="templates"):
        self.templates_dir = templates_dir
        self.env = Environment(loader=FileSystemLoader(templates_dir))
        
    def list_custom_plugins(self):
        """List all available custom plugin templates"""
        plugins = []
        for file in os.listdir(self.templates_dir):
            if file.endswith('.yml.j2') and not file.startswith('_'):
                plugin_name = file.replace('.yml.j2', '')
                plugins.append(plugin_name)
        return sorted(plugins)
    
    def generate_plugin_config(self, plugin_name, config_data=None):
        """Generate plugin configuration from template"""
        template_file = f"{plugin_name}.yml.j2"
        
        if not os.path.exists(os.path.join(self.templates_dir, template_file)):
            raise ValueError(f"Template not found: {template_file}")
        
        template = self.env.get_template(template_file)
        
        # Default empty config if none provided
        if config_data is None:
            config_data = {"config": {}}
        
        return template.render(**config_data)
    
    def generate_all_plugins(self, output_dir="generated_configs"):
        """Generate default configurations for all custom plugins"""
        os.makedirs(output_dir, exist_ok=True)
        
        plugins = self.list_custom_plugins()
        generated = []
        
        for plugin in plugins:
            try:
                config = self.generate_plugin_config(plugin)
                output_file = os.path.join(output_dir, f"{plugin}.yml")
                
                with open(output_file, 'w') as f:
                    f.write(config)
                
                generated.append(plugin)
                print(f"✓ Generated: {plugin}.yml")
                
            except Exception as e:
                print(f"✗ Failed to generate {plugin}: {e}")
        
        return generated
    
    def generate_service_config(self, service_name, plugins_config):
        """Generate complete service configuration with plugins"""
        service_config = {
            "services": [{
                "name": service_name,
                "url": "http://backend-service",
                "plugins": []
            }]
        }
        
        for plugin_name, plugin_config in plugins_config.items():
            config = self.generate_plugin_config(plugin_name, {"config": plugin_config})
            # Parse YAML and convert to dict for JSON output
            import yaml
            plugin_dict = yaml.safe_load(config)
            service_config["services"][0]["plugins"].append(plugin_dict)
        
        return json.dumps(service_config, indent=2)

def main():
    generator = KongPluginTemplateGenerator()
    
    print("Kong Custom Plugin Template Generator")
    print("=" * 40)
    
    # List available plugins
    plugins = generator.list_custom_plugins()
    print(f"Available custom plugins: {len(plugins)}")
    for plugin in plugins:
        print(f"  - {plugin}")
    
    print("\nGenerating default configurations...")
    generated = generator.generate_all_plugins()
    
    print(f"\n✅ Successfully generated {len(generated)} plugin configurations")
    print("📁 Output directory: generated_configs/")
    
    # Example: Generate specific plugin with custom config
    print("\nExample: Generating assertcondition with custom config...")
    custom_config = {
        "config": {
            "condition": "request.method == 'POST'",
            "message": "Only POST requests allowed",
            "continueOnError": False
        }
    }
    
    result = generator.generate_plugin_config("assertcondition", custom_config)
    print("Generated configuration:")
    print(result)

if __name__ == "__main__":
    main()