#!/usr/bin/env python3
"""
Simple Kong Custom Plugin Template Generator
Generates basic Kong plugin configurations from templates
"""

import os
import re

class SimpleTemplateGenerator:
    def __init__(self, templates_dir="templates"):
        self.templates_dir = templates_dir
        
    def list_custom_plugins(self):
        """List all available custom plugin templates"""
        plugins = []
        for file in os.listdir(self.templates_dir):
            if file.endswith('.yml.j2') and not file.startswith('_'):
                plugin_name = file.replace('.yml.j2', '')
                plugins.append(plugin_name)
        return sorted(plugins)
    
    def generate_basic_config(self, plugin_name):
        """Generate basic plugin configuration by removing Jinja2 syntax"""
        template_file = os.path.join(self.templates_dir, f"{plugin_name}.yml.j2")
        
        if not os.path.exists(template_file):
            return f"# Template not found: {plugin_name}.yml.j2"
        
        with open(template_file, 'r') as f:
            content = f.read()
        
        # Remove Jinja2 syntax and use defaults
        # Replace {{ config.param | default("value") }} with value
        content = re.sub(r'\{\{\s*config\.[\w.]+\s*\|\s*default\(([^)]+)\)\s*\}\}', r'\1', content)
        
        # Replace {{ config.param | default(value) }} with value (no quotes)
        content = re.sub(r'\{\{\s*config\.[\w.]+\s*\|\s*default\(([^)]+)\)\s*\}\}', r'\1', content)
        
        # Replace simple {{ config.param }} with placeholder
        content = re.sub(r'\{\{\s*config\.[\w.]+\s*\}\}', '"CONFIGURE_ME"', content)
        
        # Remove Jinja2 loops and conditions (comment them out)
        content = re.sub(r'(\s*#\s*\{%.*?%\})', r'\1', content)
        
        return content
    
    def generate_all_basic_configs(self, output_dir="generated_configs"):
        """Generate basic configurations for all custom plugins"""
        os.makedirs(output_dir, exist_ok=True)
        
        plugins = self.list_custom_plugins()
        generated = []
        
        for plugin in plugins:
            try:
                config = self.generate_basic_config(plugin)
                output_file = os.path.join(output_dir, f"{plugin}.yml")
                
                with open(output_file, 'w') as f:
                    f.write(config)
                
                generated.append(plugin)
                print(f"✓ Generated: {plugin}.yml")
                
            except Exception as e:
                print(f"✗ Failed to generate {plugin}: {e}")
        
        return generated

def main():
    generator = SimpleTemplateGenerator()
    
    print("Kong Custom Plugin Template Generator (Simple)")
    print("=" * 45)
    
    # List available plugins
    plugins = generator.list_custom_plugins()
    print(f"Available custom plugins: {len(plugins)}")
    for plugin in plugins:
        print(f"  - {plugin}")
    
    print("\nGenerating basic configurations...")
    generated = generator.generate_all_basic_configs()
    
    print(f"\n✅ Successfully generated {len(generated)} plugin configurations")
    print("📁 Output directory: generated_configs/")
    
    # Show example
    if generated:
        example_plugin = generated[0]
        print(f"\nExample configuration for {example_plugin}:")
        print("-" * 40)
        with open(f"generated_configs/{example_plugin}.yml", 'r') as f:
            print(f.read()[:300] + "...")

if __name__ == "__main__":
    main()