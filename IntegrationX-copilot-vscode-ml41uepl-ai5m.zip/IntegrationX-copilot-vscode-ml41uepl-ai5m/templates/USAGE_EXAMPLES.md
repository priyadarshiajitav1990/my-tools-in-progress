# Kong Custom Plugin Templates - Usage Examples

## Template Structure
Each template follows this pattern:
```yaml
name: plugin-name
config:
  parameter: {{ config.parameter | default("default_value") }}
  # Comments explaining Apigee equivalent
```

## Example 1: AssertCondition Plugin
```yaml
# File: assertcondition-example.yml
name: assertcondition
config:
  condition: "request.method == 'GET'"
  message: "Only GET requests allowed"
  continueOnError: false
  enabled: true
```

## Example 2: ServiceCallout Plugin
```yaml
# File: servicecallout-example.yml
name: servicecallout
config:
  enabled: true
  url: "https://api.backend.com/validate"
  method: "POST"
  timeout: 5000
  async: false
  headers:
    - name: "Content-Type"
      value: "application/json"
    - name: "Authorization"
      value: "Bearer {oauth.access_token}"
  response_variable: "validation_response"
```

## Example 3: Complete Service Configuration
```yaml
# File: complete-service-example.yml
services:
- name: "my-api-service"
  url: "http://backend.example.com"
  routes:
  - name: "api-route"
    paths: ["/api/v1"]
  plugins:
  - name: assertcondition
    config:
      condition: "request.header.api-key != null"
      message: "API key required"
      enabled: true
  - name: servicecallout
    config:
      url: "https://auth.example.com/validate"
      method: "POST"
      timeout: 3000
      response_variable: "auth_response"
  - name: datacapture
    config:
      log_path: "/var/log/kong/api-requests.log"
      enabled: true
```

## Kong Admin API Usage
```bash
# Create service
curl -X POST http://localhost:8001/services \
  -d "name=my-service" \
  -d "url=http://backend.com"

# Add assertcondition plugin
curl -X POST http://localhost:8001/services/my-service/plugins \
  -d "name=assertcondition" \
  -d "config.condition=request.method == 'GET'" \
  -d "config.message=Only GET allowed" \
  -d "config.enabled=true"

# Add servicecallout plugin
curl -X POST http://localhost:8001/services/my-service/plugins \
  -d "name=servicecallout" \
  -d "config.url=https://api.backend.com/validate" \
  -d "config.method=POST" \
  -d "config.timeout=5000"
```

## Kong Deck (decK) Usage
```bash
# Generate Kong configuration from templates
deck file render --state kong.yml --output rendered-config.yml

# Sync to Kong
deck sync --state rendered-config.yml
```

## Template Variables Reference

### Common Variables
- `{{ config.enabled | default(true) }}` - Enable/disable plugin
- `{{ config.timeout | default(5000) }}` - Timeout in milliseconds
- `{{ config.async | default(false) }}` - Async execution

### Array Variables
```yaml
# headers:
# {% for header in config.headers %}
# - name: {{ header.name }}
#   value: {{ header.value }}
# {% endfor %}
```

### Conditional Variables
```yaml
# anonymous: {{ config.anonymous | default("null") }}
# run_on_preflight: {{ config.run_on_preflight | default(true) }}
```

## Integration Patterns

### 1. API Gateway Pattern
```yaml
plugins:
- name: assertcondition  # Validate request
- name: servicecallout   # External validation
- name: datacapture      # Log request/response
```

### 2. Transformation Pattern
```yaml
plugins:
- name: jsontoxml        # Transform JSON to XML
- name: xsltransform     # Apply XSLT transformation
- name: servicecallout   # Send to SOAP service
```

### 3. Security Pattern
```yaml
plugins:
- name: assertcondition  # Validate security headers
- name: setoauthv2info   # Set OAuth info
- name: datacapture      # Security audit logging
```

## Best Practices

1. **Always set enabled: true** for active plugins
2. **Use meaningful variable names** in templates
3. **Include timeout values** for external calls
4. **Add error handling** with continueOnError flags
5. **Document Apigee mappings** in comments
6. **Test configurations** in development first
7. **Use Kong's validation** before deployment

## Troubleshooting

### Common Issues
1. **Template syntax errors** - Check Jinja2 syntax
2. **Missing default values** - Always provide defaults
3. **Kong validation failures** - Verify schema compatibility
4. **Plugin conflicts** - Check plugin execution order

### Validation Commands
```bash
# Validate Kong configuration
kong config -c /etc/kong/kong.conf

# Check plugin status
curl http://localhost:8001/plugins/enabled

# Test plugin configuration
curl -X POST http://localhost:8001/config \
  -d @your-config.yml
```