local typedefs = require "kong.db.schema.typedefs"

return {
  name = "attribute",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 1000 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { attributes = {
            type = "array",
            elements = {
              type = "record",
              fields = {
                { name = { type = "string", required = true, description = "Apigee attribute name" } },
                { value = { type = "string", required = true, description = "Attribute value" } },
              },
            },
            required = true,
            description = "List of attributes to set"
        } },
        { enabled = { type = "boolean", required = false, default = true, description = "Enable or disable this attribute plugin" } },
      },
    } },
  },
}
