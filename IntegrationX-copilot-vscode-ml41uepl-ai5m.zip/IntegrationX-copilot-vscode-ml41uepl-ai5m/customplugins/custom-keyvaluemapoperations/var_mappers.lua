local M = {}

-- Apigee to Kong variable mapping for KeyValueMapOperations
-- Extend this as needed for your environment
return {
  apigee_to_kong = {
    -- Example: ["apigee.variable"] = "kong.variable",
    ["request.header."] = "kong.request.get_header",
    ["request.queryparam."] = "kong.request.get_query_arg",
    ["request.formparam."] = "kong.request.get_form_arg",
    ["response.header."] = "kong.response.get_header",
    ["response.status"] = "kong.response.get_status",
    ["environment[variable]"] = "kong.ctx.shared",
    -- Add more mappings as needed
  },
  -- Add operator and pattern mappings if needed
}


return M