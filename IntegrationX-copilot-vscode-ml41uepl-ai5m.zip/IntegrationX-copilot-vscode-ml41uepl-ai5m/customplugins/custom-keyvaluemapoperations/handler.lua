-- In-memory store for KVMs.
-- WARNING: This is not a persistent store. The data will be lost when Kong is reloaded.
-- For a persistent implementation, you would need to use a database
-- or an external key-value store.

local vault = require("resty.vault.client") -- Placeholder: use a real Vault client or API
local var_mappers = require("kong.plugins.keyvaluemapoperations.var_mappers")

local CustomKeyValueMapOperations = {
  PRIORITY = 830,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Helper: Vault interaction (HashiCorp or other)
local function vault_get(map_identifier, key, config)
  -- Placeholder: Implement real Vault API call here
  -- Example: return vault.read(map_identifier .. "/" .. key)
  kong.log.notice("[Vault] GET " .. map_identifier .. ":" .. key)
  return nil
end

local function vault_put(map_identifier, key, value, config)
  -- Placeholder: Implement real Vault API call here
  kong.log.notice("[Vault] PUT " .. map_identifier .. ":" .. key .. " = " .. tostring(value))
  return true
end

local function vault_delete(map_identifier, key, config)
  -- Placeholder: Implement real Vault API call here
  kong.log.notice("[Vault] DELETE " .. map_identifier .. ":" .. key)
  return true
end

local function do_operation(config, phase)
  local map_identifier = config.map_identifier
  local operation = config.operation
  local key = config.key.parameter
  local use_vault = config.use_vault or false
  local value = config.value

  -- Variable mapping (Apigee to Kong)
  local kong_func, mapped_key = map_variable(key)
  if kong_func and mapped_key then
    if kong_func == "kong.request.get_header" then
      key = kong.request.get_header(mapped_key)
    elseif kong_func == "kong.request.get_query_arg" then
      key = kong.request.get_query_arg(mapped_key)
    elseif kong_func == "kong.request.get_form_arg" then
      key = kong.request.get_form_arg(mapped_key)
    elseif kong_func == "kong.response.get_header" then
      key = kong.response.get_header(mapped_key)
    elseif kong_func == "kong.response.get_status" then
      key = kong.response.get_status()
    elseif kong_func == "kong.ctx.shared" then
      key = kong.ctx.shared[mapped_key]
    end
  end

  if use_vault then
    if operation == "put" then
      if not value then value = kong.ctx.shared[key] end
      if value then
        vault_put(map_identifier, key, value, config)
      else
        kong.log.warn("[Vault] PUT operation for key '\\"(.*)\\"' has no value.")
      end
    elseif operation == "get" then
      local v = vault_get(map_identifier, key, config)
      if v then kong.ctx.shared[key] = v end
    elseif operation == "delete" then
      vault_delete(map_identifier, key, config)
    end
    return
  end

  -- Fallback: In-memory (for local/dev only)
  kong.ctx.shared._kvm = kong.ctx.shared._kvm or {}
  local kvm = kong.ctx.shared._kvm
  kvm[map_identifier] = kvm[map_identifier] or {}
  local map = kvm[map_identifier]

  if operation == "put" then
    if not value then value = kong.ctx.shared[key] end
    if value then
      map[key] = value
      kong.log.notice("KVM '\\"(.*)\\"'")
    else
      kong.log.warn("KVM '\\"(.*)\\"' has no value.")
    end
  elseif operation == "get" then
    local v = map[key]
    if v then
      kong.ctx.shared[key] = v
      kong.log.notice("KVM '\\"(.*)\\"'")
    else
      kong.log.notice("KVM '\\"(.*)\\"' not found.")
    end
  elseif operation == "delete" then
    map[key] = nil
    kong.log.notice("KVM '\\"(.*)\\"'")
  end
end

function CustomKeyValueMapOperations:access(conf)
  if conf.run_on == "access" then
    do_operation(conf.config, "access")
  end
end

function CustomKeyValueMapOperations:response(conf)
  if conf.run_on == "response" then
    do_operation(conf.config, "response")
  end
end

return CustomKeyValueMapOperations




