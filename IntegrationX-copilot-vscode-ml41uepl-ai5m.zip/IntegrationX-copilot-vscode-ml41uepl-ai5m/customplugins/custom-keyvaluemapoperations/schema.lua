local typedefs = require "kong.db.schema.typedefs"

return {
  name = "keyvaluemapoperations",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 830 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { map_identifier = { type = "string", required = true } },
        { operation = { type = "string", one_of = { "get", "put", "delete" }, required = true } },
        { key = {
          type = "record",
          fields = {
            { parameter = { type = "string", required = true } }
          },
          required = true
        } },
        { value = { type = "string" } }, -- Required for put operation
        { use_vault = { type = "boolean", default = false } },
        { vault_config = {
            type = "record",
            fields = {
              { vault_type = { type = "string", one_of = { "hashicorp", "other" }, default = "hashicorp" } },
              { api_url = { type = "string" } },
              { token = { type = "string" } },
              { mount = { type = "string" } },
              { extra = { type = "map", keys = { type = "string" }, values = { type = "string" } } },
            },
            required = false
        } },
      }
    } }
  }
}

