
local cjson = require "cjson"

-- Load Apigee to Kong variable mappings
local function load_var_mappings()
  local ok, mappings = pcall(require, "kong.plugins.custom-datacapture.var_mappers")
  if ok and mappings then
    return mappings.variable_map or {}, mappings.operator_map or {}, mappings.pattern_map or {}
  end
  return {}, {}, {}
end

local variable_map, operator_map, pattern_map = load_var_mappings()

-- Map Apigee variable names to Kong equivalents
local function map_apigee_var(var)
  if variable_map[var] then
    return variable_map[var]
  end
  -- Try pattern_map
  for _, pat in ipairs(pattern_map) do
    local pattern = pat.pattern
    local repl = pat.replacement
    local mapped = var:gsub(pattern, repl)
    if mapped ~= var then return mapped end
  end
  return var
end

local CustomDataCapture = {
  PRIORITY = 10,
  VERSION = "0.1.0",
}

local function capture_data(self, config, phase)
  local log_data = {
    request = {},
    response = {},
  }

  -- Capture request data
  if config.capture and config.capture.request then
    local req_capture = config.capture.request
    if req_capture.headers then
      log_data.request.headers = {}
      for _, header in ipairs(req_capture.headers) do
        local kong_header = map_apigee_var(header)
        log_data.request.headers[kong_header] = kong.request.get_header(header)
      end
    end
    if req_capture.query_params then
      log_data.request.query_params = {}
      local query_args = kong.request.get_query()
      for _, param in ipairs(req_capture.query_params) do
        local kong_param = map_apigee_var(param)
        log_data.request.query_params[kong_param] = query_args[param]
      end
    end
    if req_capture.body then
      log_data.request.body = kong.request.get_raw_body()
    end
  end

  -- Capture response data
  if config.capture and config.capture.response then
    local res_capture = config.capture.response
    if res_capture.headers then
      log_data.response.headers = {}
      local res_headers = kong.response.get_headers()
      for _, header in ipairs(res_capture.headers) do
        local kong_header = map_apigee_var(header)
        log_data.response.headers[kong_header] = res_headers[header]
      end
    end
    if res_capture.body then
      log_data.response.body = kong.response.get_raw_body()
    end
  end

  -- Log to file (blocking, for demo only)
  local file, err = io.open(config.log_path, "a")
  if err then
    kong.log.err("Failed to open log file: " .. config.log_path .. ", error: " .. err)
    return
  end

  local log_line = cjson.encode(log_data)
  file:write(log_line .. "\n")
  file:close()
end
function CustomDataCapture:access(config)
  capture_data(self, config, "access")
end

function CustomDataCapture:response(config)
  capture_data(self, config, "response")
end

return CustomDataCapture




