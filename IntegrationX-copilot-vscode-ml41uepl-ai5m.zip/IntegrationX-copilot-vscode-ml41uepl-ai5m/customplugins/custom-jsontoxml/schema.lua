local typedefs = require "kong.db.schema.typedefs"

return {
  name = "jsontoxml",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 840 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { options = {
          type = "record",
          fields = {
            { null_value = { type = "string", default = "NULL" } },
            { namespace_block_name = { type = "string", default = "#namespaces" } },
            { default_namespace_node_name = { type = "string", default = "$default" } },
            { namespace_separator = { type = "string", default = ":" } },
            { text_node_name = { type = "string", default = "#text" } },
            { attribute_block_name = { type = "string", default = "#attrs" } },
            { attribute_prefix = { type = "string", default = "@" } },
            { invalid_chars_replacement = { type = "string", default = "_" } },
            { object_root_element_name = { type = "string", default = "Root" } },
            { array_root_element_name = { type = "string", default = "Array" } },
            { array_item_element_name = { type = "string", default = "Item" } },
          }
        } },
        { output_variable = { type = "string" } },
        { source = { type = "string" } },
      }
    } }
  },
}

