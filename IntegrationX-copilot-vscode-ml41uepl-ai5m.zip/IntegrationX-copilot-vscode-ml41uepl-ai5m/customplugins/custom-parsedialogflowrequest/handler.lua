
local cjson = require "cjson"
local var_mappers = require("kong.plugins.parsedialogflowrequest.var_mappers")

local CustomParseDialogflowRequest = {
  PRIORITY = 810,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function parse_dialogflow_request(conf, phase)
  local raw_body = kong.request.get_raw_body()
  if not raw_body or raw_body == "" then
    kong.log.warn("Request body is empty, cannot parse Dialogflow request.")
    return
  end
  local ok, body = pcall(cjson.decode, raw_body)
  if not ok then
    kong.log.err("Failed to decode JSON body: " .. tostring(body))
    return
  end
  local ctx = kong.ctx.shared
  -- Extract relevant fields from the Dialogflow request and store them in the context
  if body.responseId then ctx["dialogflow.responseId"] = body.responseId end
  if body.session then ctx["dialogflow.session"] = body.session end
  if body.queryResult then
    local qr = body.queryResult
    if qr.queryText then ctx["dialogflow.queryText"] = qr.queryText end
    if qr.action then ctx["dialogflow.action"] = qr.action end
    if qr.parameters then
      for k, v in pairs(qr.parameters) do ctx["dialogflow.parameters." .. k] = v end
    end
    if qr.allRequiredParamsPresent then ctx["dialogflow.allRequiredParamsPresent"] = qr.allRequiredParamsPresent end
    if qr.fulfillmentText then ctx["dialogflow.fulfillmentText"] = qr.fulfillmentText end
    if qr.fulfillmentMessages then ctx["dialogflow.fulfillmentMessages"] = qr.fulfillmentMessages end
    if qr.intent then
      local intent = qr.intent
      if intent.name then ctx["dialogflow.intent.name"] = intent.name end
      if intent.displayName then ctx["dialogflow.intent.displayName"] = intent.displayName end
    end
    if qr.intentDetectionConfidence then ctx["dialogflow.intentDetectionConfidence"] = qr.intentDetectionConfidence end
    if qr.diagnosticInfo then ctx["dialogflow.diagnosticInfo"] = qr.diagnosticInfo end
    if qr.languageCode then ctx["dialogflow.languageCode"] = qr.languageCode end
  end
  if body.originalDetectIntentRequest and body.originalDetectIntentRequest.payload then
    ctx["dialogflow.originalDetectIntentRequest.payload"] = body.originalDetectIntentRequest.payload
  end
  kong.log.debug("[ParseDialogflowRequest] Parsed Dialogflow request and stored fields in context.")
end

function CustomParseDialogflowRequest:access(conf)
  if conf.run_on == "access" then
    parse_dialogflow_request(conf, "access")
  end
end

function CustomParseDialogflowRequest:response(conf)
  if conf.run_on == "response" then
    parse_dialogflow_request(conf, "response")
  end
end

return CustomParseDialogflowRequest

end

return ApigeeParseDialogflowRequest




