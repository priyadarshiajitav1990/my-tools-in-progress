local M = {}

M.variable_map = {
    ["request.verb"] = "kong.request.get_method()",
    ["request.uri"] = "kong.request.get_path()",
    ["request.header.host"] = "kong.request.get_header('host')",
}

M.operator_map = {
    ["="] = "==",
    ["!="] = "~=",
}

M.pattern_map = {}

return M
