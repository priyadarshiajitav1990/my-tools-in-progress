-- custom-plugins/LuaScriptExecuter/spec/LuaScriptExecuter_spec.lua

local LuaScriptExecuterHandler = require "custom-plugins.LuaScriptExecuter.handler"
local helpers = require "spec.helpers"

describe("LuaScriptExecuter plugin", function()
  local client

  -- Setup Kong for testing. This typically involves starting a Kong instance
  -- with the plugin enabled.
  setup(function()
    -- This helper function starts a Kong instance with a minimal configuration
    -- and ensures the plugin is loaded.
    -- For a real setup, you might need to configure a service and route.
    assert(helpers.start_kong({
      plugins = {
        "lua-script-executer",
      },
    }))
    client = helpers.get_kong_admin_client()
  end)

  -- Teardown Kong after tests are complete.
  teardown(function()
    if client then
      client:close()
    end
    helpers.stop_kong()
  end)

  describe("handler:access()", function()
    it("should execute inline lua code successfully", function()
      local conf = {
        scripts = {
          { lua_code = "kong.ctx.shared.test_var = 'hello from lua';" }
        }
      }
      local handler = LuaScriptExecuterHandler:new()
      local ok, err = pcall(handler.access, handler, conf)
      assert.is_true(ok)
      assert.is_nil(err)
      assert.equal("hello from lua", kong.ctx.shared.test_var)
    end)

    it("should handle errors in inline lua code", function()
      local conf = {
        scripts = {
          { lua_code = "error('intentional error');" }
        }
      }
      local handler = LuaScriptExecuterHandler:new()
      local ok, err = pcall(handler.access, handler, conf)
      assert.is_false(ok)
      assert.equal("Internal Server Error", err)
    end)

    it("should prevent access to restricted globals like os.execute", function()
      local conf = {
        scripts = {
          { lua_code = "os.execute('echo pwned');" }
        }
      }
      local handler = LuaScriptExecuterHandler:new()
      local ok, err = pcall(handler.access, handler, conf)
      assert.is_false(ok)
      assert.equal("Internal Server Error", err)
    end)

    it("should prevent modification of globals like _G", function()
      local conf = {
        scripts = {
          { lua_code = "_G.some_var = 'attack';" }
        }
      }
      local handler = LuaScriptExecuterHandler:new()
      local ok, err = pcall(handler.access, handler, conf)
      assert.is_false(ok)
      assert.equal("Internal Server Error", err)
    end)

    it("should prevent directory traversal in lua_file_path", function()
      local conf = {
        scripts = {
          { lua_file_path = "../../../etc/passwd" }
        }
      }
      local handler = LuaScriptExecuterHandler:new()
      local ok, err = pcall(handler.access, handler, conf)
      assert.is_false(ok)
      assert.equal("Bad Request: Invalid file path", err)
    end)

    -- Note: Testing `lua_file_path` with actual file creation/reading
    -- would typically be an integration test, requiring a temporary file
    -- system setup. For unit tests, `io.open` could be mocked.
  end)
end)