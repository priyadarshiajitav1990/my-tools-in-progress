local typedefs = require "kong.db.schema.typedefs"

return {
  name = "resetquota",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 780 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { quota = {
            type = "record",
            fields = {
              { name = { type = "string", required = true } },
              { identifier = {
                  type = "record",
                  fields = {
                    { name = { type = "string", required = true } },
                    { ref = { type = "string" } },
                  },
                  required = true
              } },
            },
            required = true
        } },
      }
    } }
  }
}

