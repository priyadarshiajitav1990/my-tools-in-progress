local typedefs = require "kong.db.schema.typedefs"

return {
  name = "assertcondition",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 1000 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { condition = { type = "string", required = true, description = "Apigee-style condition to assert" } },
        { message = { type = "string", required = false, default = "Condition failed", description = "Message to return if assertion fails" } },
        { continueOnError = { type = "boolean", required = false, default = false, description = "If true, do not terminate request on failure" } },
        { enabled = { type = "boolean", required = false, default = true, description = "Enable or disable this assertion" } },
      },
    } },
  },
}

