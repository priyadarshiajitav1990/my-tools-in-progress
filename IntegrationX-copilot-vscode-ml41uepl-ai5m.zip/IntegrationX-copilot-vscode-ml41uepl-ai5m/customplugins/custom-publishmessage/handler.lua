local var_mappers = require("kong.plugins.publishmessage.var_mappers")

local CustomPublishMessage = {
  PRIORITY = 800,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Placeholder for message publishing logic
local function publish_message(conf, phase)
  local config = conf.config or conf
  local topic = config.cloud_pub_sub and config.cloud_pub_sub.topic or ""
  local source = config.source or ""
  -- Here, you would implement the logic to publish a message to Pub/Sub or another system
  -- For now, just log the intent
  kong.log.warn("[custom-publishmessage] This is a placeholder. No message is actually published.")
  kong.log.warn("Topic: " .. tostring(topic))
  kong.log.warn("Source: " .. tostring(source))
end

function CustomPublishMessage:access(conf)
  if conf.run_on == "access" then
    publish_message(conf, "access")
  end
end

function CustomPublishMessage:response(conf)
  if conf.run_on == "response" then
    publish_message(conf, "response")
  end
end

return CustomPublishMessage




