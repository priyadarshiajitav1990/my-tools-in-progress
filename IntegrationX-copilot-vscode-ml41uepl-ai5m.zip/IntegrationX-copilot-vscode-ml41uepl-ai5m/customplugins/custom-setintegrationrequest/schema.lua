local typedefs = require "kong.db.schema.typedefs"

return {
  name = "setintegrationrequest",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 750 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { integration_name = { type = "string", required = true } },
        { project_id = { type = "string", required = true } },
      }
    } }
  }
}

