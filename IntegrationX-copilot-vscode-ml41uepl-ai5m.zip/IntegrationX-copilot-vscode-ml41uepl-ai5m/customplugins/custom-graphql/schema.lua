local typedefs = require "kong.db.schema.typedefs"

return {
  name = "graphql",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 880 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { schema = { type = "string", required = true } },
        { apigee_vars = { type = "array", elements = { type = "string" }, required = false, description = "List of Apigee variables to map" } },
        -- Add other GraphQL policy configurations here as needed
      }
    } }
  },
}

