local var_mappers = require("kong.plugins.python.var_mappers")

local CustomPython = {
  PRIORITY = 710,
  VERSION = "0.1.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Execute injected Lua code (converted from Python)
local function execute_lua_code(lua_code, ctx)
  local func, err = load(lua_code, "custom-python-lua", "t", ctx)
  if not func then
    kong.log.err("Failed to load injected Lua code: " .. tostring(err))
    return nil, err
  end
  local ok, result = pcall(func)
  if not ok then
    kong.log.err("Error running injected Lua code: " .. tostring(result))
    return nil, result
  end
  return result
end

local function run_custom_python(conf, phase)
  local config = conf.config or conf
  local lua_code = config.lua_code or ""
  if not lua_code or lua_code == "" then
    kong.log.warn("No Lua code injected for custom-python plugin.")
    return
  end
  local ctx = setmetatable({ kong = kong, phase = phase, config = config }, { __index = _G })
  local result, err = execute_lua_code(lua_code, ctx)
  if err then
    kong.log.err("custom-python plugin execution failed: " .. tostring(err))
  end
end

function CustomPython:access(conf)
  if conf.run_on == "access" then
    run_custom_python(conf, "access")
  end
end

function CustomPython:response(conf)
  if conf.run_on == "response" then
    run_custom_python(conf, "response")
  end
end

return CustomPython




