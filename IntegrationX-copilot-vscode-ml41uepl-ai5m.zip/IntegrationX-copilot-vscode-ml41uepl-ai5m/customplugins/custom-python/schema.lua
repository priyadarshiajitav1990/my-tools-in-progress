local typedefs = require "kong.db.schema.typedefs"

return {
  name = "python",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 710 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { lua_code = { type = "string", required = true, description = "Lua code converted from Python, injected dynamically" } },
      }
    } }
  }
}

