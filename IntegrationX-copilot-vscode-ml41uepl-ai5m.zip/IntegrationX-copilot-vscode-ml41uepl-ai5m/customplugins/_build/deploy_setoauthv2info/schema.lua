local typedefs = require "kong.db.schema.typedefs"

return {
  name = "setoauthv2info",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 740 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { attributes = {
            type = "map",
            keys = { type = "string" },
            values = { type = "string" },
            required = true
        } },
      }
    } }
  }
}
