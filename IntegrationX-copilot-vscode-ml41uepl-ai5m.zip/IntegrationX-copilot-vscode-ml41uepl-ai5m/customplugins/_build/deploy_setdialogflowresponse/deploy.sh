#!/bin/bash
# Deployment script for setdialogflowresponse

PLUGIN_NAME="setdialogflowresponse"
KONG_PLUGIN_DIR="/usr/local/share/lua/5.1/kong/plugins"

echo "Deploying plugin: $PLUGIN_NAME"

# Create plugin directory
sudo mkdir -p $KONG_PLUGIN_DIR/$PLUGIN_NAME

# Copy plugin files
sudo cp *.lua $KONG_PLUGIN_DIR/$PLUGIN_NAME/

# Set permissions
sudo chmod -R 644 $KONG_PLUGIN_DIR/$PLUGIN_NAME/*.lua

# Update Kong configuration
CURRENT_PLUGINS=$(grep '^plugins = ' /etc/kong/kong.conf || echo 'plugins = bundled')
if [[ "$CURRENT_PLUGINS" != *"$PLUGIN_NAME"* ]]; then
    NEW_PLUGINS="${CURRENT_PLUGINS},$PLUGIN_NAME"
    sudo sed -i "/^plugins = /c\$NEW_PLUGINS" /etc/kong/kong.conf
fi

# Reload Kong
sudo systemctl reload kong

echo "Plugin $PLUGIN_NAME deployed successfully!"
