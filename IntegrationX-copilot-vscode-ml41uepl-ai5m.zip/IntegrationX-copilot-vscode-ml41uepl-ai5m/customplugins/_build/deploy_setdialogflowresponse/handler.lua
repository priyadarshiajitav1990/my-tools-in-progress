local cjson = require "cjson"
local var_mappers = require("kong.plugins.custom-setdialogflowresponse.var_mappers")

local CustomSetDialogflowResponse = {
  PRIORITY = 760,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function set_dialogflow_response(conf, phase)
  local ctx = kong.ctx.shared
  local config = conf.config or {}
  local response = {
    fulfillmentMessages = {},
  }
  local fulfillment_text = ctx["dialogflow.fulfillmentText"]
  if fulfillment_text then response.fulfillmentText = fulfillment_text end
  local fulfillment_messages = ctx["dialogflow.fulfillmentMessages"]
  if fulfillment_messages then response.fulfillmentMessages = fulfillment_messages end
  local payload = ctx["dialogflow.payload"]
  if payload then response.payload = payload end
  local output_contexts = ctx["dialogflow.outputContexts"]
  if output_contexts then response.outputContexts = output_contexts end
  -- Allow config to override/add fields
  if config.extra_fields and type(config.extra_fields) == "table" then
    for k, v in pairs(config.extra_fields) do
      response[k] = v
    end
  end
  return kong.response.exit(200, cjson.encode(response), {
    ["Content-Type"] = "application/json",
  })
end

function CustomSetDialogflowResponse:access(conf)
  if conf.run_on == "access" then
    set_dialogflow_response(conf, "access")
  end
end

function CustomSetDialogflowResponse:response(conf)
  if conf.run_on == "response" then
    set_dialogflow_response(conf, "response")
  end
end

return CustomSetDialogflowResponse
