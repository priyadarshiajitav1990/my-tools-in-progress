local typedefs = require "kong.db.schema.typedefs"

return {
  name = "setdialogflowresponse",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 760 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { extra_fields = { type = "map", keys = { type = "string" }, values = { type = "string" }, required = false } },
      }
    } }
  }
}
