local cjson = require "cjson.safe"

-- Load Apigee to Kong variable mappings
local function load_var_mappings()
  local ok, mappings = pcall(require, "kong.plugins.custom-assertcondition.var_mappers")
  if ok and mappings then
    return mappings.variable_map or {}, mappings.operator_map or {}, mappings.pattern_map or {}
  end
  return {}, {}, {}
end

local variable_map, operator_map, pattern_map = load_var_mappings()

-- Replace Apigee variables in the condition string with Kong equivalents
local function map_apigee_vars(condition)
  if not condition then return condition end
  local mapped = condition
  -- Apply pattern_map first (regex replacements)
  for _, pat in ipairs(pattern_map) do
    local pattern = pat.pattern
    local repl = pat.replacement
    mapped = mapped:gsub(pattern, repl)
  end
  -- Apply variable_map (simple string replacements)
  for apigee_var, kong_var in pairs(variable_map) do
    mapped = mapped:gsub(apigee_var, kong_var)
  end
  -- Apply operator_map (simple string replacements)
  for apigee_op, kong_op in pairs(operator_map) do
    mapped = mapped:gsub(apigee_op, kong_op)
  end
  return mapped
end

-- Simple condition evaluator for basic expressions
local function evaluate_condition(condition)
  if not condition or condition == "" then
    return true
  end
  
  -- Simple evaluation for basic conditions
  -- This is a simplified version - in production you might want more sophisticated parsing
  local request = kong.request
  local ctx = kong.ctx.shared
  
  -- Replace common Kong variables with actual values
  local eval_condition = condition
  eval_condition = eval_condition:gsub("http%.request%.method", '\\"(.*)\\"')
  eval_condition = eval_condition:gsub("http%.path", '\\"(.*)\\"')
  
  -- Simple string matching for basic conditions
  if eval_condition:match('==".*"') then
    return eval_condition:match('\\"(.*)\\"') and true or false
  end
  
  -- Default to true for complex conditions that can't be easily evaluated
  kong.log.warn("Complex condition evaluation not implemented: " .. condition)
  return true
end

local CustomAssertCondition = {
  PRIORITY = 1000,
  VERSION = "0.1.0",
}


function CustomAssertCondition:access(config)
  if config.enabled == false then
    return  -- skip if not enabled
  end

  local condition = config.condition
  local message = config.message or "Condition failed"
  local continueOnError = config.continueOnError

  -- Map Apigee variables to Kong variables in the condition
  local kong_condition = map_apigee_vars(condition)
  kong.log.debug("Mapped Condition: " .. kong_condition)

  -- Evaluate the condition using simple evaluation
  local eval_result = evaluate_condition(kong_condition)
  if not eval_result then
    kong.log.err("Condition failed: " .. kong_condition)
    if not continueOnError then
      return kong.response.exit(400, { message = message })
    else
      return  -- continue if allowed
    end
  end
end

function CustomAssertCondition:response(config)
  self:access(config)
end

return CustomAssertCondition
