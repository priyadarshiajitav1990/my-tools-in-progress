local cjson = require "cjson.safe"

-- Load Apigee to Kong variable mappings
local function load_var_mappings()
  local ok, mappings = pcall(require, "kong.plugins.custom-attribute.var_mappers")
  if ok and mappings then
    return mappings.variable_map or {}, mappings.operator_map or {}, mappings.pattern_map or {}
  end
  return {}, {}, {}
end

local variable_map, operator_map, pattern_map = load_var_mappings()

-- Map Apigee variable names to Kong equivalents
local function map_apigee_var(var)
  if variable_map[var] then
    return variable_map[var]
  end
  -- Try pattern_map
  for _, pat in ipairs(pattern_map) do
    local pattern = pat.pattern
    local repl = pat.replacement
    local mapped = var:gsub(pattern, repl)
    if mapped ~= var then return mapped end
  end
  return var
end

local CustomAttribute = {
  PRIORITY = 1000,
  VERSION = "0.1.0",
}

function CustomAttribute:access(config)
  if config.enabled == false then
    return
  end
  if not config.attributes then
    return
  end
  for _, attr in ipairs(config.attributes) do
    local name = attr.name
    local value = attr.value
    if name and value then
      local kong_var = map_apigee_var(name)
      -- Set as a header if it matches header pattern, else as a ctx variable
      if kong_var:find("http.request.headers.") then
        local header_name = kong_var:match("http.request.headers%.(.+)")
        if header_name then
          kong.service.request.set_header(header_name, value)
        end
      else
        kong.ctx.shared[kong_var] = value
      end
    end
  end
end

function CustomAttribute:response(config)
  self:access(config)
end

return CustomAttribute