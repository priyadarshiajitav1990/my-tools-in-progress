local cjson = require "cjson"
local pl_path = require "pl.path"
local pl_file = require "pl.file"
local var_mappers = require("kong.plugins.custom-readpropertyset.var_mappers")

local CustomReadPropertySet = {
  PRIORITY = 790,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function read_property_set(conf, phase)
  local config = conf.config or conf
  local file_path = config.file_path
  local prefix = config.prefix or ""
  if not pl_path.exists(file_path) then
    kong.log.err("Property set file not found: " .. file_path)
    return
  end
  local content = pl_file.read(file_path)
  if not content then
    kong.log.err("Failed to read property set file: " .. file_path)
    return
  end
  local ok, properties = pcall(cjson.decode, content)
  if not ok then
    kong.log.err("Failed to decode JSON from property set file: " .. file_path)
    return
  end
  for key, value in pairs(properties) do
    local ctx_key = prefix .. key
    kong.ctx.shared[ctx_key] = value
    kong.log.notice("Read property '\\"(.*)\\"' from " .. file_path)
  end
end

function CustomReadPropertySet:access(conf)
  if conf.run_on == "access" then
    read_property_set(conf, "access")
  end
end

function CustomReadPropertySet:response(conf)
  if conf.run_on == "response" then
    read_property_set(conf, "response")
  end
end

return CustomReadPropertySet
