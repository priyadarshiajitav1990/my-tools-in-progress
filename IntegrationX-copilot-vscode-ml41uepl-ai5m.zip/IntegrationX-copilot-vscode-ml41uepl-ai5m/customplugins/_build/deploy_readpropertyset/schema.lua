local typedefs = require "kong.db.schema.typedefs"

return {
  name = "readpropertyset",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 790 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { file_path = { type = "string", required = true } },
        { prefix = { type = "string" } },
      }
    } }
  }
}
