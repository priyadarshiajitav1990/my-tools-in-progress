local M = {}

-- This file is auto-generated for Apigee to Kong variable/operator mapping for custom-flowcallout
return {
  variable_map = {
    ["request.verb"] = "http.request.method",
    ["proxy.pathsuffix"] = "http.path",
    ["request.header.Content-Type"] = "http.request.headers.content_type",
    ["request.header.Accept"] = "http.request.headers.accept",
    ["request.header.Host"] = "http.request.headers.host",
    ["request.header.User-Agent"] = "http.request.headers.user_agent",
    ["request.header.Authorization"] = "http.request.headers.authorization",
    ["request.querystring"] = "http.query",
    ["client.ip"] = "http.source.ip",
    ["system.timestamp"] = "kong.request.time",
  },
  operator_map = {
    [" = "] = " == ",
    [" AND "] = " and ",
    [" and "] = " and ",
    [" OR "] = " or ",
    [" or "] = " or ",
    [" IsNot null"] = " ~= \"^.$\"",
  },
  pattern_map = {
    {
      pattern = "MatchesPath%s+\"([^\"]+)\"",
      replacement = "http.path ~ \"{0}\"",
      description = "Converts Apigee MatchesPath to a Kong regex path match."
    },
    {
      pattern = "request\\.header\\.([^\\s]+)",
      replacement = "http.request.headers.{0}",
      description = "Converts any request.header.Some-Name to http.request.headers.some_name."
    },
    {
      pattern = "request\\.queryparam\\.([^\\s]+)",
      replacement = "http.request.query.{0}",
      description = "Converts any request.queryparam.some-name to http.request.query.some-name."
    },
    {
      pattern = "request\\.formparam\\.([^\\s]+)",
      replacement = "http.request.post_args.{0}",
      description = "Converts any request.formparam.some-name to http.request.post_args.some-name."
    }
  }
}

return M