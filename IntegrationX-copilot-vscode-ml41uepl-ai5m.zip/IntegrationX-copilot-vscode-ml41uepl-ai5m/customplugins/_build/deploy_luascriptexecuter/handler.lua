-- custom-plugins/custom-luascriptexecuter/handler.lua

local BasePlugin = require "kong.plugins.base_plugin"

-- Cache for compiled Lua chunks
local cache = setmetatable({}, { __newindex = function(t, k, v)
  -- Simple LRU-like cache eviction
  if table.getn(t) >= (kong.configuration.custom_luascriptexecuter_cache_size or 100) then
    local oldest_key = nil
    local oldest_access = math.huge
    for key, entry in pairs(t) do
      if entry.last_access < oldest_access then
        oldest_access = entry.last_access
        oldest_key = key
      end
    end
    if oldest_key then
      rawset(t, oldest_key, nil)
    end
  end
  rawset(t, k, v)
end })


local CustomLuaScriptExecuterHandler = BasePlugin:extend()

CustomLuaScriptExecuterHandler.PRIORITY = 1000

function CustomLuaScriptExecuterHandler
  CustomLuaScriptExecuterHandler.super.new(self, "custom-luascriptexecuter")
end

local function create_sandbox(opts)
  opts = opts or {}

  if opts.trusted then
    -- In trusted mode, return the global environment. This is insecure but allows for maximum flexibility.
    return _G
  end

  local sandbox = {}
  -- Base safe globals
  local SAFE_GLOBALS_LIST = {
    "pcall", "xpcall", "type", "tostring", "tonumber", "select", "assert", "error",
    "getmetatable", "setmetatable", "rawequal", "rawget", "rawset", "rawlen",
    "next", "pairs", "ipairs",
    "string", "table", "math", "coroutine", "utf8",
  }

  for _, name in ipairs(SAFE_GLOBALS_LIST) do
    sandbox[name] = _G[name]
  end

  -- Add additional globals from config
  if opts.additional_globals then
    for _, name in ipairs(opts.additional_globals) do
      sandbox[name] = _G[name]
    end
  end

  -- Expose Kong APIs
  sandbox.kong = kong

  -- Redirect print
  sandbox.print = function(...)
    kong.log.info(table.concat({...}, "\t"))
  end

  setmetatable(sandbox, {
    __index = function(t, k)
      if t[k] ~= nil then
        return t[k]
      end
      kong.log.warn("Attempted to access restricted global: ", k)
      return nil
    end,
    __newindex = function(t, k, v)
      error("Attempt to modify global variable '\\"(.*)\\"' in sandbox", 2)
    end,
  })

  return sandbox
end


local function execute_script(lua_script, sandbox_opts)
  if not lua_script then
    return true
  end

  local sandbox = create_sandbox(sandbox_opts)

  -- Caching logic
  local cache_key = lua_script
  local cached = cache[cache_key]
  if cached then
    cached.last_access = ngx.time()
    local ok, err = pcall(cached.chunk)
    if not ok then
      kong.log.err("failed to execute cached lua script: ", tostring(err))
      return false, "Internal Server Error"
    end
    return true
  end

  local chunk, err = load(lua_script, "@lua_script", "t", sandbox)
  if not chunk then
    kong.log.err("failed to load lua script: ", err)
    return false, "Internal Server Error"
  end

  -- Add to cache
  cache[cache_key] = { chunk = chunk, last_access = ngx.time() }

  local ok, err = pcall(chunk)
  if not ok then
    kong.log.err("failed to execute lua script: ", tostring(err))
    return false, "Internal Server Error"
  end

  return true
end

function CustomLuaScriptExecuterHandler:access(conf)
  CustomLuaScriptExecuterHandler.super.access(self)

  if not conf.scripts then
    return
  end

  for _, script_conf in ipairs(conf.scripts) do
    local lua_script
    if script_conf.lua_code then
      lua_script = script_conf.lua_code
    elseif script_conf.lua_file_path then
      if string.find(script_conf.lua_file_path, "%.%./") or string.sub(script_conf.lua_file_path, 1, 1) == "/" then
        kong.log.err("Invalid lua_file_path: ", script_conf.lua_file_path)
        return kong.response.exit(400, "Bad Request: Invalid file path")
      end

      local file, err = io.open(script_conf.lua_file_path, "r")
      if not file then
        kong.log.err("failed to open lua file: ", err)
        return kong.response.exit(500, "Internal Server Error: Could not open script file")
      end
      lua_script = file:read("*a")
      file:close()
    end

    local ok, err_msg = execute_script(lua_script, conf.sandbox_opts)
    if not ok then
      return kong.response.exit(500, err_msg)
    end
  end
end


function CustomLuaScriptExecuterHandler:response(conf)
  CustomLuaScriptExecuterHandler.super.response(self)

  if not conf.scripts then
    return
  end

  for _, script_conf in ipairs(conf.scripts) do
    local lua_script
    if script_conf.lua_code then
      lua_script = script_conf.lua_code
    elseif script_conf.lua_file_path then
      if string.find(script_conf.lua_file_path, "%../") or string.sub(script_conf.lua_file_path, 1, 1) == "/" then
        kong.log.err("Invalid lua_file_path: ", script_conf.lua_file_path)
        return kong.response.exit(400, "Bad Request: Invalid file path")
      end

      local file, err = io.open(script_conf.lua_file_path, "r")
      if not file then
        kong.log.err("failed to open lua file: ", err)
        return kong.response.exit(500, "Internal Server Error: Could not open script file")
      end
      lua_script = file:read("*a")
      file:close()
    end

    local ok, err_msg = execute_script(lua_script, conf.sandbox_opts)
    if not ok then
      return kong.response.exit(500, err_msg)
    end
  end
end


return CustomLuaScriptExecuterHandler
