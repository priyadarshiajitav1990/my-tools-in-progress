local typedefs = require "kong.db.schema.typedefs"

return {
  name = "luascriptexecuter",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 1000 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { cache_size = { type = "number", default = 100 } },
        { sandbox_opts = {
            type = "record",
            fields = {
              { additional_globals = { type = "array", elements = { type = "string" } } },
              { trusted = { type = "boolean", default = false } },
            }
        } },
        {
          scripts = {
            type = "array",
            elements = {
              type = "record",
              fields = {
                { lua_code = { type = "string" } },
                { lua_file_path = { type = "string" } },
              },
              one_of = { "lua_code", "lua_file_path" },
            },
          },
        },
      },
    } },
  },
}
