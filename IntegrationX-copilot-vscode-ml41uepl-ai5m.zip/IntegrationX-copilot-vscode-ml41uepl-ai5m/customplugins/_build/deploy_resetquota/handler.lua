local var_mappers = require("kong.plugins.custom-resetquota.var_mappers")

local CustomResetQuota = {
  PRIORITY = 780,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Placeholder for quota reset logic
local function reset_quota(conf, phase)
  local config = conf.config or conf
  local quota = config.quota or {}
  local quota_name = quota.name or ""
  local identifier = quota.identifier or {}
  local identifier_name = identifier.name or ""
  local identifier_ref = identifier.ref or ""
  -- Here, you would implement the logic to reset quota in Kong or an external system
  -- For now, just log the intent
  kong.log.warn("[custom-resetquota] This is a placeholder. No quota is actually reset.")
  kong.log.warn("Quota name: " .. tostring(quota_name))
  kong.log.warn("Identifier name: " .. tostring(identifier_name))
  kong.log.warn("Identifier ref: " .. tostring(identifier_ref))
end

function CustomResetQuota:access(conf)
  if conf.run_on == "access" then
    reset_quota(conf, "access")
  end
end

function CustomResetQuota:response(conf)
  if conf.run_on == "response" then
    reset_quota(conf, "response")
  end
end

return CustomResetQuota
