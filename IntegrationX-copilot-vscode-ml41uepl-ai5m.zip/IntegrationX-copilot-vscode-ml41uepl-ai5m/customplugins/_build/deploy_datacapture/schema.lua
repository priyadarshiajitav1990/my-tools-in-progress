local typedefs = require "kong.db.schema.typedefs"

return {
  name = "datacapture",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 10 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { log_path = { type = "string", required = true } },
        { capture = {
          type = "record",
          fields = {
            { request = {
              type = "record",
              fields = {
                { headers = { type = "array", elements = { type = "string" } } },
                { query_params = { type = "array", elements = { type = "string" } } },
                { body = { type = "boolean", default = false } },
              }
            } },
            { response = {
              type = "record",
              fields = {
                { headers = { type = "array", elements = { type = "string" } } },
                { body = { type = "boolean", default = false } },
              }
            } }
          }
        } }
      }
    } }
  },
}
