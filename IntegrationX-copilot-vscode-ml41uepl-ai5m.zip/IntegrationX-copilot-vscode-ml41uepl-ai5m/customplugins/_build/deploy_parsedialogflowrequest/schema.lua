local typedefs = require "kong.db.schema.typedefs"

return {
  name = "parsedialogflowrequest",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 810 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        -- Add config fields if needed for future extensibility
      }
    } }
  }
}
