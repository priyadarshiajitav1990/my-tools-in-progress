local var_mappers = require("kong.plugins.custom-setintegrationrequest.var_mappers")

local CustomSetIntegrationRequest = {
  PRIORITY = 750,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Placeholder for integration request logic
local function set_integration_request(conf, phase)
  local config = conf.config or conf
  local integration_name = config.integration_name or ""
  local project_id = config.project_id or ""
  -- Here, you would implement the logic to send a request to Google Cloud Integration or another system
  -- For now, just log the intent
  kong.log.warn("[custom-setintegrationrequest] This is a placeholder. No integration request is actually sent.")
  kong.log.warn("Project ID: " .. tostring(project_id))
  kong.log.warn("Integration name: " .. tostring(integration_name))
end

function CustomSetIntegrationRequest:access(conf)
  if conf.run_on == "access" then
    set_integration_request(conf, "access")
  end
end

function CustomSetIntegrationRequest:response(conf)
  if conf.run_on == "response" then
    set_integration_request(conf, "response")
  end
end

return CustomSetIntegrationRequest
