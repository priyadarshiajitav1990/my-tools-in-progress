local uuid = require "kong.tools.uuid"

local function load_var_mappings()
  local ok, mappings = pcall(require, "kong.plugins.custom-java-callout.var_mappers")
  if ok and mappings then
    return mappings.variable_map or {}, mappings.operator_map or {}, mappings.pattern_map or {}
  end
  return {}, {}, {}
end

local variable_map, operator_map, pattern_map = load_var_mappings()

local function map_apigee_var(var)
  if variable_map[var] then
    return variable_map[var]
  end
  for _, pat in ipairs(pattern_map) do
    local pattern = pat.pattern
    local repl = pat.replacement
    local mapped = var:gsub(pattern, repl)
    if mapped ~= var then return mapped end
  end
  return var
end

local function run_injected_lua(lua_code, phase, config)
  local env = {
    kong = kong,
    config = config,
    phase = phase,
    map_apigee_var = map_apigee_var,
    uuid = uuid,
    string = string,
    os = os,
    ipairs = ipairs,
    pairs = pairs,
    tostring = tostring,
    tonumber = tonumber,
    type = type,
    table = table,
    print = print,
    error = error,
    pcall = pcall,
    xpcall = xpcall,
    require = require,
    _G = _G,
  }
  local chunk, err = load(lua_code, "InjectedJavaCallout", "t", env)
  if not chunk then
    kong.log.err("Failed to load injected Lua code: ", err)
    return
  end
  local ok, result = pcall(chunk)
  if not ok then
    kong.log.err("Injected Lua code error: ", result)
  end
end

local CustomJavaCallout = {
  PRIORITY = 860,
  VERSION = "0.1.0",
}

function CustomJavaCallout:access(config)
  if config.injected_lua_code then
    run_injected_lua(config.injected_lua_code, "access", config)
  end
end

function CustomJavaCallout:response(config)
  if config.injected_lua_code then
    run_injected_lua(config.injected_lua_code, "response", config)
  end
end

return CustomJavaCallout
