local typedefs = require "kong.db.schema.typedefs"

return {
  name = "java_callout",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 860 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { injected_lua_code = { type = "string", required = false, description = "Lua code converted from Java/JAR to inject and execute" } },
      }
    } }
  },
}
