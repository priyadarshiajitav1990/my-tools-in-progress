local typedefs = require "kong.db.schema.typedefs"

return {
  name = "invalidate_cache",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 870 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { cache_key = {
          type = "record",
          fields = {
            { prefix = { type = "string" } },
            { key_fragment = { type = "string", required = true } }
          }
        } },
        { cache_resource = { type = "string" } },
        { scope = { type = "string", one_of = { "Exclusive", "Global" }, default = "Exclusive" } },
        { purge_child_entries = { type = "boolean", default = false } },
      }
    } }
  },
}
