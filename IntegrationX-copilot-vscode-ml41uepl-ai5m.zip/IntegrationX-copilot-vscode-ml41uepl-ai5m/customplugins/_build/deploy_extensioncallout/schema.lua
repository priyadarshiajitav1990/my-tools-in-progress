local typedefs = require "kong.db.schema.typedefs"

return {
  name = "extensioncallout",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 900 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { grpc_server = {
          type = "record",
          fields = {
            { name = { type = "string", required = true } }
          },
          required = true
        } },
        { timeout_ms = { type = "number", default = 5000 } },
        { configurations = {
          type = "record",
          fields = {
            { with_request_content = { type = "boolean", default = false } },
            { with_request_headers = { type = "boolean", default = false } },
            { with_response_content = { type = "boolean", default = false } },
            { with_response_headers = { type = "boolean", default = false } },
            { flow_variables = { type = "array", elements = { type = "string" } } }
          }
        } }
      }
    } }
  },
}
