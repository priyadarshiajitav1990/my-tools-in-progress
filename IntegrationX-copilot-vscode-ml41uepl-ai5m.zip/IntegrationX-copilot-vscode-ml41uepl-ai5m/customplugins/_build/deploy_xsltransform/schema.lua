local typedefs = require "kong.db.schema.typedefs"

return {
  name = "xsltransform",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 730 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { source = { type = "string", default = "response" } },
        { xslt_content = { type = "string", required = true, description = "XSLT file content injected directly" } },
        { output_variable = { type = "string" } },
      }
    } }
  }
}
