local var_mappers = require("kong.plugins.custom-xsltransform.var_mappers")

local CustomXSLTransform = {
  PRIORITY = 730,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Placeholder for XSLT transformation logic
local function do_xsl_transform(conf, phase)
  local config = conf.config or conf
  local xslt_content = config.xslt_content or ""
  local source = config.source or "response"
  local output_variable = config.output_variable
  -- In a real implementation, you would apply the XSLT to the XML payload here
  -- For now, just log the intent and store a placeholder result
  kong.log.warn("[custom-xsltransform] This is a placeholder. No XSLT transformation is actually performed.")
  kong.log.warn("XSLT content length: " .. tostring(#xslt_content))
  if output_variable then
    kong.ctx.shared[output_variable] = "<xml>transformed (placeholder)</xml>"
    kong.log.notice("Stored placeholder XSLT result in variable '\\"(.*)\\"'")
  end
end

function CustomXSLTransform:access(conf)
  if conf.run_on == "access" then
    do_xsl_transform(conf, "access")
  end
end

function CustomXSLTransform:response(conf)
  if conf.run_on == "response" then
    do_xsl_transform(conf, "response")
  end
end

return CustomXSLTransform
