local var_mappers = require("kong.plugins.custom-latencyanalysis.var_mappers")

local CustomLatencyAnalysis = {
  PRIORITY = 820,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function record_latency(conf, phase)
  local now = kong.time.gettimeofday()
  local ctx = kong.ctx.shared
  local config = conf.config or {}
  local label = config.label or (phase .. "_latency")
  local apigee_var = config.variable or label
  local kong_func, mapped_key = map_variable(apigee_var)
  -- Store timestamp in context for later calculation
  ctx["latencyanalysis_" .. label .. "_ts"] = now
  kong.log.debug("[LatencyAnalysis] " .. phase .. " phase: recorded timestamp for label '\\"(.*)\\"' = " .. tostring(now))
end

local function calculate_latency(conf, phase)
  local ctx = kong.ctx.shared
  local config = conf.config or {}
  local label = config.label or (phase .. "_latency")
  local start_label = config.start_label or "access_latency"
  local end_label = config.end_label or "response_latency"
  local start_ts = ctx["latencyanalysis_" .. start_label .. "_ts"]
  local end_ts = ctx["latencyanalysis_" .. end_label .. "_ts"] or kong.time.gettimeofday()
  if start_ts then
    local latency = end_ts - start_ts
    ctx[label] = latency
    kong.log.notice("[LatencyAnalysis] Calculated latency for label '\\"(.*)\\"': " .. tostring(latency) .. " seconds")
  else
    kong.log.warn("[LatencyAnalysis] Start timestamp for label '\\"(.*)\\"' not found.")
  end
end

function CustomLatencyAnalysis:access(conf)
  if conf.run_on == "access" then
    record_latency(conf, "access")
  elseif conf.run_on == "response" then
    calculate_latency(conf, "access")
  end
end

function CustomLatencyAnalysis:response(conf)
  if conf.run_on == "response" then
    record_latency(conf, "response")
    calculate_latency(conf, "response")
  elseif conf.run_on == "access" then
    calculate_latency(conf, "response")
  end
end

return CustomLatencyAnalysis
