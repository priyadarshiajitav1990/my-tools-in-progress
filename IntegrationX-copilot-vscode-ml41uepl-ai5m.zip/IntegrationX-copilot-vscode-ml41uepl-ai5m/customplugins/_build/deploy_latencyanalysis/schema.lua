local typedefs = require "kong.db.schema.typedefs"

return {
  name = "latencyanalysis",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 820 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { label = { type = "string", required = false, description = "Label for this latency measurement" } },
        { variable = { type = "string", required = false, description = "Apigee variable to store latency" } },
        { start_label = { type = "string", required = false, description = "Label for start timestamp" } },
        { end_label = { type = "string", required = false, description = "Label for end timestamp" } },
      }
    } }
  }
}
