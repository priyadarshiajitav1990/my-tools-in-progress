local typedefs = require "kong.db.schema.typedefs"

return {
  name = "soapvalidation",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 720 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { source = { type = "string", default = "request" } },
        { wsdl_content = { type = "string", required = true, description = "WSDL file content injected directly" } },
        { output_variable = { type = "string" } },
      }
    } }
  }
}
