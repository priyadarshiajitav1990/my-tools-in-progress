local typedefs = require "kong.db.schema.typedefs"

return {
  name = "publishmessage",
  fields = {
    { consumer = typedefs.no_consumer },} },
    { priority = { type = "number", default = 800 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { source = { type = "string", required = true } },
        { cloud_pub_sub = {
            type = "record",
            fields = {
              { topic = { type = "string", required = true } },
            },
            required = true
        } },
      }
    } }
  }
}
