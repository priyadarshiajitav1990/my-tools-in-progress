local var_mappers = require("kong.plugins.soapvalidation.var_mappers")

local CustomSOAPValidation = {
  PRIORITY = 720,
  VERSION = "0.1.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

-- Placeholder for SOAP validation logic
local function do_soap_validation(conf, phase)
  local config = conf.config or conf
  local wsdl_content = config.wsdl_content or ""
  local source = config.source or "request"
  local output_variable = config.output_variable
  -- In a real implementation, you would validate the SOAP XML against the WSDL here
  -- For now, just log the intent and store a placeholder result
  kong.log.warn("[custom-soapvalidation] This is a placeholder. No SOAP validation is actually performed.")
  kong.log.warn("WSDL content length: " .. tostring(#wsdl_content))
  if output_variable then
    kong.ctx.shared[output_variable] = "<soap:Envelope>validated (placeholder)</soap:Envelope>"
    kong.log.notice("Stored placeholder SOAP validation result in variable '\\"(.*)\\"'")
  end
end

function CustomSOAPValidation:access(conf)
  if conf.run_on == "access" then
    do_soap_validation(conf, "access")
  end
end

function CustomSOAPValidation:response(conf)
  if conf.run_on == "response" then
    do_soap_validation(conf, "response")
  end
end

return CustomSOAPValidation




