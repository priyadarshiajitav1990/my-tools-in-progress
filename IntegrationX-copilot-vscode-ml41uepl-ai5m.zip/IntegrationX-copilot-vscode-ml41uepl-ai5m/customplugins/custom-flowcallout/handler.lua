local function load_var_mappings()
  local ok, mappings = pcall(require, "kong.plugins.custom-flowcallout.var_mappers")
  if ok and mappings then
    return mappings.variable_map or {}, mappings.operator_map or {}, mappings.pattern_map or {}
  end
  return {}, {}, {}
end

local variable_map, operator_map, pattern_map = load_var_mappings()

local function map_apigee_var(var)
  if variable_map[var] then
    return variable_map[var]
  end
  for _, pat in ipairs(pattern_map) do
    local pattern = pat.pattern
    local repl = pat.replacement
    local mapped = var:gsub(pattern, repl)
    if mapped ~= var then return mapped end
  end
  return var
end

local CustomFlowCallout = {
  PRIORITY = 890,
  VERSION = "0.1.0",
}

function CustomFlowCallout:access(config)
  local opts = {
    method = kong.request.get_method(),
  }

  if config.pass_request_body then
    opts.body = kong.request.get_raw_body()
  end

  if config.pass_request_headers then
    opts.headers = kong.request.get_headers()
  end

  if config.pass_request_query_params then
    opts.vars = kong.request.get_query()
  end

  -- Example: map Apigee variables if needed for subrequest
  if config.apigee_vars then
    for _, var in ipairs(config.apigee_vars) do
      local kong_var = map_apigee_var(var)
      kong.log.debug("Mapped Apigee variable: " .. (var or "unknown"))
    end
  end

  -- Make the subrequest
  local res, err = ngx.location.capture(config.url, opts)

  if err then
    kong.log.err("FlowCallout failed to make subrequest to " .. config.url .. ": " .. err)
    return
  end

  kong.log.notice("FlowCallout subrequest to " .. config.url .. " completed with status " .. res.status)
end

function CustomFlowCallout:response(config)
  -- Placeholder for response phase logic.
end

return CustomFlowCallout




