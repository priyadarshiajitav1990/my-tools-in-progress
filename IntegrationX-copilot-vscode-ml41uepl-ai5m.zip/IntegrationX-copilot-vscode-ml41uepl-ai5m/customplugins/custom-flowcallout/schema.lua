local typedefs = require "kong.db.schema.typedefs"

return {
  name = "flowcallout",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 890 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
        required = false,
        description = "Plugin execution ordering (before/after other plugins)"
      }
    },
    { tags = { type = "array", elements = { type = "string" }, required = false, description = "Plugin tags for grouping/filtering" } },
    { config = {
      type = "record",
      fields = {
        { url = { type = "string", required = true } },
        { pass_request_body = { type = "boolean", default = true } },
        { pass_request_headers = { type = "boolean", default = true } },
        { pass_request_query_params = { type = "boolean", default = true } },
        { apigee_vars = { type = "array", elements = { type = "string" }, required = false, description = "List of Apigee variables to map" } },
      }
    } }
  },
}

