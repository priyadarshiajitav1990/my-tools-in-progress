local var_mappers = require("kong.plugins.servicecallout.var_mappers")

local CustomServiceCallout = {
  PRIORITY = 770,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function do_service_callout(conf, phase)
  local config = conf.config or conf
  local url = config.http_target_connection.url
  local request_var = config.request and config.request.variable
  local clear_payload = config.request and config.request.clear_payload
  local response_var = config.response

  local opts = {
    method = kong.request.get_method(),
    headers = kong.request.get_headers(),
  }

  if request_var then
    opts.body = kong.ctx.shared[request_var]
  elseif not clear_payload then
    opts.body = kong.request.get_raw_body()
  end

  -- Make the subrequest (blocking, for demo; production should use async HTTP client)
  local http = require "resty.http"
  local httpc = http.new()
  local res, err = httpc:request_uri(url, opts)

  if not res then
    kong.log.err("ServiceCallout failed to make request to " .. url .. ": " .. tostring(err))
    return
  end

  if response_var then
    kong.ctx.shared[response_var] = {
      status = res.status,
      body = res.body,
      headers = res.headers,
    }
    kong.log.notice("ServiceCallout response from " .. url .. " stored in '\\"(.*)\\"'")
  end
end

function CustomServiceCallout:access(conf)
  if conf.run_on == "access" then
    do_service_callout(conf, "access")
  end
end

function CustomServiceCallout:response(conf)
  if conf.run_on == "response" then
    do_service_callout(conf, "response")
  end
end

return CustomServiceCallout




