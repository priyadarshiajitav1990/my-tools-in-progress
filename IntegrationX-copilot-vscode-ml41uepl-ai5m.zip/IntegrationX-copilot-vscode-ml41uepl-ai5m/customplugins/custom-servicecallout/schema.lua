local typedefs = require "kong.db.schema.typedefs"

return {
  name = "servicecallout",
  fields = {
    { consumer = typedefs.no_consumer },
    { priority = { type = "number", default = 770 } },
    { ordering = {
        type = "record",
        fields = {
          { before = { type = "array", elements = { type = "string" } } },
          { after = { type = "array", elements = { type = "string" } } },
        },
      }
    },
    { tags = { type = "array", elements = { type = "string" } } },
    { config = {
      type = "record",
      fields = {
        { request = {
            type = "record",
            fields = {
              { clear_payload = { type = "boolean", default = false } },
              { variable = { type = "string" } },
            }
        } },
        { response = { type = "string" } },
        { http_target_connection = {
            type = "record",
            fields = {
              { url = { type = "string", required = true } },
            },
            required = true
        } },
      }
    } }
  }
}

