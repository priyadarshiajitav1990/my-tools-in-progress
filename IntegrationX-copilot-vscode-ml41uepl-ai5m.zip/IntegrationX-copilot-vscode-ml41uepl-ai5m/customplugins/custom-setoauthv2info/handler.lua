local var_mappers = require("kong.plugins.setoauthv2info.var_mappers")

local CustomSetOAuthV2Info = {
  PRIORITY = 740,
  VERSION = "0.2.0",
}

-- Helper: Map Apigee variable to Kong variable using var_mappers
local function map_variable(apigee_var)
  for prefix, kong_func in pairs(var_mappers.apigee_to_kong) do
    if apigee_var:sub(1, #prefix) == prefix then
      return kong_func, apigee_var:sub(#prefix + 1)
    end
  end
  return nil, apigee_var
end

local function set_oauth2_info(conf, phase)
  local config = conf.config or conf
  local ctx = kong.ctx.shared
  if not ctx.authenticated_oauth2_token then
    kong.log.warn("No authenticated OAuth 2.0 token found. The 'custom-setoauthv2info' plugin will not set any attributes.")
    return
  end
  for key, value in pairs(config.attributes or {}) do
    ctx["oauth2.attributes." .. key] = value
    kong.log.notice("Set OAuth 2.0 attribute '\\"(.*)\\"'")
  end
end

function CustomSetOAuthV2Info:access(conf)
  if conf.run_on == "access" then
    set_oauth2_info(conf, "access")
  end
end

function CustomSetOAuthV2Info:response(conf)
  if conf.run_on == "response" then
    set_oauth2_info(conf, "response")
  end
end

return CustomSetOAuthV2Info




