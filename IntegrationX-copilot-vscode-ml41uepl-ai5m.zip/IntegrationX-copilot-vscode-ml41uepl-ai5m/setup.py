import os
import sys
import platform
import subprocess

import urllib.request
import zipfile
from io import BytesIO
import json

VENV_NAME = ".venv"

# Checks for a virtual environment and creates it if it doesn't exist.
def create_virtual_env(project_root, venv_name=".venv"):
    venv_path = os.path.join(project_root, venv_name)
    print(f"Checking for virtual environment at: {venv_path}")

    if not os.path.exists(venv_path):
        print("Virtual environment not found. Creating...")
        try:
            subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
            print("Virtual environment '.venv' created successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error creating virtual environment: {e}")
            sys.exit(1)
    else:
        print("Virtual environment already exists.")

# Installs packages from requirements.txt into the virtual environment.
def install_requirements(project_root, venv_name=".venv"):
    requirements_path = os.path.join(project_root, "configs", "requirements_production.txt")
    
    if not os.path.exists(requirements_path):
        print(f"Error: '{requirements_path}' not found. Cannot install dependencies.")
        return False

    print("\n--- Installing Python Dependencies ---")
    os_type = platform.system()

    if os_type == "Windows":
        pip_executable = os.path.join(project_root, venv_name, "Scripts", "pip.exe")
        python_executable = os.path.join(project_root, venv_name, "Scripts", "python.exe")
    else: # Linux and macOS
        pip_executable = os.path.join(project_root, venv_name, "bin", "pip")
        python_executable = os.path.join(project_root, venv_name, "bin", "python")

    try:
        # First try to upgrade pip using python -m pip
        print("Upgrading pip...")
        subprocess.run([python_executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
        
        # Then install requirements
        print("Installing requirements...")
        subprocess.run([python_executable, "-m", "pip", "install", "-r", requirements_path], check=True)
        print("Dependencies installed successfully.")
        return True
    except FileNotFoundError:
        print(f"Error: Python executable not found at '{python_executable}'. Is the venv corrupted?")
        # Try to recreate venv
        print("Attempting to recreate virtual environment...")
        try:
            import shutil
            venv_path = os.path.join(project_root, venv_name)
            shutil.rmtree(venv_path)
            subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
            print("Virtual environment recreated. Please run setup.py again.")
        except Exception as recreate_error:
            print(f"Failed to recreate virtual environment: {recreate_error}")
        return False
    except subprocess.CalledProcessError as e:
        print(f"Error installing dependencies: {e}")
        # Check if the error is related to matplotlib/numpy to provide a specific hint
        if 'numpy' in str(e) or 'matplotlib' in str(e):
            print("\nHint: The installation of 'matplotlib' failed. This can happen on systems without a C++ compiler.")
            print("The application will still work, but the HTML report will not contain a summary chart.")
        return True # Allow setup to continue even if optional dependencies fail.

# Checks for WeasyPrint system dependencies and provides instructions if they are missing.
def check_system_dependencies(): # Placeholder for future system dependency checks
    print("\n--- Checking System Dependencies ---")
    print("✅ No special system dependencies required for HTML reporting.")
    pass

# Provides OS-specific instructions for activating the virtual environment.
def provide_activation_instructions(project_root, venv_name=".venv"):
    os_type = platform.system()
    print("\n--- How to Activate Your Virtual Environment ---")

    if os_type == "Windows":
        # 'PSModulePath' is a reliable indicator of a PowerShell environment
        if os.environ.get("PSModulePath"):
            command = f". .\\{os.path.join(venv_name, 'Scripts', 'activate.ps1')}"
            print("You appear to be in PowerShell. To activate, run:")
            print(f"\n    {command}\n")
            print("\n(You may need to run 'Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process' first if you get an error)")
        else: # Assume Command Prompt (cmd.exe)
            command = f"{os.path.join(venv_name, 'Scripts', 'activate.bat')}"
            print("You appear to be in Command Prompt. To activate, run:")
            print(f"\n    {command}\n")
    elif os_type in ["Linux", "Darwin"]:  # Darwin is macOS
        command = f"source ./{os.path.join(venv_name, 'bin', 'activate')}"
        print("In your terminal (bash/zsh), run:")
        print(f"\n    {command}\n")
    else:
        print(f"Unsupported OS: {os_type}. Please consult the venv documentation.")
    
    print("------------------------------------------------\n")

# Main function to orchestrate the project setup process.
def main():
    print("--- Starting Project Setup ---")
    project_root = os.path.dirname(os.path.abspath(__file__))

    create_virtual_env(project_root, VENV_NAME)
    
    if install_requirements(project_root, VENV_NAME):
        check_system_dependencies()
        provide_activation_instructions(project_root, VENV_NAME)
        print("\n------------------------------------------------")
        print("✅ Setup completed successfully!")
    else:
        print("\nSetup failed due to errors installing dependencies.")

if __name__ == "__main__":
    main()