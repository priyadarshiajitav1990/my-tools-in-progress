#!/usr/bin/env python3
"""
Production Apigee to Kong Migration Tool
Enterprise-grade migration with zero consumer impact
"""

import sys
import os
from pathlib import Path

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent / "scripts"))

def main():
    """Main entry point"""
    try:
        # Import and run production migration
        sys.path.insert(0, str(Path(__file__).parent / "scripts"))
        from start_production import main as production_main
        return production_main()
    except ImportError as e:
        print(f"Error importing production module: {e}")
        return False
    except Exception as e:
        print(f"Error running migration: {e}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)