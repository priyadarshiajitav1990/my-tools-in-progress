local attribute = require "custom-plugins.Attribute.handler"

describe("Attribute Plugin", function()
  local kong = {
    service = { request = {
      remove_header = function() end,
      add_header = function() end,
      set_header = function() end,
      remove_query = function() end,
      add_query = function() end,
      set_query = function() end
    } },
    log = { warn = function() end },
    ctx = { shared = {} }
  }

  setup(function()
    _G.kong = kong
  end)

  it("removes headers", function()
    local called = false
    kong.service.request.remove_header = function(header)
      called = true
      assert.are.equal(header, "X-Test")
    end
    local config = { remove = { headers = { "X-Test" } } }
    attribute:access(config)
    assert.is_true(called)
  end)

  it("adds headers", function()
    local called = false
    kong.service.request.add_header = function(header, value)
      called = true
      assert.are.equal(header, "X-Test")
      assert.are.equal(value, "val")
    end
    local config = { add = { headers = { ["X-Test"] = "val" } } }
    attribute:access(config)
    assert.is_true(called)
  end)

  it("sets headers", function()
    local called = false
    kong.service.request.set_header = function(header, value)
      called = true
      assert.are.equal(header, "X-Test")
      assert.are.equal(value, "val")
    end
    local config = { set = { headers = { ["X-Test"] = "val" } } }
    attribute:access(config)
    assert.is_true(called)
  end)
end)
