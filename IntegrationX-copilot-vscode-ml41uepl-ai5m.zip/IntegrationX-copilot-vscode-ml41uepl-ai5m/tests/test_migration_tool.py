#!/usr/bin/env python3
"""
Comprehensive Test Suite for Enhanced Migration Tool
Tests complex resource file conversion, plugin conflicts, and end-to-end migration
"""

import os
import sys
import json
import tempfile
import shutil
import logging
from pathlib import Path
from typing import Dict, Any

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from scripts.utils.resource_converter_enhanced import EnhancedResourceConverter
from scripts.utils.plugin_conflict_resolver_enhanced import EnhancedPluginConflictResolver
from scripts.utils.template_manager_enhanced import EnhancedTemplateManager
from scripts.core.policy_migration_enhanced import EnhancedPolicyMigrationEngine

class MigrationTestSuite:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.setup_logging()
        self.test_results = []
        
        # Test data
        self.complex_js_code = '''
function validateRequest() {
    var method = context.getVariable("request.verb");
    var path = context.getVariable("request.uri");
    var headers = context.getVariable("request.headers");
    
    if (method === "POST" && path.includes("/api/")) {
        var body = context.getVariable("request.content");
        var parsedBody = JSON.parse(body);
        
        if (!parsedBody.userId || !parsedBody.token) {
            throw new Error("Missing required fields");
        }
        
        context.setVariable("request.header.validated", "true");
        context.setVariable("flow.user.id", parsedBody.userId);
    }
    
    return true;
}

validateRequest();
'''
        
        self.complex_python_code = '''
import json
import re
from datetime import datetime

def process_request():
    method = flow.getVariable("request.verb")
    headers = flow.getVariable("request.headers")
    
    if method == "POST":
        body = flow.getVariable("request.content")
        data = json.loads(body)
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if 'email' in data and not re.match(email_pattern, data['email']):
            raise ValueError("Invalid email format")
        
        # Add timestamp
        data['processed_at'] = datetime.now().isoformat()
        
        # Set modified body
        flow.setVariable("request.content", json.dumps(data))
        flow.setVariable("request.header.content-type", "application/json")
    
    return True

process_request()
'''
        
        self.complex_java_code = '''
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import java.util.Map;
import java.util.HashMap;

public class CustomJavaCallout implements Execution {
    
    public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {
        try {
            String method = messageContext.getVariable("request.verb");
            String contentType = messageContext.getVariable("request.header.content-type");
            
            if ("POST".equals(method) && contentType != null && contentType.contains("application/json")) {
                String body = messageContext.getVariable("request.content");
                
                // Simple JSON validation
                if (body != null && body.trim().startsWith("{") && body.trim().endsWith("}")) {
                    messageContext.setVariable("request.header.validated", "true");
                    messageContext.setVariable("flow.validation.status", "passed");
                } else {
                    messageContext.setVariable("flow.validation.status", "failed");
                    return ExecutionResult.ABORT;
                }
            }
            
            return ExecutionResult.SUCCESS;
        } catch (Exception e) {
            messageContext.setVariable("flow.error.message", e.getMessage());
            return ExecutionResult.ABORT;
        }
    }
}
'''
        
        self.xslt_content = '''<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:template match="/">
        <response>
            <status>success</status>
            <data>
                <xsl:for-each select="//item">
                    <item>
                        <id><xsl:value-of select="@id"/></id>
                        <name><xsl:value-of select="name"/></name>
                        <value><xsl:value-of select="value"/></value>
                    </item>
                </xsl:for-each>
            </data>
        </response>
    </xsl:template>
</xsl:stylesheet>
'''
        
        self.openapi_spec = '''
openapi: 3.0.0
info:
  title: Test API
  version: 1.0.0
  description: Test API for migration validation
paths:
  /users:
    get:
      summary: Get users
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                type: array
                items:
                  type: object
                  properties:
                    id:
                      type: integer
                    name:
                      type: string
                    email:
                      type: string
    post:
      summary: Create user
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required:
                - name
                - email
              properties:
                name:
                  type: string
                email:
                  type: string
      responses:
        '201':
          description: Created
        '400':
          description: Bad Request
'''
    
    def setup_logging(self):
        """Setup test logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    def run_all_tests(self) -> bool:
        """Run all test suites"""
        self.logger.info("Starting comprehensive migration tool tests")
        
        test_suites = [
            ("Resource Converter Tests", self.test_resource_converter),
            ("Plugin Conflict Resolver Tests", self.test_plugin_conflict_resolver),
            ("Template Manager Tests", self.test_template_manager),
            ("End-to-End Migration Tests", self.test_end_to_end_migration),
            ("Complex Policy Tests", self.test_complex_policies),
            ("Error Handling Tests", self.test_error_handling)
        ]
        
        all_passed = True
        
        for suite_name, test_func in test_suites:
            self.logger.info(f"Running {suite_name}...")
            try:
                result = test_func()
                self.test_results.append((suite_name, result, None))
                if not result:
                    all_passed = False
                    self.logger.error(f"{suite_name} FAILED")
                else:
                    self.logger.info(f"{suite_name} PASSED")
            except Exception as e:
                self.test_results.append((suite_name, False, str(e)))
                all_passed = False
                self.logger.error(f"{suite_name} FAILED with exception: {e}")
        
        self.print_test_summary()
        return all_passed
    
    def test_resource_converter(self) -> bool:
        """Test resource converter with complex files"""
        converter = EnhancedResourceConverter()
        
        tests = [
            ("JavaScript Conversion", "jsc://validate.js", self.complex_js_code),
            ("Python Conversion", "py://process.py", self.complex_python_code),
            ("Java Conversion", "java://CustomCallout.java", self.complex_java_code),
            ("XSLT Handling", "transform.xslt", self.xslt_content),
            ("OpenAPI Handling", "api-spec.yaml", self.openapi_spec)
        ]
        
        all_passed = True
        
        for test_name, resource_url, content in tests:
            try:
                lua_code = converter.convert_resource_to_lua(resource_url, content, "TestPolicy")
                
                if not lua_code:
                    self.logger.error(f"{test_name}: No Lua code generated")
                    all_passed = False
                    continue
                
                # Basic validation
                if "function" not in lua_code and "local" not in lua_code:
                    self.logger.error(f"{test_name}: Generated Lua doesn't contain expected patterns")
                    all_passed = False
                    continue
                
                # Check for Kong context
                if "kong." not in lua_code:
                    self.logger.error(f"{test_name}: Generated Lua doesn't use Kong context")
                    all_passed = False
                    continue
                
                self.logger.info(f"{test_name}: PASSED")
                
            except Exception as e:
                self.logger.error(f"{test_name}: FAILED - {e}")
                all_passed = False
        
        return all_passed
    
    def test_plugin_conflict_resolver(self) -> bool:
        """Test plugin conflict resolution"""
        resolver = EnhancedPluginConflictResolver()
        
        # Create conflicting plugins
        conflicting_plugins = [
            {
                'name': 'rate-limiting',
                'config': {'minute': 100},
                'tags': ['api:test', 'policy:quota1'],
                'api_flow': 'request'
            },
            {
                'name': 'rate-limiting',
                'config': {'minute': 50},
                'tags': ['api:test', 'policy:quota2'],
                'api_flow': 'request'
            },
            {
                'name': 'luascriptexecuter',
                'config': {'script': 'return true'},
                'tags': ['api:test', 'policy:js1'],
                'api_flow': 'both'
            },
            {
                'name': 'luascriptexecuter',
                'config': {'script': 'kong.log.info("test")'},
                'tags': ['api:test', 'policy:js2'],
                'api_flow': 'both'
            }
        ]
        
        try:
            resolved_plugins = resolver.resolve_plugin_conflicts(conflicting_plugins, "test-api")
            
            # Should have fewer plugins after resolution
            if len(resolved_plugins) >= len(conflicting_plugins):
                self.logger.error("Conflict resolution didn't reduce plugin count")
                return False
            
            # Check for merged LuaScriptExecuter
            lua_plugins = [p for p in resolved_plugins if p['name'] == 'luascriptexecuter']
            if len(lua_plugins) != 1:
                self.logger.error("LuaScriptExecuter plugins not merged properly")
                return False
            
            # Check merged script contains both original scripts
            merged_script = lua_plugins[0]['config']['script']
            if 'return true' not in merged_script or 'kong.log.info' not in merged_script:
                self.logger.error("Merged Lua script doesn't contain original scripts")
                return False
            
            self.logger.info("Plugin conflict resolution: PASSED")
            return True
            
        except Exception as e:
            self.logger.error(f"Plugin conflict resolution: FAILED - {e}")
            return False
    
    def test_template_manager(self) -> bool:
        """Test template manager"""
        templates_dir = project_root / "templates"
        if not templates_dir.exists():
            templates_dir.mkdir(parents=True)
        
        # Create a test template
        test_template = templates_dir / "test-plugin.yml.j2"
        test_template.write_text('''
name: {{ plugin_name }}
config:
  enabled: {{ utils.convert_boolean(policy.enabled) }}
  script: |
{{ lua_code | indent_lua(4) if lua_code else "    -- No script provided" }}
tags:
  - "api:{{ api_name }}"
  - "policy:{{ apigee.policy_name }}"
''')
        
        try:
            manager = EnhancedTemplateManager(templates_dir)
            
            context = {
                'policy': {
                    'name': 'test-policy',
                    'enabled': True,
                    'policyType': 'JavaScript'
                },
                'api_name': 'test-api',
                'lua_code': 'kong.log.info("test")'
            }
            
            result = manager.render_plugin_template("test-plugin", context, "both")
            
            if not result:
                self.logger.error("Template rendering returned None")
                return False
            
            if result['name'] != 'test-plugin':
                self.logger.error("Template didn't render plugin name correctly")
                return False
            
            if 'kong.log.info' not in result['config']['script']:
                self.logger.error("Template didn't include Lua code")
                return False
            
            self.logger.info("Template manager: PASSED")
            return True
            
        except Exception as e:
            self.logger.error(f"Template manager: FAILED - {e}")
            return False
        finally:
            # Cleanup
            if test_template.exists():
                test_template.unlink()
    
    def test_end_to_end_migration(self) -> bool:
        """Test end-to-end migration with mock data"""
        try:
            # Create temporary test environment
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                
                # Setup test structure
                self._setup_test_environment(temp_path)
                
                # Create migration engine
                config = {
                    "kong": {"version": "3.13.0.0"},
                    "migration": {"enable_resource_conversion": True}
                }
                
                engine = EnhancedPolicyMigrationEngine(temp_path, config)
                
                # Create mock output data
                output_data = {
                    'services': [{'name': 'srv-test-api-default', 'url': 'http://backend.com'}],
                    'routes': [{'name': 'rt-test-api-default-1', 'paths': ['/api']}]
                }
                
                # Create mock entity root (simplified)
                import xml.etree.ElementTree as ET
                entity_xml = '''
                <ProxyEndpoint name="default">
                    <PreFlow>
                        <Request>
                            <Step><Name>verify-api-key</Name></Step>
                            <Step><Name>javascript-policy</Name></Step>
                        </Request>
                        <Response>
                            <Step><Name>data-capture</Name></Step>
                        </Response>
                    </PreFlow>
                </ProxyEndpoint>
                '''
                entity_root = ET.fromstring(entity_xml)
                
                # Run migration
                result = engine.migrate_policies_for_entity(
                    "route", "default", entity_root, output_data, 
                    "test-api", str(temp_path / "policies"), None
                )
                
                if not result:
                    self.logger.error("End-to-end migration returned False")
                    return False
                
                # Check if plugins were added
                routes = output_data.get('routes', [])
                if not routes or 'plugins' not in routes[0]:
                    self.logger.error("No plugins were attached to routes")
                    return False
                
                plugins = routes[0]['plugins']
                if len(plugins) == 0:
                    self.logger.error("No plugins were generated")
                    return False
                
                self.logger.info(f"End-to-end migration: PASSED - Generated {len(plugins)} plugins")
                return True
                
        except Exception as e:
            self.logger.error(f"End-to-end migration: FAILED - {e}")
            return False
    
    def test_complex_policies(self) -> bool:
        """Test complex policy scenarios"""
        try:
            # Test multiple policies with dependencies
            complex_policies = [
                {
                    '_policy_name': 'verify-api-key',
                    '_policy_type': 'VerifyAPIKey',
                    'enabled': True,
                    '_resource_files': {}
                },
                {
                    '_policy_name': 'javascript-transform',
                    '_policy_type': 'JavaScript',
                    'enabled': True,
                    '_resource_files': {
                        'jsc://transform.js': self.complex_js_code
                    }
                },
                {
                    '_policy_name': 'python-validator',
                    '_policy_type': 'PythonScript',
                    'enabled': True,
                    '_resource_files': {
                        'py://validator.py': self.complex_python_code
                    }
                }
            ]
            
            # Mock migration engine components
            converter = EnhancedResourceConverter()
            
            # Test resource conversion for each policy
            for policy in complex_policies:
                if policy['_resource_files']:
                    for resource_url, content in policy['_resource_files'].items():
                        lua_code = converter.convert_resource_to_lua(
                            resource_url, content, policy['_policy_type']
                        )
                        
                        if not lua_code:
                            self.logger.error(f"Failed to convert resource for {policy['_policy_name']}")
                            return False
            
            self.logger.info("Complex policies: PASSED")
            return True
            
        except Exception as e:
            self.logger.error(f"Complex policies: FAILED - {e}")
            return False
    
    def test_error_handling(self) -> bool:
        """Test error handling scenarios"""
        try:
            converter = EnhancedResourceConverter()
            
            # Test with invalid JavaScript
            invalid_js = "function invalid() { this is not valid javascript }"
            lua_code = converter.convert_resource_to_lua("jsc://invalid.js", invalid_js, "JavaScript")
            
            # Should return fallback Lua, not None
            if not lua_code or "fallback" not in lua_code.lower():
                self.logger.error("Error handling didn't provide fallback for invalid JS")
                return False
            
            # Test with empty content
            empty_lua = converter.convert_resource_to_lua("jsc://empty.js", "", "JavaScript")
            if not empty_lua or "placeholder" not in empty_lua.lower():
                self.logger.error("Error handling didn't provide placeholder for empty content")
                return False
            
            # Test conflict resolver with invalid data
            resolver = EnhancedPluginConflictResolver()
            invalid_plugins = [{'invalid': 'plugin'}]
            
            # Should not crash
            resolved = resolver.resolve_plugin_conflicts(invalid_plugins, "test")
            if resolved is None:
                self.logger.error("Conflict resolver crashed on invalid input")
                return False
            
            self.logger.info("Error handling: PASSED")
            return True
            
        except Exception as e:
            self.logger.error(f"Error handling: FAILED - {e}")
            return False
    
    def _setup_test_environment(self, temp_path: Path):
        """Setup test environment with mock files"""
        # Create directories
        policies_dir = temp_path / "policies"
        policies_dir.mkdir(parents=True)
        
        templates_dir = temp_path / "templates"
        templates_dir.mkdir(parents=True)
        
        mappers_dir = temp_path / "mappers"
        mappers_dir.mkdir(parents=True)
        
        # Create mock policy files
        policy_files = {
            "verify-api-key.xml": '''
            <VerifyAPIKey name="verify-api-key">
                <APIKey ref="request.queryparam.apikey"/>
            </VerifyAPIKey>
            ''',
            "javascript-policy.xml": '''
            <Javascript name="javascript-policy">
                <ResourceURL>jsc://transform.js</ResourceURL>
            </Javascript>
            ''',
            "data-capture.xml": '''
            <DataCapture name="data-capture">
                <CaptureResource ref="request"/>
                <CaptureResource ref="response"/>
            </DataCapture>
            '''
        }
        
        for filename, content in policy_files.items():
            (policies_dir / filename).write_text(content)
        
        # Create mock resource file
        resources_dir = policies_dir.parent / "resources" / "jsc"
        resources_dir.mkdir(parents=True)
        (resources_dir / "transform.js").write_text(self.complex_js_code)
        
        # Create mock mapper
        mapper_content = {
            "VerifyAPIKey": [
                {"plugin_name": "key-auth", "api_flow": "request"},
                {"plugin_name": "luascriptexecuter", "api_flow": "both"}
            ],
            "Javascript": [
                {"plugin_name": "javascript", "api_flow": "both"},
                {"plugin_name": "luascriptexecuter", "api_flow": "both"}
            ],
            "DataCapture": [
                {"plugin_name": "datacapture", "api_flow": "both"},
                {"plugin_name": "http-log", "api_flow": "both"},
                {"plugin_name": "luascriptexecuter", "api_flow": "both"}
            ]
        }
        
        (mappers_dir / "policy-to-plugin-mapper.json").write_text(json.dumps(mapper_content, indent=2))
        
        # Create basic templates
        templates = {
            "key-auth.yml.j2": '''
name: key-auth
config:
  key_names: ["apikey"]
tags:
  - "api:{{ api_name }}"
            ''',
            "luascriptexecuter.yml.j2": '''
name: luascriptexecuter
config:
  script: |
{{ lua_code | indent_lua(4) if lua_code else "    kong.log.info('No script')" }}
  enabled: true
  timeout: 30000
tags:
  - "api:{{ api_name }}"
            '''
        }
        
        for filename, content in templates.items():
            (templates_dir / filename).write_text(content)
    
    def print_test_summary(self):
        """Print test results summary"""
        self.logger.info("\\n" + "="*60)
        self.logger.info("TEST RESULTS SUMMARY")
        self.logger.info("="*60)
        
        passed = 0
        failed = 0
        
        for suite_name, result, error in self.test_results:
            status = "PASSED" if result else "FAILED"
            self.logger.info(f"{suite_name}: {status}")
            if error:
                self.logger.info(f"  Error: {error}")
            
            if result:
                passed += 1
            else:
                failed += 1
        
        self.logger.info("="*60)
        self.logger.info(f"Total Tests: {len(self.test_results)}")
        self.logger.info(f"Passed: {passed}")
        self.logger.info(f"Failed: {failed}")
        self.logger.info(f"Success Rate: {(passed/len(self.test_results)*100):.1f}%")
        self.logger.info("="*60)

def main():
    """Main test runner"""
    test_suite = MigrationTestSuite()
    success = test_suite.run_all_tests()
    
    if success:
        print("\nAll tests passed! Migration tool is ready for production.")
        sys.exit(0)
    else:
        print("\nSome tests failed. Please review the issues before production use.")
        sys.exit(1)

if __name__ == "__main__":
    main()