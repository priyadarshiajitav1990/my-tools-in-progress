#!/usr/bin/env python3
"""
Comprehensive Test Suite
Tests all components with simple, medium, complex, and highly complex scenarios
"""

import unittest
import sys
import os
import json
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent))

class SimpleTests(unittest.TestCase):
    """Simple test cases - basic functionality"""
    
    def test_lua_script_generation_simple(self):
        """Test basic Lua script generation"""
        from scripts.utils.lua_script_generator import LuaScriptGenerator
        
        generator = LuaScriptGenerator()
        lua_script = generator.generate_lua_script('VerifyAPIKey', {}, 'test-policy')
        
        self.assertIn('verify_api_key', lua_script)
        self.assertIn('kong.request.get_header', lua_script)
    
    def test_config_loading_simple(self):
        """Test basic configuration loading"""
        config = {
            'apigee': {'type': 'edge_private_cloud'},
            'kong': {'version': '3.13.0'},
            'migration': {'fallback_to_lua': True}
        }
        
        self.assertEqual(config['apigee']['type'], 'edge_private_cloud')
        self.assertTrue(config['migration']['fallback_to_lua'])
    
    def test_policy_mapping_simple(self):
        """Test basic policy mapping"""
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        
        config = {'migration': {'fallback_to_lua': True}}
        engine = EnhancedPolicyMigrationWithLua(Path(__file__).parent, config)
        
        policies = [{'name': 'test', 'policyType': 'VerifyAPIKey', 'config': {}}]
        result = engine.migrate_policies_enterprise(policies, {}, 'test-api', config)
        
        self.assertIsInstance(result, dict)
        self.assertIn('request', result)

class MediumTests(unittest.TestCase):
    """Medium complexity test cases"""
    
    def test_multiple_policies_migration(self):
        """Test migration of multiple policies"""
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        
        config = {'migration': {'fallback_to_lua': True}}
        engine = EnhancedPolicyMigrationWithLua(Path(__file__).parent, config)
        
        policies = [
            {'name': 'auth', 'policyType': 'VerifyAPIKey', 'config': {}},
            {'name': 'rate', 'policyType': 'Quota', 'config': {'count': 1000}},
            {'name': 'transform', 'policyType': 'AssignMessage', 'config': {}}
        ]
        
        result = engine.migrate_policies_enterprise(policies, {}, 'test-api', config)
        
        total_plugins = sum(len(plugins) for plugins in result.values())
        self.assertGreater(total_plugins, 0)
    
    def test_consumer_impact_validation_medium(self):
        """Test consumer impact validation with warnings"""
        from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
        
        validator = ConsumerImpactValidator()
        
        apigee_config = {
            'proxy_endpoints': [{'base_path': '/api/v1', 'flows': []}],
            'policies': [
                {'policyType': 'VerifyAPIKey', 'name': 'auth'},
                {'policyType': 'Quota', 'name': 'rate', 'config': {'count': 1000}}
            ]
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1'], 'methods': ['GET']}],
            'plugins': [
                {'name': 'key-auth'},
                {'name': 'rate-limiting', 'config': {'minute': 500}}  # Different rate
            ]
        }
        
        result = validator.validate_migration_impact(apigee_config, kong_config)
        
        self.assertIn(result['consumer_impact'], ['NONE', 'LOW'])
    
    def test_resource_conversion_medium(self):
        """Test resource file conversion"""
        from scripts.utils.resource_converter_enhanced import EnhancedResourceConverter
        
        converter = EnhancedResourceConverter()
        
        js_content = '''
        function validateRequest() {
            var method = context.getVariable("request.verb");
            return method === "GET";
        }
        '''
        
        lua_code = converter.convert_resource_to_lua('jsc://test.js', js_content, 'JavaScript')
        
        self.assertIn('function', lua_code)
        self.assertIn('kong', lua_code)

class ComplexTests(unittest.TestCase):
    """Complex test cases - multiple components interaction"""
    
    def test_end_to_end_migration_complex(self):
        """Test complete migration workflow"""
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
        from scripts.utils.api_contract_preserving_engine import APIContractPreservingEngine
        
        config = {
            'migration': {
                'fallback_to_lua': True,
                'enable_consumer_impact_validation': True,
                'enable_contract_preservation': True
            }
        }
        
        # Complex API data
        api_data = {
            'api_name': 'complex-api',
            'policies': [
                {'name': 'auth', 'policyType': 'VerifyAPIKey', 'config': {}},
                {'name': 'oauth', 'policyType': 'OAuthV2', 'config': {}},
                {'name': 'rate', 'policyType': 'Quota', 'config': {'count': 1000}},
                {'name': 'js', 'policyType': 'JavaScript', 'config': {'ResourceURL': 'jsc://test.js'}},
                {'name': 'transform', 'policyType': 'AssignMessage', 'config': {}},
                {'name': 'callout', 'policyType': 'ServiceCallout', 'config': {}},
                {'name': 'unknown', 'policyType': 'UnknownPolicy', 'config': {}}
            ],
            'resources': {
                'jsc://test.js': 'function test() { return true; }'
            },
            'proxy_endpoints': [{'base_path': '/api/v1', 'flows': []}],
            'paths': ['/api/v1/users'],
            'methods': ['GET', 'POST']
        }
        
        # Migration
        engine = EnhancedPolicyMigrationWithLua(Path(__file__).parent, config)
        migrated_plugins = engine.migrate_policies_enterprise(
            api_data['policies'], api_data['resources'], 'complex-api', config
        )
        
        # Generate Kong config
        kong_config = {
            'services': [{'name': 'test-service'}],
            'routes': [{'paths': ['/api/v1/users'], 'methods': ['GET', 'POST']}],
            'plugins': []
        }
        
        # Add plugins
        for flow, plugins in migrated_plugins.items():
            kong_config['plugins'].extend(plugins)
        
        # Validate consumer impact
        validator = ConsumerImpactValidator()
        impact_result = validator.validate_migration_impact(api_data, kong_config)
        
        # Preserve contract
        contract_engine = APIContractPreservingEngine(Path(__file__).parent, config)
        preserved_config = contract_engine.preserve_api_contract(api_data, kong_config)
        
        # Assertions
        self.assertGreater(len(preserved_config['plugins']), 0)
        self.assertIn(impact_result['consumer_impact'], ['NONE', 'LOW'])
        
        # Check Lua fallbacks were used
        stats = engine.get_migration_stats()
        self.assertGreater(stats['lua_fallbacks_used'], 0)
    
    def test_deployment_integration_complex(self):
        """Test deployment integration"""
        from deployment.deployment import DeckDeploymentManager
        
        config = {
            'kong': {
                'admin_api': 'http://localhost:8001',
                'admin_token': 'test-token'
            }
        }
        
        deployment_manager = DeckDeploymentManager(config)
        
        kong_config = {
            'services': [{'name': 'test-service', 'url': 'http://backend.com'}],
            'routes': [{'name': 'test-route', 'paths': ['/test']}],
            'plugins': [{'name': 'key-auth'}]
        }
        
        output_dir = Path(tempfile.mkdtemp())
        
        # Mock deck CLI not available
        with patch.object(deployment_manager, '_check_deck_installation', return_value=False):
            result = deployment_manager.deploy_api_configuration('test-api', kong_config, output_dir)
            self.assertEqual(result['status'], 'SKIPPED')

class HighlyComplexTests(unittest.TestCase):
    """Highly complex test cases - stress testing and edge cases"""
    
    def test_large_scale_migration(self):
        """Test migration of large number of policies"""
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        
        config = {'migration': {'fallback_to_lua': True}}
        engine = EnhancedPolicyMigrationWithLua(Path(__file__).parent, config)
        
        # Generate 50 policies of different types
        policy_types = ['VerifyAPIKey', 'OAuthV2', 'Quota', 'AssignMessage', 'JavaScript', 
                       'ServiceCallout', 'RaiseFault', 'DataCapture', 'UnknownPolicy']
        
        policies = []
        for i in range(50):
            policy_type = policy_types[i % len(policy_types)]
            policies.append({
                'name': f'policy-{i}',
                'policyType': policy_type,
                'config': {'test': f'value-{i}'}
            })
        
        result = engine.migrate_policies_enterprise(policies, {}, 'large-api', config)
        
        total_plugins = sum(len(plugins) for plugins in result.values())
        self.assertGreater(total_plugins, 40)  # Should generate plugins for most policies
        
        stats = engine.get_migration_stats()
        self.assertEqual(stats['policies_processed'], 50)
    
    def test_error_handling_complex(self):
        """Test comprehensive error handling"""
        from scripts.utils.lua_script_generator import LuaScriptGenerator
        
        generator = LuaScriptGenerator()
        
        # Test with invalid policy type
        lua_script = generator.generate_lua_script('InvalidPolicyType', {}, 'test')
        self.assertIn('generic_policy_handler', lua_script)
        
        # Test with None values
        lua_script = generator.generate_lua_script(None, None, None)
        self.assertIn('fallback_handler', lua_script)
    
    def test_concurrent_migration_simulation(self):
        """Test concurrent migration simulation"""
        import threading
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        
        config = {'migration': {'fallback_to_lua': True}}
        results = []
        
        def migrate_api(api_id):
            engine = EnhancedPolicyMigrationWithLua(Path(__file__).parent, config)
            policies = [
                {'name': f'policy-{api_id}', 'policyType': 'VerifyAPIKey', 'config': {}}
            ]
            result = engine.migrate_policies_enterprise(policies, {}, f'api-{api_id}', config)
            results.append(result)
        
        # Simulate 5 concurrent migrations
        threads = []
        for i in range(5):
            thread = threading.Thread(target=migrate_api, args=(i,))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()
        
        self.assertEqual(len(results), 5)
        for result in results:
            self.assertIsInstance(result, dict)
    
    def test_memory_usage_complex(self):
        """Test memory usage with large configurations"""
        import gc
        from scripts.utils.lua_script_generator import LuaScriptGenerator
        
        generator = LuaScriptGenerator()
        
        # Generate many Lua scripts
        scripts = []
        for i in range(100):
            script = generator.generate_lua_script('VerifyAPIKey', {'test': 'x' * 1000}, f'policy-{i}')
            scripts.append(script)
        
        # Check that scripts were generated
        self.assertEqual(len(scripts), 100)
        
        # Force garbage collection
        del scripts
        gc.collect()
    
    def test_edge_cases_complex(self):
        """Test various edge cases"""
        from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
        
        validator = ConsumerImpactValidator()
        
        # Empty configurations
        result = validator.validate_migration_impact({}, {})
        self.assertIsInstance(result, dict)
        
        # Malformed configurations
        malformed_apigee = {'policies': [{'invalid': 'data'}]}
        malformed_kong = {'plugins': [{'invalid': 'data'}]}
        
        result = validator.validate_migration_impact(malformed_apigee, malformed_kong)
        self.assertIsInstance(result, dict)

def run_all_tests():
    """Run all test suites"""
    print("=" * 80)
    print("COMPREHENSIVE TEST SUITE - ALL COMPLEXITY LEVELS")
    print("=" * 80)
    
    test_suites = [
        ('Simple Tests', SimpleTests),
        ('Medium Tests', MediumTests),
        ('Complex Tests', ComplexTests),
        ('Highly Complex Tests', HighlyComplexTests)
    ]
    
    overall_results = {
        'total_tests': 0,
        'total_failures': 0,
        'total_errors': 0,
        'suite_results': []
    }
    
    for suite_name, test_class in test_suites:
        print(f"\n{'-' * 60}")
        print(f"Running {suite_name}")
        print(f"{'-' * 60}")
        
        suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        
        suite_result = {
            'name': suite_name,
            'tests_run': result.testsRun,
            'failures': len(result.failures),
            'errors': len(result.errors),
            'success_rate': ((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100) if result.testsRun > 0 else 0
        }
        
        overall_results['suite_results'].append(suite_result)
        overall_results['total_tests'] += result.testsRun
        overall_results['total_failures'] += len(result.failures)
        overall_results['total_errors'] += len(result.errors)
    
    # Print overall summary
    print(f"\n{'=' * 80}")
    print("OVERALL TEST SUMMARY")
    print(f"{'=' * 80}")
    print(f"Total Tests Run: {overall_results['total_tests']}")
    print(f"Total Failures: {overall_results['total_failures']}")
    print(f"Total Errors: {overall_results['total_errors']}")
    
    overall_success_rate = ((overall_results['total_tests'] - overall_results['total_failures'] - overall_results['total_errors']) / overall_results['total_tests'] * 100) if overall_results['total_tests'] > 0 else 0
    print(f"Overall Success Rate: {overall_success_rate:.1f}%")
    
    print(f"\nSuite Breakdown:")
    for suite_result in overall_results['suite_results']:
        print(f"  {suite_result['name']}: {suite_result['success_rate']:.1f}% ({suite_result['tests_run']} tests)")
    
    print(f"\n{'=' * 80}")
    
    return overall_results['total_failures'] == 0 and overall_results['total_errors'] == 0

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)