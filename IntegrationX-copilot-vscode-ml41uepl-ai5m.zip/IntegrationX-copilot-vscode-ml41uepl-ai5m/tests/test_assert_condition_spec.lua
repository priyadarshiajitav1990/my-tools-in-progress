local assert_condition = require "custom-plugins.AssertCondition.handler"

describe("AssertCondition Plugin", function()
  local kong = {
    log = { debug = function() end, err = function() end },
    response = { exit = function() end },
    ctx = { shared = {} }
  }

  setup(function()
    _G.kong = kong
  end)

  it("returns 400 if condition fails", function()
    local config = { condition = "false", message = "Failed!" }
    local called = false
    kong.response.exit = function(status, body)
      called = true
      assert.are.equal(status, 400)
      assert.are.same(body, { message = "Failed!" })
    end
    -- Simulate expression loader
    package.loaded["kong.tools.expressions"] = { load = function() return function() return false end end }
    assert_condition:access(config)
    assert.is_true(called)
  end)

  it("does not call exit if condition passes", function()
    local config = { condition = "true", message = "Failed!" }
    local called = false
    kong.response.exit = function() called = true end
    package.loaded["kong.tools.expressions"] = { load = function() return function() return true end end }
    assert_condition:access(config)
    assert.is_false(called)
  end)
end)
