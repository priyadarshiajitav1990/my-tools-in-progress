local extension_callout = require "custom-plugins.ExtensionCallout.handler"

describe("ExtensionCallout Plugin", function()
  it("runs without error (placeholder)", function()
    -- Add real logic as per handler.lua implementation
    assert.is_true(true)
  end)
end)
