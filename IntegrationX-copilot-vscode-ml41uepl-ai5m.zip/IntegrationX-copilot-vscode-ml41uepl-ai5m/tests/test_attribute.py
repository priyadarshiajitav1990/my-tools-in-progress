

import sys
import types
import unittest
from unittest.mock import patch, MagicMock

# Recursive dynamic mock for any attribute access
class RecursiveMagicMock(MagicMock):
    def __getattr__(self, name):
        return self if name.startswith('__') else super().__getattr__(name)

# Mock missing 'kong' module and submodules if not present
def ensure_kong_mock():
    if 'kong' not in sys.modules:
        kong = types.ModuleType('kong')
        sys.modules['kong'] = kong
    kong = sys.modules['kong']
    # service.request
    if not hasattr(kong, 'service'):
        kong.service = types.ModuleType('kong.service')
        sys.modules['kong.service'] = kong.service
    kong.service.request = RecursiveMagicMock()
    sys.modules['kong.service.request'] = kong.service.request
    # log
    kong.log = RecursiveMagicMock()
    sys.modules['kong.log'] = kong.log
ensure_kong_mock()

# Mock missing 'kong' module and submodules if not present
if 'kong' not in sys.modules:
    kong = types.ModuleType('kong')
    kong.service = types.ModuleType('kong.service')
    kong.service.request = MagicMock()
    kong.log = MagicMock()
    setattr(kong.service, 'request', kong.service.request)
    sys.modules['kong'] = kong
    sys.modules['kong.service'] = kong.service
    sys.modules['kong.service.request'] = kong.service.request
    sys.modules['kong.log'] = kong.log

# Example test for Attribute plugin
class TestAttributePlugin(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Skip tests if plugin handler is missing
        try:
            __import__('custom-plugins.Attribute.handler')
        except ModuleNotFoundError:
            raise unittest.SkipTest('custom-plugins.Attribute.handler not found')
    @patch('kong.service.request')
    @patch('kong.log')
    def test_remove_headers(self, mock_log, mock_request):
        config = type('Config', (), {'remove': {'headers': ['X-Test']}, 'add': None, 'set': None, 'assign_variable': None})
        plugin = __import__('custom-plugins.Attribute.handler').Attribute
        plugin: object = plugin
        plugin.access(config)
        mock_request.remove_header.assert_called_with('X-Test')

    @patch('kong.service.request')
    @patch('kong.log')
    def test_add_headers(self, mock_log, mock_request):
        config = type('Config', (), {'remove': None, 'add': {'headers': {'X-Test': 'val'}}, 'set': None, 'assign_variable': None})
        plugin = __import__('custom-plugins.Attribute.handler').Attribute
        plugin: object = plugin
        plugin.access(config)
        mock_request.add_header.assert_called_with('X-Test', 'val')

    @patch('kong.service.request')
    @patch('kong.log')
    def test_set_headers(self, mock_log, mock_request):
        config = type('Config', (), {'remove': None, 'add': None, 'set': {'headers': {'X-Test': 'val'}}, 'assign_variable': None})
        plugin = __import__('custom-plugins.Attribute.handler').Attribute
        plugin: object = plugin
        plugin.access(config)
        mock_request.set_header.assert_called_with('X-Test', 'val')

if __name__ == '__main__':
    unittest.main()
