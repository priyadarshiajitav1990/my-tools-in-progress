local data_capture = require "custom-plugins.DataCapture.handler"

describe("DataCapture Plugin", function()
  local kong = {
    request = {
      get_header = function() return "header-value" end,
      get_query = function() return { q = "query-value" } end,
      get_raw_body = function() return "body-value" end
    },
    response = {
      get_headers = function() return { ["X-Test"] = "header-value" } end,
      get_raw_body = function() return "response-body" end
    },
    log = { err = function() end },
    ctx = { shared = {} }
  }

  setup(function()
    _G.kong = kong
  end)

  it("writes log file", function()
    local config = {
      capture = {
        request = { headers = { "X-Test" }, query_params = { "q" }, body = true },
        response = { headers = { "X-Test" }, body = true }
      },
      log_path = "test.log"
    }
    local file_mock = {
      write = function(self, line) self.written = line end,
      close = function(self) self.closed = true end
    }
    _G.io = { open = function() return file_mock end }
    _G.cjson = { encode = function() return "{}" end }
    data_capture:log(config)
    assert.is_true(file_mock.closed)
    assert.are.equal(file_mock.written, "{}\n")
  end)
end)
