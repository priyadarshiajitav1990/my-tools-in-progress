#!/usr/bin/env python3
"""
Comprehensive Test Suite for Production Apigee to Kong Migration Tool
Tests all components with simple, medium, complex, and highly complex scenarios
"""

import sys
import os
import json
import tempfile
import shutil
import unittest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

# Add scripts directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))

# Import components to test
from scripts.utils.lua_script_generator import LuaScriptGenerator
from scripts.utils.enterprise_logger import get_enterprise_logger
from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
from scripts.utils.api_contract_preserving_engine import APIContractPreservingEngine
from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
from scripts.start_production import ProductionMigrationTool

class TestLuaScriptGenerator(unittest.TestCase):
    """Test Lua script generation for all policy types"""
    
    def setUp(self):
        self.generator = LuaScriptGenerator()
    
    def test_simple_verify_api_key_generation(self):
        """Test simple VerifyAPIKey policy Lua generation"""
        config = {'APIKey': {'ref': 'request.header.x-api-key'}}
        lua_script = self.generator.generate_lua_script('VerifyAPIKey', config, 'test-policy')
        
        self.assertIn('verify_api_key', lua_script)
        self.assertIn('kong.request.get_header', lua_script)
        self.assertIn('API key required', lua_script)
    
    def test_medium_assign_message_generation(self):
        """Test medium complexity AssignMessage policy"""
        config = {
            'Add': {'Headers': {'X-Custom': 'value1', 'X-Source': 'apigee'}},
            'Set': {'Headers': {'Content-Type': 'application/json'}},
            'Remove': {'Headers': ['X-Debug']}
        }
        lua_script = self.generator.generate_lua_script('AssignMessage', config, 'assign-msg')
        
        self.assertIn('assign_message', lua_script)
        self.assertIn('set_header', lua_script)
        self.assertIn('clear_header', lua_script)
        self.assertIn('X-Custom', lua_script)
    
    def test_complex_javascript_with_resource(self):
        """Test complex JavaScript policy with resource content"""
        config = {'ResourceURL': 'jsc://complex-logic.js'}
        resource_content = '''
function processRequest() {
    var method = context.getVariable("request.verb");
    var path = context.getVariable("request.uri");
    if (method === "POST" && path.includes("/secure")) {
        context.setVariable("security.level", "high");
        return validateSecureRequest();
    }
    return true;
}
'''
        lua_script = self.generator.generate_lua_script('JavaScript', config, 'js-policy', resource_content)
        
        self.assertIn('javascript_handler', lua_script)
        self.assertIn('processRequest', lua_script)
        self.assertIn('getVariable', lua_script)
        self.assertIn('setVariable', lua_script)
    
    def test_highly_complex_service_callout(self):
        """Test highly complex ServiceCallout policy"""
        config = {
            'HTTPTargetConnection': {
                'URL': 'https://validation.api.com/v2/validate',
                'Authentication': {'Type': 'OAuth2'}
            },
            'Request': {
                'Verb': 'POST',
                'Headers': {'Content-Type': 'application/json', 'X-API-Version': '2.0'}
            },
            'Response': {
                'Variable': 'callout.response'
            }
        }
        lua_script = self.generator.generate_lua_script('ServiceCallout', config, 'complex-callout')
        
        self.assertIn('service_callout', lua_script)
        self.assertIn('https://validation.api.com', lua_script)
        self.assertIn('request_uri', lua_script)
        self.assertIn('callout_response', lua_script)
    
    def test_fallback_for_unknown_policy(self):
        """Test fallback Lua generation for unknown policy types"""
        config = {'custom_param': 'value'}
        lua_script = self.generator.generate_lua_script('UnknownPolicy', config, 'unknown')
        
        self.assertIn('Generic Policy Implementation', lua_script)
        self.assertIn('UnknownPolicy', lua_script)
        self.assertIn('generic_policy_handler', lua_script)
    
    def test_error_handling_in_generation(self):
        """Test error handling during Lua generation"""
        # Test with invalid config that might cause errors
        config = {'invalid': object()}  # Non-serializable object
        lua_script = self.generator.generate_lua_script('VerifyAPIKey', config, 'error-test')
        
        # Should return fallback script
        self.assertIn('fallback_handler', lua_script)
        self.assertIn('Policy generation failed', lua_script)

class TestEnterpriseLogger(unittest.TestCase):
    """Test enterprise logging functionality"""
    
    def test_logger_initialization(self):
        """Test logger initialization with configuration"""
        config = {
            'logging': {
                'level': 'INFO',
                'file_enabled': True,
                'console_enabled': True
            }
        }
        logger = get_enterprise_logger('test-logger', config)
        
        self.assertIsNotNone(logger)
        self.assertEqual(logger.name, 'test-logger')
    
    def test_structured_logging(self):
        """Test structured logging with context"""
        config = {'logging': {'level': 'DEBUG'}}
        logger = get_enterprise_logger('structured-test', config)
        
        # Test that logger can handle structured data
        logger.info("Test message", extra={'api_name': 'test-api', 'operation': 'migration'})
        
        # Should not raise exceptions
        self.assertTrue(True)

class TestConsumerImpactValidator(unittest.TestCase):
    """Test consumer impact validation"""
    
    def setUp(self):
        self.validator = ConsumerImpactValidator()
    
    def test_simple_no_impact_validation(self):
        """Test validation with no consumer impact"""
        apigee_api = {
            'api_name': 'simple-api',
            'paths': ['/api/v1/users'],
            'methods': ['GET', 'POST']
        }
        kong_config = {
            'routes': [{
                'paths': ['/api/v1/users'],
                'methods': ['GET', 'POST']
            }]
        }
        
        result = self.validator.validate_migration_impact(apigee_api, kong_config)
        
        self.assertEqual(result['consumer_impact'], 'NONE')
        self.assertEqual(len(result['breaking_changes']), 0)
    
    def test_medium_impact_path_changes(self):
        """Test validation with path changes"""
        apigee_api = {
            'api_name': 'path-change-api',
            'paths': ['/api/v1/users', '/api/v1/orders'],
            'methods': ['GET', 'POST']
        }
        kong_config = {
            'routes': [{
                'paths': ['/api/v2/users', '/api/v1/orders'],  # Changed v1 to v2
                'methods': ['GET', 'POST']
            }]
        }
        
        result = self.validator.validate_migration_impact(apigee_api, kong_config)
        
        self.assertIn(result['consumer_impact'], ['LOW', 'MEDIUM'])
        self.assertGreater(len(result.get('warnings', [])), 0)
    
    def test_high_impact_method_removal(self):
        """Test validation with method removal (breaking change)"""
        apigee_api = {
            'api_name': 'method-removal-api',
            'paths': ['/api/v1/data'],
            'methods': ['GET', 'POST', 'PUT', 'DELETE']
        }
        kong_config = {
            'routes': [{
                'paths': ['/api/v1/data'],
                'methods': ['GET', 'POST']  # Removed PUT and DELETE
            }]
        }
        
        result = self.validator.validate_migration_impact(apigee_api, kong_config)
        
        self.assertEqual(result['consumer_impact'], 'HIGH')
        self.assertGreater(len(result['breaking_changes']), 0)
    
    def test_complex_plugin_impact_analysis(self):
        """Test complex plugin impact analysis"""
        apigee_api = {
            'api_name': 'complex-api',
            'policies': [
                {'name': 'auth', 'policyType': 'VerifyAPIKey'},
                {'name': 'transform', 'policyType': 'AssignMessage'}
            ]
        }
        kong_config = {
            'plugins': [
                {'name': 'key-auth'},
                {'name': 'request-transformer'},
                {'name': 'luascriptexecuter'}  # Fallback plugin
            ]
        }
        
        result = self.validator.validate_migration_impact(apigee_api, kong_config)
        
        # Should detect potential impact from fallback plugins
        self.assertIsNotNone(result.get('plugin_analysis'))

class TestAPIContractPreservingEngine(unittest.TestCase):
    """Test API contract preservation"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config = {'migration': {'preserve_apigee_ordering': True}}
        self.engine = APIContractPreservingEngine(Path(self.temp_dir), self.config)
    
    def tearDown(self):
        shutil.rmtree(self.temp_dir)
    
    def test_simple_contract_preservation(self):
        """Test simple contract preservation"""
        apigee_api = {
            'api_name': 'contract-test',
            'paths': ['/api/v1/test'],
            'methods': ['GET']
        }
        kong_config = {
            'routes': [{'paths': ['/api/v1/test'], 'methods': ['GET']}]
        }
        
        preserved_config = self.engine.preserve_api_contract(apigee_api, kong_config)
        
        self.assertIsNotNone(preserved_config)
        self.assertEqual(preserved_config['routes'][0]['paths'], ['/api/v1/test'])
    
    def test_complex_contract_with_transformations(self):
        """Test contract preservation with transformations"""
        apigee_api = {
            'api_name': 'transform-api',
            'policies': [
                {
                    'name': 'request-transform',
                    'policyType': 'AssignMessage',
                    'config': {'Add': {'Headers': {'X-Source': 'apigee'}}}
                }
            ]
        }
        kong_config = {
            'plugins': [
                {
                    'name': 'request-transformer',
                    'config': {'add': {'headers': ['X-Source:kong']}}
                }
            ]
        }
        
        preserved_config = self.engine.preserve_api_contract(apigee_api, kong_config)
        
        # Should preserve original header value
        plugin_config = preserved_config['plugins'][0]['config']
        self.assertIn('X-Source:apigee', str(plugin_config))

class TestEnhancedPolicyMigration(unittest.TestCase):
    """Test enhanced policy migration with Lua fallbacks"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config = {
            'migration': {
                'fallback_to_lua': True,
                'enable_plugin_optimization': True
            }
        }
        self.migration_engine = EnhancedPolicyMigrationWithLua(Path(self.temp_dir), self.config)
    
    def tearDown(self):
        shutil.rmtree(self.temp_dir)
    
    def test_simple_policy_migration(self):
        """Test simple policy to plugin migration"""
        policies = [
            {
                'name': 'api-key-check',
                'policyType': 'VerifyAPIKey',
                'config': {'APIKey': {'ref': 'request.header.x-api-key'}}
            }
        ]
        
        result = self.migration_engine.migrate_policies_enterprise(
            policies, {}, 'test-api', self.config
        )
        
        self.assertIsNotNone(result)
        self.assertIn('request', result)
    
    def test_medium_complexity_with_resources(self):
        """Test medium complexity migration with resource files"""
        policies = [
            {
                'name': 'js-validation',
                'policyType': 'JavaScript',
                'config': {'ResourceURL': 'jsc://validate.js'}
            }
        ]
        resources = {
            'js-validation': {
                'jsc://validate.js': 'function validate() { return true; }'
            }
        }
        
        result = self.migration_engine.migrate_policies_enterprise(
            policies, resources, 'js-api', self.config
        )
        
        self.assertIsNotNone(result)
        # Should have fallback to luascriptexecuter
        plugins = result.get('request', [])
        lua_plugins = [p for p in plugins if p.get('name') == 'luascriptexecuter']
        self.assertGreater(len(lua_plugins), 0)
    
    def test_complex_multi_policy_migration(self):
        """Test complex migration with multiple policies"""
        policies = [
            {'name': 'auth', 'policyType': 'VerifyAPIKey', 'config': {}},
            {'name': 'quota', 'policyType': 'Quota', 'config': {'count': 1000}},
            {'name': 'transform', 'policyType': 'AssignMessage', 'config': {}},
            {'name': 'callout', 'policyType': 'ServiceCallout', 'config': {}}
        ]
        
        result = self.migration_engine.migrate_policies_enterprise(
            policies, {}, 'complex-api', self.config
        )
        
        self.assertIsNotNone(result)
        total_plugins = sum(len(plugins) for plugins in result.values())
        self.assertGreaterEqual(total_plugins, len(policies))
    
    def test_highly_complex_with_conflicts(self):
        """Test highly complex migration with plugin conflicts"""
        policies = [
            {'name': 'auth1', 'policyType': 'VerifyAPIKey', 'config': {}},
            {'name': 'auth2', 'policyType': 'BasicAuthentication', 'config': {}},
            {'name': 'rate1', 'policyType': 'Quota', 'config': {'count': 1000}},
            {'name': 'rate2', 'policyType': 'SpikeArrest', 'config': {'rate': '10ps'}},
            {'name': 'js1', 'policyType': 'JavaScript', 'config': {}},
            {'name': 'js2', 'policyType': 'JavaScript', 'config': {}}
        ]
        
        result = self.migration_engine.migrate_policies_enterprise(
            policies, {}, 'conflict-api', self.config
        )
        
        self.assertIsNotNone(result)
        # Should handle conflicts and optimize plugins
        stats = self.migration_engine.get_migration_stats()
        self.assertGreater(stats.get('conflicts_resolved', 0), 0)

class TestProductionMigrationTool(unittest.TestCase):
    """Test production migration tool end-to-end"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        # Mock configuration
        self.mock_config = {
            'apigee': {'type': 'edge_private_cloud', 'organization': 'test'},
            'kong': {'admin_api': 'http://test:8001'},
            'migration': {
                'input_dir': 'input',
                'output_dir': 'output',
                'enable_deck_deployment': False,
                'max_acceptable_consumer_impact': 'MEDIUM'
            },
            'logging': {'level': 'INFO'}
        }
    
    def tearDown(self):
        shutil.rmtree(self.temp_dir)
    
    @patch('start_production.ProductionMigrationTool._load_configuration')
    def test_tool_initialization(self, mock_config):
        """Test production tool initialization"""
        mock_config.return_value = self.mock_config
        
        tool = ProductionMigrationTool()
        
        self.assertIsNotNone(tool.config)
        self.assertIsNotNone(tool.logger)
        self.assertIsNotNone(tool.consumer_validator)
    
    @patch('start_production.ProductionMigrationTool._load_configuration')
    @patch('start_production.ProductionMigrationTool._extract_and_process_apis')
    def test_simple_migration_workflow(self, mock_extract, mock_config):
        """Test simple migration workflow"""
        mock_config.return_value = self.mock_config
        mock_extract.return_value = [{
            'api_name': 'simple-test-api',
            'policies': [{'name': 'auth', 'policyType': 'VerifyAPIKey'}],
            'target_url': 'http://backend.com'
        }]
        
        tool = ProductionMigrationTool()
        
        # Mock file operations
        with patch('builtins.open', create=True), \
             patch('pathlib.Path.mkdir'), \
             patch('pathlib.Path.exists', return_value=True):
            
            result = tool.run_production_migration()
            
            self.assertTrue(result)
    
    def test_consumer_impact_validation_integration(self):
        """Test consumer impact validation integration"""
        with patch('start_production.ProductionMigrationTool._load_configuration') as mock_config:
            mock_config.return_value = self.mock_config
            
            tool = ProductionMigrationTool()
            
            # Test impact validation
            api_data = {'api_name': 'test', 'paths': ['/api'], 'methods': ['GET']}
            kong_config = {'routes': [{'paths': ['/api'], 'methods': ['GET']}]}
            
            impact = tool.consumer_validator.validate_migration_impact(api_data, kong_config)
            
            self.assertIn('consumer_impact', impact)

class TestIntegrationScenarios(unittest.TestCase):
    """Test integration scenarios with realistic data"""
    
    def test_simple_api_end_to_end(self):
        """Test simple API migration end-to-end"""
        # Simple API with basic authentication
        api_data = {
            'api_name': 'simple-users-api',
            'policies': [
                {'name': 'verify-key', 'policyType': 'VerifyAPIKey', 'config': {}}
            ],
            'target_url': 'https://users.backend.com',
            'paths': ['/users'],
            'methods': ['GET', 'POST']
        }
        
        # Test Lua generation
        generator = LuaScriptGenerator()
        lua_script = generator.generate_lua_script('VerifyAPIKey', {}, 'verify-key')
        
        self.assertIn('verify_api_key', lua_script)
        
        # Test consumer impact
        validator = ConsumerImpactValidator()
        kong_config = {
            'routes': [{'paths': ['/users'], 'methods': ['GET', 'POST']}],
            'plugins': [{'name': 'key-auth'}]
        }
        
        impact = validator.validate_migration_impact(api_data, kong_config)
        self.assertEqual(impact['consumer_impact'], 'NONE')
    
    def test_medium_complexity_api(self):
        """Test medium complexity API with multiple policies"""
        api_data = {
            'api_name': 'orders-api',
            'policies': [
                {'name': 'auth', 'policyType': 'VerifyAPIKey', 'config': {}},
                {'name': 'quota', 'policyType': 'Quota', 'config': {'count': 1000}},
                {'name': 'transform', 'policyType': 'AssignMessage', 'config': {
                    'Add': {'Headers': {'X-API-Version': '1.0'}}
                }}
            ],
            'target_url': 'https://orders.backend.com',
            'paths': ['/orders', '/orders/{id}'],
            'methods': ['GET', 'POST', 'PUT']
        }
        
        # Test multiple Lua generations
        generator = LuaScriptGenerator()
        
        for policy in api_data['policies']:
            lua_script = generator.generate_lua_script(
                policy['policyType'], 
                policy['config'], 
                policy['name']
            )
            self.assertIsNotNone(lua_script)
            self.assertIn('return', lua_script)
    
    def test_complex_api_with_javascript(self):
        """Test complex API with JavaScript resources"""
        js_code = '''
function validateOrder(request) {
    var orderData = JSON.parse(request.content);
    if (!orderData.customerId || !orderData.items) {
        throw new Error("Invalid order data");
    }
    context.setVariable("order.validated", "true");
    return true;
}
validateOrder(context.getVariable("request"));
'''
        
        api_data = {
            'api_name': 'complex-orders-api',
            'policies': [
                {'name': 'validate-order', 'policyType': 'JavaScript', 'config': {
                    'ResourceURL': 'jsc://validate-order.js'
                }},
                {'name': 'callout', 'policyType': 'ServiceCallout', 'config': {
                    'HTTPTargetConnection': {'URL': 'https://validation.service.com'},
                    'Request': {'Verb': 'POST'}
                }}
            ],
            'resources': {
                'jsc://validate-order.js': js_code
            }
        }
        
        # Test JavaScript to Lua conversion
        generator = LuaScriptGenerator()
        lua_script = generator.generate_lua_script(
            'JavaScript', 
            api_data['policies'][0]['config'], 
            'validate-order',
            js_code
        )
        
        self.assertIn('javascript_handler', lua_script)
        self.assertIn('validateOrder', lua_script)
    
    def test_highly_complex_enterprise_api(self):
        """Test highly complex enterprise API scenario"""
        api_data = {
            'api_name': 'enterprise-banking-api',
            'policies': [
                {'name': 'oauth', 'policyType': 'OAuthV2', 'config': {'Operation': 'VerifyAccessToken'}},
                {'name': 'jwt-validate', 'policyType': 'JWT', 'config': {'Algorithm': 'RS256'}},
                {'name': 'rate-limit', 'policyType': 'Quota', 'config': {'count': 10000, 'timeUnit': 'hour'}},
                {'name': 'spike-arrest', 'policyType': 'SpikeArrest', 'config': {'rate': '100ps'}},
                {'name': 'request-validate', 'policyType': 'JavaScript', 'config': {}},
                {'name': 'audit-log', 'policyType': 'DataCapture', 'config': {}},
                {'name': 'fraud-check', 'policyType': 'ServiceCallout', 'config': {}},
                {'name': 'response-transform', 'policyType': 'AssignMessage', 'config': {}},
                {'name': 'json-threat', 'policyType': 'JSONThreatProtection', 'config': {}},
                {'name': 'xml-threat', 'policyType': 'XMLThreatProtection', 'config': {}}
            ],
            'target_url': 'https://banking.backend.com',
            'paths': ['/banking/v2/accounts', '/banking/v2/transactions'],
            'methods': ['GET', 'POST', 'PUT', 'DELETE']
        }
        
        # Test all policy types
        generator = LuaScriptGenerator()
        
        for policy in api_data['policies']:
            lua_script = generator.generate_lua_script(
                policy['policyType'], 
                policy['config'], 
                policy['name']
            )
            
            self.assertIsNotNone(lua_script)
            self.assertIn('function', lua_script)
            self.assertIn('return', lua_script)
        
        # Test consumer impact for complex API
        validator = ConsumerImpactValidator()
        kong_config = {
            'routes': [{
                'paths': ['/banking/v2/accounts', '/banking/v2/transactions'],
                'methods': ['GET', 'POST', 'PUT', 'DELETE']
            }],
            'plugins': [
                {'name': 'oauth2'},
                {'name': 'jwt'},
                {'name': 'rate-limiting'},
                {'name': 'luascriptexecuter'},  # Multiple fallbacks
                {'name': 'luascriptexecuter'},
                {'name': 'luascriptexecuter'}
            ]
        }
        
        impact = validator.validate_migration_impact(api_data, kong_config)
        
        # Complex API should have some impact due to fallbacks
        self.assertIn(impact['consumer_impact'], ['LOW', 'MEDIUM', 'HIGH'])

class TestConcurrentMigration(unittest.TestCase):
    """Test concurrent migration scenarios"""
    
    def test_multiple_api_migration_simulation(self):
        """Test migration of multiple APIs concurrently"""
        apis = [
            {'api_name': f'api-{i}', 'policies': [
                {'name': 'auth', 'policyType': 'VerifyAPIKey', 'config': {}}
            ]} for i in range(5)
        ]
        
        generator = LuaScriptGenerator()
        results = []
        
        # Simulate concurrent processing
        for api in apis:
            for policy in api['policies']:
                lua_script = generator.generate_lua_script(
                    policy['policyType'], 
                    policy['config'], 
                    policy['name']
                )
                results.append(lua_script)
        
        # All should succeed
        self.assertEqual(len(results), 5)
        for result in results:
            self.assertIn('verify_api_key', result)

def run_comprehensive_tests():
    """Run all comprehensive tests"""
    print("Running Comprehensive Test Suite")
    print("=" * 60)
    
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add all test classes
    test_classes = [
        TestLuaScriptGenerator,
        TestEnterpriseLogger,
        TestConsumerImpactValidator,
        TestAPIContractPreservingEngine,
        TestEnhancedPolicyMigration,
        TestProductionMigrationTool,
        TestIntegrationScenarios,
        TestConcurrentMigration
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Print summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    print(f"Tests Run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success Rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print(f"\nFAILURES ({len(result.failures)}):")
        for test, traceback in result.failures:
            print(f"  - {test}")
    
    if result.errors:
        print(f"\nERRORS ({len(result.errors)}):")
        for test, traceback in result.errors:
            print(f"  - {test}")
    
    if not result.failures and not result.errors:
        print("\nALL TESTS PASSED!")
        print("Production migration tool is ready for deployment!")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_comprehensive_tests()
    sys.exit(0 if success else 1)