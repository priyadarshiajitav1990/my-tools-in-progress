#!/usr/bin/env python3
"""
Comprehensive Production Migration Test
Tests all components of the production-ready migration tool
"""

import unittest
import sys
import os
import json
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

class TestProductionMigrationTool(unittest.TestCase):
    """Test the complete production migration workflow"""
    
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.project_root = Path(__file__).parent
        
        # Create mock configuration
        self.config = {
            'apigee': {
                'type': 'edge_private_cloud',
                'admin_api': 'http://apigee:8080/v1',
                'organization': 'test-org',
                'environment': 'test'
            },
            'kong': {
                'version': 'kong-enterprise-v3.13.0.0',
                'admin_api': 'http://kong:8001'
            },
            'migration': {
                'enable_consumer_impact_validation': True,
                'enable_contract_preservation': True,
                'fallback_to_lua': True,
                'max_acceptable_consumer_impact': 'LOW'
            }
        }
    
    def test_lua_script_generator(self):
        """Test Lua script generation for various policy types"""
        from scripts.utils.lua_script_generator import LuaScriptGenerator
        
        generator = LuaScriptGenerator()
        
        # Test VerifyAPIKey policy
        lua_script = generator.generate_lua_script(
            'VerifyAPIKey',
            {'APIKey': {'ref': 'request.header.x-api-key'}},
            'test-api-key-policy'
        )
        
        self.assertIn('verify_api_key', lua_script)
        self.assertIn('kong.request.get_header', lua_script)
        self.assertIn('test-api-key-policy', lua_script)
    
    def test_enhanced_policy_migration(self):
        """Test enhanced policy migration with Lua fallback"""
        from scripts.core.enhanced_policy_migration_with_lua import EnhancedPolicyMigrationWithLua
        
        engine = EnhancedPolicyMigrationWithLua(self.project_root, self.config)
        
        policies = [
            {
                'name': 'test-policy',
                'policyType': 'VerifyAPIKey',
                'config': {'APIKey': {'ref': 'request.header.x-api-key'}}
            },
            {
                'name': 'unknown-policy',
                'policyType': 'UnknownPolicyType',
                'config': {}
            }
        ]
        
        result = engine.migrate_policies_enterprise(policies, {}, 'test-api', self.config)
        
        # Should have plugins for both policies
        total_plugins = sum(len(plugins) for plugins in result.values())
        self.assertGreater(total_plugins, 0)
        
        # Should have used Lua fallback for unknown policy
        stats = engine.get_migration_stats()
        self.assertGreater(stats['lua_fallbacks_used'], 0)
    
    def test_consumer_impact_validation(self):
        """Test consumer impact validation"""
        from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
        
        validator = ConsumerImpactValidator()
        
        apigee_config = {
            'proxy_endpoints': [{
                'base_path': '/api/v1',
                'flows': [{'name': 'test-flow', 'condition': 'request.verb = "GET"'}]
            }],
            'policies': [{'policyType': 'VerifyAPIKey', 'name': 'auth'}]
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1'], 'methods': ['GET']}],
            'plugins': [{'name': 'key-auth'}]
        }
        
        result = validator.validate_migration_impact(apigee_config, kong_config)
        
        self.assertIn(result['consumer_impact'], ['NONE', 'LOW'])
        self.assertTrue(result['contract_preserved'])
    
    def test_api_contract_preservation(self):
        """Test API contract preservation"""
        from scripts.utils.api_contract_preserving_engine import APIContractPreservingEngine
        
        engine = APIContractPreservingEngine(self.project_root, self.config)
        
        apigee_config = {
            'base_paths': ['/api/v1'],
            'routes': [{'paths': ['/api/v1/users'], 'methods': ['GET', 'POST']}],
            'auth_requirements': [{'type': 'VerifyAPIKey'}]
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1/users'], 'methods': ['GET']}],
            'plugins': []
        }
        
        preserved_config = engine.preserve_api_contract(apigee_config, kong_config)
        
        # Should have preserved POST method
        route = preserved_config['routes'][0]
        self.assertIn('POST', route['methods'])
        
        # Should have added auth plugin
        auth_plugins = [p for p in preserved_config.get('plugins', []) if p['name'] == 'key-auth']
        self.assertGreater(len(auth_plugins), 0)
    
    def test_enterprise_logger(self):
        """Test enterprise logging functionality"""
        from scripts.utils.enterprise_logger import get_enterprise_logger, LoggingContext
        
        logger = get_enterprise_logger('test-logger', self.config)
        
        # Test basic logging
        logger.info("Test message")
        
        # Test context manager
        with LoggingContext('test-operation', api_name='test-api'):
            logger.info("Operation in progress")
    
    def test_virtual_environment_setup(self):
        """Test virtual environment setup functionality"""
        # Import the setup module
        import setup_environment
        
        manager = setup_environment.VirtualEnvironmentManager()
        
        # Test Python version check
        self.assertTrue(manager._check_python_version())
        
        # Test OS detection
        self.assertIn(manager.os_type, ['windows', 'linux', 'darwin'])
    
    def test_configuration_loading(self):
        """Test configuration loading and validation"""
        # Create temporary config file
        config_dir = self.temp_dir / "configs"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        
        with open(config_file, 'w') as f:
            json.dump(self.config, f)
        
        # Test loading
        with open(config_file, 'r') as f:
            loaded_config = json.load(f)
        
        self.assertEqual(loaded_config['apigee']['type'], 'edge_private_cloud')
        self.assertEqual(loaded_config['kong']['version'], 'kong-enterprise-v3.13.0.0')
    
    def test_output_directory_structure(self):
        """Test that output is created in API-specific directories"""
        api_name = 'test-api'
        output_dir = self.temp_dir / "output" / api_name
        output_dir.mkdir(parents=True)
        
        # Create expected files
        kong_file = output_dir / f"kong-{api_name}.yml"
        report_file = output_dir / f"{api_name}-migration-report.json"
        
        kong_file.touch()
        report_file.touch()
        
        # Verify structure
        self.assertTrue(kong_file.exists())
        self.assertTrue(report_file.exists())
        self.assertEqual(kong_file.parent.name, api_name)
    
    def test_policy_to_plugin_mapper(self):
        """Test policy to plugin mapper loading"""
        mapper_file = self.project_root / "mappers" / "policy-to-plugin-mapper.json"
        
        if mapper_file.exists():
            with open(mapper_file, 'r') as f:
                mapper = json.load(f)
            
            # Test that all policies have luascriptexecuter as fallback
            for policy_type, mappings in mapper.items():
                lua_fallback = any(m['plugin_name'] == 'luascriptexecuter' for m in mappings)
                self.assertTrue(lua_fallback, f"Policy {policy_type} missing Lua fallback")
    
    def test_requirements_file(self):
        """Test that requirements file exists and has necessary packages"""
        req_file = self.project_root / "configs" / "requirements_new.txt"
        
        if req_file.exists():
            with open(req_file, 'r') as f:
                content = f.read()
            
            # Check for essential packages
            essential_packages = ['requests', 'pyyaml', 'jinja2', 'click']
            for package in essential_packages:
                self.assertIn(package, content.lower())
    
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator')
    def test_zero_downtime_orchestration(self, mock_orchestrator):
        """Test zero-downtime migration orchestration"""
        mock_instance = Mock()
        mock_instance.orchestrate_zero_downtime_migration.return_value = {
            'status': 'COMPLETED',
            'traffic_distribution': {'apigee': 0, 'kong': 100}
        }
        mock_orchestrator.return_value = mock_instance
        
        from scripts.utils.zero_downtime_migration_orchestrator import ZeroDowntimeMigrationOrchestrator
        
        orchestrator = ZeroDowntimeMigrationOrchestrator(self.project_root, self.config)
        result = orchestrator.orchestrate_zero_downtime_migration({}, {})
        
        self.assertEqual(result['status'], 'COMPLETED')
    
    def test_os_independence(self):
        """Test OS independence features"""
        import platform
        
        # Test OS detection
        os_type = platform.system().lower()
        self.assertIn(os_type, ['windows', 'linux', 'darwin'])
        
        # Test path handling
        test_path = Path("test") / "path" / "file.txt"
        self.assertTrue(isinstance(test_path, Path))

def run_comprehensive_tests():
    """Run all comprehensive tests"""
    print("=" * 60)
    print("COMPREHENSIVE PRODUCTION MIGRATION TESTS")
    print("=" * 60)
    
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add all test methods
    test_loader = unittest.TestLoader()
    test_suite.addTests(test_loader.loadTestsFromTestCase(TestProductionMigrationTool))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Print summary
    print(f"\n{'='*60}")
    print("PRODUCTION MIGRATION TEST SUMMARY")
    print(f"{'='*60}")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print(f"\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}")
    
    if result.errors:
        print(f"\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}")
    
    print(f"\n{'='*60}")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_comprehensive_tests()
    sys.exit(0 if success else 1)