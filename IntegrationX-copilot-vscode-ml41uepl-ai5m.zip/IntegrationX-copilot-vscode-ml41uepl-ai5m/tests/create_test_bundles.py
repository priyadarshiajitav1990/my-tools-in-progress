#!/usr/bin/env python3
"""
Bulk Migration Test - Demonstrates processing multiple Apigee proxy bundles
"""

import sys
import shutil
from pathlib import Path

def create_test_bundles():
    """Create test zip files to demonstrate bulk migration"""
    
    project_root = Path(__file__).parent
    input_dir = project_root / "input"
    
    # Ensure input directory exists
    input_dir.mkdir(exist_ok=True)
    
    # Create test zip files (empty for demonstration)
    test_apis = [
        "users-api_rev1_2026_01_06.zip",
        "orders-api_rev2_2026_01_06.zip", 
        "products-api_rev1_2026_01_06.zip",
        "payments-api_rev3_2026_01_06.zip",
        "notifications-api_rev1_2026_01_06.zip"
    ]
    
    print("Creating test Apigee proxy bundles for bulk migration demonstration...")
    
    for api_zip in test_apis:
        zip_path = input_dir / api_zip
        if not zip_path.exists():
            # Create empty zip file for demonstration
            import zipfile
            with zipfile.ZipFile(zip_path, 'w') as zf:
                # Add a dummy file to make it a valid zip
                zf.writestr("apiproxy/dummy.txt", "Test API proxy bundle")
            print(f"  Created: {api_zip}")
        else:
            print(f"  Exists: {api_zip}")
    
    print(f"\nTotal test bundles created: {len(test_apis)}")
    print(f"Input directory: {input_dir}")
    print("\nRun 'python start_production.py' to migrate all APIs")

def cleanup_test_bundles():
    """Remove test zip files"""
    
    project_root = Path(__file__).parent
    input_dir = project_root / "input"
    
    if input_dir.exists():
        test_files = list(input_dir.glob("*-api_rev*.zip"))
        
        if test_files:
            print(f"Removing {len(test_files)} test bundles...")
            for test_file in test_files:
                test_file.unlink()
                print(f"  Removed: {test_file.name}")
        else:
            print("No test bundles found to remove")
    else:
        print("Input directory does not exist")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "cleanup":
        cleanup_test_bundles()
    else:
        create_test_bundles()