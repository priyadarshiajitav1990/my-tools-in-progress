#!/usr/bin/env python3
"""
Zero-Impact Migration Test Suite
Comprehensive tests to validate consumer impact protection
"""

import unittest
import json
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Import the components to test
import sys
sys.path.insert(0, str(Path(__file__).parent / "scripts"))

from scripts.utils.consumer_impact_validator import ConsumerImpactValidator
from scripts.utils.api_contract_preserving_engine import APIContractPreservingEngine
from scripts.utils.zero_downtime_migration_orchestrator import ZeroDowntimeMigrationOrchestrator

class TestConsumerImpactValidator(unittest.TestCase):
    def setUp(self):
        self.validator = ConsumerImpactValidator()
        
        # Sample Apigee configuration
        self.apigee_config = {
            'api_name': 'test-api',
            'proxy_endpoints': [{
                'base_path': '/api/v1',
                'flows': [{
                    'name': 'get-users',
                    'condition': 'request.verb = "GET" AND proxy.pathsuffix MatchesPath "/users"'
                }]
            }],
            'policies': [
                {'policyType': 'VerifyAPIKey', 'name': 'api-key-check'},
                {'policyType': 'Quota', 'name': 'rate-limit', 'config': {'count': 1000}},
                {'policyType': 'AssignMessage', 'name': 'add-headers', 'config': {'headers': {'X-API': 'test'}}}
            ]
        }
        
        # Sample Kong configuration
        self.kong_config = {
            'routes': [{'paths': ['/api/v1'], 'methods': ['GET']}],
            'plugins': [
                {'name': 'key-auth'},
                {'name': 'rate-limiting', 'config': {'minute': 1000}},
                {'name': 'request-transformer', 'config': {'add': {'headers': ['X-API:test']}}}
            ]
        }
    
    def test_no_consumer_impact_validation(self):
        """Test validation with no consumer impact"""
        result = self.validator.validate_migration_impact(self.apigee_config, self.kong_config)
        
        self.assertEqual(result['consumer_impact'], 'NONE')
        self.assertTrue(result['contract_preserved'])
        self.assertEqual(len(result['breaking_changes']), 0)
    
    def test_missing_path_detection(self):
        """Test detection of missing paths"""
        # Remove path from Kong config
        kong_config_missing_path = self.kong_config.copy()
        kong_config_missing_path['routes'] = [{'paths': ['/different/path'], 'methods': ['GET']}]
        
        result = self.validator.validate_migration_impact(self.apigee_config, kong_config_missing_path)
        
        self.assertEqual(result['consumer_impact'], 'HIGH')
        self.assertFalse(result['contract_preserved'])
        self.assertGreater(len(result['breaking_changes']), 0)
    
    def test_missing_authentication_detection(self):
        """Test detection of missing authentication"""
        # Remove auth plugin from Kong config
        kong_config_no_auth = self.kong_config.copy()
        kong_config_no_auth['plugins'] = [p for p in kong_config_no_auth['plugins'] if p['name'] != 'key-auth']
        
        result = self.validator.validate_migration_impact(self.apigee_config, kong_config_no_auth)
        
        self.assertEqual(result['consumer_impact'], 'HIGH')
        self.assertGreater(len(result['breaking_changes']), 0)
    
    def test_rate_limiting_preservation(self):
        """Test rate limiting preservation validation"""
        result = self.validator.validate_migration_impact(self.apigee_config, self.kong_config)
        
        # Should have no warnings about rate limiting
        rate_limit_warnings = [w for w in result['warnings'] if 'rate limit' in w.lower()]
        self.assertEqual(len(rate_limit_warnings), 0)
    
    def test_generate_compatibility_report(self):
        """Test compatibility report generation"""
        validation_result = {
            'consumer_impact': 'LOW',
            'contract_preserved': True,
            'breaking_changes': [],
            'warnings': ['Minor configuration difference detected'],
            'recommendations': ['Test thoroughly before deployment']
        }
        
        report = self.validator.generate_consumer_compatibility_report(validation_result)
        
        self.assertIn('API Consumer Compatibility Report', report)
        self.assertIn('LOW', report)
        self.assertIn('✓ Yes', report)
        self.assertIn('Minor configuration difference', report)

class TestAPIContractPreservingEngine(unittest.TestCase):
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.config = {'migration': {'preserve_api_contract': True}}
        self.engine = APIContractPreservingEngine(self.temp_dir, self.config)
        
        self.apigee_config = {
            'api_name': 'test-api',
            'base_paths': ['/api/v1'],
            'routes': [{
                'name': 'test-route',
                'paths': ['/api/v1/users'],
                'methods': ['GET', 'POST']
            }],
            'methods': ['GET', 'POST'],
            'auth_requirements': [{'type': 'VerifyAPIKey', 'name': 'api-key'}],
            'rate_limits': [{'type': 'Quota', 'config': {'count': 1000}}]
        }
        
        self.kong_config = {
            'routes': [{'name': 'test-route', 'paths': ['/api/v1/users'], 'methods': ['GET']}],
            'services': [{'name': 'test-service'}],
            'plugins': []
        }
    
    def test_path_preservation(self):
        """Test that all Apigee paths are preserved in Kong"""
        preserved_config = self.engine.preserve_api_contract(self.apigee_config, self.kong_config)
        
        # Check that all paths are preserved
        kong_paths = set()
        for route in preserved_config.get('routes', []):
            kong_paths.update(route.get('paths', []))
        
        apigee_paths = set(self.apigee_config['base_paths'])
        for route in self.apigee_config['routes']:
            apigee_paths.update(route['paths'])
        
        self.assertTrue(apigee_paths.issubset(kong_paths))
    
    def test_method_preservation(self):
        """Test that all HTTP methods are preserved"""
        preserved_config = self.engine.preserve_api_contract(self.apigee_config, self.kong_config)
        
        # Check that POST method was added to the route
        route = preserved_config['routes'][0]
        self.assertIn('POST', route['methods'])
        self.assertIn('GET', route['methods'])
    
    def test_auth_preservation(self):
        """Test that authentication requirements are preserved"""
        preserved_config = self.engine.preserve_api_contract(self.apigee_config, self.kong_config)
        
        # Check that auth plugin was added
        auth_plugins = [p for p in preserved_config.get('plugins', []) if p['name'] == 'key-auth']
        self.assertGreater(len(auth_plugins), 0)
    
    def test_rate_limit_preservation(self):
        """Test that rate limiting is preserved"""
        preserved_config = self.engine.preserve_api_contract(self.apigee_config, self.kong_config)
        
        # Check that rate limiting plugin was added
        rate_plugins = [p for p in preserved_config.get('plugins', []) if p['name'] == 'rate-limiting']
        self.assertGreater(len(rate_plugins), 0)
        
        # Check rate limit value
        rate_plugin = rate_plugins[0]
        self.assertEqual(rate_plugin['config']['minute'], 1000)
    
    def test_contract_validation_plugins(self):
        """Test that contract validation plugins are added"""
        preserved_config = self.engine.preserve_api_contract(self.apigee_config, self.kong_config)
        
        # Check for request validator plugin
        validator_plugins = [p for p in preserved_config.get('plugins', []) if p['name'] == 'request-validator']
        self.assertGreater(len(validator_plugins), 0)
        
        # Check for CORS plugin
        cors_plugins = [p for p in preserved_config.get('plugins', []) if p['name'] == 'cors']
        self.assertGreater(len(cors_plugins), 0)

class TestZeroDowntimeMigrationOrchestrator(unittest.TestCase):
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.config = {
            'kong': {'admin_api': 'http://localhost:8001'},
            'migration': {'enable_zero_downtime_orchestration': True}
        }
        self.orchestrator = ZeroDowntimeMigrationOrchestrator(self.temp_dir, self.config)
        
        self.apigee_config = {'api_name': 'test-api', 'health_check_url': '/health'}
        self.kong_config = {'services': [{'name': 'test-service'}], 'routes': [{'name': 'test-route'}]}
    
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._validate_prerequisites')
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._deploy_kong_to_production')
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._check_kong_health')
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._collect_api_metrics')
    def test_successful_migration_orchestration(self, mock_metrics, mock_health, mock_deploy, mock_prereqs):
        """Test successful zero-downtime migration orchestration"""
        # Mock successful responses
        mock_prereqs.return_value = True
        mock_deploy.return_value = {'success': True}
        mock_health.return_value = {'healthy': True}
        mock_metrics.return_value = {'error_rate': 0.01, 'avg_latency': 100}
        
        # Mock other methods
        with patch.multiple(self.orchestrator,
                          _validate_kong_configuration=Mock(return_value={'valid': True, 'errors': []}),
                          _test_kong_staging_deployment=Mock(return_value={'success': True}),
                          _setup_traffic_routing=Mock(return_value={'success': True}),
                          _configure_shadow_traffic=Mock(return_value={'success': True}),
                          _monitor_shadow_traffic=Mock(return_value={'healthy': True}),
                          _configure_live_traffic_cutover=Mock(return_value={'success': True}),
                          _monitor_live_traffic=Mock(return_value={'healthy': True}),
                          _create_configuration_backup=Mock(),
                          _cleanup_shadow_traffic_config=Mock(return_value={'success': True})):
            
            result = self.orchestrator.orchestrate_zero_downtime_migration(self.apigee_config, self.kong_config)
            
            self.assertEqual(result['status'], 'COMPLETED')
            self.assertEqual(result['traffic_distribution']['kong'], 100)
            self.assertEqual(result['traffic_distribution']['apigee'], 0)
            self.assertEqual(len(result['phases_completed']), 7)  # All phases completed
    
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._validate_prerequisites')
    def test_failed_prerequisites(self, mock_prereqs):
        """Test migration failure due to failed prerequisites"""
        mock_prereqs.return_value = False
        
        result = self.orchestrator.orchestrate_zero_downtime_migration(self.apigee_config, self.kong_config)
        
        self.assertEqual(result['status'], 'FAILED')
        self.assertGreater(len(result['errors']), 0)
    
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._validate_prerequisites')
    @patch('scripts.utils.zero_downtime_migration_orchestrator.ZeroDowntimeMigrationOrchestrator._collect_api_metrics')
    def test_rollback_on_high_error_rate(self, mock_metrics, mock_prereqs):
        """Test rollback when high error rate is detected"""
        mock_prereqs.return_value = True
        mock_metrics.return_value = {'error_rate': 0.10, 'avg_latency': 100}  # 10% error rate
        
        with patch.multiple(self.orchestrator,
                          _validate_kong_configuration=Mock(return_value={'valid': True, 'errors': []}),
                          _test_kong_staging_deployment=Mock(return_value={'success': True}),
                          _deploy_kong_to_production=Mock(return_value={'success': True}),
                          _check_kong_health=Mock(return_value={'healthy': True}),
                          _setup_traffic_routing=Mock(return_value={'success': True}),
                          _configure_shadow_traffic=Mock(return_value={'success': True}),
                          _monitor_shadow_traffic=Mock(return_value={'healthy': True}),
                          _configure_live_traffic_cutover=Mock(return_value={'success': True}),
                          _monitor_live_traffic=Mock(return_value={'healthy': False, 'issues': ['High error rate']}),
                          _create_configuration_backup=Mock(),
                          _execute_rollback=Mock()):
            
            result = self.orchestrator.orchestrate_zero_downtime_migration(self.apigee_config, self.kong_config)
            
            self.assertEqual(result['status'], 'FAILED')
            # Rollback should have been called
            self.orchestrator._execute_rollback.assert_called()

class TestZeroImpactMigrationIntegration(unittest.TestCase):
    """Integration tests for the complete zero-impact migration workflow"""
    
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        
        # Create mock configuration
        self.config = {
            'migration': {
                'enable_consumer_impact_validation': True,
                'enable_contract_preservation': True,
                'enable_zero_downtime_orchestration': False,  # Disable for testing
                'max_acceptable_consumer_impact': 'LOW'
            },
            'kong': {'admin_api': 'http://localhost:8001'}
        }
        
        # Create config file
        config_dir = self.temp_dir / "configs"
        config_dir.mkdir()
        with open(config_dir / "config.json", 'w') as f:
            json.dump(self.config, f)
        
        # Mock the start_zero_impact module
        sys.path.insert(0, str(self.temp_dir))
    
    def test_comprehensive_migration_workflow(self):
        """Test the complete migration workflow"""
        # This would be a comprehensive integration test
        # For now, we'll test the key components work together
        
        apigee_data = {
            'api_name': 'integration-test-api',
            'policies': [
                {'name': 'auth', 'policyType': 'VerifyAPIKey'},
                {'name': 'rate-limit', 'policyType': 'Quota', 'config': {'count': 1000}}
            ],
            'proxy_endpoints': [{
                'base_path': '/api/v1',
                'flows': [{'name': 'test-flow', 'condition': 'request.verb = "GET"'}]
            }],
            'paths': ['/api/v1/test'],
            'methods': ['GET', 'POST']
        }
        
        # Test consumer impact validation
        validator = ConsumerImpactValidator()
        
        # Generate basic Kong config
        kong_config = {
            'routes': [{'paths': ['/api/v1/test'], 'methods': ['GET', 'POST']}],
            'plugins': [
                {'name': 'key-auth'},
                {'name': 'rate-limiting', 'config': {'minute': 1000}}
            ]
        }
        
        # Validate consumer impact
        impact_result = validator.validate_migration_impact(apigee_data, kong_config)
        
        # Should have minimal impact
        self.assertIn(impact_result['consumer_impact'], ['NONE', 'LOW'])
        
        # Test contract preservation
        engine = APIContractPreservingEngine(self.temp_dir, self.config)
        preserved_config = engine.preserve_api_contract(apigee_data, kong_config)
        
        # Should have preserved all critical elements
        self.assertGreater(len(preserved_config.get('plugins', [])), 0)
        self.assertGreater(len(preserved_config.get('routes', [])), 0)

class TestConsumerImpactScenarios(unittest.TestCase):
    """Test various consumer impact scenarios"""
    
    def setUp(self):
        self.validator = ConsumerImpactValidator()
    
    def test_breaking_change_path_removal(self):
        """Test breaking change when API path is removed"""
        apigee_config = {
            'proxy_endpoints': [{
                'base_path': '/api/v1',
                'flows': [{
                    'name': 'users-flow',
                    'condition': 'proxy.pathsuffix MatchesPath "/users"'
                }]
            }],
            'policies': []
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1/different'], 'methods': ['GET']}],
            'plugins': []
        }
        
        result = self.validator.validate_migration_impact(apigee_config, kong_config)
        
        self.assertEqual(result['consumer_impact'], 'HIGH')
        self.assertFalse(result['contract_preserved'])
        self.assertGreater(len(result['breaking_changes']), 0)
    
    def test_auth_method_change(self):
        """Test impact when authentication method changes"""
        apigee_config = {
            'proxy_endpoints': [{'base_path': '/api/v1', 'flows': []}],
            'policies': [{'policyType': 'VerifyAPIKey', 'name': 'api-key-auth'}]
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1'], 'methods': ['GET']}],
            'plugins': [{'name': 'basic-auth'}]  # Different auth method
        }
        
        result = self.validator.validate_migration_impact(apigee_config, kong_config)
        
        self.assertEqual(result['consumer_impact'], 'HIGH')
        self.assertGreater(len(result['breaking_changes']), 0)
    
    def test_rate_limit_increase(self):
        """Test impact when rate limits are more restrictive"""
        apigee_config = {
            'proxy_endpoints': [{'base_path': '/api/v1', 'flows': []}],
            'policies': [{'policyType': 'Quota', 'name': 'rate-limit', 'config': {'count': 1000}}]
        }
        
        kong_config = {
            'routes': [{'paths': ['/api/v1'], 'methods': ['GET']}],
            'plugins': [{'name': 'rate-limiting', 'config': {'minute': 500}}]  # More restrictive
        }
        
        result = self.validator.validate_migration_impact(apigee_config, kong_config)
        
        # Should be a warning, not breaking change
        self.assertIn(result['consumer_impact'], ['LOW', 'NONE'])
        self.assertGreater(len(result['warnings']), 0)

def run_tests():
    """Run all tests"""
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test cases
    test_classes = [
        TestConsumerImpactValidator,
        TestAPIContractPreservingEngine,
        TestZeroDowntimeMigrationOrchestrator,
        TestZeroImpactMigrationIntegration,
        TestConsumerImpactScenarios
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Print summary
    print(f"\n{'='*60}")
    print("ZERO-IMPACT MIGRATION TEST SUMMARY")
    print(f"{'='*60}")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print(f"\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback.split('AssertionError: ')[-1].split('\\n')[0]}")
    
    if result.errors:
        print(f"\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback.split('\\n')[-2]}")
    
    print(f"{'='*60}")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)