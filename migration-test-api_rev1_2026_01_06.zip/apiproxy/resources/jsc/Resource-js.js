
// Read incoming request values
var userId = context.getVariable("request.queryparam.userId");
var agent  = context.getVariable("request.header.User-Agent");

// Set new context variables
context.setVariable("demo.userId", userId);
context.setVariable("demo.agent", agent);

// Add custom logic
if (!userId) {
    context.setVariable("demo.error", "Missing userId");
} else {
    context.setVariable("demo.message", "User processed successfully");
}

// Example: build a dynamic backend URL
var base   = "https://backend.example.com/users/";
var target = base + userId;

context.setVariable("target.url", target);
